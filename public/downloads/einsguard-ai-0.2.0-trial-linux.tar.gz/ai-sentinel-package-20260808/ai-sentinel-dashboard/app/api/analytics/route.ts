import {NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/db';
import {requireRole} from '@/lib/auth';

export async function GET(req:NextRequest) {
  const auth=await requireRole(req,['admin','security','auditor','viewer']);if(auth.response)return auth.response;const tenantId=auth.user!.tenantId;
  const [summary, byUser, byTool, byModel, daily] = await Promise.all([
    pool.query(`SELECT COALESCE(SUM(input_tokens),0)::bigint AS input_tokens,
      COALESCE(SUM(output_tokens),0)::bigint AS output_tokens,
      COALESCE(SUM(cost_usd),0)::numeric AS cost_usd,
      COUNT(*)::int AS executions FROM ai_usage WHERE logged_at > NOW()-INTERVAL '30 days' AND tenant_id=$1`,[tenantId]),
    pool.query(`SELECT username, COUNT(*)::int executions, COALESCE(SUM(input_tokens+output_tokens),0)::bigint tokens,
      COALESCE(SUM(cost_usd),0)::numeric cost_usd FROM ai_usage WHERE logged_at > NOW()-INTERVAL '30 days' AND tenant_id=$1
      GROUP BY username ORDER BY cost_usd DESC, executions DESC LIMIT 20`,[tenantId]),
    pool.query(`SELECT tool, COUNT(*)::int executions, COALESCE(SUM(input_tokens+output_tokens),0)::bigint tokens,
      COALESCE(SUM(cost_usd),0)::numeric cost_usd FROM ai_usage WHERE logged_at > NOW()-INTERVAL '30 days' AND tenant_id=$1
      GROUP BY tool ORDER BY cost_usd DESC, executions DESC`,[tenantId]),
    pool.query(`SELECT COALESCE(model,'미수집') model, COUNT(*)::int executions,
      COALESCE(SUM(input_tokens+output_tokens),0)::bigint tokens, COALESCE(SUM(cost_usd),0)::numeric cost_usd
      FROM ai_usage WHERE logged_at > NOW()-INTERVAL '30 days' AND tenant_id=$1 GROUP BY model ORDER BY cost_usd DESC, executions DESC`,[tenantId]),
    pool.query(`SELECT DATE(logged_at) AS usage_day, COUNT(*)::int executions,
      COALESCE(SUM(input_tokens+output_tokens),0)::bigint tokens, COALESCE(SUM(cost_usd),0)::numeric cost_usd
      FROM ai_usage WHERE logged_at > NOW()-INTERVAL '30 days' AND tenant_id=$1 GROUP BY DATE(logged_at) ORDER BY DATE(logged_at)`,[tenantId]),
  ]);
  return NextResponse.json({ summary: summary.rows[0], byUser: byUser.rows, byTool: byTool.rows, byModel: byModel.rows, daily: daily.rows });
}
