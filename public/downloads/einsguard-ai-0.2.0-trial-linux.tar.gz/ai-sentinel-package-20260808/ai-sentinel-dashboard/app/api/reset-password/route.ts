import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import nodemailer from 'nodemailer';
import fs from 'node:fs';
import pool from '@/lib/db';

const SMTP = {
  host: process.env.SMTP_HOST || '',
  port: Number(process.env.SMTP_PORT || 465),
  secure: (process.env.SMTP_SECURE || 'true') === 'true',
  auth: { user: process.env.SMTP_USER || '', pass: process.env.SMTP_PASS || (()=>{try{return fs.readFileSync(/* turbopackIgnore: true */ (process.env.SMTP_PASS_FILE||'/home/ai/.config/ai-sentinel/smtp.pass'),'utf8').trim();}catch{return '';}})() },
};

const BASE_URL = process.env.BASE_URL || 'http://localhost:3100';

// POST — 재설정 링크 요청
export async function POST(req: NextRequest) {
  const { username } = await req.json();

  const { rows } = await pool.query(
    'SELECT email,tenant_id FROM ai_admin_users WHERE username = $1',
    [username]
  );

  // 존재 여부 노출 방지 — 항상 ok 반환
  if (rows.length === 0 || !rows[0].email) {
    return NextResponse.json({ ok: true });
  }

  const token = crypto.randomBytes(32).toString('hex');
  const expiresAt = new Date(Date.now() + 30 * 60 * 1000); // 30분

  await pool.query(
    `INSERT INTO ai_password_resets (username, token, expires_at,tenant_id)
     VALUES ($1, $2, $3,$4)`,
    [username, token, expiresAt,rows[0].tenant_id]
  );

  const resetUrl = `${BASE_URL}/reset-password?token=${token}`;
  if (!SMTP.host || !SMTP.auth.user || !SMTP.auth.pass) return NextResponse.json({ ok: true });
  const mailer = nodemailer.createTransport(SMTP);

  await mailer.sendMail({
    from: `EINSTECH AI Sentinel <${SMTP.auth.user}>`,
    to: rows[0].email,
    subject: '[AI Sentinel] 비밀번호 재설정',
    html: `
      <div style="font-family:sans-serif;max-width:480px;margin:0 auto">
        <div style="background:#0a0f1e;padding:20px;border-radius:8px 8px 0 0">
          <h2 style="color:#16c79a;margin:0">AI Sentinel 비밀번호 재설정</h2>
        </div>
        <div style="background:#f8f9fa;padding:20px;border:1px solid #dee2e6;border-radius:0 0 8px 8px">
          <p>아래 버튼을 클릭하여 비밀번호를 재설정하세요.</p>
          <p>링크는 <strong>30분</strong> 동안만 유효합니다.</p>
          <a href="${resetUrl}" style="display:inline-block;background:#16c79a;color:#fff;padding:12px 24px;border-radius:6px;text-decoration:none;font-weight:bold;margin:16px 0">
            비밀번호 재설정
          </a>
          <p style="color:#666;font-size:12px">버튼이 작동하지 않으면: ${resetUrl}</p>
        </div>
      </div>
    `,
  });

  return NextResponse.json({ ok: true });
}

// PATCH — 새 비밀번호 설정
export async function PATCH(req: NextRequest) {
  const { token, newPassword } = await req.json();

  const { rows } = await pool.query(
    `SELECT username,tenant_id FROM ai_password_resets
     WHERE token = $1 AND used = FALSE AND expires_at > NOW()`,
    [token]
  );

  if (rows.length === 0) {
    return NextResponse.json({ error: '링크가 만료되었거나 유효하지 않습니다' }, { status: 400 });
  }

  const hash = await bcrypt.hash(newPassword, 10);
  await pool.query('UPDATE ai_admin_users SET password_hash = $1 WHERE username = $2 AND tenant_id=$3', [hash, rows[0].username,rows[0].tenant_id]);
  await pool.query('UPDATE ai_password_resets SET used = TRUE WHERE token = $1', [token]);

  return NextResponse.json({ ok: true });
}
