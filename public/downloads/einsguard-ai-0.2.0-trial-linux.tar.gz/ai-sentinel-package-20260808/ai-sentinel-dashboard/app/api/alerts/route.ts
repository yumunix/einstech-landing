import {NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/db';
import {requireRole} from '@/lib/auth';
import {requireActiveLicense} from '@/lib/license';

export async function GET(req:NextRequest) {
  const auth=await requireRole(req,['admin','security','auditor','viewer']);if(auth.response)return auth.response;const tenantId=auth.user!.tenantId;
  const [alerts, summary] = await Promise.all([
    pool.query(`
      SELECT id, created_at, session_id, hostname, username, tool, alert_type,
             severity, detail, resolved, risk_score, risk_reason, auto_action
      FROM ai_alerts WHERE tenant_id=$1 ORDER BY created_at DESC LIMIT 50
    `,[tenantId]),
    pool.query(`
      SELECT severity, COUNT(*) as count
      FROM ai_alerts WHERE resolved = FALSE AND tenant_id=$1
      GROUP BY severity
    `,[tenantId]),
  ]);

  return NextResponse.json({ alerts: alerts.rows, summary: summary.rows });
}

export async function PATCH(req: NextRequest) {
  const auth=await requireRole(req,['admin','security']);if(auth.response)return auth.response;
  const licenseCheck=await requireActiveLicense(auth.user!.tenantId);if(licenseCheck.response)return licenseCheck.response;
  const { id } = await req.json();
  await pool.query(`UPDATE ai_alerts SET resolved=TRUE WHERE id=$1 AND tenant_id=$2`, [id,auth.user!.tenantId]);
  return NextResponse.json({ ok: true });
}
