import { NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/db';
import { verifyAgentKey } from '@/lib/agent-auth';
import { requireActiveLicense } from '@/lib/license';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const action = searchParams.get('action') || req.nextUrl.pathname.split('/').pop();
  const hostname = searchParams.get('hostname') || '';
  const username = searchParams.get('username') || '';
  const tool = searchParams.get('tool') || '';
  const sessionId = searchParams.get('session_id') || '';
  const token = searchParams.get('token') || '';
  const agentAuth = await verifyAgentKey(req.headers.get('x-ai-sentinel-key'));
  if (!agentAuth.configured || !agentAuth.valid || !agentAuth.tenantId) return NextResponse.json({ error: 'Unauthorized agent' }, { status: 401 });
  const tenantId = agentAuth.tenantId;
  const licenseCheck=await requireActiveLicense(tenantId); if(licenseCheck.response)return licenseCheck.response;

  // 차단 확인
  if (searchParams.has('check-block') || req.url.includes('check-block')) {
    const { rows } = await pool.query(
      `SELECT id FROM ai_blocks WHERE enabled = TRUE AND tenant_id=$4
       AND (hostname = '*' OR hostname = $1)
       AND (username = '*' OR username = $2)
       AND (tool = '*' OR tool = $3)
       LIMIT 1`,
      [hostname, username, tool, tenantId]
    );
    return NextResponse.json(rows.length > 0 ? 'true' : 'false');
  }

  // 정책 확인
  if (searchParams.has('check-policy') || req.url.includes('check-policy')) {
    const hour = new Date().getHours();
    const { rows } = await pool.query(
      `SELECT allow_start, allow_end, max_per_hour, template_key FROM ai_policies WHERE enabled = TRUE AND tenant_id=$4
       AND (hostname = '*' OR hostname = $1)
       AND (username = '*' OR username = $2)
       AND (tool = '*' OR tool = $3) LIMIT 1`,
      [hostname, username, tool, tenantId]
    );
    if (rows.length > 0) {
      const p = rows[0];
      if (p.template_key === 'blocked') return NextResponse.json('AI 사용 금지 정책 적용');
      if (hour < p.allow_start || hour > p.allow_end) {
        return NextResponse.json(`허용 시간 외 사용 (허용: ${p.allow_start}시~${p.allow_end}시)`);
      }
      const { rows: cnt } = await pool.query(
        `SELECT COUNT(*) as c FROM ai_usage WHERE hostname=$1 AND username=$2 AND tenant_id=$3
         AND logged_at > NOW() - INTERVAL '1 hour'`,
        [hostname, username, tenantId]
      );
      if (parseInt(cnt[0].c) >= p.max_per_hour) {
        return NextResponse.json(`시간당 최대 사용 횟수 초과 (최대: ${p.max_per_hour}회)`);
      }
    }
    return NextResponse.json('ok');
  }

  // 승인 필요 여부
  if (searchParams.has('check-approval') || req.url.includes('check-approval')) {
    const { rows } = await pool.query(
      `SELECT id FROM ai_policies WHERE enabled = TRUE AND max_per_hour = 0 AND tenant_id=$4
       AND COALESCE(template_key,'') <> 'blocked'
       AND (hostname = '*' OR hostname = $1)
       AND (username = '*' OR username = $2)
       AND (tool = '*' OR tool = $3) LIMIT 1`,
      [hostname, username, tool, tenantId]
    );
    return NextResponse.json(rows.length > 0 ? 'true' : 'false');
  }

  // 승인 상태 확인
  if (searchParams.has('approval-status') || req.url.includes('approval-status')) {
    const { rows } = await pool.query(
      `SELECT status FROM ai_approvals WHERE token = $1 AND tenant_id=$2`, [token, tenantId]
    );
    return NextResponse.json(rows[0]?.status || 'pending');
  }

  // 세션 제어 명령 확인 (기존 check-kill도 하위 호환)
  if (searchParams.has('check-control') || req.url.includes('check-control') || searchParams.has('check-kill') || req.url.includes('check-kill')) {
    const { rows } = await pool.query(
      `SELECT id, command FROM ai_commands
       WHERE session_id = $1 AND tenant_id=$2 AND command IN ('pause', 'resume', 'kill') AND status = 'pending'
       ORDER BY CASE command WHEN 'kill' THEN 1 WHEN 'pause' THEN 2 ELSE 3 END, created_at
       LIMIT 1`,
      [sessionId, tenantId]
    );
    if (rows.length > 0) {
      await pool.query(`UPDATE ai_commands SET status='executed', executed_at=NOW() WHERE id=$1`, [rows[0].id]);
      return NextResponse.json(rows[0].command);
    }
    return NextResponse.json('ok');
  }

  return NextResponse.json({ error: 'unknown action' }, { status: 400 });
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const action = req.nextUrl.searchParams.get('action') || body.action || '';
  const agentAuth = await verifyAgentKey(req.headers.get('x-ai-sentinel-key'));
  if (!agentAuth.configured || !agentAuth.valid || !agentAuth.tenantId) return NextResponse.json({ error: 'Unauthorized agent' }, { status: 401 });
  const tenantId = agentAuth.tenantId;
  const licenseCheck=await requireActiveLicense(tenantId); if(licenseCheck.response)return licenseCheck.response;

  // 승인 요청 등록
  if (action === 'request-approval') {
    await pool.query(
      `INSERT INTO ai_approvals (session_id, hostname, username, tool, work_dir, args, token, tenant_id)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
      [body.session_id, body.hostname, body.username, body.tool, body.work_dir, body.args, body.token, tenantId]
    );
    return NextResponse.json({ ok: true });
  }

  // PID 등록
  if (action === 'register-pid') {
    await pool.query(
      `INSERT INTO ai_commands (session_id, hostname, username, tool, pid, command, status, tenant_id)
       VALUES ($1,$2,$3,$4,$5,'registered','active',$6)
       ON CONFLICT DO NOTHING`,
      [body.session_id, body.hostname, body.username, body.tool, body.pid, tenantId]
    );
    return NextResponse.json({ ok: true });
  }

  // CLI hook/수집기가 제공하는 실제 토큰·비용 텔레메트리
  if (action === 'usage-report') {
    const inputTokens = Math.max(0, Number(body.input_tokens) || 0);
    const outputTokens = Math.max(0, Number(body.output_tokens) || 0);
    const costUsd = Math.max(0, Number(body.cost_usd) || 0);
    await pool.query(
      `UPDATE ai_usage SET model=COALESCE($1,model), input_tokens=$2, output_tokens=$3, cost_usd=$4
       WHERE id=(SELECT id FROM ai_usage WHERE hostname=$5 AND username=$6 AND tool=$7 AND tenant_id=$8 ORDER BY logged_at DESC LIMIT 1)`,
      [body.model || null, inputTokens, outputTokens, costUsd, body.hostname, body.username, body.tool, tenantId]
    );
    return NextResponse.json({ ok: true });
  }

  return NextResponse.json({ error: 'unknown action' }, { status: 400 });
}
