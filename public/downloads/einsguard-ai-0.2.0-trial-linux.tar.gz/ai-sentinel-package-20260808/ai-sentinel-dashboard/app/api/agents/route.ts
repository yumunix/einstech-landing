import { NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/db';
import { requireRole } from '@/lib/auth';
import { verifyAgentKey } from '@/lib/agent-auth';
import { requireActiveLicense } from '@/lib/license';

const KNOWN_TOOLS = ['claude','codex','cursor','copilot','gemini','aider','continue','windsurf','ollama'];

export async function GET(req:NextRequest) {
  const auth=await requireRole(req,['admin','security','auditor','viewer']); if(auth.response)return auth.response;
  const tenantId=auth.user!.tenantId;
  const [agents, events, summary] = await Promise.all([
    pool.query(`SELECT hostname,os,os_version,arch,agent_version,username,installed_tools,running_tools,
      approved_tools,last_ip,first_seen,last_seen FROM ai_agents WHERE tenant_id=$1 ORDER BY last_seen DESC`,[tenantId]),
    pool.query(`SELECT * FROM ai_shadow_events WHERE tenant_id=$1 ORDER BY created_at DESC LIMIT 100`,[tenantId]),
    pool.query(`SELECT COUNT(*)::int agents,
      COUNT(*) FILTER (WHERE last_seen > NOW()-INTERVAL '5 minutes')::int online,
      COUNT(*) FILTER (WHERE last_seen <= NOW()-INTERVAL '5 minutes')::int offline
      FROM ai_agents WHERE tenant_id=$1`,[tenantId]),
  ]);
  return NextResponse.json({ agents: agents.rows, events: events.rows, summary: summary.rows[0], knownTools: KNOWN_TOOLS });
}

export async function POST(req: NextRequest) {
  const action = req.nextUrl.searchParams.get('action') || '';
  if (action === 'inventory-report') {
    const agentAuth = await verifyAgentKey(req.headers.get('x-ai-sentinel-key'));
    if (!agentAuth.configured) return NextResponse.json({ error: 'Agent authentication is not configured' }, { status: 503 });
    if (!agentAuth.valid) {
      return NextResponse.json({ error: 'Unauthorized agent' }, { status: 401 });
    }
    const tenantId=agentAuth.tenantId!;
    const licenseCheck=await requireActiveLicense(tenantId); if(licenseCheck.response)return licenseCheck.response;
    const body = await req.json();
    const installed = Array.isArray(body.installed_tools) ? body.installed_tools.filter((x: unknown) => typeof x === 'string') : [];
    const running = Array.isArray(body.running_tools) ? body.running_tools.filter((x: unknown) => typeof x === 'string') : [];
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const existing = await client.query('SELECT approved_tools FROM ai_agents WHERE tenant_id=$1 AND hostname=$2', [tenantId,body.hostname]);
      if (!existing.rows.length) {
        const count=await client.query('SELECT COUNT(*)::int count FROM ai_agents WHERE tenant_id=$1',[tenantId]);
        if(Number(count.rows[0].count)>=licenseCheck.license.agent_limit) {
          await client.query('ROLLBACK');
          return NextResponse.json({error:'요금제의 관리 대상 수를 초과했습니다.',code:'AGENT_LIMIT_REACHED',license:licenseCheck.license},{status:402});
        }
      }
      const approved = existing.rows[0]?.approved_tools || ['claude','codex'];
      await client.query(`INSERT INTO ai_agents(hostname,os,os_version,arch,agent_version,username,installed_tools,running_tools,last_ip,tenant_id)
        VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
        ON CONFLICT(tenant_id,hostname) DO UPDATE SET os=EXCLUDED.os,os_version=EXCLUDED.os_version,arch=EXCLUDED.arch,
        agent_version=EXCLUDED.agent_version,username=EXCLUDED.username,installed_tools=EXCLUDED.installed_tools,
        running_tools=EXCLUDED.running_tools,last_ip=EXCLUDED.last_ip,last_seen=NOW()`,
        [body.hostname,body.os||'unknown',body.os_version||'',body.arch||'',body.agent_version||'unknown',body.username||'',JSON.stringify(installed),JSON.stringify(running),req.headers.get('x-forwarded-for')?.split(',')[0]||null,tenantId]);
      for (const tool of running.filter((tool: string) => !approved.includes(tool))) {
        await client.query(`INSERT INTO ai_shadow_events(hostname,username,tool,event_type,detail,tenant_id)
          SELECT $1::varchar,$2::varchar,$3::varchar,'UNAPPROVED_AI_RUNNING',$4::text,$5 WHERE NOT EXISTS(
            SELECT 1 FROM ai_shadow_events WHERE hostname=$1::varchar AND tool=$3::varchar AND tenant_id=$5 AND resolved=false AND created_at>NOW()-INTERVAL '1 hour')`,
          [body.hostname,body.username||'',tool,`승인되지 않은 AI 도구 실행 감지: ${tool}`,tenantId]);
      }
      await client.query('COMMIT');
      return NextResponse.json({ ok:true, approved_tools:approved });
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally { client.release(); }
  }
  const auth = await requireRole(req,['admin','security']);
  if (auth.response) return auth.response;
  const licenseCheck=await requireActiveLicense(auth.user!.tenantId); if(licenseCheck.response)return licenseCheck.response;
  const body = await req.json();
  if (body.action === 'set_approved_tools') {
    const tools = Array.isArray(body.tools) ? body.tools.filter((x: unknown) => typeof x === 'string') : [];
    await pool.query('UPDATE ai_agents SET approved_tools=$1 WHERE hostname=$2 AND tenant_id=$3',[JSON.stringify(tools),body.hostname,auth.user!.tenantId]);
    return NextResponse.json({ok:true});
  }
  if (body.action === 'resolve_event') {
    await pool.query('UPDATE ai_shadow_events SET resolved=true,resolved_at=NOW(),resolved_by=$1 WHERE id=$2 AND tenant_id=$3',[auth.user?.username,body.id,auth.user!.tenantId]);
    return NextResponse.json({ok:true});
  }
  return NextResponse.json({error:'unknown action'},{status:400});
}
