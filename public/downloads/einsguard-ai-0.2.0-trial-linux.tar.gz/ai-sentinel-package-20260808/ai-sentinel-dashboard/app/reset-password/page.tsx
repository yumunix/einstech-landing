'use client';

import { useState, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';

function ResetForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const token = searchParams.get('token');

  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [msg, setMsg] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirm) { setMsg('❌ 비밀번호가 일치하지 않습니다'); return; }
    setLoading(true);
    const r = await fetch('/api/reset-password', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token, newPassword: password }),
    });
    const d = await r.json();
    if (d.ok) {
      setMsg('✅ 비밀번호가 변경되었습니다. 로그인 페이지로 이동합니다...');
      setTimeout(() => router.push('/login'), 2000);
    } else {
      setMsg('❌ ' + d.error);
    }
    setLoading(false);
  };

  return (
    <form onSubmit={handleSubmit} className="bg-slate-900 border border-slate-800 rounded-lg p-6 space-y-4">
      <div>
        <label className="text-xs text-slate-400 block mb-1">새 비밀번호</label>
        <input type="password" value={password} onChange={e => setPassword(e.target.value)}
          className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-emerald-500" />
      </div>
      <div>
        <label className="text-xs text-slate-400 block mb-1">비밀번호 확인</label>
        <input type="password" value={confirm} onChange={e => setConfirm(e.target.value)}
          className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-emerald-500" />
      </div>
      {msg && <div className="text-xs">{msg}</div>}
      <button type="submit" disabled={loading}
        className="w-full bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-400 rounded py-2 text-sm transition-colors disabled:opacity-50">
        {loading ? '처리 중...' : '비밀번호 변경'}
      </button>
    </form>
  );
}

export default function ResetPasswordPage() {
  return (
    <div className="min-h-screen bg-[#0a0f1e] flex items-center justify-center">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <div className="text-emerald-400 text-xs tracking-widest mb-1">EINSTECH</div>
          <div className="text-2xl font-bold text-white font-mono">AI SENTINEL</div>
          <div className="text-slate-500 text-xs mt-1">비밀번호 재설정</div>
        </div>
        <Suspense>
          <ResetForm />
        </Suspense>
      </div>
    </div>
  );
}
