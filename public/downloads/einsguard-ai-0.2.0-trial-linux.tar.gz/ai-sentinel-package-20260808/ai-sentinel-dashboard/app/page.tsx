'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, Legend } from 'recharts';
import { formatDistanceToNow, format } from 'date-fns';
import { ko } from 'date-fns/locale';

const TOOL_COLOR: Record<string, string> = { claude: '#16c79a', codex: '#6366f1' };
const SEV_COLOR: Record<string, string> = { HIGH: '#ef4444', MED: '#f59e0b', LOW: '#3b82f6' };

type Tab = 'overview' | 'analytics' | 'agents' | 'reports' | 'sessions' | 'alerts' | 'control' | 'governance' | 'license';
type ControlTab = 'blocks' | 'policies' | 'approvals' | 'active';

export default function Dashboard() {
  const [tab, setTab] = useState<Tab>('overview');
  const [controlTab, setControlTab] = useState<ControlTab>('blocks');
  const [stats, setStats] = useState<any>(null);
  const [sessions, setSessions] = useState<any>(null);
  const [alerts, setAlerts] = useState<any>(null);
  const [controls, setControls] = useState<any>(null);
  const [analytics, setAnalytics] = useState<any>(null);
  const [governance, setGovernance] = useState<any>(null);
  const [agents, setAgents] = useState<any>(null);
  const [reports, setReports] = useState<any>(null);
  const [tenants, setTenants] = useState<any>(null);
  const [license, setLicense] = useState<any>(null);
  const [licenseKey, setLicenseKey] = useState('');
  const [licenseMsg, setLicenseMsg] = useState('');
  const [tenantForm, setTenantForm] = useState({name:'',code:'',admin_username:'',admin_email:'',admin_password:''});
  const [newAgentKey, setNewAgentKey] = useState('');
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [lastUpdated, setLastUpdated] = useState(new Date());
  const [formMsg, setFormMsg] = useState('');
  const [showSettings, setShowSettings] = useState(false);
  const [settingsForm, setSettingsForm] = useState({ currentPassword: '', newUsername: '', newPassword: '', confirmPassword: '' });
  const [settingsMsg, setSettingsMsg] = useState('');
  const router = useRouter();

  const logout = async () => {
    await fetch('/api/auth', { method: 'DELETE' });
    router.push('/login');
  };

  const saveSettings = async () => {
    setSettingsMsg('');
    if (settingsForm.newPassword && settingsForm.newPassword !== settingsForm.confirmPassword) {
      setSettingsMsg('❌ 새 비밀번호가 일치하지 않습니다');
      return;
    }
    const r = await fetch('/api/auth', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        currentPassword: settingsForm.currentPassword,
        newUsername: settingsForm.newUsername || undefined,
        newPassword: settingsForm.newPassword || undefined,
      }),
    });
    const d = await r.json();
    if (d.ok) {
      setSettingsMsg('✅ 변경 완료');
      setSettingsForm({ currentPassword: '', newUsername: '', newPassword: '', confirmPassword: '' });
    } else {
      setSettingsMsg('❌ ' + d.error);
    }
  };

  const [blockForm, setBlockForm] = useState({ hostname: '', username: '', tool: 'claude', reason: '' });
  const [policyForm, setPolicyForm] = useState({ hostname: '', username: '', allow_start: 9, allow_end: 18, max_per_hour: 10, template_key: '', tool: '*' });

  const fetchAll = async () => {
    const [s, se, al, an, ag, rep, gov, me, ten, lic] = await Promise.all([
      fetch('/api/stats').then(r => r.json()),
      fetch('/api/sessions').then(r => r.json()),
      fetch('/api/alerts').then(r => r.json()),
      fetch('/api/analytics').then(r => r.json()),
      fetch('/api/agents').then(r => r.json()),
      fetch('/api/reports').then(r => r.json()),
      fetch('/api/governance').then(r => r.json()),
      fetch('/api/auth').then(r => r.json()),
      fetch('/api/tenants').then(r => r.json()),
      fetch('/api/license').then(r => r.json()),
    ]);
    setStats(s); setSessions(se); setAlerts(al); setAnalytics(an); setAgents(ag); setReports(rep); setGovernance(gov); setCurrentUser(me); setTenants(ten); setLicense(lic.license);
    setLastUpdated(new Date());
  };

  const fetchControls = async () => {
    const c = await fetch('/api/control').then(r => r.json());
    setControls(c);
  };

  useEffect(() => {
    fetchAll();
    fetchControls();
    const t = setInterval(() => { fetchAll(); fetchControls(); }, 15000);
    return () => clearInterval(t);
  }, []);

  const resolveAlert = async (id: number) => {
    await fetch('/api/alerts', { method: 'PATCH', body: JSON.stringify({ id }), headers: { 'Content-Type': 'application/json' } });
    fetchAll();
  };

  const addBlock = async () => {
    setFormMsg('');
    const r = await fetch('/api/control', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'add_block', ...blockForm }),
    });
    const d = await r.json();
    setFormMsg(d.ok ? '✅ 차단 등록 완료' : '❌ 실패: ' + d.error);
    fetchControls();
  };

  const removeBlock = async (id: number) => {
    await fetch('/api/control', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'remove_block', id }) });
    fetchControls();
  };

  const addPolicy = async () => {
    setFormMsg('');
    const r = await fetch('/api/control', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'add_policy', ...policyForm }),
    });
    const d = await r.json();
    setFormMsg(d.ok ? '✅ 정책 등록 완료' : '❌ 실패: ' + d.error);
    fetchControls();
  };

  const selectTemplate = (key: string) => {
    const template = governance?.templates?.find((item: any) => item.template_key === key);
    if (!template) return;
    setPolicyForm(f => ({ ...f, template_key: key, allow_start: template.allow_start, allow_end: template.allow_end, max_per_hour: template.max_per_hour, tool: template.tool }));
  };

  const updateRole = async (id: number, role: string) => {
    const r = await fetch('/api/governance', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'update_role', id, role }) });
    const d = await r.json();
    setFormMsg(d.ok ? '✅ 역할 변경 완료' : '❌ 실패: ' + d.error);
    fetchAll();
  };

  const resolveShadowEvent = async (id: number) => {
    await fetch('/api/agents', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({action:'resolve_event',id}) });
    fetchAll();
  };

  const toggleApprovedTool = async (agent: any, tool: string) => {
    const current: string[] = agent.approved_tools || [];
    const tools = current.includes(tool) ? current.filter(item => item !== tool) : [...current, tool];
    await fetch('/api/agents', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({action:'set_approved_tools',hostname:agent.hostname,tools}) });
    fetchAll();
  };

  const saveWeeklyReport = async () => {
    const r=await fetch('/api/reports',{method:'POST'}); const d=await r.json();
    setFormMsg(d.ok?'✅ 주간 보고서 초안 저장 완료':'❌ 실패: '+d.error); fetchAll();
  };

  const createTenant = async () => {
    setNewAgentKey(''); const r=await fetch('/api/tenants',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(tenantForm)});const d=await r.json();
    if(d.ok){setFormMsg('✅ 고객사 생성 완료');setNewAgentKey(d.agent_key);setTenantForm({name:'',code:'',admin_username:'',admin_email:'',admin_password:''});fetchAll();}else setFormMsg('❌ 실패: '+d.error);
  };

  const activateLicense = async () => {
    setLicenseMsg('');
    const r=await fetch('/api/license',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key:licenseKey})});
    const d=await r.json();
    if(d.ok){setLicense(d.license);setLicenseKey('');setLicenseMsg('✅ 라이선스 인증 완료');fetchAll();}
    else setLicenseMsg('❌ '+(d.error||'인증 실패'));
  };

  const removePolicy = async (id: number) => {
    await fetch('/api/control', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'remove_policy', id }) });
    fetchControls();
  };

  const killSession = async (sessionId: string) => {
    const r = await fetch('/api/control', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'kill_session', session_id: sessionId }),
    });
    const d = await r.json();
    setFormMsg(d.ok ? '🛑 강제종료 명령 전송됨' : '❌ 실패: ' + d.error);
    fetchControls();
  };

  const toggleSession = async (sessionId: string, paused: boolean) => {
    const r = await fetch('/api/control', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: paused ? 'resume_session' : 'pause_session', session_id: sessionId }),
    });
    const d = await r.json();
    setFormMsg(d.ok ? (paused ? '▶️ 세션 재개 명령 전송됨' : '⏸️ 세션 일시정지 명령 전송됨') : '❌ 실패: ' + d.error);
    fetchControls();
  };

  const reviewApproval = async (id: number, approved: boolean) => {
    await fetch('/api/control', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'review_approval', id, approved }),
    });
    fetchControls();
  };

  const unresolvedCount = alerts?.alerts?.filter((a: any) => !a.resolved).length ?? 0;
  const highRiskAlerts = alerts?.alerts?.filter((a: any) => !a.resolved && a.severity === 'HIGH') ?? [];
  const pendingApprovals = controls?.approvals?.filter((a: any) => a.status === 'pending').length ?? 0;
  const activeSessionCount = controls?.activeSessions?.length ?? 0;
  const blockedTargetCount = controls?.blocks?.length ?? 0;

  const openControl = (next: ControlTab) => {
    setControlTab(next);
    setTab('control');
  };

  return (
    <div className="min-h-screen bg-[#0a0f1e] text-white font-mono">
      <div className="border-b border-slate-800 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-6">
          <div>
            <div className="text-emerald-400 text-[10px] tracking-widest">EINSTECH</div>
            <div className="text-lg font-bold">AI SENTINEL</div>
          </div>
          <div className="flex gap-1">
            {(['overview', 'analytics', 'agents', 'reports', 'sessions', 'alerts', 'control', 'governance', 'license'] as Tab[]).map(t => (
              <button key={t} onClick={() => setTab(t)}
                className={`px-4 py-1.5 text-xs rounded transition-colors relative ${tab === t ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`}>
                {t === 'overview' ? '개요' : t === 'analytics' ? '비용·분석' : t === 'agents' ? 'AI 자산' : t === 'reports' ? '보고서' : t === 'sessions' ? '세션 활동' : t === 'alerts' ? '보안 알림' : t === 'control' ? '에이전트 제어' : t === 'governance' ? '거버넌스' : '라이선스'}
                {t === 'alerts' && unresolvedCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[9px] rounded-full w-4 h-4 flex items-center justify-center">{unresolvedCount}</span>
                )}
                {t === 'control' && pendingApprovals > 0 && (
                  <span className="absolute -top-1 -right-1 bg-yellow-500 text-white text-[9px] rounded-full w-4 h-4 flex items-center justify-center">{pendingApprovals}</span>
                )}
              </button>
            ))}
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-xs text-slate-500">
            최종 갱신: {format(lastUpdated, 'HH:mm:ss')}
            <span className="ml-3 text-emerald-400 animate-pulse">● LIVE</span>
          </div>
          <button onClick={() => setShowSettings(true)} className="text-xs text-slate-500 hover:text-white transition-colors">⚙ 설정</button>
          <span className="text-[10px] text-slate-600">{currentUser?.role || ''}</span>
          <span className="text-[10px] text-emerald-500">{currentUser?.tenant_name || ''}</span>
          <button onClick={logout} className="text-xs text-slate-500 hover:text-red-400 transition-colors">로그아웃</button>
        </div>
      </div>

      <div className="p-6">
        {license && (!license.active || license.days_remaining <= 7) && <button onClick={()=>setTab('license')} className={`mb-4 w-full rounded-lg border p-3 text-left text-xs ${license.active?'border-yellow-500/40 bg-yellow-500/10 text-yellow-300':'border-red-500/40 bg-red-500/10 text-red-300'}`}>{license.active?`무료 체험 또는 구독 만료까지 ${license.days_remaining}일 남았습니다.`:`제품 기능이 잠겼습니다: ${license.reason}`} <span className="float-right">라이선스 관리 →</span></button>}
        {/* 개요 */}
        {tab === 'overview' && stats && (
          <div className="space-y-6">
            <div className="flex flex-col gap-1">
              <div className="text-xl font-semibold">보안 운영 현황</div>
              <div className="text-xs text-slate-500">위험을 확인하고 필요한 조치를 바로 실행하세요.</div>
            </div>
            <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
              {[
                { label: '고위험 알림', value: highRiskAlerts.length, color: highRiskAlerts.length ? 'text-red-400' : 'text-slate-400', action: () => setTab('alerts') },
                { label: '승인 대기', value: pendingApprovals, color: pendingApprovals ? 'text-yellow-400' : 'text-slate-400', action: () => openControl('approvals') },
                { label: '활성 세션', value: activeSessionCount, color: 'text-emerald-400', action: () => openControl('active') },
                { label: '차단 대상', value: blockedTargetCount, color: 'text-orange-400', action: () => openControl('blocks') },
                { label: '오늘 실행', value: stats.summary?.today_usage ?? 0, color: 'text-blue-400' },
              ].map(({ label, value, color, action }) => (
                <button key={label} onClick={action} disabled={!action}
                  className={`bg-slate-900 border border-slate-800 rounded-lg p-4 text-left transition-colors ${action ? 'hover:border-slate-600 hover:bg-slate-800/70 cursor-pointer' : 'cursor-default'}`}>
                  <div className="text-slate-400 text-xs mb-1">{label}</div>
                  <div className={`text-3xl font-bold ${color}`}>{value}</div>
                  {action && <div className="text-[10px] text-slate-600 mt-2">클릭하여 확인 →</div>}
                </button>
              ))}
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <div className="text-sm font-semibold">즉시 확인이 필요한 위험</div>
                    <div className="text-[11px] text-slate-500 mt-1">미해결 고위험 이벤트와 탐지 근거</div>
                  </div>
                  <button onClick={() => setTab('alerts')} className="text-xs text-emerald-400 hover:text-emerald-300">전체 알림 보기</button>
                </div>
                {highRiskAlerts.length === 0 ? (
                  <div className="rounded-lg border border-emerald-500/20 bg-emerald-500/5 px-4 py-5 text-sm text-emerald-300">현재 미해결 고위험 알림이 없습니다.</div>
                ) : (
                  <div className="space-y-2">
                    {highRiskAlerts.slice(0, 4).map((a: any) => (
                      <button key={a.id} onClick={() => setTab('alerts')} className="w-full flex items-start gap-3 rounded-lg border border-red-500/25 bg-red-500/5 p-3 text-left hover:bg-red-500/10">
                        <span className="mt-1 h-2 w-2 rounded-full bg-red-500 flex-shrink-0" />
                        <span className="flex-1 min-w-0">
                          <span className="flex items-center gap-2 text-xs">
                            <span className="font-bold text-red-400">HIGH</span>
                            <span className="rounded bg-red-500/15 px-1.5 py-0.5 text-[10px] text-red-300">위험도 {a.risk_score ?? 80}점</span>
                            <span className="text-white">{a.alert_type}</span>
                            <span className="text-slate-500">{a.hostname} / {a.username}</span>
                          </span>
                          <span className="block mt-1 text-xs text-slate-400 truncate">탐지 근거: {a.risk_reason || a.detail || '상세 정보 없음'}</span>
                        </span>
                        <span className="text-[10px] text-slate-600">{formatDistanceToNow(new Date(a.created_at), { addSuffix: true, locale: ko })}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                <div className="text-sm font-semibold">빠른 조치</div>
                <div className="text-[11px] text-slate-500 mt-1 mb-4">운영 화면을 찾지 않고 바로 이동합니다.</div>
                <div className="space-y-2">
                  <button onClick={() => openControl('approvals')} className="w-full rounded-lg border border-yellow-500/25 bg-yellow-500/5 px-3 py-2.5 text-left text-xs text-yellow-300 hover:bg-yellow-500/10">승인 요청 검토 <span className="float-right">{pendingApprovals}건 →</span></button>
                  <button onClick={() => openControl('active')} className="w-full rounded-lg border border-red-500/25 bg-red-500/5 px-3 py-2.5 text-left text-xs text-red-300 hover:bg-red-500/10">활성 세션 제어 <span className="float-right">{activeSessionCount}건 →</span></button>
                  <button onClick={() => openControl('blocks')} className="w-full rounded-lg border border-slate-700 bg-slate-800/60 px-3 py-2.5 text-left text-xs text-slate-300 hover:bg-slate-800">사용자·서버 차단 <span className="float-right">→</span></button>
                  <button onClick={() => openControl('policies')} className="w-full rounded-lg border border-slate-700 bg-slate-800/60 px-3 py-2.5 text-left text-xs text-slate-300 hover:bg-slate-800">사용 정책 관리 <span className="float-right">→</span></button>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                <div className="text-xs text-slate-400 mb-3">시간대별 AI 사용량</div>
                <ResponsiveContainer width="100%" height={200}>
                  <LineChart data={stats.timeline ?? []}>
                    <XAxis dataKey="hour" tick={{ fill: '#94a3b8', fontSize: 10 }} />
                    <YAxis tick={{ fill: '#94a3b8', fontSize: 10 }} />
                    <Tooltip contentStyle={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 6 }} />
                    <Legend />
                    <Line type="monotone" dataKey="count" stroke="#16c79a" dot={false} name="실행 횟수" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                <div className="text-xs text-slate-400 mb-3">서버별 사용량</div>
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={stats.byServer ?? []}>
                    <XAxis dataKey="hostname" tick={{ fill: '#94a3b8', fontSize: 10 }} />
                    <YAxis tick={{ fill: '#94a3b8', fontSize: 10 }} />
                    <Tooltip contentStyle={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 6 }} />
                    <Bar dataKey="count" fill="#6366f1" name="횟수" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                <div className="text-xs text-slate-400 mb-3">도구별 사용량</div>
                <div className="space-y-2">
                  {(stats.byTool ?? []).map((t: any) => (
                    <div key={t.tool} className="flex items-center gap-2">
                      <span className="w-16 text-xs" style={{ color: TOOL_COLOR[t.tool] ?? '#94a3b8' }}>{t.tool}</span>
                      <div className="flex-1 bg-slate-800 rounded-full h-2">
                        <div className="h-2 rounded-full" style={{ width: `${Math.min(100, (t.count / (stats.summary?.total_usage || 1)) * 100)}%`, background: TOOL_COLOR[t.tool] ?? '#94a3b8' }} />
                      </div>
                      <span className="text-xs text-slate-400">{t.count}회</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                <div className="text-xs text-slate-400 mb-3">최근 실행</div>
                <div className="space-y-1">
                  {(stats.recent ?? []).slice(0, 8).map((r: any, i: number) => (
                    <div key={i} className="flex items-center gap-2 text-xs text-slate-400 py-1 border-b border-slate-800">
                      <span className="text-emerald-400">{format(new Date(r.logged_at), 'HH:mm:ss')}</span>
                      <span className="text-blue-400">{r.hostname}</span>
                      <span>{r.username}</span>
                      <span style={{ color: TOOL_COLOR[r.tool] ?? '#94a3b8' }}>{r.tool}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 비용·사용량 분석 */}
        {tab === 'analytics' && analytics && (
          <div className="space-y-6">
            <div>
              <div className="text-xl font-semibold">비용·사용량 분석</div>
              <div className="text-xs text-slate-500 mt-1">최근 30일 · 수집된 실제 텔레메트리만 표시합니다.</div>
            </div>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                ['총 실행', Number(analytics.summary?.executions || 0).toLocaleString() + '회', 'text-emerald-400'],
                ['입력 토큰', Number(analytics.summary?.input_tokens || 0).toLocaleString(), 'text-blue-400'],
                ['출력 토큰', Number(analytics.summary?.output_tokens || 0).toLocaleString(), 'text-purple-400'],
                ['총 비용', '$' + Number(analytics.summary?.cost_usd || 0).toFixed(2), 'text-yellow-400'],
              ].map(([label, value, color]) => <div key={label} className="bg-slate-900 border border-slate-800 rounded-lg p-4"><div className="text-xs text-slate-400">{label}</div><div className={`text-2xl font-bold mt-1 ${color}`}>{value}</div></div>)}
            </div>
            {Number(analytics.summary?.input_tokens || 0) + Number(analytics.summary?.output_tokens || 0) === 0 && (
              <div className="rounded-lg border border-blue-500/25 bg-blue-500/5 p-4 text-xs text-blue-300">현재 CLI에서 토큰 텔레메트리가 제공되지 않아 실행 횟수만 집계됩니다. 토큰과 비용은 실제 수집값이 들어오면 자동 표시됩니다.</div>
            )}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {[['사용자별', analytics.byUser, 'username'], ['모델별', analytics.byModel, 'model']].map(([title, rows, key]: any) => (
                <div key={title} className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                  <div className="text-sm font-semibold mb-3">{title}</div>
                  <div className="space-y-2">{(rows || []).map((row: any) => <div key={row[key]} className="grid grid-cols-3 text-xs border-b border-slate-800 pb-2"><span>{row[key]}</span><span className="text-slate-400 text-right">{row.executions}회 · {Number(row.tokens).toLocaleString()} tokens</span><span className="text-yellow-400 text-right">${Number(row.cost_usd).toFixed(4)}</span></div>)}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* AI 자산 및 Shadow AI */}
        {tab === 'agents' && agents && (
          <div className="space-y-6">
            <div><div className="text-xl font-semibold">AI 자산 및 Shadow AI</div><div className="text-xs text-slate-500 mt-1">Windows·macOS·Linux 에이전트와 미승인 AI 실행 현황</div></div>
            <div className="grid grid-cols-3 gap-4">
              {[['등록 에이전트',agents.summary?.agents||0,'text-blue-400'],['온라인',agents.summary?.online||0,'text-emerald-400'],['미해결 Shadow AI',(agents.events||[]).filter((e:any)=>!e.resolved).length,'text-red-400']].map(([label,value,color]:any)=><div key={label} className="bg-slate-900 border border-slate-800 rounded-lg p-4"><div className="text-xs text-slate-400">{label}</div><div className={`text-2xl font-bold mt-1 ${color}`}>{value}</div></div>)}
            </div>
            <div className="space-y-3">{(agents.agents||[]).map((agent:any)=>{
              const online=Date.now()-new Date(agent.last_seen).getTime()<300000;
              return <div key={agent.hostname} className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                <div className="flex items-center gap-3"><span className={`h-2 w-2 rounded-full ${online?'bg-emerald-400':'bg-slate-600'}`}/><span className="font-semibold">{agent.hostname}</span><span className="text-xs text-slate-500">{agent.os} {agent.os_version} · {agent.arch} · Agent {agent.agent_version}</span><span className="ml-auto text-xs text-slate-500">{formatDistanceToNow(new Date(agent.last_seen),{addSuffix:true,locale:ko})}</span></div>
                <div className="mt-3 flex flex-wrap gap-2">{(agents.knownTools||[]).map((tool:string)=>{const installed=(agent.installed_tools||[]).includes(tool); const running=(agent.running_tools||[]).includes(tool); const approved=(agent.approved_tools||[]).includes(tool); return <button key={tool} disabled={!installed||currentUser?.role==='auditor'||currentUser?.role==='viewer'} onClick={()=>toggleApprovedTool(agent,tool)} className={`rounded border px-2 py-1 text-[10px] ${running&&!approved?'border-red-500 bg-red-500/10 text-red-300':approved&&installed?'border-emerald-500/30 text-emerald-300':installed?'border-yellow-500/30 text-yellow-300':'border-slate-800 text-slate-700'}`}>{tool}{running?' ●':''}{approved?' ✓':''}</button>})}</div>
              </div>})}</div>
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4"><div className="text-sm font-semibold mb-3">Shadow AI 이벤트</div><div className="space-y-2">{(agents.events||[]).length===0?<div className="text-xs text-slate-600">탐지된 이벤트 없음</div>:(agents.events||[]).map((e:any)=><div key={e.id} className={`flex items-center gap-3 rounded border p-3 text-xs ${e.resolved?'border-slate-800 opacity-40':'border-red-500/30 bg-red-500/5'}`}><span className="text-red-400">{e.event_type}</span><span>{e.hostname} / {e.username}</span><span className="text-yellow-300">{e.tool}</span><span className="flex-1 text-slate-500">{e.detail}</span>{!e.resolved&&<button onClick={()=>resolveShadowEvent(e.id)} className="text-emerald-400">해결</button>}</div>)}</div></div>
          </div>
        )}

        {/* 주간 보고서 */}
        {tab === 'reports' && reports?.preview && (()=>{const r=reports.preview;return <div className="space-y-6">
          <div className="flex items-end justify-between"><div><div className="text-xl font-semibold">주간 운영·보안 보고서</div><div className="text-xs text-slate-500 mt-1">{r.periodStart} ~ {r.periodEnd} · 실시간 미리보기</div></div><button onClick={saveWeeklyReport} className="rounded border border-emerald-500/40 bg-emerald-500/10 px-4 py-2 text-xs text-emerald-300">초안 저장</button></div>
          <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">{[['실행',r.usage.executions,'text-blue-400'],['사용자',r.usage.users,'text-emerald-400'],['세션',r.sessions.total,'text-purple-400'],['Shadow AI',r.shadow.unresolved,'text-red-400'],['비용','$'+Number(r.usage.cost_usd).toFixed(2),'text-yellow-400']].map(([l,v,c]:any)=><div key={l} className="bg-slate-900 border border-slate-800 rounded-lg p-4"><div className="text-xs text-slate-400">{l}</div><div className={`text-2xl font-bold mt-1 ${c}`}>{v}</div></div>)}</div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6"><div className="bg-slate-900 border border-slate-800 rounded-lg p-4"><div className="text-sm font-semibold mb-3">보안 알림</div>{r.alerts.length===0?<div className="text-xs text-slate-500">이번 주 알림 없음</div>:r.alerts.map((a:any)=><div key={a.severity} className="flex justify-between border-b border-slate-800 py-2 text-xs"><span style={{color:SEV_COLOR[a.severity]}}>{a.severity}</span><span>{a.count}건 · 미해결 {a.unresolved}건</span></div>)}</div><div className="bg-slate-900 border border-slate-800 rounded-lg p-4"><div className="text-sm font-semibold mb-3">권장 조치</div>{r.recommendations.map((x:string,i:number)=><div key={i} className="border-b border-slate-800 py-2 text-xs text-slate-300">{i+1}. {x}</div>)}</div></div>
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-4"><div className="text-sm font-semibold mb-3">저장된 보고서</div>{(reports.reports||[]).length===0?<div className="text-xs text-slate-500">저장된 초안 없음</div>:(reports.reports||[]).map((x:any)=><div key={x.id} className="flex justify-between border-b border-slate-800 py-2 text-xs"><span>{x.title}</span><span className="text-slate-500">{x.delivery_status} · {format(new Date(x.created_at),'yyyy-MM-dd HH:mm')}</span></div>)}</div>
        </div>})()}

        {/* 세션 활동 */}
        {tab === 'sessions' && sessions && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                <div className="text-xs text-slate-400 mb-3">Top 사용자</div>
                {(sessions.topUsers ?? []).map((u: any, i: number) => (
                  <div key={i} className="flex justify-between text-xs py-1.5 border-b border-slate-800">
                    <span>{u.username}</span>
                    <span className="text-slate-400">{u.session_count}세션 / {Math.round((u.avg_duration ?? 0) / 60)}분 평균</span>
                  </div>
                ))}
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                <div className="text-xs text-slate-400 mb-3">Top 서버</div>
                {(sessions.topServers ?? []).map((s: any, i: number) => (
                  <div key={i} className="flex justify-between text-xs py-1.5 border-b border-slate-800">
                    <span className="text-blue-400">{s.hostname}</span>
                    <span className="text-slate-400">{s.session_count}세션 / {s.user_count}명</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
              <div className="text-xs text-slate-400 mb-3">세션 상세 로그</div>
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="text-slate-500 border-b border-slate-800">
                      <th className="text-left py-2 pr-4">시작</th>
                      <th className="text-left py-2 pr-4">서버</th>
                      <th className="text-left py-2 pr-4">사용자</th>
                      <th className="text-left py-2 pr-4">도구</th>
                      <th className="text-left py-2 pr-4">경로</th>
                      <th className="text-left py-2 pr-4">소요</th>
                      <th className="text-left py-2">변경</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(sessions.sessions ?? []).map((s: any, i: number) => (
                      <tr key={i} className="border-b border-slate-800/50 hover:bg-slate-800/30">
                        <td className="py-2 pr-4 text-emerald-400">{format(new Date(s.started_at), 'MM/dd HH:mm')}</td>
                        <td className="py-2 pr-4 text-blue-400">{s.hostname}</td>
                        <td className="py-2 pr-4">{s.username}</td>
                        <td className="py-2 pr-4" style={{ color: TOOL_COLOR[s.tool] ?? '#94a3b8' }}>{s.tool}</td>
                        <td className="py-2 pr-4 text-slate-400 max-w-[200px] truncate">{s.work_dir}</td>
                        <td className="py-2 pr-4 text-slate-400">{s.duration_sec ? `${Math.round(s.duration_sec / 60)}분` : '-'}</td>
                        <td className="py-2 text-slate-400">{s.files_changed || '-'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* 보안 알림 */}
        {tab === 'alerts' && alerts && (
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              {['HIGH', 'MED', 'LOW'].map(sev => (
                <div key={sev} className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                  <div className="text-xs mb-1" style={{ color: SEV_COLOR[sev] }}>{sev}</div>
                  <div className="text-2xl font-bold" style={{ color: SEV_COLOR[sev] }}>{alerts.summary?.[sev.toLowerCase()] ?? 0}</div>
                </div>
              ))}
            </div>
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2">
              {(alerts.alerts ?? []).map((a: any) => (
                <div key={a.id} className={`flex items-start gap-3 p-3 rounded border ${a.resolved ? 'border-slate-800 opacity-40' : 'border-slate-700'}`}>
                  <div className="w-2 h-2 rounded-full mt-1 flex-shrink-0" style={{ background: SEV_COLOR[a.severity] }} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-bold" style={{ color: SEV_COLOR[a.severity] }}>{a.severity}</span>
                      <span className="rounded bg-slate-800 px-1.5 py-0.5 text-[10px] text-slate-300">위험도 {a.risk_score ?? 0}점</span>
                      <span className="text-xs text-white">{a.alert_type}</span>
                      <span className="text-xs text-slate-500">{a.hostname} / {a.username}</span>
                      <span className="text-xs text-slate-600 ml-auto">{formatDistanceToNow(new Date(a.created_at), { addSuffix: true, locale: ko })}</span>
                    </div>
                    <div className="text-xs text-slate-400">{a.detail}</div>
                    {a.risk_reason && <div className="mt-1 text-[10px] text-slate-500">점수 근거: {a.risk_reason}</div>}
                    {a.auto_action === 'pause_requested' && <div className="mt-1 text-[10px] text-yellow-400">자동 조치: 세션 일시정지 및 관리자 승인 요청</div>}
                  </div>
                  {!a.resolved && (
                    <button onClick={() => resolveAlert(a.id)} className="text-xs text-emerald-400 hover:text-emerald-300">해결</button>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 에이전트 제어 */}
        {tab === 'control' && (
          <div className="space-y-4">
            {formMsg && <div className="bg-slate-800 border border-slate-700 rounded px-4 py-2 text-sm">{formMsg}</div>}

            <div className="flex gap-1">
              {([
                { key: 'blocks', label: '🚫 차단 관리' },
                { key: 'policies', label: '📋 사용 정책' },
                { key: 'approvals', label: `✅ 승인 큐${pendingApprovals > 0 ? ` (${pendingApprovals})` : ''}` },
                { key: 'active', label: '🔴 활성 세션' },
              ] as { key: ControlTab; label: string }[]).map(({ key, label }) => (
                <button key={key} onClick={() => setControlTab(key)}
                  className={`px-4 py-1.5 text-xs rounded transition-colors ${controlTab === key ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`}>
                  {label}
                </button>
              ))}
            </div>

            {/* 차단 관리 */}
            {controlTab === 'blocks' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                  <div className="text-xs text-slate-400 mb-3">새 차단 등록</div>
                  <div className="space-y-2">
                    <input placeholder="서버명 (비우면 전체 *)" value={blockForm.hostname}
                      onChange={e => setBlockForm(f => ({ ...f, hostname: e.target.value }))}
                      className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500" />
                    <input placeholder="사용자명 (비우면 전체 *)" value={blockForm.username}
                      onChange={e => setBlockForm(f => ({ ...f, username: e.target.value }))}
                      className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500" />
                    <select value={blockForm.tool} onChange={e => setBlockForm(f => ({ ...f, tool: e.target.value }))}
                      className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500">
                      <option value="claude">claude</option>
                      <option value="codex">codex</option>
                      <option value="*">전체</option>
                    </select>
                    <input placeholder="차단 사유" value={blockForm.reason}
                      onChange={e => setBlockForm(f => ({ ...f, reason: e.target.value }))}
                      className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500" />
                    <button onClick={addBlock}
                      className="w-full bg-red-500/20 hover:bg-red-500/30 border border-red-500/40 text-red-400 rounded px-3 py-2 text-xs transition-colors">
                      차단 등록
                    </button>
                  </div>
                </div>
                <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                  <div className="text-xs text-slate-400 mb-3">현재 차단 목록</div>
                  {(controls?.blocks ?? []).length === 0 ? (
                    <div className="text-xs text-slate-600">등록된 차단 없음</div>
                  ) : (
                    <div className="space-y-2">
                      {controls.blocks.map((b: any) => (
                        <div key={b.id} className="flex items-center gap-2 text-xs p-2 bg-slate-800 rounded">
                          <div className="flex-1">
                            <span className="text-red-400">{b.hostname || '*'}</span>
                            <span className="text-slate-500 mx-1">/</span>
                            <span className="text-white">{b.username || '*'}</span>
                            <span className="text-slate-500 mx-1">/</span>
                            <span style={{ color: TOOL_COLOR[b.tool] ?? '#94a3b8' }}>{b.tool}</span>
                            {b.reason && <div className="text-slate-500 mt-0.5">{b.reason}</div>}
                          </div>
                          <button onClick={() => removeBlock(b.id)} className="text-slate-500 hover:text-red-400">✕</button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* 정책 설정 */}
            {controlTab === 'policies' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                  <div className="text-xs text-slate-400 mb-3">새 정책 등록</div>
                  <div className="space-y-2">
                    <select value={policyForm.template_key} onChange={e => selectTemplate(e.target.value)} className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white">
                      <option value="">정책 템플릿 선택</option>
                      {(governance?.templates || []).map((t: any) => <option key={t.template_key} value={t.template_key}>{t.name} — {t.description}</option>)}
                    </select>
                    <input placeholder="서버명 (비우면 전체 *)" value={policyForm.hostname}
                      onChange={e => setPolicyForm(f => ({ ...f, hostname: e.target.value }))}
                      className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500" />
                    <input placeholder="사용자명 (비우면 전체 *)" value={policyForm.username}
                      onChange={e => setPolicyForm(f => ({ ...f, username: e.target.value }))}
                      className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500" />
                    <select value={policyForm.tool} onChange={e => setPolicyForm(f => ({ ...f, tool: e.target.value }))} className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white"><option value="*">전체 AI 도구</option><option value="claude">Claude</option><option value="codex">Codex</option><option value="cursor">Cursor</option></select>
                    <div className="flex gap-2">
                      <div className="flex-1">
                        <div className="text-xs text-slate-500 mb-1">허용 시작 (시)</div>
                        <input type="number" min={0} max={23} value={policyForm.allow_start}
                          onChange={e => setPolicyForm(f => ({ ...f, allow_start: parseInt(e.target.value) }))}
                          className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500" />
                      </div>
                      <div className="flex-1">
                        <div className="text-xs text-slate-500 mb-1">허용 종료 (시)</div>
                        <input type="number" min={0} max={23} value={policyForm.allow_end}
                          onChange={e => setPolicyForm(f => ({ ...f, allow_end: parseInt(e.target.value) }))}
                          className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500" />
                      </div>
                      <div className="flex-1">
                        <div className="text-xs text-slate-500 mb-1">시간당 최대</div>
                        <input type="number" min={0} value={policyForm.max_per_hour}
                          onChange={e => setPolicyForm(f => ({ ...f, max_per_hour: parseInt(e.target.value) }))}
                          className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500" />
                      </div>
                    </div>
                    <div className="text-xs text-slate-500">* 시간당 최대 = 0 이면 승인 필수 모드</div>
                    <button onClick={addPolicy}
                      className="w-full bg-blue-500/20 hover:bg-blue-500/30 border border-blue-500/40 text-blue-400 rounded px-3 py-2 text-xs transition-colors">
                      정책 등록
                    </button>
                  </div>
                </div>
                <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                  <div className="text-xs text-slate-400 mb-3">현재 정책 목록</div>
                  {(controls?.policies ?? []).length === 0 ? (
                    <div className="text-xs text-slate-600">등록된 정책 없음</div>
                  ) : (
                    <div className="space-y-2">
                      {controls.policies.map((p: any) => (
                        <div key={p.id} className="flex items-start gap-2 text-xs p-2 bg-slate-800 rounded">
                          <div className="flex-1">
                            <span className="text-blue-400">{p.hostname || '*'}</span>
                            <span className="text-slate-500 mx-1">/</span>
                            <span className="text-white">{p.username || '*'}</span>
                            <div className="text-slate-500 mt-0.5">
                              허용: {p.allow_start}시~{p.allow_end}시 | 시간당 최대 {p.max_per_hour === 0 ? '승인필수' : `${p.max_per_hour}회`}
                            </div>
                          </div>
                          <button onClick={() => removePolicy(p.id)} className="text-slate-500 hover:text-red-400">✕</button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* 승인 큐 */}
            {controlTab === 'approvals' && (
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                <div className="text-xs text-slate-400 mb-3">승인 대기 목록</div>
                {(controls?.approvals ?? []).length === 0 ? (
                  <div className="text-xs text-slate-600">대기 중인 승인 요청 없음</div>
                ) : (
                  <div className="space-y-3">
                    {controls.approvals.map((a: any) => (
                      <div key={a.id} className={`p-3 rounded border ${a.status === 'pending' ? 'border-yellow-500/40 bg-yellow-500/5' : a.status === 'approved' ? 'border-emerald-500/30 opacity-50' : 'border-red-500/30 opacity-50'}`}>
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1 space-y-1 text-xs">
                            <div className="flex gap-3">
                              <span className="text-yellow-400">{a.status === 'pending' ? '⏳ 대기' : a.status === 'approved' ? '✅ 승인됨' : '❌ 거부됨'}</span>
                              {a.token?.startsWith('risk-pause:') && <span className="rounded bg-red-500/15 px-1.5 py-0.5 text-[10px] text-red-300">위험 세션 자동정지</span>}
                              <span className="text-blue-400">{a.hostname}</span>
                              <span>{a.username}</span>
                              <span style={{ color: TOOL_COLOR[a.tool] ?? '#94a3b8' }}>{a.tool}</span>
                            </div>
                            <div className="text-slate-400">{a.work_dir}</div>
                            {a.args && <div className="text-slate-500">args: {a.args}</div>}
                            <div className="text-slate-600">{formatDistanceToNow(new Date(a.created_at), { addSuffix: true, locale: ko })}</div>
                          </div>
                          {a.status === 'pending' && (
                            <div className="flex gap-2 flex-shrink-0">
                              <button onClick={() => reviewApproval(a.id, true)}
                                className="bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-400 rounded px-3 py-1 text-xs">승인</button>
                              <button onClick={() => reviewApproval(a.id, false)}
                                className="bg-red-500/20 hover:bg-red-500/30 border border-red-500/40 text-red-400 rounded px-3 py-1 text-xs">거부</button>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* 활성 세션 */}
            {controlTab === 'active' && (
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                <div className="text-xs text-slate-400 mb-3">활성 세션 (강제종료 가능)</div>
                {(controls?.activeSessions ?? []).length === 0 ? (
                  <div className="text-xs text-slate-600">현재 활성 세션 없음</div>
                ) : (
                  <div className="space-y-2">
                    {controls.activeSessions.map((s: any) => (
                      <div key={s.session_id} className="flex items-center gap-3 p-3 bg-slate-800 rounded border border-slate-700">
                        <div className={`w-2 h-2 rounded-full flex-shrink-0 ${s.state === 'paused' ? 'bg-yellow-400' : 'bg-green-400 animate-pulse'}`} />
                        <div className="flex-1 text-xs space-y-0.5">
                          <div className="flex gap-3">
                            <span className="text-blue-400">{s.hostname}</span>
                            <span>{s.username}</span>
                            <span style={{ color: TOOL_COLOR[s.tool] ?? '#94a3b8' }}>{s.tool}</span>
                            <span className="text-slate-500">PID: {s.pid}</span>
                            <span className={s.state === 'paused' ? 'text-yellow-400' : 'text-emerald-400'}>{s.state === 'paused' ? '일시정지' : '실행 중'}</span>
                          </div>
                          <div className="text-slate-500">{s.work_dir || '-'}</div>
                          <div className="text-slate-600">{formatDistanceToNow(new Date(s.started_at), { addSuffix: true, locale: ko })} 시작</div>
                        </div>
                        <button onClick={() => toggleSession(s.session_id, s.state === 'paused')}
                          className="bg-yellow-500/20 hover:bg-yellow-500/30 border border-yellow-500/40 text-yellow-300 rounded px-3 py-1.5 text-xs flex-shrink-0">
                          {s.state === 'paused' ? '▶ 재개' : '⏸ 일시정지'}
                        </button>
                        <button
                          onClick={() => { if (confirm(`${s.hostname}/${s.username} 세션을 강제 종료하시겠습니까?`)) killSession(s.session_id); }}
                          className="bg-red-500/20 hover:bg-red-500/30 border border-red-500/40 text-red-400 rounded px-3 py-1.5 text-xs flex-shrink-0">
                          🛑 강제종료
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* 거버넌스 */}
      {tab === 'governance' && governance && (
        <div className="space-y-6 p-6">
          <div><div className="text-xl font-semibold">거버넌스 설정</div><div className="text-xs text-slate-500 mt-1">정책 템플릿, 역할 및 데이터 보호 상태</div></div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
              <div className="text-sm font-semibold mb-3">정책 템플릿</div>
              <div className="space-y-2">{(governance.templates || []).map((t: any) => <button key={t.template_key} onClick={() => { selectTemplate(t.template_key); openControl('policies'); }} className="w-full rounded-lg border border-slate-700 p-3 text-left hover:bg-slate-800"><span className="text-xs text-white">{t.name}</span><span className="float-right text-[10px] text-slate-500">{t.risk_level}</span><span className="block text-[10px] text-slate-500 mt-1">{t.description}</span></button>)}</div>
            </div>
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
              <div className="text-sm font-semibold mb-3">데이터 보호</div>
              {(governance.settings || []).map((s: any) => <div key={s.setting_key} className="border-b border-slate-800 py-3 text-xs"><span className="text-slate-300">{s.setting_key === 'retention' ? '로그 보존정책' : '민감정보 보호'}</span><pre className="text-[10px] text-emerald-400 mt-1 whitespace-pre-wrap">{JSON.stringify(s.setting_value)}</pre></div>)}
              <div className="mt-3 text-[10px] text-slate-500">보존기간 자동삭제는 기본 비활성화되어 있으며 별도 승인 후 활성화합니다.</div>
            </div>
          </div>
          {currentUser?.platform_admin && <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4"><div className="text-sm font-semibold mb-3">고객사 관리</div><div className="space-y-2">{(tenants?.tenants||[]).map((t:any)=><div key={t.id} className="flex justify-between border-b border-slate-800 py-2 text-xs"><span>{t.name}<span className="ml-2 text-slate-500">{t.code}</span></span><span className="text-slate-500">관리자 {t.admins} · 에이전트 {t.agents}</span></div>)}</div></div>
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4"><div className="text-sm font-semibold mb-3">새 고객사 생성</div><div className="grid grid-cols-2 gap-2">{[['고객사명','name','text'],['고객사 코드','code','text'],['관리자 아이디','admin_username','text'],['관리자 이메일','admin_email','email'],['초기 비밀번호','admin_password','password']].map(([label,key,type])=><input key={key} type={type} placeholder={label} value={(tenantForm as any)[key]} onChange={e=>setTenantForm(f=>({...f,[key]:e.target.value}))} className="bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs"/>)}<button onClick={createTenant} className="col-span-2 rounded border border-emerald-500/40 bg-emerald-500/10 py-2 text-xs text-emerald-300">고객사 생성</button></div>{newAgentKey&&<div className="mt-3 rounded border border-yellow-500/30 bg-yellow-500/5 p-3 text-xs"><div className="text-yellow-300">에이전트 키는 지금 한 번만 표시됩니다.</div><code className="mt-2 block break-all text-slate-300">{newAgentKey}</code></div>}</div>
          </div>}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
            <div className="text-sm font-semibold mb-3">관리자 역할</div>
            {(governance.users || []).map((u: any) => <div key={u.id} className="flex items-center gap-3 border-b border-slate-800 py-2 text-xs"><span className="flex-1">{u.username}<span className="ml-2 text-slate-500">{u.email}</span></span><select value={u.role} disabled={currentUser?.role !== 'admin'} onChange={e => updateRole(u.id, e.target.value)} className="bg-slate-800 border border-slate-700 rounded px-2 py-1"><option value="admin">관리자</option><option value="security">보안담당자</option><option value="auditor">감사자</option><option value="viewer">열람자</option></select></div>)}
          </div>
        </div>
      )}

      {tab === 'license' && license && (
        <div className="space-y-6 p-6">
          <div><div className="text-xl font-semibold">라이선스 관리</div><div className="mt-1 text-xs text-slate-500">15일 무료 체험과 월 구독 상태를 관리합니다.</div></div>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="rounded-lg border border-slate-800 bg-slate-900 p-4"><div className="text-xs text-slate-500">상태</div><div className={`mt-2 text-lg ${license.active?'text-emerald-400':'text-red-400'}`}>{license.active?'사용 가능':'기능 잠김'}</div><div className="mt-1 text-[10px] text-slate-500">{license.license_type==='trial'?'15일 무료 체험':license.plan}</div></div>
            <div className="rounded-lg border border-slate-800 bg-slate-900 p-4"><div className="text-xs text-slate-500">남은 기간</div><div className="mt-2 text-lg text-white">{license.days_remaining}일</div><div className="mt-1 text-[10px] text-slate-500">만료 {new Date(license.expires_at).toLocaleString('ko-KR')}</div></div>
            <div className="rounded-lg border border-slate-800 bg-slate-900 p-4"><div className="text-xs text-slate-500">관리 대상</div><div className="mt-2 text-lg text-white">{license.agent_count} / {license.agent_limit}대</div><div className="mt-1 text-[10px] text-slate-500">OS와 관계없이 장비 ID 기준</div></div>
          </div>
          <div className="rounded-lg border border-slate-800 bg-slate-900 p-4">
            <div className="text-sm font-semibold">구독 키 인증</div><div className="mt-1 text-[10px] text-slate-500">설치 ID: {license.installation_id}</div>
            <textarea value={licenseKey} onChange={e=>setLicenseKey(e.target.value)} placeholder="EINSTECH에서 발급받은 라이선스 키를 입력하세요" className="mt-4 h-24 w-full rounded border border-slate-700 bg-slate-800 p-3 text-xs" />
            {licenseMsg&&<div className="mt-2 text-xs">{licenseMsg}</div>}
            <button disabled={currentUser?.role!=='admin'||!licenseKey.trim()} onClick={activateLicense} className="mt-3 rounded border border-emerald-500/40 bg-emerald-500/10 px-4 py-2 text-xs text-emerald-300 disabled:opacity-40">라이선스 인증</button>
          </div>
        </div>
      )}

      {/* 설정 모달 */}
      {showSettings && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50" onClick={() => setShowSettings(false)}>
          <div className="bg-slate-900 border border-slate-700 rounded-lg p-6 w-full max-w-sm" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-center mb-4">
              <div className="text-sm font-bold">계정 설정</div>
              <button onClick={() => setShowSettings(false)} className="text-slate-500 hover:text-white">✕</button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-xs text-slate-400 block mb-1">현재 비밀번호 *</label>
                <input type="password" value={settingsForm.currentPassword}
                  onChange={e => setSettingsForm(f => ({ ...f, currentPassword: e.target.value }))}
                  className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500" />
              </div>
              <div>
                <label className="text-xs text-slate-400 block mb-1">새 아이디 (변경 시)</label>
                <input type="text" value={settingsForm.newUsername}
                  onChange={e => setSettingsForm(f => ({ ...f, newUsername: e.target.value }))}
                  className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500" />
              </div>
              <div>
                <label className="text-xs text-slate-400 block mb-1">새 비밀번호 (변경 시)</label>
                <input type="password" value={settingsForm.newPassword}
                  onChange={e => setSettingsForm(f => ({ ...f, newPassword: e.target.value }))}
                  className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500" />
              </div>
              <div>
                <label className="text-xs text-slate-400 block mb-1">새 비밀번호 확인</label>
                <input type="password" value={settingsForm.confirmPassword}
                  onChange={e => setSettingsForm(f => ({ ...f, confirmPassword: e.target.value }))}
                  className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500" />
              </div>
              {settingsMsg && <div className="text-xs">{settingsMsg}</div>}
              <button onClick={saveSettings}
                className="w-full bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-400 rounded py-2 text-xs transition-colors">
                저장
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
