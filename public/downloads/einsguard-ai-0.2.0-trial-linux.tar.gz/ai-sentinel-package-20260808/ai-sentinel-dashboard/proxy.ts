import { NextRequest, NextResponse } from 'next/server';
import jwt from 'jsonwebtoken';

const SECRET = process.env.SESSION_SECRET || 'development-only-session-secret-change-me';
// 에이전트는 사용자 브라우저가 아니므로 로그인 쿠키를 가질 수 없다.
// /api/agent는 서버/계정/도구 정책으로 검증하며 외부 관리 API와 분리한다.
const PUBLIC_PATHS = ['/login', '/api/auth', '/reset-password', '/api/reset-password', '/api/agent'];

export async function proxy(req: NextRequest) {
  const { pathname } = req.nextUrl;

  if (PUBLIC_PATHS.some(p => pathname.startsWith(p))) {
    return NextResponse.next();
  }

  const token = req.cookies.get('ai-sentinel-token')?.value;
  if (token) {
    try {
      jwt.verify(token, SECRET);
      return NextResponse.next();
    } catch {}
  }

  if (pathname.startsWith('/api/')) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  return NextResponse.redirect(new URL('/login', req.url));
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'],
};
