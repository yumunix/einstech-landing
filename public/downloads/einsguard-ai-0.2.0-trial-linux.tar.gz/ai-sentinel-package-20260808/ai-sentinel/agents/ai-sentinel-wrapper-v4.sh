#!/bin/bash
# AI Sentinel Agent v4 — 차단/정책/승인/일시정지/재개/종료

TOOL="${AI_SENTINEL_TOOL:-$(basename "$0")}" 
REAL_BIN="${AI_SENTINEL_REAL_BIN:-$HOME/.local/bin/${TOOL}.real}"
API="${AI_SENTINEL_API:-http://192.168.0.123:3100/api/agent}"
KEY_FILE="${AI_SENTINEL_KEY_FILE:-$HOME/.config/ai-sentinel/agent.key}"
[ -r "$KEY_FILE" ] || { echo "[AI Sentinel] agent key not found: $KEY_FILE" >&2; exit 1; }
AGENT_KEY=$(tr -d '\r\n' < "$KEY_FILE")
SESSION_ID="$(hostname)-$(whoami)-$(date +%s)-$$"
AGENT_HOSTNAME=$(hostname)
AGENT_USERNAME=$(whoami)
WORK_DIR="$PWD"

api_value() {
  curl -sf -H "x-ai-sentinel-key: $AGENT_KEY" "$1" 2>/dev/null | tr -d '"'
}

BLOCKED=$(api_value "$API?check-block=1&hostname=$AGENT_HOSTNAME&username=$AGENT_USERNAME&tool=$TOOL")
if [ "$BLOCKED" = "true" ]; then
  echo "[AI Sentinel] 이 서버/계정은 AI 사용이 차단되어 있습니다." >&2
  logger -t ai-monitor "BLOCKED|$AGENT_HOSTNAME|$AGENT_USERNAME|$TOOL|$$|$*"
  exit 1
fi

POLICY_RESULT=$(api_value "$API?check-policy=1&hostname=$AGENT_HOSTNAME&username=$AGENT_USERNAME&tool=$TOOL")
if [ "$POLICY_RESULT" != "ok" ] && [ -n "$POLICY_RESULT" ]; then
  echo "[AI Sentinel] 사용 정책 위반: $POLICY_RESULT" >&2
  logger -t ai-monitor "POLICY_DENIED|$AGENT_HOSTNAME|$AGENT_USERNAME|$TOOL|$$|$POLICY_RESULT"
  exit 1
fi

APPROVAL_REQUIRED=$(api_value "$API?check-approval=1&hostname=$AGENT_HOSTNAME&username=$AGENT_USERNAME&tool=$TOOL")
if [ "$APPROVAL_REQUIRED" = "true" ]; then
  echo "[AI Sentinel] 관리자 승인이 필요합니다." >&2
  TOKEN=$(openssl rand -hex 16)
  REQUEST_BODY=$(TOOL="$TOOL" SESSION_ID="$SESSION_ID" AGENT_HOSTNAME="$AGENT_HOSTNAME" AGENT_USERNAME="$AGENT_USERNAME" WORK_DIR="$WORK_DIR" TOKEN="$TOKEN" ARGS="$*" python3 -c \
    'import json,os; print(json.dumps({"session_id":os.environ["SESSION_ID"],"hostname":os.environ["AGENT_HOSTNAME"],"username":os.environ["AGENT_USERNAME"],"tool":os.environ["TOOL"],"work_dir":os.environ["WORK_DIR"],"args":os.environ["ARGS"],"token":os.environ["TOKEN"]}))')
  curl -sf -X POST "$API?action=request-approval" -H "Content-Type: application/json" -H "x-ai-sentinel-key: $AGENT_KEY" -d "$REQUEST_BODY" >/dev/null 2>&1
  for i in $(seq 1 60); do
    sleep 5
    STATUS=$(api_value "$API?approval-status=1&token=$TOKEN")
    [ "$STATUS" = "approved" ] && break
    if [ "$STATUS" = "rejected" ]; then
      echo "[AI Sentinel] 관리자가 요청을 거부했습니다." >&2
      exit 1
    fi
  done
  if [ "$STATUS" != "approved" ]; then
    echo "[AI Sentinel] 승인 시간이 초과되었습니다." >&2
    exit 1
  fi
fi

GIT_BRANCH=$(git -C "$WORK_DIR" rev-parse --abbrev-ref HEAD 2>/dev/null || true)
GIT_COMMIT_BEFORE=$(git -C "$WORK_DIR" rev-parse HEAD 2>/dev/null || true)
STARTED=$(date '+%Y-%m-%d %H:%M:%S')
logger -t ai-monitor "SESSION_START|$SESSION_ID|$AGENT_HOSTNAME|$AGENT_USERNAME|$TOOL|$WORK_DIR|$STARTED|$GIT_BRANCH|$*"

"$REAL_BIN" "$@" &
AI_PID=$!
REGISTER_BODY=$(TOOL="$TOOL" SESSION_ID="$SESSION_ID" AGENT_HOSTNAME="$AGENT_HOSTNAME" AGENT_USERNAME="$AGENT_USERNAME" AI_PID="$AI_PID" python3 -c \
  'import json,os; print(json.dumps({"session_id":os.environ["SESSION_ID"],"hostname":os.environ["AGENT_HOSTNAME"],"username":os.environ["AGENT_USERNAME"],"tool":os.environ["TOOL"],"pid":int(os.environ["AI_PID"])}))')
curl -sf -X POST "$API?action=register-pid" -H "Content-Type: application/json" -H "x-ai-sentinel-key: $AGENT_KEY" -d "$REGISTER_BODY" >/dev/null 2>&1

(
  PAUSED=false
  while kill -0 "$AI_PID" 2>/dev/null; do
    CONTROL=$(api_value "$API?check-control=1&session_id=$SESSION_ID")
    case "$CONTROL" in
      pause)
        if [ "$PAUSED" = false ]; then
          kill -STOP "$AI_PID" 2>/dev/null
          PAUSED=true
          logger -t ai-monitor "PAUSED|$SESSION_ID|$AGENT_HOSTNAME|$AGENT_USERNAME|$TOOL|$AI_PID"
        fi
        ;;
      resume)
        if [ "$PAUSED" = true ]; then
          kill -CONT "$AI_PID" 2>/dev/null
          PAUSED=false
          logger -t ai-monitor "RESUMED|$SESSION_ID|$AGENT_HOSTNAME|$AGENT_USERNAME|$TOOL|$AI_PID"
        fi
        ;;
      kill)
        [ "$PAUSED" = true ] && kill -CONT "$AI_PID" 2>/dev/null
        kill "$AI_PID" 2>/dev/null
        logger -t ai-monitor "KILLED|$SESSION_ID|$AGENT_HOSTNAME|$AGENT_USERNAME|$TOOL|$AI_PID"
        break
        ;;
    esac
    sleep 3
  done
) &
WATCHER_PID=$!

wait "$AI_PID"
EXIT_CODE=$?
kill "$WATCHER_PID" 2>/dev/null || true

ENDED=$(date '+%Y-%m-%d %H:%M:%S')
START_TS=$(echo "$SESSION_ID" | awk -F'-' '{print $(NF-1)}')
DURATION=$(( $(date +%s) - ${START_TS:-0} ))
GIT_COMMIT_AFTER=$(git -C "$WORK_DIR" rev-parse HEAD 2>/dev/null || true)
FILES_CHANGED=""
GIT_COMMITS=""
if [ -n "$GIT_COMMIT_BEFORE" ] && [ "$GIT_COMMIT_BEFORE" != "$GIT_COMMIT_AFTER" ]; then
  FILES_CHANGED=$(git -C "$WORK_DIR" diff --stat "$GIT_COMMIT_BEFORE" "$GIT_COMMIT_AFTER" 2>/dev/null | tail -1)
  GIT_COMMITS=$(git -C "$WORK_DIR" log --oneline "$GIT_COMMIT_BEFORE".."$GIT_COMMIT_AFTER" 2>/dev/null | head -5 | tr '\n' '|')
fi
logger -t ai-monitor "SESSION_END|$SESSION_ID|$AGENT_HOSTNAME|$AGENT_USERNAME|$TOOL|$WORK_DIR|$ENDED|${DURATION}s|$FILES_CHANGED|$GIT_COMMITS"
exit "$EXIT_CODE"
