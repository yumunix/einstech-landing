#!/usr/bin/env python3
"""EINSGUARD AI governance agent for Linux/macOS (process, browser policy and CLI DLP)."""
import argparse, hashlib, json, os, platform, pwd, re, shlex, signal, subprocess, sys, time, urllib.parse, urllib.request
from pathlib import Path

AGENT_VERSION='1.3.1'
MAX_FILE_SCAN_BYTES=20*1024*1024
MAX_FILE_CONTENT_BYTES=1024*1024
DLP_PATTERNS=(
    ('PRIVATE_KEY','CRITICAL',re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----')),
    ('API_KEY','CRITICAL',re.compile(r'(?:sk-[A-Za-z0-9_-]{20,}|sk-ant-[A-Za-z0-9_-]{20,}|AIza[0-9A-Za-z_-]{30,}|gh[pousr]_[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16})',re.I)),
    ('PASSWORD','HIGH',re.compile(r'(?:password|passwd|pwd|비밀번호)\s*[:=]\s*[^\s,;]{6,}',re.I)),
    ('KOREAN_RRN','HIGH',re.compile(r'(?<!\d)(?:\d{6})[- ]?[1-4]\d{6}(?!\d)')),
    ('CARD_NUMBER','HIGH',re.compile(r'(?<!\d)(?:\d[ -]?){13,19}(?!\d)')),
    ('CUSTOMER_DATA','HIGH',re.compile(r'(?:고객명|고객정보|customer(?:\s+name|\s+list)?|account(?:\s+number)?|전화번호|휴대폰)\s*[:=,]\s*.{3,}',re.I)),
)

def log_error(message):
    print(time.strftime('%Y-%m-%dT%H:%M:%S%z')+' '+str(message),file=sys.stderr)

def api_base(value):
    value=value.strip().rstrip('/')
    if value.startswith(('http://','https://')):return value
    if ':' in value:return 'http://'+value
    return 'http://'+value+':3100'

def api(base,key,path,method='GET',body=None):
    data=json.dumps(body).encode() if body is not None else None
    req=urllib.request.Request(api_base(base)+path,data=data,method=method,headers={'x-ai-sentinel-key':key,'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=15) as res:return json.load(res)

def processes():
    out=subprocess.run(['ps','-axo','pid=,user=,comm=,args='],capture_output=True,text=True,check=True).stdout
    rows=[]
    for line in out.splitlines():
        parts=line.strip().split(None,3)
        if len(parts)>=3: rows.append({'pid':int(parts[0]),'user':parts[1],'comm':os.path.basename(parts[2]).lower(),'args':parts[3] if len(parts)>3 else ''})
    return rows

def local_users():
    system=platform.system()
    minimum_uid=500 if system=='Darwin' else 1000
    users=[]
    for entry in pwd.getpwall():
        shell=(entry.pw_shell or '').lower()
        if entry.pw_uid!=0 and entry.pw_uid<minimum_uid:continue
        if entry.pw_name.startswith('_'):continue
        if shell.endswith(('nologin','false')):continue
        users.append(entry.pw_name)
    return sorted(set(users))

def match(catalog,rows):
    found={x['key']:[] for x in catalog}
    for row in rows:
        args_lower=row['args'].lower()
        for item in catalog:
            procs=[x.lower() for x in item.get('processes',[])]
            cmds=[x.lower() for x in item.get('commands',[])]
            proc_match=any(row['comm']==x or (len(x)>=4 and row['comm'].startswith(x)) for x in procs)
            command_match=any(len(x)>=3 and (' '+x+' ') in (' '+args_lower+' ') for x in cmds)
            short_command_match=any(len(x)<3 and row['comm']==x for x in cmds)
            if proc_match or command_match or short_command_match:found[item['key']].append(row)
    return found

def masked(value):
    if len(value)<=8:return '*'*min(len(value),8)
    return value[:4]+'…'+value[-4:]

def valid_card_number(value):
    digits=''.join(character for character in value if character.isdigit())
    if not 13<=len(digits)<=19 or len(set(digits))==1:return False
    total=0
    for index,character in enumerate(reversed(digits)):
        number=int(character)
        if index%2==1:
            number*=2
            if number>9:number-=9
        total+=number
    return total%10==0

def inspect_content(api_base,key,host,policy,tool,row,sent,enforce,channel,content,marker_prefix=''):
    if not policy.get('enabled',True) or not content:return False
    content=content[:12000]
    should_block=False
    for violation,severity,pattern in DLP_PATTERNS:
        matches=list(pattern.finditer(content))
        if violation=='CARD_NUMBER':matches=[item for item in matches if valid_card_number(item.group(0))]
        if not matches:continue
        evidence=matches[0].group(0)
        digest=hashlib.sha256(evidence.encode()).hexdigest()
        marker=(row['pid'],marker_prefix+digest)
        if marker in sent:continue
        sent.add(marker)
        critical=enforce and severity=='CRITICAL' and policy.get('blockCritical',True)
        body={'hostname':host,'username':row.get('user','system'),'tool':tool,'channel':channel,
              'violation_type':violation,'severity':severity,'evidence_hash':digest,
              'masked_evidence':masked(evidence),'match_count':len(matches),
              'action_taken':'blocked' if critical else 'alerted'}
        if policy.get('inspectContentWithLocalAi',True):body['raw_content']=content
        try:api(api_base,key,'/api/dlp','POST',body)
        except Exception as exc:log_error(f'EINSGUARD DLP report failed: {exc}')
        should_block=should_block or critical
    return should_block

def inspect_cli(api_base,key,host,policy,tool,row,sent,enforce):
    if not policy.get('enabled',True) or not policy.get('scanCliArguments',True):return False
    return inspect_content(api_base,key,host,policy,tool,row,sent,enforce,'cli',row.get('args',''),'cli:')

def referenced_files(row):
    try:tokens=shlex.split(row.get('args',''))
    except ValueError:tokens=re.findall(r'"([^"]+)"|\'([^\']+)\'|(\S+)',row.get('args',''))
    if tokens and isinstance(tokens[0],tuple):tokens=[next((part for part in item if part),'') for item in tokens]
    cwd=None
    if platform.system()=='Linux':
        try:cwd=Path(f"/proc/{row['pid']}/cwd").resolve()
        except (OSError,RuntimeError):pass
    files=[]
    for token in tokens:
        value=str(token).strip().lstrip('@')
        if value.startswith('file://'):value=urllib.parse.unquote(urllib.parse.urlparse(value).path)
        if not value or value.startswith('-'):continue
        path=Path(os.path.expandvars(os.path.expanduser(value)))
        if not path.is_absolute() and cwd:path=cwd/path
        try:
            if path.is_file() and path.stat().st_size<=MAX_FILE_SCAN_BYTES and path.suffix.lower() not in {'.exe','.dll','.so','.dylib','.bin'}:files.append(path.resolve())
        except OSError:continue
    return list(dict.fromkeys(files))

def inspect_files(api_base,key,host,policy,tool,row,sent,enforce):
    if not policy.get('enabled',True) or not policy.get('scanFileUploads',True):return False
    should_block=False
    for path in referenced_files(row):
        try:raw=path.read_bytes()[:MAX_FILE_CONTENT_BYTES]
        except OSError:continue
        if not raw or b'\x00' in raw[:4096]:continue
        content=raw.decode('utf-8',errors='ignore')
        if not content.strip():continue
        file_marker='file:'+hashlib.sha256((str(path)+str(path.stat().st_mtime_ns)).encode()).hexdigest()+':'
        pattern_block=inspect_content(api_base,key,host,policy,tool,row,sent,enforce,'file_upload',content,file_marker)
        internal_block=classify_internal(api_base,key,host,policy,tool,row,sent,enforce,'file_upload',content,file_marker)
        should_block=should_block or pattern_block or internal_block
    return should_block

def classify_internal(api_base,key,host,policy,tool,row,sent,enforce,channel='cli',content=None,marker_prefix='internal:'):
    if not policy.get('enabled',True) or not policy.get('inspectInternalFingerprints',True) or tool=='unknown-ai':return False
    content=(row.get('args','') if content is None else content)[:12000]
    if len(content)<20:return False
    digest=hashlib.sha256(content.encode()).hexdigest();marker=(row['pid'],marker_prefix+digest)
    if marker in sent:return False
    sent.add(marker)
    body={'hostname':host,'username':row.get('user','system'),'tool':tool,'channel':channel,
          'violation_type':'CONTENT_FINGERPRINT_CHECK','severity':'LOW','evidence_hash':digest,
          'masked_evidence':masked(content),'match_count':1,'action_taken':'classification_requested','raw_content':content}
    try:
        response=api(api_base,key,'/api/dlp?action=classify','POST',body)
        return enforce and response.get('recommended_action')=='block'
    except Exception as exc:
        log_error(f'EINSGUARD fingerprint classification failed: {exc}');return False

def browser_policy(catalog,approved):
    blocked=sorted({d.replace('*.','') for x in catalog if x['key'] not in approved for d in x.get('domains',[]) if d})
    payload={'URLBlocklist':blocked,'DnsOverHttpsMode':'off'}
    if platform.system()=='Linux' and os.geteuid()==0:
        for path in ['/etc/opt/chrome/policies/managed/einsguard-ai.json','/etc/chromium/policies/managed/einsguard-ai.json','/etc/opt/edge/policies/managed/einsguard-ai.json']:
            p=Path(path);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(payload,ensure_ascii=False),encoding='utf-8')
    elif platform.system()=='Darwin' and os.geteuid()==0:
        for bundle in ['com.google.Chrome','com.microsoft.Edge']:
            cmd=['defaults','write',f'/Library/Managed Preferences/{bundle}','URLBlocklist','-array']+blocked
            subprocess.run(cmd,check=False,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            subprocess.run(['defaults','write',f'/Library/Managed Preferences/{bundle}','DnsOverHttpsMode','-string','off'],check=False)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--api',required=True);ap.add_argument('--key-file',required=True);ap.add_argument('--once',action='store_true');args=ap.parse_args()
    key=Path(args.key_file).read_text().strip();host=platform.node();user=os.getenv('USER') or 'system';sent_dlp=set()
    while True:
        try:
            policy=api(args.api,key,'/api/agent?action=policy-profile&hostname='+urllib.parse.quote(host))
            enforce=policy.get('mode')=='enforce'
            catalog=policy.get('catalog',[]);approved=set(policy.get('approved_tools',[]));seen=match(catalog,processes())
            running=sorted(k for k,v in seen.items() if v)
            report={'hostname':host,'username':user,'local_users':local_users(),'os':platform.system().lower(),'os_version':platform.platform(),'arch':platform.machine(),'agent_version':AGENT_VERSION,'installed_tools':running,'running_tools':running}
            api(args.api,key,'/api/agents?action=inventory-report','POST',report)
            browser_policy(catalog,approved if enforce else {item['key'] for item in catalog})
            for tool,rows in seen.items():
                for row in rows:
                    pattern_block=inspect_cli(args.api,key,host,policy.get('dlp',{}),tool,row,sent_dlp,enforce)
                    internal_block=classify_internal(args.api,key,host,policy.get('dlp',{}),tool,row,sent_dlp,enforce)
                    file_block=inspect_files(args.api,key,host,policy.get('dlp',{}),tool,row,sent_dlp,enforce)
                    if (pattern_block or internal_block or file_block) and row['pid'] not in (os.getpid(),os.getppid()):
                        try:os.kill(row['pid'],signal.SIGTERM)
                        except (ProcessLookupError,PermissionError):pass
                if rows and tool not in approved:
                    if enforce:
                        for row in rows:
                            if row['pid'] not in (os.getpid(),os.getppid()):
                                try:os.kill(row['pid'],signal.SIGTERM)
                                except (ProcessLookupError,PermissionError):pass
                        event_type='UNAPPROVED_AI_BLOCKED';detail=f'Unapproved app/CLI blocked: {tool}'
                    else:
                        event_type='UNAPPROVED_AI_RUNNING';detail=f'Monitor only: unapproved app/CLI detected: {tool}'
                    api(args.api,key,'/api/agent?action=security-event','POST',{'hostname':host,'username':user,'tool':tool,'event_type':event_type,'detail':detail})
            active_pids={row['pid'] for rows in seen.values() for row in rows}
            sent_dlp={marker for marker in sent_dlp if marker[0] in active_pids}
        except Exception as exc: log_error(f'EINSGUARD cycle failed: {exc}')
        if args.once:return
        time.sleep(5)
if __name__=='__main__':main()
