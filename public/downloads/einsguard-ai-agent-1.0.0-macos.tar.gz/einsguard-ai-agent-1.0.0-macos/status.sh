#!/bin/sh
set -u
echo 'EINSGUARD AI macOS Agent 1.0 status'
echo '-----------------------------------'
if launchctl print system/com.einstech.einsguard-ai >/dev/null 2>&1; then echo 'Service: RUNNING'; else echo 'Service: STOPPED'; fi
echo "Server: $(cat /Library/EINSGUARD/etc/server.url 2>/dev/null || echo 'not configured')"
echo 'Recent error log:'
tail -n 20 /Library/Logs/einsguard-ai-error.log 2>/dev/null || true
