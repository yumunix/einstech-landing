#!/usr/bin/env python3
"""EINSGUARD AI governance agent for Linux/macOS (process + browser policy)."""
import argparse, hashlib, json, os, platform, signal, subprocess, sys, time, urllib.parse, urllib.request
from pathlib import Path

def api(base,key,path,method='GET',body=None):
    data=json.dumps(body).encode() if body is not None else None
    req=urllib.request.Request(base.rstrip('/')+path,data=data,method=method,headers={'x-ai-sentinel-key':key,'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=15) as res:return json.load(res)

def processes():
    out=subprocess.run(['ps','-axo','pid=,user=,comm=,args='],capture_output=True,text=True,check=True).stdout
    rows=[]
    for line in out.splitlines():
        parts=line.strip().split(None,3)
        if len(parts)>=3: rows.append({'pid':int(parts[0]),'user':parts[1],'comm':os.path.basename(parts[2]).lower(),'args':parts[3].lower() if len(parts)>3 else ''})
    return rows

def match(catalog,rows):
    found={x['key']:[] for x in catalog}
    for row in rows:
        for item in catalog:
            procs=[x.lower() for x in item.get('processes',[])]
            cmds=[x.lower() for x in item.get('commands',[])]
            proc_match=any(row['comm']==x or (len(x)>=4 and row['comm'].startswith(x)) for x in procs)
            command_match=any(len(x)>=3 and (' '+x+' ') in (' '+row['args']+' ') for x in cmds)
            short_command_match=any(len(x)<3 and row['comm']==x for x in cmds)
            if proc_match or command_match or short_command_match:found[item['key']].append(row)
    return found

def browser_policy(catalog,approved):
    blocked=sorted({d.replace('*.','') for x in catalog if x['key'] not in approved for d in x.get('domains',[]) if d})
    payload={'URLBlocklist':blocked,'DnsOverHttpsMode':'off'}
    if platform.system()=='Linux' and os.geteuid()==0:
        for path in ['/etc/opt/chrome/policies/managed/einsguard-ai.json','/etc/chromium/policies/managed/einsguard-ai.json','/etc/opt/edge/policies/managed/einsguard-ai.json']:
            p=Path(path);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(payload,ensure_ascii=False),encoding='utf-8')
    elif platform.system()=='Darwin' and os.geteuid()==0:
        for bundle in ['com.google.Chrome','com.microsoft.Edge']:
            cmd=['defaults','write',f'/Library/Managed Preferences/{bundle}','URLBlocklist','-array']+blocked
            subprocess.run(cmd,check=False,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            subprocess.run(['defaults','write',f'/Library/Managed Preferences/{bundle}','DnsOverHttpsMode','-string','off'],check=False)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--api',required=True);ap.add_argument('--key-file',required=True);ap.add_argument('--once',action='store_true');args=ap.parse_args()
    key=Path(args.key_file).read_text().strip();host=platform.node();user=os.getenv('USER') or 'system'
    while True:
        try:
            policy=api(args.api,key,'/api/agent?action=policy-profile&hostname='+urllib.parse.quote(host))
            catalog=policy.get('catalog',[]);approved=set(policy.get('approved_tools',[]));seen=match(catalog,processes())
            running=sorted(k for k,v in seen.items() if v)
            report={'hostname':host,'username':user,'os':platform.system().lower(),'os_version':platform.platform(),'arch':platform.machine(),'agent_version':'1.0.0','installed_tools':running,'running_tools':running}
            api(args.api,key,'/api/agents?action=inventory-report','POST',report)
            browser_policy(catalog,approved)
            for tool,rows in seen.items():
                if rows and tool not in approved:
                    for row in rows:
                        if row['pid'] not in (os.getpid(),os.getppid()):
                            try:os.kill(row['pid'],signal.SIGTERM)
                            except (ProcessLookupError,PermissionError):pass
                    api(args.api,key,'/api/agent?action=security-event','POST',{'hostname':host,'username':user,'tool':tool,'event_type':'UNAPPROVED_AI_BLOCKED','detail':f'Unapproved app/CLI blocked: {tool}'})
        except Exception as exc: print(f'EINSGUARD cycle failed: {exc}',file=sys.stderr)
        if args.once:return
        time.sleep(5)
if __name__=='__main__':main()
