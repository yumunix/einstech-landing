#!/bin/sh
set -eu
[ "$(id -u)" -eq 0 ] || { echo 'Run with sudo.' >&2; exit 1; }
EINSGUARD_API=${1:-${EINSGUARD_API:-}}
EINSGUARD_AGENT_KEY=${2:-${EINSGUARD_AGENT_KEY:-}}
[ -n "$EINSGUARD_API" ] || { echo 'Usage: sudo ./install.sh http://SERVER:3100 AGENT_KEY' >&2; exit 2; }
[ -n "$EINSGUARD_AGENT_KEY" ] || { echo 'Agent key is required. Copy it from AI GUARD server configuration.' >&2; exit 2; }
[ -x /usr/bin/python3 ] || { echo 'python3 is required. Install Apple Command Line Tools or Python 3.' >&2; exit 3; }
src=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
install -d -m 0755 /Library/EINSGUARD /Library/EINSGUARD/bin /Library/EINSGUARD/etc
install -m 0755 "$src/einsguard-agent.py" /Library/EINSGUARD/bin/einsguard-agent
printf '%s' "$EINSGUARD_AGENT_KEY" > /Library/EINSGUARD/etc/agent.key;chmod 0600 /Library/EINSGUARD/etc/agent.key
printf '%s\n' "$EINSGUARD_API" > /Library/EINSGUARD/etc/server.url;chmod 0644 /Library/EINSGUARD/etc/server.url
cat > /Library/LaunchDaemons/com.einstech.einsguard-ai.plist <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict><key>Label</key><string>com.einstech.einsguard-ai</string><key>ProgramArguments</key><array><string>/usr/bin/python3</string><string>/Library/EINSGUARD/bin/einsguard-agent</string><string>--api</string><string>$EINSGUARD_API</string><string>--key-file</string><string>/Library/EINSGUARD/etc/agent.key</string></array><key>RunAtLoad</key><true/><key>KeepAlive</key><true/><key>StandardOutPath</key><string>/Library/Logs/einsguard-ai.log</string><key>StandardErrorPath</key><string>/Library/Logs/einsguard-ai-error.log</string></dict></plist>
EOF
chmod 0644 /Library/LaunchDaemons/com.einstech.einsguard-ai.plist
launchctl bootout system/com.einstech.einsguard-ai 2>/dev/null || true
launchctl bootstrap system /Library/LaunchDaemons/com.einstech.einsguard-ai.plist
sleep 2
launchctl print system/com.einstech.einsguard-ai >/dev/null
echo 'EINSGUARD AI macOS Agent 1.0 installed successfully.'
echo 'Status: sudo ./status.sh'
echo 'Logs: /Library/Logs/einsguard-ai*.log'
