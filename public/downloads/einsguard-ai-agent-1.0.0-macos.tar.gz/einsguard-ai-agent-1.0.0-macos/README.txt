EINSGUARD AI macOS Agent 1.0

Requirements: macOS 13 or later, Python 3, administrator privileges, network access to the AI GUARD server.

Install:
  tar -xzf einsguard-ai-agent-1.0.0-macos.tar.gz
  cd einsguard-ai-agent-1.0.0-macos
  sudo ./install.sh http://SERVER_IP:3100 AGENT_KEY

Status:
  sudo ./status.sh

Uninstall:
  sudo ./uninstall.sh

Logs:
  /Library/Logs/einsguard-ai.log
  /Library/Logs/einsguard-ai-error.log
  /Library/Logs/einsguard-ai-uninstall-*.log

The Agent key is issued by the AI GUARD server administrator. Do not share it publicly.
