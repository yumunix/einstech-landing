# EINSGUARD AI 설치 시작

지원 서버는 Linux x86_64/arm64이며 Docker Compose 또는 Podman Compose가 필요합니다.

```bash
tar -xzf einsguard-ai-0.3.0-trial-linux.tar.gz
cd einsguard-ai-0.3.0-trial
./ai-sentinel-dashboard/release/preflight.sh
./ai-sentinel-dashboard/release/install.sh
```

설치 프로그램은 DB 비밀번호, 세션 비밀값, 에이전트 키를 자동 생성하고 `.env`를
권한 600으로 저장합니다. 관리자 비밀번호는 12자 이상이어야 합니다. 내부 내용
판정은 `사용 안 함`, `Ollama`, `OpenAI 호환 API` 중에서 선택하고 고객사 내부
LLM 주소와 모델명을 입력합니다. 에이전트에는 LLM 접속 정보가 아닌 관리 서버
주소만 입력합니다. 설치 요청을 관리자가 승인하면 장비별 연결 키를 자동 수령합니다.

운영 명령:

```bash
./ai-sentinel-dashboard/release/status.sh
./ai-sentinel-dashboard/release/backup.sh
./ai-sentinel-dashboard/release/update.sh
```

기존 설치의 내부 LLM 설정을 추가하거나 변경할 때는 다음을 실행합니다. 설정 변경만
저장하고 운영 재시작은 자동 수행하지 않습니다.

```bash
./ai-sentinel-dashboard/release/configure-local-ai.sh
```

삭제 명령은 기본적으로 데이터 볼륨을 보존합니다. `--purge DELETE-ALL-DATA`는
백업 없이는 복구할 수 없으므로 운영 승인 후에만 사용하십시오.

상세 내용은 `ai-sentinel-dashboard/deploy/README.md`와
`ai-sentinel-dashboard/release/RELEASE_NOTES.md`를 확인하십시오.
