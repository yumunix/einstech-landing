#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
ENV_FILE=${EINSGUARD_ENV_FILE:-$ROOT/.env.production.local}
DATA_ROOT=${DATA_SOURCE_HOST_ROOT:-$ROOT/data-sources}
umask 077

[ -f "$ENV_FILE" ] || : > "$ENV_FILE"
if ! grep -q '^FINGERPRINT_HMAC_KEY=' "$ENV_FILE"; then
  printf 'FINGERPRINT_HMAC_KEY=%s\n' "$(openssl rand -hex 32)" >> "$ENV_FILE"
fi
if ! grep -q '^DATA_SOURCE_ALLOWED_ROOTS=' "$ENV_FILE"; then
  printf 'DATA_SOURCE_ALLOWED_ROOTS=%s\n' "$DATA_ROOT" >> "$ENV_FILE"
fi
chmod 600 "$ENV_FILE"
mkdir -p "$DATA_ROOT"
chmod 0750 "$DATA_ROOT"
printf 'Native indexer environment ready: %s\n' "$DATA_ROOT"
