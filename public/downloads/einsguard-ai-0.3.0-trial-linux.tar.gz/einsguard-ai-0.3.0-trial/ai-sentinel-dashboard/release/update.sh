#!/bin/sh
set -eu
. "$(dirname -- "$0")/common.sh"
if ! grep -q '^FINGERPRINT_HMAC_KEY=' "$DEPLOY_DIR/.env"; then
  printf 'FINGERPRINT_HMAC_KEY=%s\n' "$(openssl rand -hex 32)" >> "$DEPLOY_DIR/.env"
fi
if ! grep -q '^DATA_SOURCE_HOST_ROOT=' "$DEPLOY_DIR/.env"; then
  if [ "$(id -u)" -eq 0 ]; then data_source_host_root=/var/lib/einsguard-ai/data-sources; else data_source_host_root="$PACKAGE_ROOT/data-sources"; fi
  printf 'DATA_SOURCE_HOST_ROOT=%s\nDATA_SOURCE_ALLOWED_ROOTS=/data-sources\nDATA_SOURCE_VOLUME_OPTIONS=ro,Z\n' "$data_source_host_root" >> "$DEPLOY_DIR/.env"
fi
if grep -q '^DATA_SOURCE_VOLUME_OPTIONS=ro$' "$DEPLOY_DIR/.env"; then sed -i 's/^DATA_SOURCE_VOLUME_OPTIONS=ro$/DATA_SOURCE_VOLUME_OPTIONS=ro,Z/' "$DEPLOY_DIR/.env"; fi
chmod 600 "$DEPLOY_DIR/.env"
data_source_host_root=$(sed -n 's/^DATA_SOURCE_HOST_ROOT=//p' "$DEPLOY_DIR/.env")
mkdir -p "${data_source_host_root:-/var/lib/einsguard-ai/data-sources}"
"$(dirname -- "$0")/backup.sh"
compose build --pull
compose up -d
compose ps
printf '업데이트 완료.\n'
