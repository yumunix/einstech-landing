#!/bin/sh
set -eu
PACKAGE_ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$PACKAGE_ROOT"

fail=0
ok(){ printf 'OK   %s\n' "$1"; }
bad(){ printf 'FAIL %s\n' "$1"; fail=1; }
warn(){ printf 'WARN %s\n' "$1"; }

[ "$(uname -s)" = Linux ] && ok 'Linux 운영체제' || bad 'Linux 서버가 필요합니다.'
arch=$(uname -m)
case "$arch" in x86_64|aarch64|arm64) ok "지원 아키텍처: $arch";; *) bad "지원하지 않는 아키텍처: $arch";; esac
for command_name in openssl curl sha256sum; do
  command -v "$command_name" >/dev/null 2>&1 && ok "$command_name 사용 가능" || bad "$command_name 명령이 필요합니다."
done

if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
  ok 'Docker Compose 사용 가능'
elif command -v podman >/dev/null 2>&1 && (podman compose version >/dev/null 2>&1 || command -v podman-compose >/dev/null 2>&1); then
  ok 'Podman Compose 사용 가능'
else
  bad 'Docker Compose 또는 Podman Compose가 필요합니다.'
fi

free_kb=$(df -Pk . | awk 'NR==2{print $4}')
[ "$free_kb" -ge 10485760 ] && ok '여유 디스크 10GB 이상' || bad '여유 디스크가 10GB 미만입니다.'
mem_kb=$(awk '/MemTotal/{print $2}' /proc/meminfo)
[ "$mem_kb" -ge 3900000 ] && ok '메모리 4GB 이상' || warn '메모리 4GB 미만 — 시험은 가능하지만 4GB 이상을 권장합니다.'

for port in "${DASHBOARD_PORT:-3100}" "${SYSLOG_PORT:-5514}"; do
  if command -v ss >/dev/null 2>&1 && ss -lntup 2>/dev/null | awk '{print $5}' | grep -Eq "[:.]${port}$"; then bad "포트 $port 사용 중"; else ok "포트 $port 사용 가능"; fi
done

[ -f ai-sentinel-dashboard/deploy/docker-compose.yml ] && ok '배포 구성 확인' || bad '패키지 최상위 디렉터리에서 실행해야 합니다.'
[ "$fail" -eq 0 ] || exit 1
printf '\n사전점검을 통과했습니다.\n'
