#!/bin/sh
set -eu

provider=${LOCAL_AI_PROVIDER:-disabled}
base_url=${LOCAL_AI_BASE_URL:-}
model=${LOCAL_AI_MODEL:-}
api_key=${LOCAL_AI_API_KEY:-}
timeout_ms=${LOCAL_AI_TIMEOUT_MS:-5000}
timeout_seconds=$(( (timeout_ms + 999) / 1000 ))
[ "$timeout_seconds" -ge 1 ] || timeout_seconds=1

case "$provider" in
  disabled)
    printf 'Local AI 내용 판정: 사용 안 함\n'
    exit 0
    ;;
  ollama|openai-compatible) ;;
  *) printf '지원하지 않는 Local AI 제공자: %s\n' "$provider" >&2; exit 1 ;;
esac

[ -n "$base_url" ] || { printf 'LOCAL_AI_BASE_URL이 필요합니다.\n' >&2; exit 1; }
[ -n "$model" ] || { printf 'LOCAL_AI_MODEL이 필요합니다.\n' >&2; exit 1; }

auth_args=''
if [ -n "$api_key" ]; then auth_args="Authorization: Bearer $api_key"; fi

if [ "$provider" = ollama ]; then
  root=${base_url%/api/generate}; root=${root%/}
  if [ -n "$auth_args" ]; then
    response=$(curl -fsS --max-time "$timeout_seconds" -H "$auth_args" "$root/api/tags")
  else
    response=$(curl -fsS --max-time "$timeout_seconds" "$root/api/tags")
  fi
else
  root=${base_url%/chat/completions}; root=${root%/v1}; root=${root%/}
  if [ -n "$auth_args" ]; then
    response=$(curl -fsS --max-time "$timeout_seconds" -H "$auth_args" "$root/v1/models")
  else
    response=$(curl -fsS --max-time "$timeout_seconds" "$root/v1/models")
  fi
fi

printf '%s' "$response" | grep -F "$model" >/dev/null 2>&1 || {
  printf 'Local AI 서버에는 연결됐지만 모델을 찾지 못했습니다: %s\n' "$model" >&2
  exit 1
}
printf 'Local AI 연결 확인 완료: %s / %s\n' "$provider" "$model"
