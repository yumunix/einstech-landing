#!/bin/sh
set -eu
. "$(dirname -- "$0")/common.sh"
BACKUP_ROOT=${AI_SENTINEL_BACKUP_DIR:-"$PACKAGE_ROOT/backups"}
stamp=$(date +%Y%m%d-%H%M%S)
target="$BACKUP_ROOT/$stamp"
mkdir -p "$target"
chmod 700 "$BACKUP_ROOT" "$target"
compose exec -T postgres sh -c 'PGPASSWORD="$POSTGRES_PASSWORD" pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Fc' > "$target/database.dump"
cp "$DEPLOY_DIR/.env" "$target/config.env"
chmod 600 "$target/database.dump" "$target/config.env"
sha256sum "$target/database.dump" "$target/config.env" > "$target/SHA256SUMS"
printf '백업 완료: %s\n' "$target"
