#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
./ai-sentinel-dashboard/release/preflight.sh
DEPLOY="$ROOT/ai-sentinel-dashboard/deploy"

if [ ! -f "$DEPLOY/.env" ]; then
  admin_password=${AI_SENTINEL_ADMIN_PASSWORD:-}
  if [ -z "$admin_password" ]; then
    printf '초기 관리자 비밀번호: ' >&2
    stty -echo; IFS= read -r admin_password; stty echo; printf '\n' >&2
  fi
  [ "${#admin_password}" -ge 12 ] || { printf '관리자 비밀번호는 12자 이상이어야 합니다.\n' >&2; exit 1; }
  printf '%s' "$admin_password" | grep -Eq '^[A-Za-z0-9._!@#%+=-]+$' || { printf '비밀번호에는 영문, 숫자 및 ._!@#%%+=-만 사용할 수 있습니다.\n' >&2; exit 1; }
  db_password=$(openssl rand -hex 24)
  session_secret=$(openssl rand -hex 32)
  agent_key=$(openssl rand -hex 32)
  fingerprint_key=$(openssl rand -hex 32)
  data_source_host_root=${DATA_SOURCE_HOST_ROOT:-}
  if [ -z "$data_source_host_root" ]; then
    if [ "$(id -u)" -eq 0 ]; then data_source_host_root=/var/lib/einsguard-ai/data-sources; else data_source_host_root="$ROOT/data-sources"; fi
  fi
  case "$data_source_host_root" in /*) ;; *) printf '내부 문서 호스트 경로는 절대경로여야 합니다.\n' >&2; exit 1 ;; esac
  printf '%s' "$data_source_host_root" | grep -Eq '^/[A-Za-z0-9._/ -]+$' || { printf '내부 문서 호스트 경로에 지원하지 않는 문자가 있습니다.\n' >&2; exit 1; }

  local_ai_provider=${LOCAL_AI_PROVIDER:-}
  if [ -z "$local_ai_provider" ]; then
    printf '\n내부 LLM 내용 판정 방식을 선택하세요.\n' >&2
    printf '  0) 사용 안 함\n  1) Ollama\n  2) OpenAI 호환 API (vLLM·LocalAI·LM Studio 등)\n선택 [0]: ' >&2
    IFS= read -r local_ai_choice
    case "${local_ai_choice:-0}" in
      0) local_ai_provider=disabled ;;
      1) local_ai_provider=ollama ;;
      2) local_ai_provider=openai-compatible ;;
      *) printf '잘못된 Local AI 선택입니다.\n' >&2; exit 1 ;;
    esac
  fi
  local_ai_base_url=${LOCAL_AI_BASE_URL:-}
  local_ai_model=${LOCAL_AI_MODEL:-}
  local_ai_api_key=${LOCAL_AI_API_KEY:-}
  local_ai_timeout_ms=${LOCAL_AI_TIMEOUT_MS:-5000}
  if [ "$local_ai_provider" != disabled ]; then
    # 관리 서버 호스트에서 실행하는 LLM은 Docker 내부에서 host.docker.internal로 접근한다.
    # 별도 내부 서버를 쓰는 고객은 해당 서버의 IP 또는 DNS 주소를 입력하면 된다.
    default_url=http://host.docker.internal:11434
    [ "$local_ai_provider" = openai-compatible ] && default_url=http://host.docker.internal:8000
    if [ -z "$local_ai_base_url" ]; then
      printf '내부 LLM 주소 [%s]: ' "$default_url" >&2; IFS= read -r local_ai_base_url
      local_ai_base_url=${local_ai_base_url:-$default_url}
    fi
    if [ -z "$local_ai_model" ]; then
      printf '사용할 모델명: ' >&2; IFS= read -r local_ai_model
    fi
    if [ "$local_ai_provider" = openai-compatible ] && [ -z "$local_ai_api_key" ]; then
      printf 'API 키 (없으면 Enter): ' >&2
      stty -echo; IFS= read -r local_ai_api_key; stty echo; printf '\n' >&2
    fi
    printf '%s' "$local_ai_base_url" | grep -Eq '^[A-Za-z0-9:/._?&=%%+~-]+$' || { printf '내부 LLM 주소 형식이 올바르지 않습니다.\n' >&2; exit 1; }
    printf '%s' "$local_ai_model" | grep -Eq '^[A-Za-z0-9._:/+-]+$' || { printf '모델명 형식이 올바르지 않습니다.\n' >&2; exit 1; }
    printf '%s' "$local_ai_api_key" | grep -Eq '^[A-Za-z0-9._~+/=-]*$' || { printf 'API 키에 지원하지 않는 문자가 있습니다.\n' >&2; exit 1; }
    if ! LOCAL_AI_PROVIDER="$local_ai_provider" LOCAL_AI_BASE_URL="$local_ai_base_url" LOCAL_AI_MODEL="$local_ai_model" \
      LOCAL_AI_API_KEY="$local_ai_api_key" LOCAL_AI_TIMEOUT_MS="$local_ai_timeout_ms" "$ROOT/ai-sentinel-dashboard/release/check-local-ai.sh"; then
      if [ "${AI_SENTINEL_SKIP_LOCAL_AI_CHECK:-0}" != 1 ]; then
        printf '내부 LLM 연결 확인에 실패했습니다. 주소·모델을 확인하거나 LOCAL_AI_PROVIDER=disabled로 설치하세요.\n' >&2
        exit 1
      fi
      printf '경고: 요청에 따라 Local AI 연결 실패를 무시합니다.\n' >&2
    fi
  fi
  sed -e "s|CHANGE_TO_A_LONG_RANDOM_PASSWORD|$db_password|" \
      -e "s|CHANGE_TO_AT_LEAST_32_RANDOM_CHARACTERS|$session_secret|" \
      -e "s|CHANGE_TO_A_STRONG_ADMIN_PASSWORD|$admin_password|" \
      -e "s|CHANGE_TO_A_64_HEX_CHARACTER_KEY|$agent_key|" \
      -e "s|CHANGE_TO_A_64_HEX_CHARACTER_FINGERPRINT_KEY|$fingerprint_key|" \
      -e "s|DATA_SOURCE_HOST_ROOT=/var/lib/einsguard-ai/data-sources|DATA_SOURCE_HOST_ROOT=$data_source_host_root|" \
      -e "s|INIT_TENANT_NAME=EINSTECH|INIT_TENANT_NAME=${AI_SENTINEL_TENANT_NAME:-EINSTECH}|" \
      -e "s|INIT_TENANT_CODE=einstech|INIT_TENANT_CODE=${AI_SENTINEL_TENANT_CODE:-einstech}|" \
      "$DEPLOY/.env.example" | grep -v '^LOCAL_AI_' > "$DEPLOY/.env"
  {
    printf 'LOCAL_AI_PROVIDER=%s\n' "$local_ai_provider"
    printf 'LOCAL_AI_BASE_URL=%s\n' "$local_ai_base_url"
    printf 'LOCAL_AI_MODEL=%s\n' "$local_ai_model"
    printf 'LOCAL_AI_API_KEY=%s\n' "$local_ai_api_key"
    printf 'LOCAL_AI_TIMEOUT_MS=%s\n' "$local_ai_timeout_ms"
  } >> "$DEPLOY/.env"
  chmod 600 "$DEPLOY/.env"
fi
. "$ROOT/ai-sentinel-dashboard/release/common.sh"
data_source_host_root=$(sed -n 's/^DATA_SOURCE_HOST_ROOT=//p' "$DEPLOY/.env")
data_source_host_root=${data_source_host_root:-/var/lib/einsguard-ai/data-sources}
mkdir -p "$data_source_host_root"
chmod 0750 "$data_source_host_root"
compose up -d --build
compose ps
dashboard_port=$(sed -n 's/^DASHBOARD_PORT=//p' "$DEPLOY/.env")
printf '\n설치 완료: http://서버주소:%s\n' "${dashboard_port:-3100}"
printf '에이전트 키는 %s/.env의 INIT_AGENT_KEY에 저장되어 있습니다.\n' "$DEPLOY"
provider=$(sed -n 's/^LOCAL_AI_PROVIDER=//p' "$DEPLOY/.env")
printf '내부 LLM 내용 판정: %s\n' "${provider:-disabled}"
printf '내부 문서 읽기 전용 루트: %s\n' "$data_source_host_root"
