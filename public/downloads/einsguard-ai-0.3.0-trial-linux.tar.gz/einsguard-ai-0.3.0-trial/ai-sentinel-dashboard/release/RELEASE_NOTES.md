# EINSGUARD AI 0.4.0-internal

- 상단 기능 메뉴를 `홈·장비/사용자·보안·정책·운영` 5개 업무 영역으로 단순화
- 알림과 실제 관리자 승인 화면을 분리하고 현재 위치·하위 메뉴를 명확히 표시
- Windows·macOS·Linux Agent 1.3.0 통합 배포
- 모든 Agent가 서버 주소만으로 등록을 요청하고 승인 후 장비 전용 키를 자동 수령
- 키를 URL이나 설치 명령에 포함하던 기존 설치 경로 중단
- Agent 좌석 반환·장비 해제·로컬 사용자 추적·현재 API 인증 상태 점검 지원

- Linux Docker/Podman 온프레미스 관리 서버
- Windows·Linux·macOS Agent 1.3.0
- AI 도구 인벤토리·세션·정책·위험 제어와 CLI/클립보드 DLP
- Ollama 또는 OpenAI 호환 내부 LLM(vLLM·LocalAI·LM Studio 등) 선택 지원
- 기존 설치용 `configure-local-ai.sh` 설정·연결시험·백업 지원
- 내부 LLM 판정을 수집 응답과 분리해 느린 모델이 에이전트를 지연시키지 않음
- 내부 LLM 장애 시 패턴 판정 유지, 5초 기본 제한시간과 회로 차단기 적용
- 원문은 기본적으로 저장하지 않고 내부 LLM 판정 중에만 메모리에서 사용
- 고객사별 데이터와 에이전트 키 격리
- EINSTECH 회사 내부용 영구 라이선스
- 사용기간과 관리 대상 장비 수 제한 없음
- 별도 라이선스 키 인증이나 기간 갱신 불필요
- PostgreSQL, 대시보드, 파서, TCP/UDP syslog 수집기 포함

브라우저 웹 채팅의 입력창 전체를 직접 수집하려면 브라우저 확장, 보안 프록시 또는
해당 서비스의 공식 감사 연동이 추가로 필요합니다. 현재 에이전트는 Windows
클립보드·CLI 인수와 Linux/macOS CLI 인수를 검사합니다.
