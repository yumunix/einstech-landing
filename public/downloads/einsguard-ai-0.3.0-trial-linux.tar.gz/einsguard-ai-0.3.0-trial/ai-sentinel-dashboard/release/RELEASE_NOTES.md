# EINSGUARD AI 0.3.0-trial

- Linux Docker/Podman 온프레미스 관리 서버
- Windows 1.1.0, Linux 및 macOS 에이전트
- AI 도구 인벤토리·세션·정책·위험 제어와 CLI/클립보드 DLP
- Ollama 또는 OpenAI 호환 내부 LLM(vLLM·LocalAI·LM Studio 등) 선택 지원
- 기존 설치용 `configure-local-ai.sh` 설정·연결시험·백업 지원
- 내부 LLM 판정을 수집 응답과 분리해 느린 모델이 에이전트를 지연시키지 않음
- 내부 LLM 장애 시 패턴 판정 유지, 5초 기본 제한시간과 회로 차단기 적용
- 원문은 기본적으로 저장하지 않고 내부 LLM 판정 중에만 메모리에서 사용
- 고객사별 데이터와 에이전트 키 격리
- 15일 무료 체험, 관리 대상 5대
- Ed25519 서명 월 구독 키와 설치 ID 결합
- 만료 시 핵심 기능 잠금 및 기존 데이터 조회 유지
- PostgreSQL, 대시보드, 파서, TCP/UDP syslog 수집기 포함

브라우저 웹 채팅의 입력창 전체를 직접 수집하려면 브라우저 확장, 보안 프록시 또는
해당 서비스의 공식 감사 연동이 추가로 필요합니다. 현재 에이전트는 Windows
클립보드·CLI 인수와 Linux/macOS CLI 인수를 검사합니다.
