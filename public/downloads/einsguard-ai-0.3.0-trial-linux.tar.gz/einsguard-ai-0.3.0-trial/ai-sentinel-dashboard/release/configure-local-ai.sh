#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
DEPLOY="$ROOT/ai-sentinel-dashboard/deploy"
ENV_FILE="$DEPLOY/.env"
[ -f "$ENV_FILE" ] || { printf '먼저 관리 서버를 설치해 %s를 생성하십시오.\n' "$ENV_FILE" >&2; exit 1; }

provider=${LOCAL_AI_PROVIDER:-}
if [ -z "$provider" ]; then
  printf '내부 LLM 내용 판정 방식을 선택하세요.\n' >&2
  printf '  0) 사용 안 함\n  1) Ollama\n  2) OpenAI 호환 API (vLLM·LocalAI·LM Studio 등)\n선택 [0]: ' >&2
  IFS= read -r choice
  case "${choice:-0}" in
    0) provider=disabled ;;
    1) provider=ollama ;;
    2) provider=openai-compatible ;;
    *) printf '잘못된 Local AI 선택입니다.\n' >&2; exit 1 ;;
  esac
fi
case "$provider" in disabled|ollama|openai-compatible) ;; *) printf '지원하지 않는 제공자입니다: %s\n' "$provider" >&2; exit 1 ;; esac

base_url=${LOCAL_AI_BASE_URL:-}
model=${LOCAL_AI_MODEL:-}
api_key=${LOCAL_AI_API_KEY:-}
timeout_ms=${LOCAL_AI_TIMEOUT_MS:-5000}
case "$timeout_ms" in *[!0-9]*|'') printf '제한시간은 밀리초 단위 정수여야 합니다.\n' >&2; exit 1 ;; esac
[ "$timeout_ms" -ge 1000 ] && [ "$timeout_ms" -le 60000 ] || { printf '제한시간은 1000~60000ms 범위여야 합니다.\n' >&2; exit 1; }

if [ "$provider" != disabled ]; then
  default_url=http://host.docker.internal:11434
  [ "$provider" = openai-compatible ] && default_url=http://host.docker.internal:8000
  if [ -z "$base_url" ]; then
    printf '내부 LLM 주소 [%s]: ' "$default_url" >&2; IFS= read -r base_url
    base_url=${base_url:-$default_url}
  fi
  if [ -z "$model" ]; then printf '사용할 모델명: ' >&2; IFS= read -r model; fi
  if [ "$provider" = openai-compatible ] && [ -z "$api_key" ]; then
    printf 'API 키 (없으면 Enter): ' >&2
    stty -echo; IFS= read -r api_key; stty echo; printf '\n' >&2
  fi
  printf '%s' "$base_url" | grep -Eq '^[A-Za-z0-9:/._?&=%%+~-]+$' || { printf '내부 LLM 주소 형식이 올바르지 않습니다.\n' >&2; exit 1; }
  printf '%s' "$model" | grep -Eq '^[A-Za-z0-9._:/+-]+$' || { printf '모델명 형식이 올바르지 않습니다.\n' >&2; exit 1; }
  printf '%s' "$api_key" | grep -Eq '^[A-Za-z0-9._~+/=-]*$' || { printf 'API 키에 지원하지 않는 문자가 있습니다.\n' >&2; exit 1; }
  LOCAL_AI_PROVIDER="$provider" LOCAL_AI_BASE_URL="$base_url" LOCAL_AI_MODEL="$model" \
    LOCAL_AI_API_KEY="$api_key" LOCAL_AI_TIMEOUT_MS="$timeout_ms" "$ROOT/ai-sentinel-dashboard/release/check-local-ai.sh"
else
  base_url=''; model=''; api_key=''
fi

backup="$ENV_FILE.before-local-ai-$(date +%Y%m%d%H%M%S)"
cp "$ENV_FILE" "$backup"
chmod 600 "$backup"
tmp=$(mktemp "$DEPLOY/.env.local-ai.XXXXXX")
trap 'rm -f "$tmp"' EXIT
awk '!/^LOCAL_AI_(PROVIDER|BASE_URL|MODEL|API_KEY|TIMEOUT_MS)=/' "$ENV_FILE" > "$tmp"
{
  printf 'LOCAL_AI_PROVIDER=%s\n' "$provider"
  printf 'LOCAL_AI_BASE_URL=%s\n' "$base_url"
  printf 'LOCAL_AI_MODEL=%s\n' "$model"
  printf 'LOCAL_AI_API_KEY=%s\n' "$api_key"
  printf 'LOCAL_AI_TIMEOUT_MS=%s\n' "$timeout_ms"
} >> "$tmp"
chmod 600 "$tmp"
mv "$tmp" "$ENV_FILE"
trap - EXIT
printf 'Local AI 설정 저장 완료: %s / %s\n' "$provider" "${model:--}"
printf '이전 설정 백업: %s\n' "$backup"

if [ "${1:-}" = --restart ]; then
  . "$ROOT/ai-sentinel-dashboard/release/common.sh"
  compose up -d --build dashboard
  compose ps dashboard
else
  printf '적용하려면 승인된 점검 시간에 다음을 실행하십시오:\n  %s/ai-sentinel-dashboard/release/update.sh\n' "$ROOT"
fi
