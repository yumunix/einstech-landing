#!/bin/sh
set -eu
. "$(dirname -- "$0")/common.sh"
compose ps
port=$(sed -n 's/^DASHBOARD_PORT=//p' "$DEPLOY_DIR/.env")
curl -fsS -o /dev/null -w 'Dashboard HTTP: %{http_code}\n' "http://127.0.0.1:${port:-3100}/login"
