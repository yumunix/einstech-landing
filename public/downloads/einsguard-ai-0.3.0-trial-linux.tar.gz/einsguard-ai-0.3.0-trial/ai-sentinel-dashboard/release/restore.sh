#!/bin/sh
set -eu
[ "${1:-}" = --confirm ] && [ -n "${2:-}" ] || { printf '사용법: %s --confirm 백업디렉터리\n' "$0" >&2; exit 2; }
backup=$2
[ -f "$backup/database.dump" ] || { printf 'database.dump가 없습니다.\n' >&2; exit 1; }
(cd "$backup" && sha256sum -c SHA256SUMS)
. "$(dirname -- "$0")/common.sh"
backup_fingerprint_key=$(sed -n 's/^FINGERPRINT_HMAC_KEY=//p' "$backup/config.env")
current_fingerprint_key=$(sed -n 's/^FINGERPRINT_HMAC_KEY=//p' "$DEPLOY_DIR/.env")
if [ -n "$backup_fingerprint_key" ] && [ "$backup_fingerprint_key" != "$current_fingerprint_key" ]; then
  printf '문서 지문 비밀키가 백업과 현재 설치에서 다릅니다. DB 복원 전에 config.env의 FINGERPRINT_HMAC_KEY를 안전하게 복구하십시오.\n' >&2
  exit 1
fi
compose stop dashboard parser indexer
compose exec -T postgres sh -c 'PGPASSWORD="$POSTGRES_PASSWORD" pg_restore -U "$POSTGRES_USER" -d "$POSTGRES_DB" --clean --if-exists' < "$backup/database.dump"
compose start dashboard parser indexer
printf '복원 완료. 대시보드를 확인하십시오.\n'
