#!/bin/sh
set -eu
. "$(dirname -- "$0")/common.sh"
if [ "${1:-}" = --purge ] && [ "${2:-}" = DELETE-ALL-DATA ]; then
  compose down -v
  printf '서비스와 데이터 볼륨을 모두 제거했습니다. 백업 없이는 복구할 수 없습니다.\n'
else
  compose down
  printf '서비스를 중지·제거했으며 데이터 볼륨은 보존했습니다.\n'
  printf '데이터까지 삭제하려면 --purge DELETE-ALL-DATA가 필요합니다.\n'
fi
