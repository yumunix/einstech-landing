#!/bin/sh
set -eu
node scripts/migrate.cjs
node scripts/bootstrap.cjs
exec node node_modules/next/dist/bin/next start -p 3100
