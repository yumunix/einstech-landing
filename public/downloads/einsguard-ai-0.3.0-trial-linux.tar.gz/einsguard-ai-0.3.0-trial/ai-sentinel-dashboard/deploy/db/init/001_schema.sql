--
-- PostgreSQL database dump
--

\restrict WiYo0XfhQVdXSisdEbfnYonfsyrYXJdlmQv2ldrR35qKxQrQehBSVfsigwveABf

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ai_admin_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_admin_users (
    id integer NOT NULL,
    username character varying(100) NOT NULL,
    password_hash character varying(200) NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    email character varying(200),
    role character varying(30) DEFAULT 'admin'::character varying NOT NULL,
    tenant_id bigint DEFAULT 1 NOT NULL,
    platform_admin boolean DEFAULT false NOT NULL
);


--
-- Name: ai_admin_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_admin_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_admin_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_admin_users_id_seq OWNED BY public.ai_admin_users.id;


--
-- Name: ai_agent_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_agent_keys (
    id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    key_name character varying(100) NOT NULL,
    key_hash character(64) NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_used_at timestamp with time zone
);


--
-- Name: ai_agent_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_agent_keys_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_agent_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_agent_keys_id_seq OWNED BY public.ai_agent_keys.id;


--
-- Name: ai_agents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_agents (
    hostname character varying(255) NOT NULL,
    os character varying(50) NOT NULL,
    os_version character varying(150),
    arch character varying(50),
    agent_version character varying(30) DEFAULT 'unknown'::character varying NOT NULL,
    username character varying(150),
    installed_tools jsonb DEFAULT '[]'::jsonb NOT NULL,
    running_tools jsonb DEFAULT '[]'::jsonb NOT NULL,
    approved_tools jsonb DEFAULT '["claude", "codex"]'::jsonb NOT NULL,
    last_ip inet,
    first_seen timestamp with time zone DEFAULT now() NOT NULL,
    last_seen timestamp with time zone DEFAULT now() NOT NULL,
    tenant_id bigint DEFAULT 1 NOT NULL
);


--
-- Name: ai_alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_alerts (
    id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    hostname character varying(100),
    username character varying(100),
    tool character varying(50),
    alert_type character varying(50),
    severity character varying(10),
    detail text,
    resolved boolean DEFAULT false,
    session_id character varying(200),
    risk_score integer DEFAULT 0 NOT NULL,
    risk_reason text,
    auto_action character varying(30),
    tenant_id bigint DEFAULT 1 NOT NULL
);


--
-- Name: ai_alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_alerts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_alerts_id_seq OWNED BY public.ai_alerts.id;


--
-- Name: ai_approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_approvals (
    id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    session_id character varying(200),
    hostname character varying(100),
    username character varying(100),
    tool character varying(50),
    work_dir text,
    args text,
    status character varying(20) DEFAULT 'pending'::character varying,
    reviewed_by character varying(100),
    reviewed_at timestamp with time zone,
    token character varying(200),
    tenant_id bigint DEFAULT 1 NOT NULL
);


--
-- Name: ai_approvals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_approvals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_approvals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_approvals_id_seq OWNED BY public.ai_approvals.id;


--
-- Name: ai_blocks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_blocks (
    id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    hostname character varying(100) DEFAULT '*'::character varying,
    username character varying(100) DEFAULT '*'::character varying,
    tool character varying(50) DEFAULT '*'::character varying,
    reason text,
    enabled boolean DEFAULT true,
    tenant_id bigint DEFAULT 1 NOT NULL
);


--
-- Name: ai_blocks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_blocks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_blocks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_blocks_id_seq OWNED BY public.ai_blocks.id;


--
-- Name: ai_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_commands (
    id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    hostname character varying(100),
    username character varying(100),
    tool character varying(50),
    pid integer,
    command character varying(50),
    status character varying(20) DEFAULT 'pending'::character varying,
    executed_at timestamp with time zone,
    heartbeat_at timestamp with time zone,
    session_id character varying(200),
    tenant_id bigint DEFAULT 1 NOT NULL
);


--
-- Name: ai_commands_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_commands_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_commands_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_commands_id_seq OWNED BY public.ai_commands.id;


--
-- Name: ai_licenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_licenses (
    tenant_id bigint NOT NULL,
    installation_id uuid DEFAULT gen_random_uuid() NOT NULL,
    license_type character varying(20) DEFAULT 'perpetual'::character varying NOT NULL,
    plan character varying(30) DEFAULT 'internal'::character varying NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    starts_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone,
    agent_limit integer DEFAULT 0 NOT NULL,
    license_hash character varying(64),
    last_verified_at timestamp with time zone,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ai_licenses_agent_limit_check CHECK ((agent_limit >= 0))
);


--
-- Name: ai_password_resets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_password_resets (
    id integer NOT NULL,
    username character varying(100) NOT NULL,
    token character varying(200) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    tenant_id bigint DEFAULT 1 NOT NULL
);


--
-- Name: ai_password_resets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_password_resets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_password_resets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_password_resets_id_seq OWNED BY public.ai_password_resets.id;


--
-- Name: ai_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_policies (
    id integer NOT NULL,
    policy_name character varying(100),
    hostname character varying(100) DEFAULT '*'::character varying,
    username character varying(100) DEFAULT '*'::character varying,
    allow_hours character varying(50) DEFAULT '0-23'::character varying,
    max_per_hour integer DEFAULT 100,
    enabled boolean DEFAULT true,
    allow_start integer DEFAULT 0,
    allow_end integer DEFAULT 23,
    template_key character varying(50),
    tool character varying(30) DEFAULT '*'::character varying NOT NULL,
    tenant_id bigint DEFAULT 1 NOT NULL
);


--
-- Name: ai_policies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_policies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_policies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_policies_id_seq OWNED BY public.ai_policies.id;


--
-- Name: ai_policy_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_policy_templates (
    template_key character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    description text NOT NULL,
    allow_start integer NOT NULL,
    allow_end integer NOT NULL,
    max_per_hour integer NOT NULL,
    tool character varying(30) DEFAULT '*'::character varying NOT NULL,
    risk_level character varying(20) DEFAULT 'MED'::character varying NOT NULL
);


--
-- Name: ai_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_reports (
    id bigint NOT NULL,
    report_type character varying(50) NOT NULL,
    period_start date NOT NULL,
    period_end date NOT NULL,
    title character varying(255) NOT NULL,
    content jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by character varying(150),
    delivery_status character varying(30) DEFAULT 'draft'::character varying NOT NULL,
    tenant_id bigint DEFAULT 1 NOT NULL
);


--
-- Name: ai_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_reports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_reports_id_seq OWNED BY public.ai_reports.id;


--
-- Name: ai_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_sessions (
    id integer NOT NULL,
    session_id character varying(200),
    hostname character varying(100),
    username character varying(100),
    tool character varying(50),
    work_dir text,
    started_at timestamp with time zone,
    ended_at timestamp with time zone,
    duration_sec integer,
    git_branch character varying(200),
    git_commits text,
    files_changed text,
    args text,
    tenant_id bigint DEFAULT 1 NOT NULL
);


--
-- Name: ai_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_sessions_id_seq OWNED BY public.ai_sessions.id;


--
-- Name: ai_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_settings (
    setting_key character varying(100) NOT NULL,
    setting_value jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by character varying(100),
    tenant_id bigint DEFAULT 1 NOT NULL
);


--
-- Name: ai_shadow_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_shadow_events (
    id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    hostname character varying(255) NOT NULL,
    username character varying(150),
    tool character varying(100) NOT NULL,
    event_type character varying(50) NOT NULL,
    detail text,
    resolved boolean DEFAULT false NOT NULL,
    resolved_at timestamp with time zone,
    resolved_by character varying(150),
    tenant_id bigint DEFAULT 1 NOT NULL
);


--
-- Name: ai_shadow_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_shadow_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_shadow_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_shadow_events_id_seq OWNED BY public.ai_shadow_events.id;


--
-- Name: ai_tenants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_tenants (
    id bigint NOT NULL,
    code character varying(50) NOT NULL,
    name character varying(150) NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ai_tenants_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_tenants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_tenants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_tenants_id_seq OWNED BY public.ai_tenants.id;


--
-- Name: ai_usage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_usage (
    id integer NOT NULL,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    logged_at timestamp with time zone,
    hostname character varying(100),
    username character varying(100),
    tool character varying(50),
    pid integer,
    args text,
    model character varying(100),
    input_tokens bigint DEFAULT 0 NOT NULL,
    output_tokens bigint DEFAULT 0 NOT NULL,
    cost_usd numeric(14,6) DEFAULT 0 NOT NULL,
    tenant_id bigint DEFAULT 1 NOT NULL
);


--
-- Name: ai_usage_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_usage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_usage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_usage_id_seq OWNED BY public.ai_usage.id;


--
-- Name: ai_admin_users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_admin_users ALTER COLUMN id SET DEFAULT nextval('public.ai_admin_users_id_seq'::regclass);


--
-- Name: ai_agent_keys id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_agent_keys ALTER COLUMN id SET DEFAULT nextval('public.ai_agent_keys_id_seq'::regclass);


--
-- Name: ai_alerts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_alerts ALTER COLUMN id SET DEFAULT nextval('public.ai_alerts_id_seq'::regclass);


--
-- Name: ai_approvals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_approvals ALTER COLUMN id SET DEFAULT nextval('public.ai_approvals_id_seq'::regclass);


--
-- Name: ai_blocks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_blocks ALTER COLUMN id SET DEFAULT nextval('public.ai_blocks_id_seq'::regclass);


--
-- Name: ai_commands id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_commands ALTER COLUMN id SET DEFAULT nextval('public.ai_commands_id_seq'::regclass);


--
-- Name: ai_password_resets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_password_resets ALTER COLUMN id SET DEFAULT nextval('public.ai_password_resets_id_seq'::regclass);


--
-- Name: ai_policies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_policies ALTER COLUMN id SET DEFAULT nextval('public.ai_policies_id_seq'::regclass);


--
-- Name: ai_reports id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_reports ALTER COLUMN id SET DEFAULT nextval('public.ai_reports_id_seq'::regclass);


--
-- Name: ai_sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_sessions ALTER COLUMN id SET DEFAULT nextval('public.ai_sessions_id_seq'::regclass);


--
-- Name: ai_shadow_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_shadow_events ALTER COLUMN id SET DEFAULT nextval('public.ai_shadow_events_id_seq'::regclass);


--
-- Name: ai_tenants id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_tenants ALTER COLUMN id SET DEFAULT nextval('public.ai_tenants_id_seq'::regclass);


--
-- Name: ai_usage id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_usage ALTER COLUMN id SET DEFAULT nextval('public.ai_usage_id_seq'::regclass);


--
-- Name: ai_admin_users ai_admin_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_admin_users
    ADD CONSTRAINT ai_admin_users_pkey PRIMARY KEY (id);


--
-- Name: ai_admin_users ai_admin_users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_admin_users
    ADD CONSTRAINT ai_admin_users_username_key UNIQUE (username);


--
-- Name: ai_agent_keys ai_agent_keys_key_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_agent_keys
    ADD CONSTRAINT ai_agent_keys_key_hash_key UNIQUE (key_hash);


--
-- Name: ai_agent_keys ai_agent_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_agent_keys
    ADD CONSTRAINT ai_agent_keys_pkey PRIMARY KEY (id);


--
-- Name: ai_agents ai_agents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_agents
    ADD CONSTRAINT ai_agents_pkey PRIMARY KEY (tenant_id, hostname);


--
-- Name: ai_alerts ai_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_alerts
    ADD CONSTRAINT ai_alerts_pkey PRIMARY KEY (id);


--
-- Name: ai_approvals ai_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_approvals
    ADD CONSTRAINT ai_approvals_pkey PRIMARY KEY (id);


--
-- Name: ai_approvals ai_approvals_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_approvals
    ADD CONSTRAINT ai_approvals_token_key UNIQUE (token);


--
-- Name: ai_blocks ai_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_blocks
    ADD CONSTRAINT ai_blocks_pkey PRIMARY KEY (id);


--
-- Name: ai_commands ai_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_commands
    ADD CONSTRAINT ai_commands_pkey PRIMARY KEY (id);


--
-- Name: ai_licenses ai_licenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_licenses
    ADD CONSTRAINT ai_licenses_pkey PRIMARY KEY (tenant_id);


--
-- Name: ai_password_resets ai_password_resets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_password_resets
    ADD CONSTRAINT ai_password_resets_pkey PRIMARY KEY (id);


--
-- Name: ai_password_resets ai_password_resets_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_password_resets
    ADD CONSTRAINT ai_password_resets_token_key UNIQUE (token);


--
-- Name: ai_policies ai_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_policies
    ADD CONSTRAINT ai_policies_pkey PRIMARY KEY (id);


--
-- Name: ai_policy_templates ai_policy_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_policy_templates
    ADD CONSTRAINT ai_policy_templates_pkey PRIMARY KEY (template_key);


--
-- Name: ai_reports ai_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_reports
    ADD CONSTRAINT ai_reports_pkey PRIMARY KEY (id);


--
-- Name: ai_sessions ai_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_sessions
    ADD CONSTRAINT ai_sessions_pkey PRIMARY KEY (id);


--
-- Name: ai_sessions ai_sessions_session_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_sessions
    ADD CONSTRAINT ai_sessions_session_id_key UNIQUE (session_id);


--
-- Name: ai_settings ai_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_settings
    ADD CONSTRAINT ai_settings_pkey PRIMARY KEY (tenant_id, setting_key);


--
-- Name: ai_shadow_events ai_shadow_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_shadow_events
    ADD CONSTRAINT ai_shadow_events_pkey PRIMARY KEY (id);


--
-- Name: ai_tenants ai_tenants_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_tenants
    ADD CONSTRAINT ai_tenants_code_key UNIQUE (code);


--
-- Name: ai_tenants ai_tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_tenants
    ADD CONSTRAINT ai_tenants_pkey PRIMARY KEY (id);


--
-- Name: ai_usage ai_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_usage
    ADD CONSTRAINT ai_usage_pkey PRIMARY KEY (id);


--
-- Name: idx_ai_agents_last_seen; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_agents_last_seen ON public.ai_agents USING btree (last_seen DESC);


--
-- Name: idx_ai_agents_tenant_seen; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_agents_tenant_seen ON public.ai_agents USING btree (tenant_id, last_seen DESC);


--
-- Name: idx_ai_alerts_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_alerts_session_id ON public.ai_alerts USING btree (session_id);


--
-- Name: idx_ai_alerts_tenant_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_alerts_tenant_time ON public.ai_alerts USING btree (tenant_id, created_at DESC);


--
-- Name: idx_ai_commands_session_command_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_commands_session_command_status ON public.ai_commands USING btree (session_id, command, status);


--
-- Name: idx_ai_commands_tenant_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_commands_tenant_session ON public.ai_commands USING btree (tenant_id, session_id);


--
-- Name: idx_ai_reports_period; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_reports_period ON public.ai_reports USING btree (period_end DESC, report_type);


--
-- Name: idx_ai_reports_tenant_period; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_reports_tenant_period ON public.ai_reports USING btree (tenant_id, period_end DESC);


--
-- Name: idx_ai_sessions_tenant_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_sessions_tenant_time ON public.ai_sessions USING btree (tenant_id, started_at DESC);


--
-- Name: idx_ai_shadow_events_open; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_shadow_events_open ON public.ai_shadow_events USING btree (resolved, created_at DESC);


--
-- Name: idx_ai_usage_hostname; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_usage_hostname ON public.ai_usage USING btree (hostname);


--
-- Name: idx_ai_usage_logged_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_usage_logged_at ON public.ai_usage USING btree (logged_at);


--
-- Name: idx_ai_usage_model_logged_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_usage_model_logged_at ON public.ai_usage USING btree (model, logged_at);


--
-- Name: idx_ai_usage_tenant_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_usage_tenant_time ON public.ai_usage USING btree (tenant_id, logged_at DESC);


--
-- Name: idx_ai_usage_tool; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_usage_tool ON public.ai_usage USING btree (tool);


--
-- Name: idx_alerts_resolved; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alerts_resolved ON public.ai_alerts USING btree (resolved);


--
-- Name: idx_alerts_severity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alerts_severity ON public.ai_alerts USING btree (severity);


--
-- Name: idx_sessions_hostname; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sessions_hostname ON public.ai_sessions USING btree (hostname);


--
-- Name: idx_sessions_started; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sessions_started ON public.ai_sessions USING btree (started_at);


--
-- Name: ai_admin_users ai_admin_users_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_admin_users
    ADD CONSTRAINT ai_admin_users_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.ai_tenants(id);


--
-- Name: ai_agent_keys ai_agent_keys_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_agent_keys
    ADD CONSTRAINT ai_agent_keys_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.ai_tenants(id);


--
-- Name: ai_agents ai_agents_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_agents
    ADD CONSTRAINT ai_agents_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.ai_tenants(id);


--
-- Name: ai_alerts ai_alerts_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_alerts
    ADD CONSTRAINT ai_alerts_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.ai_tenants(id);


--
-- Name: ai_approvals ai_approvals_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_approvals
    ADD CONSTRAINT ai_approvals_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.ai_tenants(id);


--
-- Name: ai_blocks ai_blocks_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_blocks
    ADD CONSTRAINT ai_blocks_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.ai_tenants(id);


--
-- Name: ai_commands ai_commands_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_commands
    ADD CONSTRAINT ai_commands_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.ai_tenants(id);


--
-- Name: ai_licenses ai_licenses_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_licenses
    ADD CONSTRAINT ai_licenses_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.ai_tenants(id) ON DELETE CASCADE;


--
-- Name: ai_password_resets ai_password_resets_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_password_resets
    ADD CONSTRAINT ai_password_resets_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.ai_tenants(id);


--
-- Name: ai_policies ai_policies_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_policies
    ADD CONSTRAINT ai_policies_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.ai_tenants(id);


--
-- Name: ai_reports ai_reports_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_reports
    ADD CONSTRAINT ai_reports_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.ai_tenants(id);


--
-- Name: ai_sessions ai_sessions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_sessions
    ADD CONSTRAINT ai_sessions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.ai_tenants(id);


--
-- Name: ai_settings ai_settings_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_settings
    ADD CONSTRAINT ai_settings_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.ai_tenants(id);


--
-- Name: ai_shadow_events ai_shadow_events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_shadow_events
    ADD CONSTRAINT ai_shadow_events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.ai_tenants(id);


--
-- Name: ai_usage ai_usage_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_usage
    ADD CONSTRAINT ai_usage_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.ai_tenants(id);


--
-- PostgreSQL database dump complete
--

\unrestrict WiYo0XfhQVdXSisdEbfnYonfsyrYXJdlmQv2ldrR35qKxQrQehBSVfsigwveABf
