# AI Sentinel 온프레미스 설치

## 기본 라이선스

- 최초 설치 시 15일 무료 체험이 자동 시작됩니다.
- 체험판은 운영체제와 관계없이 관리 대상 5대까지 등록할 수 있습니다.
- 관리 화면의 `라이선스` 메뉴에서 설치 ID, 남은 기간, 등록 장비 수를 확인합니다.
- 구독 키는 해당 설치 ID에 결합되어 다른 관리 서버에서 재사용할 수 없습니다.
- 만료 시 수집·분석·제어·설정 변경·보고서 생성은 잠기고 기존 데이터 조회와
  라이선스 갱신은 계속 사용할 수 있습니다.

## 설치

필수 조건은 Linux 서버, 4GB 이상 메모리, 10GB 이상 여유 공간과 Docker Compose
또는 Podman Compose입니다. 패키지 최상위 디렉터리에서 먼저 다음을 실행하십시오.

```bash
./ai-sentinel-dashboard/release/preflight.sh
./ai-sentinel-dashboard/release/install.sh
```

설치 중 내부 문서·대화 내용 판정 방식을 선택합니다.

- `Ollama`: 관리 서버 호스트 또는 내부 Ollama 서버의 주소와 모델명을 입력합니다.
- `OpenAI 호환 API`: vLLM, LocalAI, LM Studio 등 `/v1/chat/completions` 호환 주소,
  모델명과 필요 시 API 키를 입력합니다.
- `사용 안 함`: 정규식 기반 민감정보 탐지만 사용합니다.

관리 서버 호스트의 LLM은 기본 주소 `host.docker.internal`로 접근합니다. 다른
서버의 LLM은 해당 내부 IP 또는 DNS 주소를 입력하십시오. 기본 제한시간은 5초이며,
LLM 판정은 사건 수집 응답 뒤 백그라운드로 실행됩니다. 연결 실패 시 설치 단계에서
중단되므로 주소와 모델을 먼저 확인할 수 있습니다.

원문은 기본적으로 데이터베이스에 저장하지 않습니다. 고객사 정책에서
`storeRawChat`을 명시적으로 켠 경우에만 지원 채널의 원문을 제한 기간 보관합니다.
브라우저 웹 채팅 입력창 전체 검사는 별도 브라우저 확장·프록시·공식 감사 연동이
필요하며 기본 에이전트의 클립보드/CLI 검사 범위와 구분해야 합니다.

기존 설치를 0.3.0으로 올리는 경우 내부 LLM 설정을 다음 명령으로 추가합니다.

```bash
./ai-sentinel-dashboard/release/configure-local-ai.sh
```

스크립트는 기존 `.env`를 권한 600의 시간표시 백업으로 보존하고 설정만 갱신합니다.
서비스 재시작은 하지 않으므로 점검 시간에 `release/update.sh`로 반영하십시오.

### 수동 설치

1. `.env.example`을 `.env`로 복사하고 `CHANGE_` 값을 모두 강한 난수로 변경합니다.
2. `docker compose --env-file .env up -d --build`를 실행합니다.
3. `http://서버주소:3100`에서 초기 관리자 계정으로 로그인합니다.
4. 발급한 `INIT_AGENT_KEY`를 에이전트의 `~/.config/ai-sentinel/agent.key`에 권한 600으로 저장합니다.
5. 고객사 서버의 rsyslog가 AI Sentinel 서버의 `${SYSLOG_PORT}` TCP 포트로 전달하도록 설정합니다.

데이터는 `postgres-data`, 수집 로그는 `ai-logs` 볼륨에 보존됩니다. 이메일 설정을
비워두면 외부 메일은 발송되지 않습니다. 운영 전에는 리버스 프록시에서 HTTPS를
적용하고 PostgreSQL 볼륨 백업 정책을 구성해야 합니다.
