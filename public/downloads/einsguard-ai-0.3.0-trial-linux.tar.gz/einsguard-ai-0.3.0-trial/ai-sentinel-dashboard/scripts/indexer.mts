import fs from 'node:fs/promises';
import path from 'node:path';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import pg from 'pg';
import {fingerprintConfigStatus,fingerprintContent} from '../lib/fingerprint.ts';

const {Pool}=pg;const runFile=promisify(execFile);const once=process.argv.includes('--once');
const pool=new Pool({host:process.env.PGHOST||'127.0.0.1',port:Number(process.env.PGPORT||5432),database:process.env.PGDATABASE||'aisentinel',user:process.env.PGUSER||'aisentinel',password:process.env.PGPASSWORD});
const defaultExtensions=new Set(['txt','md','csv','json','log','xml','yaml','yml','sql','js','ts','tsx','jsx','py','sh','ps1','html','htm','pdf','docx','xlsx','pptx']);
const plainExtensions=new Set(['txt','md','csv','json','log','xml','yaml','yml','sql','js','ts','tsx','jsx','py','sh','ps1','html','htm']);
const allowedRoots=String(process.env.DATA_SOURCE_ALLOWED_ROOTS||'/data-sources').split(',').map(value=>path.resolve(value.trim())).filter(Boolean);
let stopping=false;

function within(root:string,target:string){const relative=path.relative(root,target);return relative===''||(!relative.startsWith(`..${path.sep}`)&&relative!=='..'&&!path.isAbsolute(relative));}
function cleanXml(value:string){return value.replace(/<[^>]+>/g,' ').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&').replace(/&quot;/g,'"').replace(/&#39;|&apos;/g,"'").replace(/&#(\d+);/g,(_,number)=>String.fromCodePoint(Number(number))).replace(/\s+/g,' ').trim();}

async function unzipText(file:string,patterns:string[]){
  const parts:string[]=[];
  for(const pattern of patterns){
    try{const {stdout}=await runFile('unzip',['-p',file,pattern],{encoding:'utf8',maxBuffer:32*1024*1024,timeout:30_000});if(stdout)parts.push(cleanXml(stdout));}
    catch(error:any){if(![1,11].includes(Number(error?.code)))throw error;}
  }
  return parts.join(' ');
}

async function extractText(file:string,extension:string){
  if(plainExtensions.has(extension)){
    const buffer=await fs.readFile(file);if(buffer.subarray(0,4096).includes(0))return '';
    return buffer.toString('utf8');
  }
  if(extension==='pdf')return (await runFile('pdftotext',['-enc','UTF-8',file,'-'],{encoding:'utf8',maxBuffer:32*1024*1024,timeout:30_000})).stdout;
  if(extension==='docx')return unzipText(file,['word/document.xml','word/header*.xml','word/footer*.xml']);
  if(extension==='xlsx')return unzipText(file,['xl/sharedStrings.xml','xl/worksheets/sheet*.xml']);
  if(extension==='pptx')return unzipText(file,['ppt/slides/slide*.xml','ppt/notesSlides/notesSlide*.xml']);
  return '';
}

async function* walk(root:string,recursive:boolean):AsyncGenerator<string>{
  const directories=[root];
  while(directories.length){
    const current=directories.pop()!;
    for await(const entry of await fs.opendir(current)){
      if(entry.isSymbolicLink())continue;
      const absolute=path.join(current,entry.name);
      if(entry.isDirectory()&&recursive)directories.push(absolute);
      else if(entry.isFile())yield absolute;
    }
  }
}

async function claimJob(){
  const client=await pool.connect();
  try{
    await client.query('BEGIN');
    const {rows}=await client.query(`SELECT j.id,j.tenant_id,j.data_source_id,s.name,s.source_type,s.location,s.config,s.enabled
      FROM ai_index_jobs j JOIN ai_data_sources s ON s.id=j.data_source_id AND s.tenant_id=j.tenant_id
      WHERE j.status='queued' ORDER BY j.requested_at FOR UPDATE OF j SKIP LOCKED LIMIT 1`);
    if(!rows.length){await client.query('COMMIT');return null;}
    await client.query(`UPDATE ai_index_jobs SET status='running',started_at=NOW(),error=NULL WHERE id=$1`,[rows[0].id]);
    await client.query(`UPDATE ai_data_sources SET status='indexing',last_error=NULL,updated_at=NOW() WHERE id=$1`,[rows[0].data_source_id]);
    await client.query('COMMIT');return rows[0];
  }catch(error){await client.query('ROLLBACK').catch(()=>{});throw error;}finally{client.release();}
}

async function storeDocument(job:any,relativePath:string,stat:any,classificationLevel:string,generated:any){
  const client=await pool.connect();
  try{
    await client.query('BEGIN');
    const existing=await client.query(`SELECT d.id,d.content_hmac,d.fingerprint_count,
      (SELECT COUNT(*)::int FROM ai_document_fingerprints f WHERE f.tenant_id=d.tenant_id AND f.document_id=d.id) stored_fingerprint_count
      FROM ai_indexed_documents d WHERE d.data_source_id=$1 AND d.relative_path=$2 FOR UPDATE`,[job.data_source_id,relativePath]);
    if(existing.rows[0]?.content_hmac===generated.contentHmac
      && Number(existing.rows[0].fingerprint_count)===generated.fingerprints.length
      && Number(existing.rows[0].stored_fingerprint_count)===generated.fingerprints.length){
      await client.query(`UPDATE ai_indexed_documents SET file_size=$2,modified_at=$3,classification_level=$4,
        last_seen_job_id=$5,indexed_at=NOW(),deleted_at=NULL WHERE id=$1`,[existing.rows[0].id,stat.size,stat.mtime,classificationLevel,job.id]);
      await client.query('COMMIT');return Number(existing.rows[0].id);
    }
    const {rows}=await client.query(`INSERT INTO ai_indexed_documents
      (tenant_id,data_source_id,relative_path,content_hmac,file_size,modified_at,classification_level,fingerprint_count,last_seen_job_id,deleted_at)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,NULL)
      ON CONFLICT(data_source_id,relative_path) DO UPDATE SET content_hmac=EXCLUDED.content_hmac,file_size=EXCLUDED.file_size,
        modified_at=EXCLUDED.modified_at,classification_level=EXCLUDED.classification_level,fingerprint_count=EXCLUDED.fingerprint_count,
        last_seen_job_id=EXCLUDED.last_seen_job_id,indexed_at=NOW(),deleted_at=NULL RETURNING id`,
      [job.tenant_id,job.data_source_id,relativePath,generated.contentHmac,stat.size,stat.mtime,classificationLevel,generated.fingerprints.length,job.id]);
    const documentId=Number(rows[0].id);
    await client.query('DELETE FROM ai_document_fingerprints WHERE tenant_id=$1 AND document_id=$2',[job.tenant_id,documentId]);
    if(generated.fingerprints.length)await client.query(`INSERT INTO ai_document_fingerprints(tenant_id,document_id,fingerprint)
      SELECT $1,$2,UNNEST($3::text[]) ON CONFLICT DO NOTHING`,[job.tenant_id,documentId,generated.fingerprints]);
    await client.query('COMMIT');return documentId;
  }catch(error){await client.query('ROLLBACK').catch(()=>{});throw error;}finally{client.release();}
}

async function processJob(job:any){
  let indexed=0,skipped=0,fingerprints=0;
  try{
    if(!job.enabled)throw new Error('데이터 원본이 비활성화되었습니다.');
    if(!['filesystem','nas'].includes(job.source_type))throw new Error('현재 파일시스템과 NAS 인덱싱만 지원합니다.');
    const sourceRoot=await fs.realpath(path.resolve(job.location));
    const resolvedAllowed=await Promise.all(allowedRoots.map(async root=>{try{return await fs.realpath(root);}catch{return root;}}));
    if(!resolvedAllowed.some(root=>within(root,sourceRoot)))throw new Error('데이터 원본 경로가 허용된 읽기 전용 루트 밖에 있습니다.');
    const config=job.config||{};const recursive=config.recursive!==false;
    const extensions=new Set(Array.isArray(config.includeExtensions)&&config.includeExtensions.length?config.includeExtensions:defaultExtensions);
    const excludes=(Array.isArray(config.excludePaths)?config.excludePaths:[]).map((value:string)=>value.replaceAll('\\','/').replace(/\/$/,''));
    const maxBytes=Math.max(1,Math.min(100,Number(config.maxFileSizeMb)||25))*1024*1024;
    const classificationLevel=['PUBLIC','INTERNAL','CONFIDENTIAL','RESTRICTED'].includes(config.classificationLevel)?config.classificationLevel:'INTERNAL';
    for await(const file of walk(sourceRoot,recursive)){
      const relativePath=path.relative(sourceRoot,file).split(path.sep).join('/');
      if(excludes.some((prefix:string)=>relativePath===prefix||relativePath.startsWith(`${prefix}/`))){skipped++;continue;}
      const extension=path.extname(file).slice(1).toLowerCase();if(!extensions.has(extension)){skipped++;continue;}
      const stat=await fs.stat(file);if(stat.size>maxBytes){skipped++;continue;}
      const realFile=await fs.realpath(file);if(!within(sourceRoot,realFile)){skipped++;continue;}
      try{
        const content=await extractText(realFile,extension);const generated=fingerprintContent(Number(job.tenant_id),content);
        if(generated.status!=='ready'||!generated.fingerprints.length){skipped++;continue;}
        await storeDocument(job,relativePath,stat,classificationLevel,generated);indexed++;fingerprints+=generated.fingerprints.length;
      }catch(error){skipped++;console.error(`[indexer] skipped source=${job.data_source_id} file=${relativePath} reason=${error instanceof Error?error.message:'extract failed'}`);}
    }
    const client=await pool.connect();
    try{
      await client.query('BEGIN');
      const removed=await client.query(`UPDATE ai_indexed_documents SET deleted_at=NOW(),fingerprint_count=0
        WHERE tenant_id=$1 AND data_source_id=$2 AND deleted_at IS NULL AND last_seen_job_id IS DISTINCT FROM $3 RETURNING id`,[job.tenant_id,job.data_source_id,job.id]);
      if(removed.rows.length)await client.query('DELETE FROM ai_document_fingerprints WHERE tenant_id=$1 AND document_id=ANY($2::bigint[])',[job.tenant_id,removed.rows.map(row=>row.id)]);
      await client.query(`UPDATE ai_index_jobs SET status='completed',completed_at=NOW(),files_indexed=$2,files_skipped=$3,fingerprints_indexed=$4 WHERE id=$1`,[job.id,indexed,skipped,fingerprints]);
      await client.query(`UPDATE ai_data_sources SET status='ready',last_indexed_at=NOW(),last_error=NULL,updated_at=NOW() WHERE id=$1`,[job.data_source_id]);
      await client.query('COMMIT');
    }catch(error){await client.query('ROLLBACK').catch(()=>{});throw error;}finally{client.release();}
  }catch(error){
    const reason=(error instanceof Error?error.message:'인덱싱 실패').slice(0,1000);
    await pool.query(`UPDATE ai_index_jobs SET status='failed',completed_at=NOW(),files_indexed=$2,files_skipped=$3,fingerprints_indexed=$4,error=$5 WHERE id=$1`,[job.id,indexed,skipped,fingerprints,reason]).catch(()=>{});
    await pool.query(`UPDATE ai_data_sources SET status='error',last_error=$2,updated_at=NOW() WHERE id=$1`,[job.data_source_id,reason.slice(0,500)]).catch(()=>{});
  }
}

async function main(){
  if(!fingerprintConfigStatus().configured)throw new Error('FINGERPRINT_HMAC_KEY must be at least 32 random bytes encoded as hex.');
  while(!stopping){const job=await claimJob();if(job)await processJob(job);else if(once)break;else await new Promise(resolve=>setTimeout(resolve,2000));}
}
process.on('SIGTERM',()=>{stopping=true;});process.on('SIGINT',()=>{stopping=true;});
main().catch(error=>{console.error('[indexer] fatal:',error instanceof Error?error.message:error);process.exitCode=1;}).finally(()=>pool.end());
