#!/usr/bin/env bash
set -euo pipefail

MODE="${1:-}"
BACKUP_DIR="${2:-}"
if [[ "$MODE" != "--validate-only" && "$MODE" != "--restore" ]]; then
  echo "Usage: $0 --validate-only BACKUP_DIR"
  echo "       RESTORE_CONFIRM=RESTORE_AI_GUARD $0 --restore BACKUP_DIR"
  exit 2
fi
if [[ -z "$BACKUP_DIR" || ! -d "$BACKUP_DIR" || ! -f "$BACKUP_DIR/SHA256SUMS" || ! -f "$BACKUP_DIR/backup.json" ]]; then
  echo "Invalid AI GUARD backup directory"
  exit 2
fi
cd "$BACKUP_DIR"
sha256sum --check SHA256SUMS
echo "Backup integrity: OK"
if [[ "$MODE" == "--validate-only" ]]; then exit 0; fi
if [[ "${RESTORE_CONFIRM:-}" != "RESTORE_AI_GUARD" ]]; then
  echo "Restore refused. Set RESTORE_CONFIRM=RESTORE_AI_GUARD after maintenance approval."
  exit 3
fi
if [[ "$(id -u)" -ne 0 ]]; then echo "Restore must be run as root."; exit 3; fi

APP_DIR="${AI_GUARD_APP_DIR:-/home/ai/ai-sentinel-dashboard}"
systemctl stop ai-sentinel-dashboard.service
if [[ -f database.dump ]]; then
  pg_restore --clean --if-exists --no-owner --no-privileges --dbname="${PGDATABASE:-aisentinel}" database.dump
fi
if [[ -d environment ]]; then
  install -m 600 environment/.env.production.local "$APP_DIR/.env.production.local" 2>/dev/null || true
  install -m 600 environment/.env.local "$APP_DIR/.env.local" 2>/dev/null || true
  chown ai:ai "$APP_DIR"/.env.production.local "$APP_DIR"/.env.local 2>/dev/null || true
fi
systemctl start ai-sentinel-dashboard.service
echo "Restore completed. Verify the service and login before ending the maintenance window."
