const crypto=require('crypto');
const bcrypt=require('bcryptjs');
const {Client}=require('pg');

async function main(){
  const db=new Client(); await db.connect();
  const code=process.env.INIT_TENANT_CODE||'einstech'; const name=process.env.INIT_TENANT_NAME||'EINSTECH';
  const username=process.env.INIT_ADMIN_USER||'admin'; const password=process.env.INIT_ADMIN_PASSWORD;
  const agentKey=process.env.INIT_AGENT_KEY;
  if(!password||!agentKey)throw new Error('INIT_ADMIN_PASSWORD and INIT_AGENT_KEY are required');
  await db.query('BEGIN');
  try{
    const {rows}=await db.query(`INSERT INTO ai_tenants(code,name) VALUES($1,$2) ON CONFLICT(code) DO UPDATE SET name=EXCLUDED.name RETURNING id`,[code,name]);const tenantId=rows[0].id;
    const hash=await bcrypt.hash(password,12);
    await db.query(`INSERT INTO ai_admin_users(username,password_hash,email,role,tenant_id,platform_admin) VALUES($1,$2,$3,'admin',$4,true)
      ON CONFLICT(username) DO NOTHING`,[username,hash,process.env.INIT_ADMIN_EMAIL||null,tenantId]);
    const keyHash=crypto.createHash('sha256').update(agentKey).digest('hex');
    await db.query(`INSERT INTO ai_agent_keys(tenant_id,key_name,key_hash) VALUES($1,'기본 에이전트 키',$2) ON CONFLICT(key_hash) DO NOTHING`,[tenantId,keyHash]);
    await db.query(`INSERT INTO ai_licenses(tenant_id,license_type,plan,agent_limit) VALUES($1,'perpetual','internal',0)
      ON CONFLICT(tenant_id) DO NOTHING`,[tenantId]);
    await db.query(`INSERT INTO ai_settings(setting_key,setting_value,updated_by,tenant_id) VALUES
      ('retention','{"days":90,"enabled":false}'::jsonb,'bootstrap',$1),('data_protection','{"maskSecrets":true,"maskEmails":true}'::jsonb,'bootstrap',$1)
      ON CONFLICT(tenant_id,setting_key) DO NOTHING`,[tenantId]);
    await db.query(`INSERT INTO ai_onboarding_state(tenant_id) VALUES($1)
      ON CONFLICT(tenant_id) DO NOTHING`,[tenantId]);
    await db.query(`INSERT INTO ai_organization_profiles(tenant_id,company_name,updated_by) VALUES($1,$2,'bootstrap')
      ON CONFLICT(tenant_id) DO UPDATE SET company_name=EXCLUDED.company_name,updated_at=NOW()
      WHERE ai_organization_profiles.updated_by='bootstrap'`,[tenantId,name]);
    await db.query(`INSERT INTO ai_classification_rules
      (tenant_id,name,classification_level,rule_type,pattern,action,weight,updated_by) VALUES
      ($1,'기밀 표시','RESTRICTED','keyword','대외비','block',100,'bootstrap'),
      ($1,'영문 기밀 표시','RESTRICTED','keyword','confidential','block',100,'bootstrap'),
      ($1,'내부 전용 표시','INTERNAL','keyword','internal use only','audit',60,'bootstrap'),
      ($1,'고객 정보 표시','CONFIDENTIAL','keyword','고객정보','warn',80,'bootstrap')
      ON CONFLICT(tenant_id,name) DO NOTHING`,[tenantId]);
    await db.query(`INSERT INTO ai_policy_templates(template_key,name,description,allow_start,allow_end,max_per_hour,tool,risk_level) VALUES
      ('standard','표준','일반 업무용 기본 정책',8,22,30,'*','MED'),
      ('strict','엄격','중요 시스템용 제한 정책',9,18,10,'*','HIGH'),
      ('approval','승인 필요','제한 도구를 승인 절차로 운영',8,20,15,'*','HIGH'),
      ('blocked','차단','사용을 원칙적으로 차단',0,0,0,'*','CRITICAL')
      ON CONFLICT(template_key) DO NOTHING`);
    await db.query('COMMIT'); console.log(`AI Sentinel initialized: ${name} (${code})`);
  }catch(e){await db.query('ROLLBACK');throw e;}finally{await db.end();}
}
main().catch(e=>{console.error(e);process.exit(1)});
