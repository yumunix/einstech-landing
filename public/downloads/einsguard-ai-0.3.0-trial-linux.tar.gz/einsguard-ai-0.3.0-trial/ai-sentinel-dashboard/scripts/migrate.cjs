const fs=require('fs');
const path=require('path');
const {Client}=require('pg');

// 20260808 migrations are already represented in the shipped base schema.
// These later migrations must run on both fresh installs and upgrades.
const migrations=[
  '20260812_ai_catalog_management.sql',
  '20260812_ai_subscriptions.sql',
  '20260812_alert_read_delete.sql',
  '20260812_dlp_audit.sql',
  '20260812_windows_enrollment.sql',
  '20260817_local_ai_verification.sql',
  '20260817_onboarding_foundation.sql',
  '20260817_fingerprint_index.sql',
  '20260817_agent_discovery.sql',
  '20260824_internal_perpetual_license.sql',
  '20260824_active_session_lifecycle.sql',
  '20260824_agent_seat_lifecycle.sql',
  '20260831_agent_removal_approval.sql',
];

async function main(){
  const db=new Client();
  await db.connect();
  try{
    await db.query(`CREATE TABLE IF NOT EXISTS ai_schema_migrations(
      name varchar(255) PRIMARY KEY,applied_at timestamptz NOT NULL DEFAULT NOW())`);
    for(const name of migrations){
      const exists=await db.query('SELECT 1 FROM ai_schema_migrations WHERE name=$1',[name]);
      if(exists.rowCount)continue;
      const sql=fs.readFileSync(path.join(__dirname,'..','db','migrations',name),'utf8');
      await db.query(sql);
      await db.query('INSERT INTO ai_schema_migrations(name) VALUES($1)',[name]);
      console.log(`Applied migration: ${name}`);
    }
  }finally{
    await db.end();
  }
}

main().catch(error=>{console.error(error);process.exit(1)});
