import test from 'node:test';
import assert from 'node:assert/strict';
import {cidrContains,enumerateIpv4Hosts,isPrivateIpv4Cidr,normalizeAgentNetworks,parseIpv4Cidr,usableHostCount} from '../lib/discovery.ts';

test('CIDR을 네트워크 주소로 정규화한다',()=>assert.equal(parseIpv4Cidr('192.168.1.44/24').cidr,'192.168.1.0/24'));
test('사설 대역만 허용한다',()=>{assert.equal(isPrivateIpv4Cidr('10.3.0.0/16'),true);assert.equal(isPrivateIpv4Cidr('8.8.8.0/24'),false);});
test('등록 범위 포함 여부를 검사한다',()=>{assert.equal(cidrContains('192.168.0.0/16','192.168.20.0/24'),true);assert.equal(cidrContains('192.168.0.0/24','192.168.1.0/24'),false);});
test('네트워크·브로드캐스트 주소를 제외한다',()=>{assert.equal(usableHostCount('192.168.1.0/30'),2);assert.deepEqual(enumerateIpv4Hosts('192.168.1.0/30'),['192.168.1.1','192.168.1.2']);});
test('과도한 검색 범위를 거부한다',()=>assert.throws(()=>enumerateIpv4Hosts('10.0.0.0/8'),/초과/));
test('Agent 네트워크 값을 제한·정규화한다',()=>assert.deepEqual(normalizeAgentNetworks(['192.168.1.4','bad','127.0.0.1'],['AA-BB-CC-DD-EE-FF','bad']),{localIps:['192.168.1.4'],macAddresses:['aa:bb:cc:dd:ee:ff']}));
