import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import test from 'node:test';
import {
  OnboardingInputError,
  validCidr,
  validDomain,
  validHttpUrl,
  validateClassificationRules,
  validateDlpPolicy,
  validateDataSources,
  validateDestinations,
  validateOrganization,
} from '../lib/onboarding.ts';
import {validateBackupPolicy} from '../lib/config-backup.ts';
import {fingerprintContent,normalizeFingerprintTokens} from '../lib/fingerprint.ts';
import {validCardNumber,validateReportedEvidence} from '../lib/dlp-evidence.ts';

test('회사 기본정보를 정규화하고 중복을 제거한다',()=>{
  const value=validateOrganization({
    company_name:' Test Corp ',
    company_domains:['EXAMPLE.COM','example.com'],
    internal_cidrs:['10.0.0.0/8','2001:db8::/32'],
    timezone:'Asia/Seoul',
    data_residency:'onpremise',
  });
  assert.equal(value.companyName,'Test Corp');
  assert.deepEqual(value.domains,['example.com']);
  assert.deepEqual(value.cidrs,['10.0.0.0/8','2001:db8::/32']);
});

test('도메인·CIDR·URL 경계값을 검증한다',()=>{
  assert.equal(validDomain('*.example.com',true),true);
  assert.equal(validDomain('localhost'),false);
  assert.equal(validCidr('10.10.0.0/16'),true);
  assert.equal(validCidr('10.10.0.0/33'),false);
  assert.equal(validHttpUrl('https://ai.example.com/v1'),true);
  assert.equal(validHttpUrl('https://user:pass@ai.example.com'),false);
});

test('잘못된 IANA 시간대를 거부한다',()=>{
  assert.throws(()=>validateOrganization({company_name:'Test',timezone:'Mars/Seoul'}),OnboardingInputError);
});

test('중복 AI 목적지와 자격증명 포함 URL을 거부한다',()=>{
  assert.throws(()=>validateDestinations([
    {name:'내부 AI',destination_type:'internal_ai',match_type:'domain',match_value:'ai.example.com',decision:'allow'},
    {name:'내부 AI 2',destination_type:'internal_ai',match_type:'domain',match_value:'AI.EXAMPLE.COM',decision:'audit'},
  ]),OnboardingInputError);
  assert.throws(()=>validateDestinations([
    {name:'외부 AI',destination_type:'approved_external_ai',match_type:'url',match_value:'https://user:pass@ai.example.com',decision:'audit'},
  ]),OnboardingInputError);
});

test('실행 안전성이 준비되지 않은 regex 분류 규칙을 거부한다',()=>{
  assert.throws(()=>validateClassificationRules([
    {name:'무제한 정규식',classification_level:'RESTRICTED',rule_type:'regex',pattern:'.*',action:'block',weight:100},
  ]),OnboardingInputError);
});

test('데이터 원본에 원문 자격증명을 저장하지 않는다',()=>{
  assert.throws(()=>validateDataSources([
    {name:'NAS 문서',source_type:'nas',location:'/einstech-doc',config:{password:'do-not-store'}},
  ]),OnboardingInputError);
  assert.throws(()=>validateDataSources([
    {name:'NAS 문서',source_type:'nas',location:'/einstech-doc',config:{},secret_ref:'client-controlled'},
  ]),OnboardingInputError);
  assert.deepEqual(validateDataSources([
    {name:'NAS 문서',source_type:'nas',location:'/einstech-doc',config:{recursive:true,includeExtensions:['pdf','docx']}},
  ])[0].location,'/einstech-doc');
});

test('문서 원문 대신 고객사별 HMAC 지문을 생성한다',()=>{
  const previous=process.env.FINGERPRINT_HMAC_KEY;
  process.env.FINGERPRINT_HMAC_KEY='ab'.repeat(32);
  try{
    const document='이 문서는 인스테크 고객사 내부 프로젝트 일정과 보안 구성 방식을 설명하며 외부 공개를 금지합니다. 세부 작업 순서와 책임자 역시 회사 내부 정보입니다.';
    const excerpt='고객사 내부 프로젝트 일정과 보안 구성 방식을 설명하며 외부 공개를 금지합니다. 세부 작업 순서와 책임자';
    const full=fingerprintContent(1,document);const partial=fingerprintContent(1,excerpt);
    assert.equal(full.status,'ready');assert.equal(partial.status,'ready');
    const overlap=partial.fingerprints.filter(hash=>full.fingerprints.includes(hash));
    assert.ok(overlap.length>=2,`지문 공통값이 부족합니다: ${overlap.length}`);
    assert.equal(document.includes(full.fingerprints[0]||''),false);
    assert.deepEqual(normalizeFingerprintTokens('기밀\n  문서'),['기밀','문서']);
  }finally{
    if(previous===undefined)delete process.env.FINGERPRINT_HMAC_KEY;else process.env.FINGERPRINT_HMAC_KEY=previous;
  }
});

test('카드번호는 Luhn 검증을 통과한 보고만 허용한다',()=>{
  const valid='4111 1111 1111 1111';
  const invalid='1234 5678 9012 3456';
  assert.equal(validCardNumber(valid),true);
  assert.equal(validCardNumber(invalid),false);
  assert.equal(validateReportedEvidence('CARD_NUMBER',crypto.createHash('sha256').update(invalid).digest('hex'),`process-id ${invalid}`),'invalid');
  assert.equal(validateReportedEvidence('CARD_NUMBER',crypto.createHash('sha256').update(valid).digest('hex'),`card ${valid}`),'valid');
});

test('DLP 보호 채널과 보관기간을 안전한 범위로 검증한다',()=>{
  const policy=validateDlpPolicy({scanFileUploads:true,storeRawChat:false,evidenceRetentionDays:365});
  assert.equal(policy.scanFileUploads,true);
  assert.equal(policy.storeRawChat,false);
  assert.throws(()=>validateDlpPolicy({evidenceRetentionDays:1}),OnboardingInputError);
});

test('설정 백업은 지정된 NAS 내부 경로와 하나 이상의 대상을 요구한다',()=>{
  const policy=validateBackupPolicy({storagePath:'/einstech-ai/05-backups/ai-sentinel/internal',includeDatabase:true,includeEnvironment:false,includeApplicationConfig:false});
  assert.equal(policy.storagePath,'/einstech-ai/05-backups/ai-sentinel/internal');
  assert.throws(()=>validateBackupPolicy({storagePath:'/tmp/backup'}));
  assert.throws(()=>validateBackupPolicy({includeDatabase:false,includeEnvironment:false,includeApplicationConfig:false}));
});
