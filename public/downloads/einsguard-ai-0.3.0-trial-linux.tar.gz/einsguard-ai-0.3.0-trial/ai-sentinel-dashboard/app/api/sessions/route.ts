import { NextRequest,NextResponse } from 'next/server';
import pool from '@/lib/db';
import {requireRole} from '@/lib/auth';

export async function GET(req:NextRequest) {
  const auth=await requireRole(req,['admin','security','auditor','viewer']);if(auth.response)return auth.response;const tenantId=auth.user!.tenantId;
  const [sessions, topUsers, topServers] = await Promise.all([
    pool.query(`
      SELECT session_id, hostname, username, tool, work_dir,
             started_at, ended_at, duration_sec, git_branch, git_commits, files_changed, args
      FROM ai_sessions WHERE tenant_id=$1
      ORDER BY started_at DESC LIMIT 50
    `,[tenantId]),
    pool.query(`
      SELECT username, COUNT(*)::int as session_count, AVG(duration_sec)::int as avg_duration
      FROM ai_sessions
      WHERE started_at > NOW() - INTERVAL '7 days' AND tenant_id=$1
      GROUP BY username ORDER BY session_count DESC LIMIT 10
    `,[tenantId]),
    pool.query(`
      SELECT hostname, COUNT(*)::int as session_count, COUNT(DISTINCT username)::int as user_count
      FROM ai_sessions
      WHERE started_at > NOW() - INTERVAL '7 days' AND tenant_id=$1
      GROUP BY hostname ORDER BY session_count DESC
    `,[tenantId]),
  ]);

  return NextResponse.json({
    sessions: sessions.rows,
    topUsers: topUsers.rows,
    topServers: topServers.rows,
  });
}
