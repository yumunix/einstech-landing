import { NextRequest, NextResponse } from 'next/server';
import crypto from 'node:crypto';
import pool from '@/lib/db';
import { verifyAgentKey } from '@/lib/agent-auth';
import { signRemovalToken, verifyRemovalToken } from '@/lib/removal-token';

// 에이전트 자가 제거는 관리 서버 관리자 승인을 거쳐야 한다.
// 제거 스크립트가 이 엔드포인트로 요청을 열고, 관리자가 대시보드에서 승인하면
// 서명된 제거 토큰을 받아 그때부터 실제 제거를 진행한다.

const clientIp = (req: NextRequest) => (req.headers.get('x-forwarded-for') || '').split(',')[0].trim() || null;

export async function GET(req: NextRequest) {
  const verify = req.nextUrl.searchParams.get('verify');
  if (verify) {
    const decoded = verifyRemovalToken(verify);
    return NextResponse.json(
      decoded ? { valid: true, hostname: decoded.hostname } : { valid: false },
      { status: decoded ? 200 : 401 },
    );
  }

  const agent = await verifyAgentKey(req.headers.get('x-ai-sentinel-key'));
  if (!agent.valid || !agent.tenantId || !agent.hostname) {
    return NextResponse.json({ error: 'Unauthorized agent' }, { status: 401 });
  }
  const { rows } = await pool.query(
    `SELECT id,status FROM ai_agent_removal_requests
       WHERE tenant_id=$1 AND LOWER(hostname)=LOWER($2) AND created_at>NOW()-INTERVAL '24 hours'
       ORDER BY created_at DESC LIMIT 1`,
    [agent.tenantId, agent.hostname],
  );
  if (!rows.length) return NextResponse.json({ status: 'none' });
  const row = rows[0];
  if (row.status === 'approved') {
    return NextResponse.json({
      status: 'approved',
      removal_token: signRemovalToken({
        hostname: agent.hostname,
        tenantId: Number(agent.tenantId),
        removalId: Number(row.id),
      }),
    });
  }
  return NextResponse.json({ status: row.status });
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const agent = await verifyAgentKey(req.headers.get('x-ai-sentinel-key'));
  if (!agent.valid || !agent.tenantId || !agent.hostname) {
    return NextResponse.json({ error: 'Unauthorized agent' }, { status: 401 });
  }
  const hostname = agent.hostname;

  if (body.action === 'complete') {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const done = await client.query(
        `UPDATE ai_agent_removal_requests SET status='completed',completed_at=NOW()
           WHERE tenant_id=$1 AND LOWER(hostname)=LOWER($2) AND status='approved'`,
        [agent.tenantId, hostname],
      );
      if (!done.rowCount) {
        await client.query('ROLLBACK');
        return NextResponse.json({ error: '승인된 제거 요청이 없습니다.' }, { status: 409 });
      }
      await client.query(
        `UPDATE ai_agents SET status='retired',retired_at=NOW(),retired_by='agent-removal',running_tools='[]'::jsonb
           WHERE tenant_id=$1 AND LOWER(hostname)=LOWER($2) AND status='active'`,
        [agent.tenantId, hostname],
      );
      await client.query(
        `UPDATE ai_agent_keys SET enabled=false,revoked_at=NOW(),revoked_by='agent-removal'
           WHERE tenant_id=$1 AND LOWER(hostname)=LOWER($2) AND enabled=true`,
        [agent.tenantId, hostname],
      );
      await client.query(
        `UPDATE ai_agent_enrollments SET status='revoked',issued_key=NULL
           WHERE tenant_id=$1 AND LOWER(hostname)=LOWER($2) AND status IN ('approved','claimed')`,
        [agent.tenantId, hostname],
      );
      await client.query(
        `UPDATE ai_agent_users SET status='inactive',inactive_at=COALESCE(inactive_at,NOW())
           WHERE tenant_id=$1 AND LOWER(hostname)=LOWER($2) AND status='active'`,
        [agent.tenantId, hostname],
      );
      await client.query('COMMIT');
      return NextResponse.json({ ok: true });
    } catch (e) {
      await client.query('ROLLBACK');
      throw e;
    } finally {
      client.release();
    }
  }

  // 기본 동작: 제거 요청 생성 (이미 대기/승인 상태면 그대로 반환)
  const existing = await pool.query(
    `SELECT status FROM ai_agent_removal_requests
       WHERE tenant_id=$1 AND LOWER(hostname)=LOWER($2) AND status IN ('pending','approved')
         AND created_at>NOW()-INTERVAL '24 hours' ORDER BY created_at DESC LIMIT 1`,
    [agent.tenantId, hostname],
  );
  if (existing.rows.length) {
    return NextResponse.json({ ok: true, status: existing.rows[0].status, reused: true });
  }
  await pool.query(
    `INSERT INTO ai_agent_removal_requests(tenant_id,request_hash,hostname,username,os_version,remote_ip,reason)
       VALUES($1,$2,$3,$4,$5,$6::inet,$7)`,
    [
      agent.tenantId,
      crypto.randomBytes(32).toString('hex'),
      hostname,
      String(body.username || '').slice(0, 150) || null,
      String(body.os_version || '').slice(0, 150) || null,
      clientIp(req),
      String(body.reason || '').slice(0, 500) || null,
    ],
  );
  return NextResponse.json({ ok: true, status: 'pending' });
}
