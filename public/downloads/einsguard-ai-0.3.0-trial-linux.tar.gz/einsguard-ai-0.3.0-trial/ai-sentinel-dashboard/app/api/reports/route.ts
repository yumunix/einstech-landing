import { NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/db';
import { requireRole } from '@/lib/auth';
import { requireActiveLicense } from '@/lib/license';

async function buildWeeklyReport(tenantId:number) {
  const [usage, sessions, alerts, shadow, agents, topUsers] = await Promise.all([
    pool.query(`SELECT COUNT(*)::int executions,COUNT(DISTINCT username)::int users,COUNT(DISTINCT hostname)::int hosts,
      COALESCE(SUM(input_tokens+output_tokens),0)::bigint tokens,COALESCE(SUM(cost_usd),0)::numeric cost_usd
      FROM ai_usage WHERE logged_at>=CURRENT_DATE-INTERVAL '7 days' AND tenant_id=$1`,[tenantId]),
    pool.query(`SELECT COUNT(*)::int total,COUNT(*) FILTER(WHERE ended_at IS NULL)::int incomplete,
      COALESCE(SUM(duration_sec),0)::bigint duration_sec FROM ai_sessions WHERE started_at>=CURRENT_DATE-INTERVAL '7 days' AND tenant_id=$1`,[tenantId]),
    pool.query(`SELECT severity,COUNT(*)::int count,COUNT(*) FILTER(WHERE resolved=false)::int unresolved
      FROM ai_alerts WHERE created_at>=CURRENT_DATE-INTERVAL '7 days' AND tenant_id=$1 GROUP BY severity ORDER BY severity`,[tenantId]),
    pool.query(`SELECT COUNT(*)::int total,COUNT(*) FILTER(WHERE resolved=false)::int unresolved
      FROM ai_shadow_events WHERE created_at>=CURRENT_DATE-INTERVAL '7 days' AND tenant_id=$1`,[tenantId]),
    pool.query(`SELECT COUNT(*)::int total,COUNT(*) FILTER(WHERE last_seen>NOW()-INTERVAL '5 minutes')::int online FROM ai_agents WHERE tenant_id=$1`,[tenantId]),
    pool.query(`SELECT username,COUNT(*)::int executions FROM ai_usage WHERE logged_at>=CURRENT_DATE-INTERVAL '7 days'
      AND tenant_id=$1 GROUP BY username ORDER BY executions DESC LIMIT 10`,[tenantId]),
  ]);
  const periodEnd=new Date(); const periodStart=new Date(); periodStart.setDate(periodStart.getDate()-6);
  return { periodStart:periodStart.toISOString().slice(0,10),periodEnd:periodEnd.toISOString().slice(0,10),
    generatedAt:new Date().toISOString(),usage:usage.rows[0],sessions:sessions.rows[0],alerts:alerts.rows,
    shadow:shadow.rows[0],agents:agents.rows[0],topUsers:topUsers.rows,
    recommendations:[
      Number(alerts.rows.reduce((n,r)=>n+Number(r.unresolved),0))>0?'미해결 보안 알림을 검토하세요.':'미해결 보안 알림이 없습니다.',
      Number(shadow.rows[0].unresolved)>0?'미승인 AI 실행 이벤트를 확인하세요.':'Shadow AI 미해결 이벤트가 없습니다.',
      Number(agents.rows[0].online)<Number(agents.rows[0].total)?'오프라인 에이전트의 연결 상태를 점검하세요.':'등록 에이전트가 정상 보고 중입니다.'
    ] };
}

export async function GET(req:NextRequest) {
  const auth=await requireRole(req,['admin','security','auditor','viewer']);if(auth.response)return auth.response;const tenantId=auth.user!.tenantId;
  const [preview,reports]=await Promise.all([buildWeeklyReport(tenantId),pool.query('SELECT id,report_type,period_start,period_end,title,created_at,created_by,delivery_status FROM ai_reports WHERE tenant_id=$1 ORDER BY created_at DESC LIMIT 20',[tenantId])]);
  return NextResponse.json({preview,reports:reports.rows});
}

export async function POST(req:NextRequest) {
  const auth=await requireRole(req,['admin','security','auditor']); if(auth.response)return auth.response;
  const licenseCheck=await requireActiveLicense(auth.user!.tenantId);if(licenseCheck.response)return licenseCheck.response;
  const report=await buildWeeklyReport(auth.user!.tenantId);
  const {rows}=await pool.query(`INSERT INTO ai_reports(report_type,period_start,period_end,title,content,created_by,tenant_id)
    VALUES('weekly',$1,$2,$3,$4,$5,$6) RETURNING id,created_at`,[report.periodStart,report.periodEnd,`AI GUARD 주간 보고서 ${report.periodStart}~${report.periodEnd}`,JSON.stringify(report),auth.user?.username,auth.user!.tenantId]);
  return NextResponse.json({ok:true,report:{...report,...rows[0]}});
}
