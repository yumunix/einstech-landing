import {after,NextRequest,NextResponse} from 'next/server';
import pool from '@/lib/db';
import {requireRole} from '@/lib/auth';
import {verifyAgentKey} from '@/lib/agent-auth';
import {verifySensitiveContent} from '@/lib/local-ai';
import {getActivePolicySnapshot,getAgentPolicyState} from '@/lib/agent-policy';
import {matchInternalContent} from '@/lib/fingerprint-match';
import {validateReportedEvidence} from '@/lib/dlp-evidence';

const allowedSeverity=new Set(['LOW','MED','HIGH','CRITICAL']);
let nextRetentionMaintenance=0;

type VerificationJob = {
  eventId: number;
  tenantId: number;
  hostname: string;
  username: string;
  tool: string;
  violationType: string;
  maskedEvidence: string;
  content: string;
  originalSeverity: string;
  actionTaken: string;
  verifyWithAi: boolean;
  minimumSeverity: string;
  internalMatchReason: string;
};

const severityRank:Record<string,number>={LOW:0,MED:1,HIGH:2,CRITICAL:3};
function maximumSeverity(left:string,right:string){return severityRank[right]>severityRank[left]?right:left;}

function activeDestinationDecision(snapshot:Awaited<ReturnType<typeof getActivePolicySnapshot>>,tool:string){
  const rank:Record<string,number>={block:3,audit:2,allow:1};
  return (snapshot?.destinations||[])
    .filter(item=>item.enabled!==false&&item.match_type==='application'&&String(item.match_value||'').toLowerCase()===tool.toLowerCase())
    .map(item=>String(item.decision||'audit'))
    .sort((left,right)=>(rank[right]||0)-(rank[left]||0))[0]||'audit';
}

async function sourceIsActive(tenantId:number,sourceId:number,snapshot:Awaited<ReturnType<typeof getActivePolicySnapshot>>){
  const sources=(snapshot?.data_sources||[]).filter(item=>item.enabled!==false);
  if(sources.some(item=>Number(item.id)===sourceId))return true;
  const {rows}=await pool.query('SELECT name,source_type,location FROM ai_data_sources WHERE tenant_id=$1 AND id=$2',[tenantId,sourceId]);
  const source=rows[0];
  return Boolean(source&&sources.some(item=>item.name===source.name&&item.source_type===source.source_type&&item.location===source.location));
}

async function createAlert(job:VerificationJob,severity:string,riskReason:string){
  if(job.actionTaken==='classification_allowed')return;
  if(!['HIGH','CRITICAL'].includes(severity))return;
  await pool.query(`INSERT INTO ai_alerts(hostname,username,tool,alert_type,severity,detail,risk_score,risk_reason,auto_action,tenant_id)
    VALUES($1,$2,$3,'DLP_VIOLATION',$4,$5,$6,$7,$8,$9)`,[
      job.hostname,job.username,job.tool,severity,
      `${job.violationType}: ${job.maskedEvidence.slice(0,300)}`,
      severity==='CRITICAL'?100:85,riskReason,job.actionTaken,job.tenantId,
    ]);
}

async function finishVerification(job:VerificationJob){
  try{
    if(!job.verifyWithAi){
      await pool.query(`UPDATE ai_dlp_events SET ai_verification_status='skipped' WHERE tenant_id=$1 AND id=$2`,[job.tenantId,job.eventId]);
      await createAlert(job,job.originalSeverity,job.internalMatchReason||'Local AI 판정 비활성화: 패턴 탐지 결과 유지');
      return;
    }
    const verdict=await verifySensitiveContent(job.violationType,job.content||job.maskedEvidence);
    let finalSeverity=job.originalSeverity;
    if(verdict.status==='verified'&&verdict.isRealViolation===false){
      finalSeverity=maximumSeverity(job.originalSeverity==='CRITICAL'?'MED':'LOW',job.minimumSeverity);
    }
    await pool.query(`UPDATE ai_dlp_events SET severity=$1,ai_verified_reason=$2,ai_verification_status=$3,
      ai_provider=$4,ai_model=$5,ai_latency_ms=$6 WHERE tenant_id=$7 AND id=$8`,[
        finalSeverity,verdict.reason,verdict.status,verdict.provider||null,verdict.model||null,
        verdict.latencyMs,job.tenantId,job.eventId,
      ]);
    const reason=(job.internalMatchReason?`${job.internalMatchReason}; `:'')+(verdict.status==='verified'
      ? `내부 LLM 판정: ${verdict.reason}`
      : `내부 LLM 사용 불가, 패턴 탐지 결과 유지: ${verdict.reason}`);
    await createAlert(job,finalSeverity,reason);
  }catch(error){
    const reason=error instanceof Error?error.message:'Background verification failed';
    console.error('[dlp] background verification failed:',reason);
    await pool.query(`UPDATE ai_dlp_events SET ai_verification_status='error',ai_verified_reason=$1
      WHERE tenant_id=$2 AND id=$3`,[reason.slice(0,300),job.tenantId,job.eventId]).catch(()=>{});
    await createAlert(job,job.originalSeverity,'내부 LLM 판정 오류: 패턴 탐지 결과 유지').catch(()=>{});
  }
}

async function runRetentionMaintenance(tenantId:number,evidenceDays:number){
  try{
    await pool.query(`UPDATE ai_dlp_events SET raw_content=NULL WHERE tenant_id=$1 AND raw_expires_at<NOW() AND raw_content IS NOT NULL`,[tenantId]);
    await pool.query(`DELETE FROM ai_dlp_events WHERE tenant_id=$1 AND created_at<NOW()-($2::text||' days')::interval`,[tenantId,evidenceDays]);
  }catch(error){
    console.error('[dlp] retention maintenance failed:',error instanceof Error?error.message:error);
  }
}

export async function POST(req:NextRequest){
  const auth=await verifyAgentKey(req.headers.get('x-ai-sentinel-key'));
  if(!auth.configured||!auth.valid||!auth.tenantId)return NextResponse.json({error:'Unauthorized agent'},{status:401});
  const contentLength=Number(req.headers.get('content-length')||0);
  if(contentLength>100_000)return NextResponse.json({error:'Payload too large'},{status:413});
  const body=await req.json();
  const classificationOnly=req.nextUrl.searchParams.get('action')==='classify';
  const severity=allowedSeverity.has(String(body.severity))?String(body.severity):'HIGH';
  const hash=String(body.evidence_hash||'');
  if(!/^[a-f0-9]{64}$/i.test(hash))return NextResponse.json({error:'Invalid evidence hash'},{status:400});
  const suppliedRawContent=String(body.raw_content||'').slice(0,12000);
  if(!classificationOnly){
    const evidenceStatus=validateReportedEvidence(String(body.violation_type||''),hash,suppliedRawContent);
    if(evidenceStatus==='mismatch')return NextResponse.json({error:'Reported evidence does not match transient content'},{status:400});
    if(evidenceStatus==='invalid')return NextResponse.json({ok:true,filtered:true,filter_reason:'invalid_card_checksum',raw_stored:false});
  }
  const [settings,policyState,activeSnapshot]=await Promise.all([
    pool.query(`SELECT setting_value FROM ai_settings WHERE tenant_id=$1 AND setting_key='dlp_policy'`,[auth.tenantId]),
    getAgentPolicyState(auth.tenantId),
    getActivePolicySnapshot(auth.tenantId),
  ]);
  const policy=activeSnapshot?.dlp_policy||settings.rows[0]?.setting_value||{};
  const evidenceDays=Math.max(7,Math.min(3650,Number(policy.evidenceRetentionDays)||90));
  const now=Date.now();
  const maintainRetention=now>=nextRetentionMaintenance;
  if(maintainRetention)nextRetentionMaintenance=now+300_000;

  const hostname=String(body.hostname||'').slice(0,255);
  const username=String(body.username||'').slice(0,150);
  const tool=String(body.tool||'unknown').slice(0,100);
  const channel=String(body.channel||'unknown').slice(0,30);
  const violationType=String(classificationOnly?'INTERNAL_DOCUMENT_MATCH':body.violation_type||'SENSITIVE_DATA').slice(0,80);
  const maskedEvidence=String(body.masked_evidence||'').slice(0,500);
  const reportedAction=String(body.action_taken||'alert').slice(0,50);
  const actionTaken=policyState.mode==='monitor'&&/(block|kill|removed)/i.test(reportedAction)?'alerted':reportedAction;
  const inspectTransientContent=classificationOnly?policy.inspectInternalFingerprints!==false:policy.inspectContentWithLocalAi!==false;
  const transientContent=inspectTransientContent?suppliedRawContent:'';
  if(classificationOnly&&transientContent.length<20)return NextResponse.json({error:'Classification content is too short'},{status:400});
  let internalMatch=transientContent?await matchInternalContent(auth.tenantId,transientContent):null;
  if(internalMatch?.match&&!await sourceIsActive(auth.tenantId,internalMatch.match.dataSourceId,activeSnapshot)){
    internalMatch={...internalMatch,match:null};
  }
  if(classificationOnly&&!internalMatch?.match){
    return NextResponse.json({ok:true,mode:policyState.mode,deduplicated:false,raw_stored:false,ai_verification_status:'not_requested',internal_match:null,recommended_action:'allow'});
  }
  const internalLevel=internalMatch?.match?.classification_level||null;
  const minimumSeverity=internalLevel==='RESTRICTED'?'CRITICAL':internalLevel==='CONFIDENTIAL'?'HIGH':internalLevel==='INTERNAL'?'MED':'LOW';
  const effectiveSeverity=internalLevel?maximumSeverity(severity,minimumSeverity):severity;
  const rawAllowed=policy.storeRawChat===true&&['chat','clipboard'].includes(channel);
  const raw=rawAllowed?String(body.raw_content||'').slice(0,50000):null;
  const rawDays=Math.max(1,Math.min(30,Number(policy.rawRetentionDays)||7));
  const destinationDecision=activeDestinationDecision(activeSnapshot,tool);
  const recommendedAction=!internalMatch?.match?'allow':destinationDecision==='allow'?'allow':policyState.mode==='enforce'&&destinationDecision==='block'&&['CONFIDENTIAL','RESTRICTED'].includes(internalLevel)?'block':'alert';
  const recordedAction=classificationOnly
    ? recommendedAction==='block'?'block_recommended':recommendedAction==='allow'?'classification_allowed':'classification_alerted'
    : actionTaken;
  const verifyWithAi=policy.aiVerification!==false&&['HIGH','CRITICAL'].includes(effectiveSeverity);
  const inserted=await pool.query(`INSERT INTO ai_dlp_events
    (tenant_id,hostname,username,tool,channel,violation_type,severity,evidence_hash,masked_evidence,match_count,action_taken,raw_content,raw_expires_at,ai_verification_status,
      internal_match_count,internal_document_id,internal_data_source_id,internal_classification_level)
    SELECT $1::bigint,$2::varchar,$3::varchar,$4::varchar,$5::varchar,$6::varchar,$7::varchar,$8::char(64),$9::varchar,$10::integer,$11::varchar,$12::text,
      CASE WHEN $12::text IS NULL THEN NULL ELSE NOW()+($13::text||' days')::interval END,$14::varchar,$15::integer,$16::bigint,$17::bigint,$18::varchar
    WHERE NOT EXISTS(SELECT 1 FROM ai_dlp_events WHERE tenant_id=$1 AND hostname=$2 AND username=$3 AND tool=$4 AND channel=$5
      AND violation_type=$6 AND evidence_hash=$8 AND created_at>NOW()-INTERVAL '24 hours') RETURNING id`,[
      auth.tenantId,hostname,username,tool,channel,violationType,effectiveSeverity,hash,maskedEvidence,
      Math.max(1,Number(body.match_count)||1),recordedAction,raw,rawDays,verifyWithAi?'pending':'skipped',internalMatch?.match?.matchCount||0,
      internalMatch?.match?.documentId||null,internalMatch?.match?.dataSourceId||null,internalLevel,
    ]);
  const job=inserted.rowCount?{eventId:Number(inserted.rows[0].id),tenantId:auth.tenantId,hostname,username,tool,violationType,maskedEvidence,
    content:transientContent||maskedEvidence,originalSeverity:effectiveSeverity,actionTaken:recordedAction,verifyWithAi,minimumSeverity,
    internalMatchReason:internalMatch?.match?`내부 문서 지문 ${internalMatch.match.matchCount}개 일치(${internalLevel})`:''} satisfies VerificationJob:null;
  if(job||maintainRetention)after(async()=>{
    if(job)await finishVerification(job);
    if(maintainRetention)await runRetentionMaintenance(auth.tenantId!,evidenceDays);
  });
  return NextResponse.json({ok:true,mode:policyState.mode,deduplicated:inserted.rowCount===0,raw_stored:Boolean(raw),ai_verification_status:inserted.rowCount?(verifyWithAi?'pending':'skipped'):'deduplicated',internal_match:internalMatch?.match?{classification_level:internalLevel,match_count:internalMatch.match.matchCount}:null,recommended_action:recommendedAction,destination_decision:destinationDecision});
}

export async function GET(req:NextRequest){
  const auth=await requireRole(req,['admin','security','auditor']);if(auth.response)return auth.response;
  const id=req.nextUrl.searchParams.get('id');
  if(id){
    if(!['admin','security'].includes(auth.user!.role))return NextResponse.json({error:'원문 감사 권한이 없습니다'},{status:403});
    const reason=String(req.nextUrl.searchParams.get('reason')||'').trim();
    if(reason.length<5)return NextResponse.json({error:'원문 열람 사유를 입력해야 합니다'},{status:400});
    const {rows}=await pool.query(`SELECT id,raw_content,raw_expires_at FROM ai_dlp_events WHERE tenant_id=$1 AND id=$2`,[auth.user!.tenantId,id]);
    await pool.query(`INSERT INTO ai_audit_access_log(tenant_id,username,action,object_type,object_id,reason,remote_ip) VALUES($1,$2,'READ_RAW_CONTENT','ai_dlp_events',$3,$4,$5::inet)`,[auth.user!.tenantId,auth.user!.username,id,reason,(req.headers.get('x-forwarded-for')||'').split(',')[0]||null]);
    if(!rows.length)return NextResponse.json({error:'사건을 찾을 수 없습니다'},{status:404});
    return NextResponse.json({id:rows[0].id,raw_content:rows[0].raw_content,raw_expires_at:rows[0].raw_expires_at});
  }
  const {rows}=await pool.query(`SELECT e.id,e.created_at,e.hostname,e.username,e.tool,e.channel,e.violation_type,e.severity,e.evidence_hash,e.masked_evidence,e.match_count,e.action_taken,
    e.raw_content IS NOT NULL raw_available,e.ai_verification_status,e.ai_verified_reason,e.ai_provider,e.ai_model,e.ai_latency_ms,
    e.internal_match_count,e.internal_classification_level,d.relative_path internal_document_path,s.name internal_data_source_name
    FROM ai_dlp_events e LEFT JOIN ai_indexed_documents d ON d.id=e.internal_document_id AND d.tenant_id=e.tenant_id
    LEFT JOIN ai_data_sources s ON s.id=e.internal_data_source_id AND s.tenant_id=e.tenant_id
    WHERE e.tenant_id=$1 ORDER BY e.created_at DESC LIMIT 200`,[auth.user!.tenantId]);
  await pool.query(`INSERT INTO ai_audit_access_log(tenant_id,username,action,object_type,reason,remote_ip) VALUES($1,$2,'LIST_DLP_EVENTS','ai_dlp_events','DLP 사건 목록 열람',$3::inet)`,[auth.user!.tenantId,auth.user!.username,(req.headers.get('x-forwarded-for')||'').split(',')[0]||null]);
  return NextResponse.json({events:rows});
}
