import {NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/db';
import {requireRole} from '@/lib/auth';
import {requireActiveLicense} from '@/lib/license';

export async function GET(req:NextRequest) {
  const auth=await requireRole(req,['admin','security','auditor','viewer']);if(auth.response)return auth.response;const tenantId=auth.user!.tenantId;
  const [alerts, summary] = await Promise.all([
    pool.query(`
      SELECT id, created_at, session_id, hostname, username, tool, alert_type,
             severity, detail, resolved, risk_score, risk_reason, auto_action,read_at,read_by
      FROM ai_alerts WHERE tenant_id=$1 AND deleted_at IS NULL ORDER BY created_at DESC LIMIT 100
    `,[tenantId]),
    pool.query(`
      SELECT severity, COUNT(*) as count
      FROM ai_alerts WHERE resolved = FALSE AND tenant_id=$1 AND deleted_at IS NULL
      GROUP BY severity
    `,[tenantId]),
  ]);

  return NextResponse.json({ alerts: alerts.rows, summary: summary.rows, unread:alerts.rows.filter((x:any)=>!x.read_at).length });
}

export async function PATCH(req: NextRequest) {
  const auth=await requireRole(req,['admin','security','auditor','viewer']);if(auth.response)return auth.response;
  const body = await req.json();
  if(body.action==='mark_read'){
    await pool.query(`UPDATE ai_alerts SET read_at=COALESCE(read_at,NOW()),read_by=COALESCE(read_by,$1) WHERE tenant_id=$2 AND deleted_at IS NULL AND read_at IS NULL`,[auth.user!.username,auth.user!.tenantId]);
    return NextResponse.json({ok:true});
  }
  if(!['admin','security'].includes(auth.user!.role))return NextResponse.json({error:'권한이 없습니다'},{status:403});
  const licenseCheck=await requireActiveLicense(auth.user!.tenantId);if(licenseCheck.response)return licenseCheck.response;
  if(body.action==='delete'){
    await pool.query(`UPDATE ai_alerts SET deleted_at=NOW(),deleted_by=$1 WHERE id=$2 AND tenant_id=$3`,[auth.user!.username,body.id,auth.user!.tenantId]);
    await pool.query(`INSERT INTO ai_audit_access_log(tenant_id,username,action,object_type,object_id,reason,remote_ip) VALUES($1,$2,'SOFT_DELETE_ALERT','ai_alerts',$3,$4,$5::inet)`,[auth.user!.tenantId,auth.user!.username,String(body.id),String(body.reason||'사용자 요청 삭제').slice(0,500),(req.headers.get('x-forwarded-for')||'').split(',')[0]||null]);
    return NextResponse.json({ok:true});
  }
  if(body.action==='delete_many'){
    const ids=Array.isArray(body.ids)?body.ids.map(Number).filter(Number.isInteger).slice(0,500):[];
    if(!ids.length)return NextResponse.json({error:'삭제할 알림을 선택하세요'},{status:400});
    const {rows}=await pool.query(`UPDATE ai_alerts SET deleted_at=NOW(),deleted_by=$1 WHERE tenant_id=$2 AND id=ANY($3::int[]) AND deleted_at IS NULL RETURNING id`,[auth.user!.username,auth.user!.tenantId,ids]);
    if(rows.length)await pool.query(`INSERT INTO ai_audit_access_log(tenant_id,username,action,object_type,object_id,reason,remote_ip) VALUES($1,$2,'BULK_SOFT_DELETE_ALERT','ai_alerts',$3,$4,$5::inet)`,[auth.user!.tenantId,auth.user!.username,rows.map((x:any)=>x.id).join(','),`보안 알림 ${rows.length}건 일괄 삭제`,(req.headers.get('x-forwarded-for')||'').split(',')[0]||null]);
    return NextResponse.json({ok:true,deleted:rows.length});
  }
  await pool.query(`UPDATE ai_alerts SET resolved=TRUE WHERE id=$1 AND tenant_id=$2`, [body.id,auth.user!.tenantId]);
  return NextResponse.json({ ok: true });
}
