import { NextRequest, NextResponse } from 'next/server';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import pool from '@/lib/db';

const SECRET = process.env.SESSION_SECRET || 'development-only-session-secret-change-me';

function setTokenCookie(res: NextResponse, username: string, role = 'admin', tenantId = 1) {
  const token = jwt.sign({ username, role, tenantId }, SECRET, { expiresIn: '8h' });
  res.cookies.set('ai-sentinel-token', token, {
    httpOnly: true,
    maxAge: 60 * 60 * 8,
    path: '/',
    sameSite: 'lax',
  });
  return res;
}

// POST /api/auth — 로그인
export async function POST(req: NextRequest) {
  const { username, password } = await req.json();

  // DB에서 사용자 조회
  const { rows } = await pool.query(
    'SELECT password_hash, role, tenant_id FROM ai_admin_users WHERE username = $1',
    [username]
  );

  let valid = false;
  if (rows.length > 0) {
    valid = await bcrypt.compare(password, rows[0].password_hash);
  }

  if (!valid) {
    return NextResponse.json({ error: '아이디 또는 비밀번호가 틀렸습니다' }, { status: 401 });
  }

  return setTokenCookie(NextResponse.json({ ok: true, role: rows[0]?.role || 'admin' }), username, rows[0]?.role || 'admin', rows[0]?.tenant_id || 1);
}

export async function GET(req: NextRequest) {
  const token = req.cookies.get('ai-sentinel-token')?.value;
  if (!token) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  try {
    const decoded = jwt.verify(token, SECRET) as { username: string };
    const { rows } = await pool.query(`SELECT u.username,u.email,u.role,u.tenant_id,u.platform_admin,t.code tenant_code,t.name tenant_name
      FROM ai_admin_users u JOIN ai_tenants t ON t.id=u.tenant_id WHERE u.username=$1`, [decoded.username]);
    return rows[0] ? NextResponse.json(rows[0]) : NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  } catch {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
}

// PATCH /api/auth — 비밀번호 변경
export async function PATCH(req: NextRequest) {
  const token = req.cookies.get('ai-sentinel-token')?.value;
  if (!token) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  let decoded: any;
  try {
    decoded = jwt.verify(token, SECRET);
  } catch {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const { currentPassword, newPassword, newUsername } = await req.json();

  // 현재 비밀번호 확인
  const { rows } = await pool.query(
    'SELECT password_hash, role, tenant_id FROM ai_admin_users WHERE username = $1',
    [decoded.username]
  );
  if (rows.length === 0) return NextResponse.json({ error: '사용자를 찾을 수 없습니다' }, { status: 404 });

  const valid = await bcrypt.compare(currentPassword, rows[0].password_hash);
  if (!valid) return NextResponse.json({ error: '현재 비밀번호가 틀렸습니다' }, { status: 401 });

  const updates: string[] = [];
  const params: any[] = [];

  if (newPassword) {
    params.push(await bcrypt.hash(newPassword, 10));
    updates.push(`password_hash = $${params.length}`);
  }
  if (newUsername) {
    params.push(newUsername);
    updates.push(`username = $${params.length}`);
  }

  if (updates.length === 0) return NextResponse.json({ error: '변경할 내용이 없습니다' }, { status: 400 });

  params.push(decoded.username);
  await pool.query(
    `UPDATE ai_admin_users SET ${updates.join(', ')} WHERE username = $${params.length}`,
    params
  );

  const finalUsername = newUsername || decoded.username;
  return setTokenCookie(NextResponse.json({ ok: true }), finalUsername, rows[0].role || 'admin', rows[0].tenant_id || 1);
}

// DELETE /api/auth — 로그아웃
export async function DELETE() {
  const res = NextResponse.json({ ok: true });
  res.cookies.delete('ai-sentinel-token');
  return res;
}
