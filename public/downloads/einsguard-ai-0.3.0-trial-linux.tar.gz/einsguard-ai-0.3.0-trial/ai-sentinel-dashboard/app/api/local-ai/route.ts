import {NextRequest,NextResponse} from 'next/server';
import {requireRole} from '@/lib/auth';
import {getLocalAiPublicConfig,verifySensitiveContent} from '@/lib/local-ai';

export async function GET(req:NextRequest){
  const auth=await requireRole(req,['admin','security']);
  if(auth.response)return auth.response;
  return NextResponse.json(getLocalAiPublicConfig());
}

export async function POST(req:NextRequest){
  const auth=await requireRole(req,['admin']);
  if(auth.response)return auth.response;
  const body=await req.json().catch(()=>({}));
  if(body.action!=='test')return NextResponse.json({error:'Unsupported action'},{status:400});
  const verdict=await verifySensitiveContent('CONNECTION_TEST','공개 테스트 문자열: 프로젝트 일정은 다음 주 화요일입니다.');
  return NextResponse.json({ok:verdict.status==='verified',...getLocalAiPublicConfig(),test:verdict},{status:verdict.status==='verified'?200:503});
}
