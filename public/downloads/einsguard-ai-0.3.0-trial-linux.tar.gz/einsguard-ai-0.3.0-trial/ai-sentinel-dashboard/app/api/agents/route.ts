import { NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/db';
import { requireRole } from '@/lib/auth';
import { verifyAgentKey } from '@/lib/agent-auth';
import { requireActiveLicense } from '@/lib/license';
import {AI_CATALOG} from '@/lib/ai-catalog';
import {getAgentPolicyState} from '@/lib/agent-policy';
import crypto from 'node:crypto';
import {signRemovalToken} from '@/lib/removal-token';

const KNOWN_TOOLS = AI_CATALOG.map(x=>x.key);
const SHADOW_EVENT_LABELS:Record<string,string>={
  UNAPPROVED_AI_RUNNING:'승인되지 않은 AI 실행 감지',
  UNAPPROVED_AI_BLOCKED:'승인되지 않은 AI 앱·CLI 실행 차단',
  UNAPPROVED_WEB_AI_BLOCKED:'승인되지 않은 웹 AI 접속 차단',
  AI_WINDOW_DETECTED:'AI 앱 창 실행 감지',
  WINDOWS_SECURITY_EVENT:'Windows 보안 이벤트',
};
type ShadowActionState='detected'|'blocked'|'information'|'error'|'other';
const SHADOW_EVENT_GUIDES:Record<string,{meaning:string;cause:string;recommendation:string;action_state:ShadowActionState}>={
  UNAPPROVED_AI_RUNNING:{meaning:'승인 목록에 없는 AI가 현재 실행되었습니다.',cause:'사용자가 미승인 앱·CLI를 실행했거나 승인 정책에 해당 AI가 등록되지 않았습니다.',recommendation:'업무상 필요한 AI인지 사용자에게 확인한 뒤 승인 목록에 추가하거나, 불필요하면 프로세스를 종료하고 차단 정책을 적용하십시오.',action_state:'detected'},
  UNAPPROVED_AI_BLOCKED:{meaning:'승인되지 않은 AI 앱 또는 CLI 실행을 Agent가 차단했습니다.',cause:'실행한 AI가 허용 목록에 없거나 해당 사용자·PC에 차단 정책이 적용되어 있습니다.',recommendation:'오탐 여부와 업무 필요성을 확인하십시오. 정상 업무라면 승인 목록에 추가하고, 비인가 사용이면 현재 차단 상태를 유지하십시오.',action_state:'blocked'},
  UNAPPROVED_WEB_AI_BLOCKED:{meaning:'브라우저에서 승인되지 않은 AI 서비스 접속을 Agent가 차단했습니다.',cause:'접속 도메인이 AI 카탈로그에 탐지되었지만 사용자 또는 PC의 허용 목록에는 없습니다.',recommendation:'접속 목적과 서비스의 데이터 처리 정책을 확인하십시오. 업무 승인 시 웹 AI를 허용 목록에 추가하고, 미승인 서비스라면 차단을 유지하십시오.',action_state:'blocked'},
  AI_WINDOW_DETECTED:{meaning:'AI 앱 또는 AI 웹 화면의 창 제목이 감지되었습니다.',cause:'AI 앱 실행, 브라우저 탭, 또는 WebView 기반 AI 화면이 열렸습니다.',recommendation:'프로세스·창 제목·네트워크 기록을 함께 확인하십시오. 허용된 사용이면 승인 처리하고, 미승인 사용이면 세션을 종료하거나 차단 정책을 적용하십시오.',action_state:'detected'},
  WINDOWS_SECURITY_EVENT:{meaning:'Windows Agent가 보안 관련 상태를 보고했습니다.',cause:'Agent 정책, 실행 상태 또는 Windows 감시 과정에서 확인이 필요한 이벤트가 발생했습니다.',recommendation:'상세 내용과 해당 PC의 Agent 진단 로그를 확인한 뒤 정책 오류인지 실제 위반인지 판별하십시오.',action_state:'information'},
};

function normalizeShadowEvent(event:any){
  const label=SHADOW_EVENT_LABELS[event.event_type]||String(event.event_type||'알 수 없는 이벤트');
  const guide=SHADOW_EVENT_GUIDES[event.event_type]||{meaning:'분류되지 않은 AI 보안 이벤트입니다.',cause:'Agent가 보낸 이벤트 코드가 현재 서버 카탈로그에 등록되지 않았습니다.',recommendation:'이벤트 코드와 상세 로그를 확인하고 AI 이벤트 카탈로그에 새 유형을 등록하십시오.',action_state:'other' as ShadowActionState};
  const eventContext=`${event.event_type||''} ${event.detail||''}`;
  const actionState:ShadowActionState=/ERROR|FAIL(?:ED|URE)?|EXCEPTION|오류|실패/i.test(eventContext)?'error':guide.action_state;
  const corrupt=typeof event.detail==='string'&&/\?{2,}/.test(event.detail);
  const isCli=event.event_type==='UNAPPROVED_AI_BLOCKED'||event.event_type==='UNAPPROVED_AI_RUNNING';
  const occurrence=`${event.hostname||'알 수 없는 Client'} PC에서 ${event.username||'알 수 없는 사용자'} 계정이 ${event.tool||'알 수 없는 AI'}${isCli?' 앱 또는 CLI를 실행':' 서비스를 사용'}할 때 Windows Agent가 발생시켰습니다.`;
  const currentAction=actionState==='blocked'
    ? `Agent가 ${event.tool||'해당 AI'} 실행 또는 접속을 이미 차단했습니다. 현재 추가 차단 작업은 필요하지 않습니다.`
    : actionState==='error'
      ? 'Agent 처리 과정에서 오류 또는 실패 신호가 확인되었습니다. 자동 보호가 정상 적용됐다고 단정할 수 없습니다.'
      : 'Agent가 사용 사실을 탐지했으며 자동 차단 여부는 적용된 정책에 따라 다릅니다.';
  const resolution=actionState==='blocked'
    ? `업무상 필요한 사용이면 [AI 자산] → Client 목록에서 ${event.hostname||'해당 PC'}를 검색하고 ${event.tool||'해당 AI'}를 승인하십시오. 비업무 사용이면 [에이전트 제어] → [차단 관리]에서 차단 정책을 유지한 뒤 사용자에게 사유를 안내하고 이 사건을 해결 처리하십시오.`
    : actionState==='error'
      ? `해당 Client의 Agent 상태와 로그를 먼저 확인하고 통신·정책 적용 오류를 해결하십시오. 이후 ${event.tool||'해당 AI'}의 실행 또는 차단 상태를 다시 점검하십시오.`
    : `먼저 [AI 자산] → Client 목록에서 ${event.hostname||'해당 PC'}와 실행 중인 AI를 확인하십시오. 업무 승인 대상이면 ${event.tool||'해당 AI'}를 승인하고, 미승인 대상이면 [에이전트 제어] → [차단 관리]에서 차단 정책을 추가하십시오.`;
  return {...event,event_label:label,...guide,action_state:actionState,occurrence,current_action:currentAction,resolution,detail:corrupt?`${label}: ${event.tool||'알 수 없는 AI'}`:event.detail,encoding_warning:corrupt?'Agent에서 전송한 한글 상세 문구가 손상되어 이벤트 코드 기준으로 복원했습니다.':null};
}

const CURRENT_AGENT_VERSION = '1.4.0';

export async function GET(req:NextRequest) {
  // 에이전트가 최신 버전 확인 시 사용 (인증 키로 접근)
  if (req.nextUrl.searchParams.has('latest-version')) {
    return NextResponse.json(CURRENT_AGENT_VERSION);
  }
  const auth=await requireRole(req,['admin','security','auditor','viewer']); if(auth.response)return auth.response;
  const tenantId=auth.user!.tenantId;
  const [agents, retired, events, summary, enrollments, removals] = await Promise.all([
    pool.query(`SELECT a.hostname,a.os,a.os_version,a.arch,a.agent_version,a.username,a.installed_tools,a.running_tools,
      a.approved_tools,a.last_ip,a.first_seen,a.last_seen,COALESCE((SELECT jsonb_agg(jsonb_build_object(
        'username',u.username,'status',u.status,'first_seen',u.first_seen,'last_seen',u.last_seen,'inactive_at',u.inactive_at)
        ORDER BY u.status,u.username) FROM ai_agent_users u WHERE u.tenant_id=a.tenant_id AND u.hostname=a.hostname),'[]'::jsonb) users
      FROM ai_agents a WHERE a.tenant_id=$1 AND a.status='active' ORDER BY a.last_seen DESC`,[tenantId]),
    pool.query(`SELECT hostname,os,os_version,username,last_ip,first_seen,last_seen,retired_at,retired_by
      FROM ai_agents WHERE tenant_id=$1 AND status='retired' ORDER BY retired_at DESC NULLS LAST`,[tenantId]),
    pool.query(`SELECT * FROM ai_shadow_events WHERE tenant_id=$1 ORDER BY created_at DESC LIMIT 100`,[tenantId]),
    pool.query(`SELECT COUNT(*)::int agents,
      COUNT(*) FILTER (WHERE last_seen > NOW()-INTERVAL '5 minutes')::int online,
      COUNT(*) FILTER (WHERE last_seen <= NOW()-INTERVAL '5 minutes')::int offline
      FROM ai_agents WHERE tenant_id=$1 AND status='active'`,[tenantId]),
    pool.query(`SELECT id,hostname,username,os_version,remote_ip,status,created_at,decided_at,claimed_at
      FROM ai_agent_enrollments WHERE tenant_id=$1 AND created_at>NOW()-INTERVAL '24 hours'
      ORDER BY created_at DESC LIMIT 100`,[tenantId]),
    pool.query(`SELECT id,hostname,username,os_version,remote_ip,reason,status,created_at,decided_at,decided_by,completed_at
      FROM ai_agent_removal_requests WHERE tenant_id=$1 AND created_at>NOW()-INTERVAL '7 days'
      ORDER BY created_at DESC LIMIT 100`,[tenantId]),
  ]);
  return NextResponse.json({ agents: agents.rows, retired:retired.rows, events: events.rows.map(normalizeShadowEvent), enrollments:enrollments.rows, removal_requests:removals.rows, summary: summary.rows[0], knownTools: KNOWN_TOOLS });
}

export async function POST(req: NextRequest) {
  const action = req.nextUrl.searchParams.get('action') || '';
  if (action === 'inventory-report') {
    const agentAuth = await verifyAgentKey(req.headers.get('x-ai-sentinel-key'));
    if (!agentAuth.configured) return NextResponse.json({ error: 'Agent authentication is not configured' }, { status: 503 });
    if (!agentAuth.valid) {
      return NextResponse.json({ error: 'Unauthorized agent' }, { status: 401 });
    }
    const tenantId=agentAuth.tenantId!;
    const licenseCheck=await requireActiveLicense(tenantId); if(licenseCheck.response)return licenseCheck.response;
    const body = await req.json();
    const hostname=String(body.hostname||'').slice(0,255);
    if(agentAuth.hostname&&agentAuth.hostname.toLowerCase()!==hostname.toLowerCase())return NextResponse.json({error:'Agent key does not match this device',code:'AGENT_KEY_DEVICE_MISMATCH'},{status:403});
    const retired=await pool.query(`SELECT 1 FROM ai_agents WHERE tenant_id=$1 AND LOWER(hostname)=LOWER($2) AND status='retired'`,[tenantId,hostname]);
    if(retired.rowCount)return NextResponse.json({error:'이 장비는 관리 해제되었습니다. 다시 등록 승인을 받아야 합니다.',code:'AGENT_RETIRED'},{status:403});
    const installed = Array.isArray(body.installed_tools) ? body.installed_tools.filter((x: unknown) => typeof x === 'string') : [];
    const running = Array.isArray(body.running_tools) ? body.running_tools.filter((x: unknown) => typeof x === 'string') : [];
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const existing = await client.query("SELECT approved_tools,running_tools FROM ai_agents WHERE tenant_id=$1 AND hostname=$2 AND status='active'", [tenantId,hostname]);
      if (!existing.rows.length) {
        const count=await client.query("SELECT COUNT(*)::int count FROM ai_agents WHERE tenant_id=$1 AND status='active'",[tenantId]);
        if(licenseCheck.license.agent_limit > 0 && Number(count.rows[0].count)>=licenseCheck.license.agent_limit) {
          await client.query('ROLLBACK');
          return NextResponse.json({error:'요금제의 관리 대상 수를 초과했습니다.',code:'AGENT_LIMIT_REACHED',license:licenseCheck.license},{status:402});
        }
      }
      const approved = existing.rows[0]?.approved_tools || ['claude','codex'];
      const previouslyRunning:string[]=Array.isArray(existing.rows[0]?.running_tools)?existing.rows[0].running_tools:[];
      await client.query(`INSERT INTO ai_agents(hostname,os,os_version,arch,agent_version,username,installed_tools,running_tools,last_ip,tenant_id)
        VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
        ON CONFLICT(tenant_id,hostname) DO UPDATE SET os=EXCLUDED.os,os_version=EXCLUDED.os_version,arch=EXCLUDED.arch,
        agent_version=EXCLUDED.agent_version,username=EXCLUDED.username,installed_tools=EXCLUDED.installed_tools,
        running_tools=EXCLUDED.running_tools,last_ip=EXCLUDED.last_ip,last_seen=NOW()`,
        [hostname,body.os||'unknown',body.os_version||'',body.arch||'',body.agent_version||'unknown',body.username||'',JSON.stringify(installed),JSON.stringify(running),req.headers.get('x-forwarded-for')?.split(',')[0]||null,tenantId]);
      const hasFullUserSnapshot=Array.isArray(body.local_users);
      const observedUsers=Array.from(new Set<string>((hasFullUserSnapshot?body.local_users:[body.username])
        .map((value:unknown)=>String(value||'').trim().slice(0,150)).filter(Boolean)));
      for(const username of observedUsers){
        await client.query(`INSERT INTO ai_agent_users(tenant_id,hostname,username,status,source)
          VALUES($1,$2,$3,'active',$4) ON CONFLICT(tenant_id,hostname,username) DO UPDATE
          SET status='active',last_seen=NOW(),inactive_at=NULL,source=EXCLUDED.source`,[tenantId,hostname,username,hasFullUserSnapshot?'os-inventory':'current-user']);
      }
      if(hasFullUserSnapshot){
        await client.query(`UPDATE ai_agent_users SET status='inactive',inactive_at=COALESCE(inactive_at,NOW())
          WHERE tenant_id=$1 AND hostname=$2 AND status='active' AND NOT(username=ANY($3::varchar[]))`,[tenantId,hostname,observedUsers]);
      }
      for (const tool of running.filter((tool:string)=>!previouslyRunning.includes(tool))) {
        await client.query(`INSERT INTO ai_usage(logged_at,hostname,username,tool,args,tenant_id)
          VALUES(NOW(),$1,$2,$3,$4,$5)`,[body.hostname,body.username||'',tool,'앱/브라우저/CLI 실행 감지',tenantId]);
      }
      for (const tool of running.filter((tool: string) => !approved.includes(tool))) {
        await client.query(`INSERT INTO ai_shadow_events(hostname,username,tool,event_type,detail,tenant_id)
          SELECT $1::varchar,$2::varchar,$3::varchar,'UNAPPROVED_AI_RUNNING',$4::text,$5::bigint WHERE NOT EXISTS(
            SELECT 1 FROM ai_shadow_events WHERE hostname=$1::varchar AND tool=$3::varchar AND tenant_id=$5::bigint AND resolved=false AND created_at>NOW()-INTERVAL '1 hour')`,
          [body.hostname,body.username||'',tool,`승인되지 않은 AI 도구 실행 감지: ${tool}`,tenantId]);
      }
      await client.query('COMMIT');
      const policyState=await getAgentPolicyState(tenantId);
      return NextResponse.json({ ok:true, approved_tools:approved, ...policyState });
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally { client.release(); }
  }
  const auth = await requireRole(req,['admin','security']);
  if (auth.response) return auth.response;
  const body = await req.json();
  if(body.action==='retire_agent'){
    const hostname=String(body.hostname||'').trim().slice(0,255);
    if(!hostname)return NextResponse.json({error:'hostname required'},{status:400});
    const client=await pool.connect();
    try{await client.query('BEGIN');
      const target=await client.query(`UPDATE ai_agents SET status='retired',retired_at=NOW(),retired_by=$1,running_tools='[]'::jsonb
        WHERE tenant_id=$2 AND LOWER(hostname)=LOWER($3) AND status='active' RETURNING hostname`,[auth.user!.username,auth.user!.tenantId,hostname]);
      if(!target.rowCount){await client.query('ROLLBACK');return NextResponse.json({error:'활성 관리 대상에서 해당 장비를 찾지 못했습니다.'},{status:404});}
      await client.query(`UPDATE ai_agent_keys SET enabled=false,revoked_at=NOW(),revoked_by=$1
        WHERE tenant_id=$2 AND LOWER(hostname)=LOWER($3) AND enabled=true`,[auth.user!.username,auth.user!.tenantId,target.rows[0].hostname]);
      await client.query(`UPDATE ai_agent_enrollments SET status='revoked',issued_key=NULL
        WHERE tenant_id=$1 AND LOWER(hostname)=LOWER($2) AND status IN ('approved','claimed')`,[auth.user!.tenantId,target.rows[0].hostname]);
      await client.query(`UPDATE ai_agent_users SET status='inactive',inactive_at=COALESCE(inactive_at,NOW())
        WHERE tenant_id=$1 AND LOWER(hostname)=LOWER($2) AND status='active'`,[auth.user!.tenantId,target.rows[0].hostname]);
      await client.query(`INSERT INTO ai_configuration_audit(tenant_id,username,action,object_type,object_id,summary,details,remote_ip)
        VALUES($1,$2,'retire_agent','agent',$3,$4,$5,$6::inet)`,[auth.user!.tenantId,auth.user!.username,target.rows[0].hostname,`${target.rows[0].hostname} 관리 해제 및 관리 가능 장비 수 복구`,JSON.stringify({hostname:target.rows[0].hostname}),req.headers.get('x-forwarded-for')?.split(',')[0]||null]);
      await client.query('COMMIT');return NextResponse.json({ok:true,hostname:target.rows[0].hostname,seat_released:true});
    }catch(error){await client.query('ROLLBACK');throw error;}finally{client.release();}
  }
  if(body.action==='decide_removal'){
    const decision=body.decision==='approve'?'approved':body.decision==='reject'?'rejected':null;
    if(!decision)return NextResponse.json({error:'decision must be approve or reject'},{status:400});
    const {rows}=await pool.query(`UPDATE ai_agent_removal_requests
      SET status=$1,decided_at=NOW(),decided_by=$2
      WHERE id=$3 AND tenant_id=$4 AND status='pending'
      RETURNING hostname`,[decision,auth.user!.username,body.id,auth.user!.tenantId]);
    if(!rows.length)return NextResponse.json({error:'대기 중인 제거 요청이 없거나 이미 처리됐습니다.'},{status:409});
    await pool.query(`INSERT INTO ai_configuration_audit(tenant_id,username,action,object_type,object_id,summary,details,remote_ip)
      VALUES($1,$2,'decide_agent_removal','agent',$3,$4,$5,$6::inet)`,
      [auth.user!.tenantId,auth.user!.username,rows[0].hostname,
       `${rows[0].hostname} 에이전트 제거 요청 ${decision==='approved'?'승인':'거부'}`,
       JSON.stringify({hostname:rows[0].hostname,decision}),
       req.headers.get('x-forwarded-for')?.split(',')[0]||null]);
    return NextResponse.json({ok:true,hostname:rows[0].hostname,status:decision});
  }
  if(body.action==='issue_removal_token'){
    // 홈페이지 제거 요청을 받은 담당자가 대상 장비의 제거를 승인하고
    // 이메일로 전달할 서명 토큰을 발급한다. (EINSGUARD-AI-Windows-Cleanup.exe --token <값>)
    const hostname=String(body.hostname||'').trim().slice(0,255);
    if(!hostname)return NextResponse.json({error:'hostname required'},{status:400});
    const agent=await pool.query(`SELECT hostname FROM ai_agents WHERE tenant_id=$1 AND LOWER(hostname)=LOWER($2)`,[auth.user!.tenantId,hostname]);
    if(!agent.rowCount)return NextResponse.json({error:'관리 대상에서 해당 장비를 찾지 못했습니다.'},{status:404});
    const host=agent.rows[0].hostname;
    const client=await pool.connect();
    try{await client.query('BEGIN');
      await client.query(`UPDATE ai_agent_removal_requests SET status='expired'
        WHERE tenant_id=$1 AND LOWER(hostname)=LOWER($2) AND status IN ('pending','approved')`,[auth.user!.tenantId,host]);
      const ins=await client.query(`INSERT INTO ai_agent_removal_requests(tenant_id,request_hash,hostname,reason,status,decided_at,decided_by)
        VALUES($1,$2,$3,$4,'approved',NOW(),$5) RETURNING id`,
        [auth.user!.tenantId,crypto.randomBytes(32).toString('hex'),host,String(body.reason||'홈페이지 제거 요청').slice(0,500),auth.user!.username]);
      await client.query(`INSERT INTO ai_configuration_audit(tenant_id,username,action,object_type,object_id,summary,details,remote_ip)
        VALUES($1,$2,'issue_agent_removal_token','agent',$3,$4,$5,$6::inet)`,
        [auth.user!.tenantId,auth.user!.username,host,`${host} 에이전트 제거 토큰 발급`,JSON.stringify({hostname:host}),req.headers.get('x-forwarded-for')?.split(',')[0]||null]);
      await client.query('COMMIT');
      const token=signRemovalToken({hostname:host,tenantId:Number(auth.user!.tenantId),removalId:Number(ins.rows[0].id)});
      return NextResponse.json({ok:true,hostname:host,token,expires_in:'2h',
        windows_command:`EINSGUARD-AI-Windows-Cleanup-1.4.0.exe --token ${token}`,
        linux_command:`sudo EINSGUARD_REMOVAL_TOKEN='${token}' /opt/einsguard-ai/uninstall.sh`});
    }catch(e){await client.query('ROLLBACK');throw e;}finally{client.release();}
  }
  const licenseCheck=await requireActiveLicense(auth.user!.tenantId); if(licenseCheck.response)return licenseCheck.response;
  if (body.action === 'set_approved_tools') {
    const tools = Array.isArray(body.tools) ? body.tools.filter((x: unknown) => typeof x === 'string') : [];
    await pool.query('UPDATE ai_agents SET approved_tools=$1 WHERE hostname=$2 AND tenant_id=$3',[JSON.stringify(tools),body.hostname,auth.user!.tenantId]);
    return NextResponse.json({ok:true});
  }
  if (body.action === 'resolve_event') {
    await pool.query('UPDATE ai_shadow_events SET resolved=true,resolved_at=NOW(),resolved_by=$1 WHERE id=$2 AND tenant_id=$3',[auth.user?.username,body.id,auth.user!.tenantId]);
    return NextResponse.json({ok:true});
  }
  return NextResponse.json({error:'unknown action'},{status:400});
}
