import {NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/db';
import {requireRole} from '@/lib/auth';
import {requireActiveLicense} from '@/lib/license';

export async function GET(req:NextRequest) {
  const auth=await requireRole(req,['admin','security','auditor','viewer']);if(auth.response)return auth.response;const tenantId=auth.user!.tenantId;
  const [summary, byUser, byTool, byModel, daily, subscriptions, subscriptionTotals] = await Promise.all([
    pool.query(`SELECT COALESCE(SUM(input_tokens),0)::bigint AS input_tokens,
      COALESCE(SUM(output_tokens),0)::bigint AS output_tokens,
      COALESCE(SUM(cost_usd),0)::numeric AS cost_usd,
      COUNT(*)::int AS executions FROM ai_usage WHERE logged_at > NOW()-INTERVAL '30 days' AND tenant_id=$1`,[tenantId]),
    pool.query(`SELECT username, COUNT(*)::int executions, COALESCE(SUM(input_tokens+output_tokens),0)::bigint tokens,
      COALESCE(SUM(cost_usd),0)::numeric cost_usd FROM ai_usage WHERE logged_at > NOW()-INTERVAL '30 days' AND tenant_id=$1
      GROUP BY username ORDER BY cost_usd DESC, executions DESC LIMIT 20`,[tenantId]),
    pool.query(`SELECT tool, COUNT(*)::int executions, COALESCE(SUM(input_tokens+output_tokens),0)::bigint tokens,
      COALESCE(SUM(cost_usd),0)::numeric cost_usd FROM ai_usage WHERE logged_at > NOW()-INTERVAL '30 days' AND tenant_id=$1
      GROUP BY tool ORDER BY cost_usd DESC, executions DESC`,[tenantId]),
    pool.query(`SELECT model, COUNT(*)::int executions,
      COALESCE(SUM(input_tokens+output_tokens),0)::bigint tokens, COALESCE(SUM(cost_usd),0)::numeric cost_usd
      FROM ai_usage WHERE logged_at > NOW()-INTERVAL '30 days' AND tenant_id=$1 AND model IS NOT NULL AND model<>''
      AND (input_tokens>0 OR output_tokens>0 OR cost_usd>0) GROUP BY model ORDER BY cost_usd DESC, executions DESC`,[tenantId]),
    pool.query(`SELECT DATE(logged_at) AS usage_day, COUNT(*)::int executions,
      COALESCE(SUM(input_tokens+output_tokens),0)::bigint tokens, COALESCE(SUM(cost_usd),0)::numeric cost_usd
      FROM ai_usage WHERE logged_at > NOW()-INTERVAL '30 days' AND tenant_id=$1 GROUP BY DATE(logged_at) ORDER BY DATE(logged_at)`,[tenantId]),
    pool.query(`SELECT id,service_key,service_name,plan_name,seats,unit_price,currency,billing_cycle,starts_at,ends_at FROM ai_service_subscriptions WHERE tenant_id=$1 AND enabled=true ORDER BY service_name,plan_name`,[tenantId]),
    pool.query(`SELECT currency,COALESCE(SUM(seats*unit_price),0)::numeric monthly_total FROM ai_service_subscriptions WHERE tenant_id=$1 AND enabled=true AND starts_at<=CURRENT_DATE AND (ends_at IS NULL OR ends_at>=CURRENT_DATE) GROUP BY currency`,[tenantId]),
  ]);
  const unknownModelExecutions=Number(summary.rows[0].executions)-byModel.rows.reduce((n:number,x:any)=>n+Number(x.executions),0);
  return NextResponse.json({ summary: summary.rows[0], byUser: byUser.rows, byTool: byTool.rows, byModel: byModel.rows, unknownModelExecutions, daily: daily.rows,subscriptions:subscriptions.rows,subscriptionTotals:subscriptionTotals.rows });
}

export async function POST(req:NextRequest){
  const auth=await requireRole(req,['admin','security']);if(auth.response)return auth.response;
  const license=await requireActiveLicense(auth.user!.tenantId);if(license.response)return license.response;
  const body=await req.json();
  if(body.action==='add_subscription'){
    const currency=['USD','KRW'].includes(body.currency)?body.currency:'USD';
    await pool.query(`INSERT INTO ai_service_subscriptions(tenant_id,service_key,service_name,plan_name,seats,unit_price,currency,starts_at,ends_at,updated_by) VALUES($1,$2,$3,$4,$5,$6,$7,COALESCE($8::date,CURRENT_DATE),$9::date,$10)`,[auth.user!.tenantId,String(body.service_key||'custom').slice(0,80),String(body.service_name||'').slice(0,150),String(body.plan_name||'').slice(0,100),Math.max(1,Number(body.seats)||1),Math.max(0,Number(body.unit_price)||0),currency,body.starts_at||null,body.ends_at||null,auth.user!.username]);return NextResponse.json({ok:true});
  }
  if(body.action==='remove_subscription'){await pool.query(`UPDATE ai_service_subscriptions SET enabled=false,updated_at=NOW(),updated_by=$1 WHERE id=$2 AND tenant_id=$3`,[auth.user!.username,body.id,auth.user!.tenantId]);return NextResponse.json({ok:true});}
  return NextResponse.json({error:'unknown action'},{status:400});
}
