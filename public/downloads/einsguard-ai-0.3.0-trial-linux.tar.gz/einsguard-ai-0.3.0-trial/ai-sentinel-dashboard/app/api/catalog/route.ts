import {NextRequest,NextResponse} from 'next/server';
import pool from '@/lib/db';
import {requireRole} from '@/lib/auth';
import {requireActiveLicense} from '@/lib/license';
import {AI_CATALOG} from '@/lib/ai-catalog';

export async function GET(req:NextRequest){
  const auth=await requireRole(req,['admin','security','auditor','viewer']);if(auth.response)return auth.response;
  const [custom,history,schedule]=await Promise.all([
    pool.query(`SELECT * FROM ai_catalog_entries WHERE tenant_id=$1 ORDER BY CASE status WHEN 'review' THEN 1 WHEN 'active' THEN 2 WHEN 'retired' THEN 3 ELSE 4 END,updated_at DESC`,[auth.user!.tenantId]),
    pool.query(`SELECT tool_key,action,changed_at,changed_by,before_value,after_value FROM ai_catalog_history WHERE tenant_id=$1 ORDER BY changed_at DESC LIMIT 100`,[auth.user!.tenantId]),
    pool.query(`SELECT setting_value FROM ai_settings WHERE tenant_id=$1 AND setting_key='catalog_schedule'`,[auth.user!.tenantId])
  ]);
  return NextResponse.json({builtIn:AI_CATALOG.map(x=>({key:x.key,name:x.name,status:'active',source:'built-in'})),entries:custom.rows,history:history.rows,schedule:schedule.rows[0]?.setting_value});
}

export async function POST(req:NextRequest){
  const auth=await requireRole(req,['admin','security']);if(auth.response)return auth.response;
  const license=await requireActiveLicense(auth.user!.tenantId);if(license.response)return license.response;
  const body=await req.json();const tenantId=auth.user!.tenantId;
  if(body.action==='add_candidate'){
    const key=String(body.key||'').trim().toLowerCase().replace(/[^a-z0-9._-]/g,'-').slice(0,80);
    if(!key)return NextResponse.json({error:'식별자가 필요합니다'},{status:400});
    const after={tool_key:key,display_name:String(body.name||key).slice(0,150),status:'review',processes:[String(body.process||'').trim()].filter(Boolean),commands:[String(body.process||'').trim()].filter(Boolean),domains:[String(body.domain||'').trim().toLowerCase().replace(/^https?:\/\//,'').split('/')[0]].filter(Boolean),aliases:[],source:String(body.source||'manual'),notes:String(body.notes||'').slice(0,2000)};
    const {rows}=await pool.query(`INSERT INTO ai_catalog_entries(tenant_id,tool_key,display_name,status,processes,commands,domains,aliases,source,notes,updated_by) VALUES($1,$2,$3,'review',$4,$5,$6,$7,$8,$9,$10) ON CONFLICT(tenant_id,tool_key) DO UPDATE SET display_name=EXCLUDED.display_name,processes=EXCLUDED.processes,commands=EXCLUDED.commands,domains=EXCLUDED.domains,notes=EXCLUDED.notes,status='review',updated_at=NOW(),updated_by=EXCLUDED.updated_by RETURNING *`,[tenantId,key,after.display_name,JSON.stringify(after.processes),JSON.stringify(after.commands),JSON.stringify(after.domains),'[]',after.source,after.notes,auth.user!.username]);
    await pool.query(`INSERT INTO ai_catalog_history(tenant_id,entry_id,tool_key,action,after_value,changed_by) VALUES($1,$2,$3,'candidate_added',$4,$5)`,[tenantId,rows[0].id,key,JSON.stringify(rows[0]),auth.user!.username]);
    return NextResponse.json({ok:true,entry:rows[0]});
  }
  if(body.action==='set_status'){
    const status=String(body.status);if(!['active','review','retired','false_positive'].includes(status))return NextResponse.json({error:'잘못된 상태'},{status:400});
    const client=await pool.connect();try{await client.query('BEGIN');const before=await client.query(`SELECT * FROM ai_catalog_entries WHERE id=$1 AND tenant_id=$2 FOR UPDATE`,[body.id,tenantId]);if(!before.rows.length){await client.query('ROLLBACK');return NextResponse.json({error:'항목 없음'},{status:404});}const after=await client.query(`UPDATE ai_catalog_entries SET status=$1,updated_at=NOW(),updated_by=$2 WHERE id=$3 AND tenant_id=$4 RETURNING *`,[status,auth.user!.username,body.id,tenantId]);await client.query(`INSERT INTO ai_catalog_history(tenant_id,entry_id,tool_key,action,before_value,after_value,changed_by) VALUES($1,$2,$3,$4,$5,$6,$7)`,[tenantId,body.id,before.rows[0].tool_key,`status_${status}`,JSON.stringify(before.rows[0]),JSON.stringify(after.rows[0]),auth.user!.username]);await client.query('COMMIT');return NextResponse.json({ok:true});}catch(e){await client.query('ROLLBACK');throw e;}finally{client.release();}
  }
  if(body.action==='update_schedule'){
    await pool.query(`INSERT INTO ai_settings(setting_key,setting_value,updated_by,tenant_id) VALUES('catalog_schedule',$1,$2,$3) ON CONFLICT(tenant_id,setting_key) DO UPDATE SET setting_value=EXCLUDED.setting_value,updated_at=NOW(),updated_by=EXCLUDED.updated_by`,[body.schedule,auth.user!.username,tenantId]);return NextResponse.json({ok:true});
  }
  return NextResponse.json({error:'unknown action'},{status:400});
}
