import { NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/db';
import { requireRole } from '@/lib/auth';
import { requireActiveLicense } from '@/lib/license';

export async function GET(req:NextRequest) {
  const auth=await requireRole(req,['admin','security','auditor','viewer']);if(auth.response)return auth.response;const tenantId=auth.user!.tenantId;
  const [templates, settings, users] = await Promise.all([
    pool.query('SELECT * FROM ai_policy_templates ORDER BY risk_level, name'),
    pool.query('SELECT setting_key, setting_value, updated_at, updated_by FROM ai_settings WHERE tenant_id=$1 ORDER BY setting_key',[tenantId]),
    pool.query('SELECT id, username, email, role, created_at FROM ai_admin_users WHERE tenant_id=$1 ORDER BY username',[tenantId]),
  ]);
  return NextResponse.json({ templates: templates.rows, settings: settings.rows, users: users.rows });
}

export async function PATCH(req: NextRequest) {
  const auth = await requireRole(req, ['admin']);
  if (auth.response) return auth.response;
  const licenseCheck=await requireActiveLicense(auth.user!.tenantId);if(licenseCheck.response)return licenseCheck.response;
  const body = await req.json();
  if (body.action === 'update_role') {
    if (!['admin','security','auditor','viewer'].includes(body.role)) return NextResponse.json({ error: '잘못된 역할' }, { status: 400 });
    await pool.query('UPDATE ai_admin_users SET role=$1 WHERE id=$2 AND tenant_id=$3', [body.role, body.id,auth.user!.tenantId]);
    return NextResponse.json({ ok: true });
  }
  if (body.action === 'update_setting') {
    await pool.query(`INSERT INTO ai_settings(setting_key,setting_value,updated_by,tenant_id) VALUES($1,$2,$3,$4)
      ON CONFLICT(tenant_id,setting_key) DO UPDATE SET setting_value=EXCLUDED.setting_value,updated_at=NOW(),updated_by=EXCLUDED.updated_by`,
      [body.key, body.value, auth.user?.username,auth.user!.tenantId]);
    return NextResponse.json({ ok: true });
  }
  return NextResponse.json({ error: 'unknown action' }, { status: 400 });
}
