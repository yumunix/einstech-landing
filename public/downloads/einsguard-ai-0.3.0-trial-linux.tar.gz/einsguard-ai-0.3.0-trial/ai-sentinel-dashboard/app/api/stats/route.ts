import { NextRequest,NextResponse } from 'next/server';
import pool from '@/lib/db';
import {requireRole} from '@/lib/auth';

export async function GET(req:NextRequest) {
  const auth=await requireRole(req,['admin','security','auditor','viewer']);if(auth.response)return auth.response;const tenantId=auth.user!.tenantId;
  const [summary, byServer, byTool, recent, timeline] = await Promise.all([
    pool.query(`
      SELECT COUNT(*)::int as total_usage,
             COUNT(*) FILTER (WHERE logged_at >= CURRENT_DATE)::int as today_usage,
             COUNT(DISTINCT hostname)::int as active_servers,
             COUNT(DISTINCT username)::int as active_users
      FROM ai_usage
      WHERE logged_at > NOW() - INTERVAL '7 days' AND tenant_id=$1
    `,[tenantId]),
    pool.query(`
      SELECT hostname, COUNT(*)::int as count
      FROM ai_usage
      WHERE logged_at > NOW() - INTERVAL '7 days' AND tenant_id=$1
      GROUP BY hostname ORDER BY count DESC
    `,[tenantId]),
    pool.query(`
      SELECT tool, COUNT(*)::int as count
      FROM ai_usage
      WHERE logged_at > NOW() - INTERVAL '7 days' AND tenant_id=$1
      GROUP BY tool ORDER BY count DESC
    `,[tenantId]),
    pool.query(`
      SELECT logged_at, hostname, username, tool, args
      FROM ai_usage
      WHERE tenant_id=$1 ORDER BY logged_at DESC LIMIT 20
    `,[tenantId]),
    pool.query(`
      SELECT DATE_TRUNC('hour', logged_at) as hour, COUNT(*)::int as count
      FROM ai_usage
      WHERE logged_at > NOW() - INTERVAL '24 hours' AND tenant_id=$1
      GROUP BY hour ORDER BY hour
    `,[tenantId]),
  ]);

  return NextResponse.json({
    summary: summary.rows[0],
    byServer: byServer.rows,
    byTool: byTool.rows,
    recent: recent.rows,
    timeline: timeline.rows,
  });
}
