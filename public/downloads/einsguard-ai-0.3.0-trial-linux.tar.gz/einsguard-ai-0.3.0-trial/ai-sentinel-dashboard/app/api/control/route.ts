import { NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/db';
import { requireRole } from '@/lib/auth';
import { requireActiveLicense } from '@/lib/license';
import {AI_CATALOG} from '@/lib/ai-catalog';

// GET: 차단/정책/승인/활성세션 목록 조회
export async function GET(req:NextRequest) {
  const auth=await requireRole(req,['admin','security','auditor','viewer']);if(auth.response)return auth.response;const tenantId=auth.user!.tenantId;
  await pool.query(`UPDATE ai_commands SET status='stale'
    WHERE tenant_id=$1 AND command='registered' AND status='active'
      AND COALESCE(heartbeat_at,created_at)<NOW()-INTERVAL '2 minutes'`,[tenantId]);
  const [blocks, policies, approvals, activeSessions, customCatalog, managedCatalog, blockTargetAgents, blockTargetUsers] = await Promise.all([
    pool.query(`SELECT * FROM ai_blocks WHERE enabled = TRUE AND tenant_id=$1 ORDER BY created_at DESC`,[tenantId]),
    pool.query(`SELECT * FROM ai_policies WHERE enabled = TRUE AND tenant_id=$1 ORDER BY id DESC`,[tenantId]),
    pool.query(`SELECT * FROM ai_approvals WHERE tenant_id=$1
      AND COALESCE(TRIM(args),'') !~* '^(--version|-V|version|--help|-h)$'
      ORDER BY created_at DESC LIMIT 50`,[tenantId]),
    pool.query(`WITH live_registered AS (
      SELECT DISTINCT ON (session_id) * FROM ai_commands
      WHERE command='registered' AND status='active' AND tenant_id=$1
        AND heartbeat_at>NOW()-INTERVAL '30 seconds'
      ORDER BY session_id,heartbeat_at DESC,created_at DESC,id DESC
    )
      SELECT c.session_id,c.hostname,c.username,c.tool,c.pid,
             s.work_dir,COALESCE(s.started_at,c.created_at) started_at,c.heartbeat_at,
             CASE WHEN EXISTS (
               SELECT 1 FROM ai_commands p
               WHERE p.session_id = c.session_id AND p.tenant_id=c.tenant_id AND p.command = 'pause' AND p.status = 'executed'
                 AND NOT EXISTS (
                   SELECT 1 FROM ai_commands r
                   WHERE r.session_id = c.session_id AND r.tenant_id=c.tenant_id AND r.command IN ('resume', 'kill')
                     AND r.created_at > p.created_at
                 )
             ) THEN 'paused' ELSE 'running' END AS state
      FROM live_registered c
      LEFT JOIN ai_sessions s ON s.session_id = c.session_id AND s.tenant_id=c.tenant_id
      WHERE s.ended_at IS NULL
      ORDER BY COALESCE(s.started_at,c.created_at) DESC
    `,[tenantId]),
    pool.query(`SELECT setting_value FROM ai_settings WHERE tenant_id=$1 AND setting_key='custom_ai_catalog'`,[tenantId]),
    pool.query(`SELECT tool_key key,display_name name FROM ai_catalog_entries WHERE tenant_id=$1 AND status IN('active','review')`,[tenantId]),
    pool.query(`SELECT hostname,os,os_version,agent_version,host(last_ip) last_ip,local_ips::text[],last_seen
      FROM ai_agents WHERE tenant_id=$1 ORDER BY last_seen DESC,hostname`,[tenantId]),
    pool.query(`WITH observed_users AS (
        SELECT hostname,username,last_seen observed_at FROM ai_agents WHERE tenant_id=$1
        UNION ALL
        SELECT hostname,username,COALESCE(logged_at,received_at) FROM ai_usage WHERE tenant_id=$1
        UNION ALL
        SELECT hostname,username,COALESCE(ended_at,started_at) FROM ai_sessions WHERE tenant_id=$1
      )
      SELECT a.hostname,o.username,MAX(o.observed_at) last_seen
      FROM ai_agents a JOIN observed_users o ON LOWER(o.hostname)=LOWER(a.hostname)
      WHERE a.tenant_id=$1 AND COALESCE(TRIM(o.username),'')<>'' AND RIGHT(TRIM(o.username),1)<>'$'
      GROUP BY a.hostname,o.username ORDER BY a.hostname,MAX(o.observed_at) DESC,o.username`,[tenantId]),
  ]);

  const blockTargets=blockTargetAgents.rows.map((agent:any)=>{
    const ips=Array.from(new Set([agent.last_ip,...(agent.local_ips||[])]
      .map((ip:unknown)=>String(ip||'').replace(/^::ffff:/i,'').replace(/\/(?:32|128)$/,''))
      .filter(Boolean)));
    return {...agent,ips,users:blockTargetUsers.rows.filter((user:any)=>
      String(user.hostname).toLowerCase()===String(agent.hostname).toLowerCase())};
  });

  return NextResponse.json({
    blocks: blocks.rows,
    policies: policies.rows,
    approvals: approvals.rows,
    activeSessions: activeSessions.rows,
    catalog: [...AI_CATALOG.map(x=>({key:x.key,name:x.name})),...managedCatalog.rows],
    customCatalog: customCatalog.rows[0]?.setting_value||[],
    blockTargets,
  });
}

// POST: 제어 액션 실행
export async function POST(req: NextRequest) {
  const auth = await requireRole(req, ['admin', 'security']);
  if (auth.response) return auth.response;
  const licenseCheck=await requireActiveLicense(auth.user!.tenantId);if(licenseCheck.response)return licenseCheck.response;
  const body = await req.json();
  const { action } = body;
  const tenantId=auth.user!.tenantId;

  try {
    if(action==='add_custom_ai'){
      const key=String(body.key||'').trim().toLowerCase().replace(/[^a-z0-9._-]/g,'-').slice(0,80);
      const name=String(body.name||key).trim().slice(0,120);
      const process=String(body.process||'').trim().toLowerCase().slice(0,150);
      const domain=String(body.domain||'').trim().toLowerCase().replace(/^https?:\/\//,'').split('/')[0].slice(0,253);
      if(!key||(!process&&!domain))return NextResponse.json({ok:false,error:'식별자와 프로세스명 또는 도메인이 필요합니다'},{status:400});
      await pool.query(`INSERT INTO ai_settings(setting_key,setting_value,updated_by,tenant_id) VALUES('custom_ai_catalog',jsonb_build_array(jsonb_build_object('key',$1,'name',$2,'processes',jsonb_build_array($3),'commands',jsonb_build_array($3),'domains',jsonb_build_array($4))),$5,$6)
        ON CONFLICT(tenant_id,setting_key) DO UPDATE SET setting_value=(SELECT jsonb_agg(DISTINCT x) FROM jsonb_array_elements(ai_settings.setting_value||EXCLUDED.setting_value)x),updated_at=NOW(),updated_by=EXCLUDED.updated_by`,[key,name,process,domain,auth.user!.username,tenantId]);
      return NextResponse.json({ok:true,key});
    }
    if (action === 'add_block') {
      const requestedHostname=String(body.hostname||'*').trim().slice(0,255)||'*';
      let hostname=requestedHostname;
      if(hostname!=='*'){
        const target=await pool.query(`SELECT hostname FROM ai_agents WHERE tenant_id=$1 AND LOWER(hostname)=LOWER($2) LIMIT 1`,[tenantId,hostname]);
        if(!target.rowCount)return NextResponse.json({ok:false,error:'등록된 Agent Client를 선택해 주세요.'},{status:400});
        hostname=target.rows[0].hostname;
      }
      const requestedUsers=Array.isArray(body.usernames)?body.usernames:[body.username||'*'];
      let usernames=Array.from(new Set(requestedUsers.map((value:unknown)=>String(value||'').trim().slice(0,100)).filter(Boolean)));
      if(usernames.includes('*'))usernames=['*'];
      if(!usernames.length)return NextResponse.json({ok:false,error:'차단할 사용자를 한 명 이상 선택해 주세요.'},{status:400});
      const tool=String(body.tool||'*').trim().slice(0,50)||'*';
      const reason=String(body.reason||'').trim().slice(0,1000);
      const client=await pool.connect();
      try{
        await client.query('BEGIN');
        let created=0;
        for(const username of usernames){
          const result=await client.query(`INSERT INTO ai_blocks (hostname,username,tool,reason,enabled,tenant_id)
            SELECT $1,$2,$3,$4,TRUE,$5 WHERE NOT EXISTS(
              SELECT 1 FROM ai_blocks WHERE tenant_id=$5 AND enabled=TRUE
                AND LOWER(hostname)=LOWER($1) AND LOWER(username)=LOWER($2) AND LOWER(tool)=LOWER($3))`,
            [hostname,username,tool,reason,tenantId]);
          created+=result.rowCount||0;
        }
        await client.query('COMMIT');
        return NextResponse.json({ok:true,created,requested:usernames.length});
      }catch(error){await client.query('ROLLBACK');throw error;}finally{client.release();}
    }

    if (action === 'remove_block') {
      await pool.query(`UPDATE ai_blocks SET enabled = FALSE WHERE id = $1 AND tenant_id=$2`, [body.id,tenantId]);
      return NextResponse.json({ ok: true });
    }

    if (action === 'add_policy') {
      const hostname=String(body.hostname||'*').trim().slice(0,100)||'*';
      const username=String(body.username||'*').trim().slice(0,100)||'*';
      const tool=String(body.tool||'*').trim().slice(0,30)||'*';
      const templateKey=String(body.template_key||'').trim().slice(0,50)||null;
      const allowStart=Number(body.allow_start??0);
      const allowEnd=Number(body.allow_end??23);
      const maxPerHour=Number(body.max_per_hour??10);
      if(!Number.isInteger(allowStart)||allowStart<0||allowStart>23||!Number.isInteger(allowEnd)||allowEnd<0||allowEnd>23||allowStart>allowEnd){
        return NextResponse.json({ok:false,error:'허용 시간은 0~23시 범위에서 시작 시간이 종료 시간보다 빠르게 설정되어야 합니다.'},{status:400});
      }
      if(!Number.isInteger(maxPerHour)||maxPerHour<0||maxPerHour>10000){
        return NextResponse.json({ok:false,error:'시간당 최대 실행 횟수는 0~10,000 사이여야 합니다.'},{status:400});
      }
      if(templateKey){
        const template=await pool.query('SELECT 1 FROM ai_policy_templates WHERE template_key=$1',[templateKey]);
        if(!template.rowCount)return NextResponse.json({ok:false,error:'존재하지 않는 정책 템플릿입니다.'},{status:400});
      }
      const client=await pool.connect();
      try{
        await client.query('BEGIN');
        const replaced=await client.query(`UPDATE ai_policies SET enabled=false WHERE tenant_id=$1 AND enabled=true
          AND LOWER(hostname)=LOWER($2) AND LOWER(username)=LOWER($3) AND LOWER(tool)=LOWER($4)`,[tenantId,hostname,username,tool]);
        await client.query(`INSERT INTO ai_policies (hostname,username,allow_start,allow_end,max_per_hour,enabled,template_key,tool,tenant_id)
          VALUES($1,$2,$3,$4,$5,true,$6,$7,$8)`,[hostname,username,allowStart,allowEnd,maxPerHour,templateKey,tool,tenantId]);
        await client.query('COMMIT');
        return NextResponse.json({ok:true,replaced:replaced.rowCount||0});
      }catch(error){await client.query('ROLLBACK');throw error;}finally{client.release();}
    }

    if (action === 'remove_policy') {
      await pool.query(`UPDATE ai_policies SET enabled = FALSE WHERE id = $1 AND tenant_id=$2`, [body.id,tenantId]);
      return NextResponse.json({ ok: true });
    }

    if (action === 'kill_session') {
      const { session_id } = body;
      // session_id에 해당하는 활성 command 레코드 조회해서 hostname/username/tool 가져오기
      const { rows } = await pool.query(
        `SELECT hostname, username, tool, pid FROM ai_commands
         WHERE session_id = $1 AND tenant_id=$2 AND command = 'registered' AND status = 'active' LIMIT 1`,
        [session_id,tenantId]
      );
      if (rows.length === 0) return NextResponse.json({ ok: false, error: '세션을 찾을 수 없습니다' });

      const { hostname, username, tool, pid } = rows[0];
      await pool.query(
        `INSERT INTO ai_commands (session_id, hostname, username, tool, pid, command, status,tenant_id)
         VALUES ($1, $2, $3, $4, $5, 'kill', 'pending',$6)`,
        [session_id, hostname, username, tool, pid,tenantId]
      );
      return NextResponse.json({ ok: true });
    }

    if (action === 'pause_session' || action === 'resume_session') {
      const command = action === 'pause_session' ? 'pause' : 'resume';
      const { rows } = await pool.query(
        `SELECT hostname, username, tool, pid FROM ai_commands
         WHERE session_id = $1 AND tenant_id=$2 AND command = 'registered' AND status = 'active' LIMIT 1`,
        [body.session_id,tenantId]
      );
      if (rows.length === 0) return NextResponse.json({ ok: false, error: '활성 세션을 찾을 수 없습니다' });
      const { hostname, username, tool, pid } = rows[0];
      await pool.query(
        `INSERT INTO ai_commands (session_id, hostname, username, tool, pid, command, status,tenant_id)
         VALUES ($1, $2, $3, $4, $5, $6, 'pending',$7)`,
        [body.session_id, hostname, username, tool, pid, command,tenantId]
      );
      return NextResponse.json({ ok: true });
    }

    if (action === 'review_approval') {
      const { id, approved } = body;
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        const { rows } = await client.query(
          `UPDATE ai_approvals SET status = $1, reviewed_by = 'admin', reviewed_at = NOW()
           WHERE id = $2 AND tenant_id=$3 AND status = 'pending'
           RETURNING session_id, hostname, username, tool, token`,
          [approved ? 'approved' : 'rejected', id,tenantId]
        );
        if (rows.length === 0) {
          await client.query('ROLLBACK');
          return NextResponse.json({ ok: false, error: '이미 처리되었거나 존재하지 않는 승인 요청입니다' }, { status: 409 });
        }
        const approval = rows[0];
        if (approval.token?.startsWith('risk-pause:')) {
          const command = approved ? 'resume' : 'kill';
          const { rows: registered } = await client.query(
            `SELECT pid FROM ai_commands WHERE session_id=$1 AND tenant_id=$2 AND command='registered' ORDER BY created_at DESC LIMIT 1`,
            [approval.session_id,tenantId]
          );
          await client.query(
            `INSERT INTO ai_commands (session_id, hostname, username, tool, pid, command, status,tenant_id)
             VALUES ($1,$2,$3,$4,$5,$6,'pending',$7)`,
            [approval.session_id, approval.hostname, approval.username, approval.tool, registered[0]?.pid ?? null, command,tenantId]
          );
        }
        await client.query('COMMIT');
      } catch (error) {
        await client.query('ROLLBACK');
        throw error;
      } finally {
        client.release();
      }
      return NextResponse.json({ ok: true });
    }

    return NextResponse.json({ error: 'unknown action' }, { status: 400 });
  } catch (err: any) {
    return NextResponse.json({ ok: false, error: err.message }, { status: 500 });
  }
}
