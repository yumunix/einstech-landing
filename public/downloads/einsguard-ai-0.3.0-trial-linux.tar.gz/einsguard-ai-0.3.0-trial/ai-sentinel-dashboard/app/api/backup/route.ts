import {after,NextRequest,NextResponse} from 'next/server';
import {createReadStream} from 'node:fs';
import {rm,stat} from 'node:fs/promises';
import {Readable} from 'node:stream';
import path from 'node:path';
import pool from '@/lib/db';
import {requireRole} from '@/lib/auth';
import {auditConfiguration,remoteIp} from '@/lib/onboarding';
import {browseBackupStorage,createBackupArchive,defaultBackupPolicy,importBackupArchive,listConfigBackups,runConfigBackup,validateBackupDirectory,validateBackupPolicy} from '@/lib/config-backup';

export const runtime='nodejs';

async function authorize(req:NextRequest){
  const auth=await requireRole(req,['admin']);
  if(auth.response)return auth;
  if(!auth.user!.platformAdmin)return {...auth,response:NextResponse.json({error:'서버 전체 백업은 플랫폼 관리자만 관리할 수 있습니다.'},{status:403})};
  return auth;
}

async function loadPolicy(tenantId:number){
  const {rows}=await pool.query(`SELECT setting_value,updated_at,updated_by FROM ai_settings WHERE tenant_id=$1 AND setting_key='backup_policy'`,[tenantId]);
  return {policy:validateBackupPolicy(rows[0]?.setting_value||defaultBackupPolicy),updatedAt:rows[0]?.updated_at||null,updatedBy:rows[0]?.updated_by||null};
}

export async function GET(req:NextRequest){
  const auth=await authorize(req);if(auth.response)return auth.response;
  try{
    if(req.nextUrl.searchParams.get('action')==='browse')return NextResponse.json(await browseBackupStorage(req.nextUrl.searchParams.get('path')||''));
    const configured=await loadPolicy(auth.user!.tenantId);
    if(req.nextUrl.searchParams.get('action')==='download'){
      const backupName=String(req.nextUrl.searchParams.get('backupName')||'');const archive=await createBackupArchive(configured.policy.storagePath,backupName);const archiveStat=await stat(archive);
      after(()=>rm(archive,{force:true}));
      return new NextResponse(Readable.toWeb(createReadStream(archive)) as ReadableStream,{headers:{'content-type':'application/gzip','content-length':String(archiveStat.size),'content-disposition':`attachment; filename="AI-GUARD-${backupName}.tar.gz"`,'cache-control':'no-store'}});
    }
    const listed=await listConfigBackups(configured.policy.storagePath);return NextResponse.json({...configured,...listed,restoreCommand:'sudo ./scripts/restore-config-backup.sh --validate-only <백업경로>'});
  }
  catch(error){return NextResponse.json({error:error instanceof Error?error.message:'백업 상태를 확인하지 못했습니다.'},{status:500});}
}

export async function POST(req:NextRequest){
  const auth=await authorize(req);if(auth.response)return auth.response;
  if((req.headers.get('content-type')||'').includes('multipart/form-data')){
    const contentLength=Number(req.headers.get('content-length')||0);if(contentLength>250*1024*1024)return NextResponse.json({error:'가져올 백업 파일은 최대 250MB입니다.'},{status:413});
    try{
      const form=await req.formData();if(form.get('action')!=='import_backup')throw new Error('지원하지 않는 가져오기 작업입니다.');const file=form.get('file');if(!(file instanceof File)||file.size===0||file.size>250*1024*1024)throw new Error('올바른 백업 파일을 선택하십시오.');
      const configured=await loadPolicy(auth.user!.tenantId);const imported=await importBackupArchive(configured.policy.storagePath,new Uint8Array(await file.arrayBuffer()));const client=await pool.connect();
      try{await auditConfiguration(client,{tenantId:auth.user!.tenantId,username:auth.user!.username,action:'IMPORT_CONFIGURATION_BACKUP',objectType:'backup',objectId:imported.backupName,summary:'관리자 PC에서 백업 묶음을 가져오고 무결성을 검증함',details:{path:imported.path,bytes:file.size},remoteIp:remoteIp(req.headers)});}finally{client.release();}
      return NextResponse.json({ok:true,imported});
    }catch(error){return NextResponse.json({error:error instanceof Error?error.message:'백업 파일을 가져오지 못했습니다.'},{status:400});}
  }
  const body=await req.json();const client=await pool.connect();
  try{
    if(body.action==='save_policy'){
      const policy=validateBackupPolicy(body.policy);
      await client.query('BEGIN');
      await client.query(`INSERT INTO ai_settings(tenant_id,setting_key,setting_value,updated_by) VALUES($1,'backup_policy',$2,$3)
        ON CONFLICT(tenant_id,setting_key) DO UPDATE SET setting_value=EXCLUDED.setting_value,updated_at=NOW(),updated_by=EXCLUDED.updated_by`,[auth.user!.tenantId,policy,auth.user!.username]);
      await auditConfiguration(client,{tenantId:auth.user!.tenantId,username:auth.user!.username,action:'SAVE_BACKUP_POLICY',objectType:'backup',summary:'정기 백업 위치·대상·주기를 저장함',details:{storagePath:policy.storagePath,frequency:policy.frequency,time:policy.time,content:{database:policy.includeDatabase,environment:policy.includeEnvironment,applicationConfig:policy.includeApplicationConfig}},remoteIp:remoteIp(req.headers)});
      await client.query('COMMIT');return NextResponse.json({ok:true,policy});
    }
    if(body.action==='run_backup'){
      const configured=await loadPolicy(auth.user!.tenantId);const backup=await runConfigBackup({tenantId:auth.user!.tenantId,username:auth.user!.username,trigger:'manual',policy:configured.policy,notes:String(body.notes||configured.policy.description)});
      await auditConfiguration(client,{tenantId:auth.user!.tenantId,username:auth.user!.username,action:'RUN_CONFIGURATION_BACKUP',objectType:'backup',objectId:backup.backupName,summary:'수동 설정 백업을 완료함',details:{path:backup.storagePath,content:backup.content,bytes:backup.bytes},remoteIp:remoteIp(req.headers)});
      return NextResponse.json({ok:true,backup});
    }
    if(body.action==='validate_backup'){
      const configured=await loadPolicy(auth.user!.tenantId);const backupName=String(body.backupName||'');if(!/^\d{8}-\d{6}-(manual|scheduled)$/.test(backupName))throw new Error('백업 이름이 올바르지 않습니다.');
      const directory=`${configured.policy.storagePath}/${backupName}`;const validation=await validateBackupDirectory(directory);
      await auditConfiguration(client,{tenantId:auth.user!.tenantId,username:auth.user!.username,action:'VALIDATE_CONFIGURATION_BACKUP',objectType:'backup',objectId:backupName,summary:'복구 전 백업 무결성을 검증함',details:validation,remoteIp:remoteIp(req.headers)});
      return NextResponse.json({ok:validation.ok,validation});
    }
    if(body.action==='prepare_restore'){
      const configured=await loadPolicy(auth.user!.tenantId);const backupName=String(body.backupName||'');
      if(!/^\d{8}-\d{6}-(manual|scheduled)$/.test(backupName)||String(body.confirmation||'')!==`RESTORE ${backupName}`)throw new Error('복구 확인 문구가 일치하지 않습니다.');
      const directory=`${configured.policy.storagePath}/${backupName}`;const validation=await validateBackupDirectory(directory);if(!validation.ok)throw new Error(`백업 무결성 검증 실패: ${validation.failures.join(', ')}`);
      await auditConfiguration(client,{tenantId:auth.user!.tenantId,username:auth.user!.username,action:'PREPARE_CONFIGURATION_RESTORE',objectType:'backup',objectId:backupName,summary:'설정 복구 대상을 선택하고 유지보수 복구 절차를 준비함',details:{path:directory,checkedFiles:validation.checkedFiles},remoteIp:remoteIp(req.headers)});
      return NextResponse.json({ok:true,backupName,path:directory,command:`sudo RESTORE_CONFIRM=RESTORE_AI_GUARD ./scripts/restore-config-backup.sh --restore '${directory}'`,steps:['사용자 접속이 없는 유지보수 시간을 확보합니다.','선택한 백업의 무결성 검증 결과를 다시 확인합니다.','서버 콘솔에서 복구 명령을 실행합니다.','서비스 재시작 후 로그인·정책·Agent 통신을 확인합니다.']});
    }
    return NextResponse.json({error:'지원하지 않는 작업입니다.'},{status:400});
  }catch(error){await client.query('ROLLBACK').catch(()=>{});return NextResponse.json({error:error instanceof Error?error.message:'백업 작업에 실패했습니다.'},{status:400});}
  finally{client.release();}
}
