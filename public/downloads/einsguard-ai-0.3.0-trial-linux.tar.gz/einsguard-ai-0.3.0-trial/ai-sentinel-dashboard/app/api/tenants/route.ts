import {NextRequest,NextResponse} from 'next/server';
import crypto from 'node:crypto';
import bcrypt from 'bcryptjs';
import pool from '@/lib/db';
import {currentUser} from '@/lib/auth';
import type {PoolClient} from 'pg';

async function platformUser(req:NextRequest){const user=await currentUser(req);return user?.platformAdmin?user:null;}

async function initializeOnboarding(client:PoolClient,tenantId:number,name:string,username:string){
  await client.query('INSERT INTO ai_onboarding_state(tenant_id) VALUES($1)',[tenantId]);
  await client.query('INSERT INTO ai_organization_profiles(tenant_id,company_name,updated_by) VALUES($1,$2,$3)',[tenantId,name,username]);
  await client.query(`INSERT INTO ai_classification_rules
    (tenant_id,name,classification_level,rule_type,pattern,action,weight,updated_by) VALUES
    ($1,'기밀 표시','RESTRICTED','keyword','대외비','block',100,$2),
    ($1,'영문 기밀 표시','RESTRICTED','keyword','confidential','block',100,$2),
    ($1,'내부 전용 표시','INTERNAL','keyword','internal use only','audit',60,$2),
    ($1,'고객 정보 표시','CONFIDENTIAL','keyword','고객정보','warn',80,$2)`,[tenantId,username]);
}

export async function GET(req:NextRequest){
  const user=await platformUser(req);if(!user)return NextResponse.json({error:'플랫폼 관리자 권한이 필요합니다'},{status:403});
  const {rows}=await pool.query(`SELECT t.id,t.code,t.name,t.enabled,t.created_at,
    COUNT(DISTINCT u.id)::int admins,COUNT(DISTINCT a.hostname)::int agents
    FROM ai_tenants t LEFT JOIN ai_admin_users u ON u.tenant_id=t.id LEFT JOIN ai_agents a ON a.tenant_id=t.id
    GROUP BY t.id ORDER BY t.created_at`);
  return NextResponse.json({tenants:rows});
}

export async function POST(req:NextRequest){
  const user=await platformUser(req);if(!user)return NextResponse.json({error:'플랫폼 관리자 권한이 필요합니다'},{status:403});
  const body=await req.json();
  if(!/^[a-z0-9][a-z0-9-]{1,48}$/.test(body.code||''))return NextResponse.json({error:'고객사 코드는 영문 소문자·숫자·하이픈만 사용할 수 있습니다'},{status:400});
  if(!body.name||!body.admin_username||!body.admin_password)return NextResponse.json({error:'고객사명과 관리자 계정·비밀번호가 필요합니다'},{status:400});
  const rawKey=crypto.randomBytes(32).toString('hex');const keyHash=crypto.createHash('sha256').update(rawKey).digest('hex');
  const client=await pool.connect();
  try{await client.query('BEGIN');
    const {rows}=await client.query('INSERT INTO ai_tenants(code,name) VALUES($1,$2) RETURNING id,code,name',[body.code,body.name]);const tenant=rows[0];
    await client.query(`INSERT INTO ai_admin_users(username,password_hash,email,role,tenant_id) VALUES($1,$2,$3,'admin',$4)`,[body.admin_username,await bcrypt.hash(body.admin_password,10),body.admin_email||null,tenant.id]);
    await client.query(`INSERT INTO ai_agent_keys(tenant_id,key_name,key_hash) VALUES($1,'기본 에이전트 키',$2)`,[tenant.id,keyHash]);
    await client.query(`INSERT INTO ai_settings(setting_key,setting_value,updated_by,tenant_id) VALUES
      ('retention','{"days":90,"enabled":false}'::jsonb,$1,$2),('data_protection','{"maskSecrets":true,"maskEmails":true}'::jsonb,$1,$2)`,[user.username,tenant.id]);
    await initializeOnboarding(client,tenant.id,tenant.name,user.username);
    await client.query('COMMIT');return NextResponse.json({ok:true,tenant,agent_key:rawKey});
  }catch(error:any){await client.query('ROLLBACK');return NextResponse.json({error:error.code==='23505'?'고객사 코드 또는 관리자 아이디가 이미 존재합니다':error.message},{status:409});}finally{client.release();}
}
