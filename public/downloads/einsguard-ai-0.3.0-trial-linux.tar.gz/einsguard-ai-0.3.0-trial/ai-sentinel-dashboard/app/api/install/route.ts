import { NextRequest, NextResponse } from 'next/server';
import { requireRole } from '@/lib/auth';
import { verifyAgentKey } from '@/lib/agent-auth';

const AGENT_VERSION = '1.4.0';

function buildWrapperScript(apiBase: string): string {
  return `#!/bin/bash
# AI Sentinel Agent v${AGENT_VERSION}
TOOL="\${AI_SENTINEL_TOOL:-\$(basename "\$0")}"
REAL_BIN="\${AI_SENTINEL_REAL_BIN:-\$HOME/.local/bin/\${TOOL}.real}"
API="${apiBase}/api/agent"
AGENTS_API="${apiBase}/api/agents"
KEY_FILE="\${AI_SENTINEL_KEY_FILE:-\$HOME/.config/ai-sentinel/agent.key}"
AGENT_VERSION="${AGENT_VERSION}"

[ -r "\$KEY_FILE" ] || { exec "\$REAL_BIN" "\$@"; }
AGENT_KEY=\$(tr -d '\\r\\n' < "\$KEY_FILE")

SESSION_ID="\$(hostname)-\$(whoami)-\$(date +%s)-\$\$"
AGENT_HOSTNAME=\$(hostname)
AGENT_USERNAME=\$(whoami)
WORK_DIR="\$PWD"

# 버전·도움말 조회는 AI 대화나 데이터 전송이 아니므로 보안 검토에서 제외합니다.
case "\${1:-}" in
  --version|-V|version|--help|-h) exec "\$REAL_BIN" "\$@" ;;
esac

_inventory_report() {
  local os_name=\$(uname -s | tr '[:upper:]' '[:lower:]'); [ "\$os_name" = "darwin" ] && os_name="macos"
  local arch=\$(uname -m)
  local os_ver=\$(uname -r 2>/dev/null)
  local tools=()
  for t in claude codex gemini; do
    { [ -x "\$HOME/.local/bin/\${t}.real" ] || [ -x "/usr/local/bin/\${t}.real" ] || [ -x "\$HOME/.npm-global/bin/\${t}.real" ]; } && tools+=("\$t")
  done
  local tools_str=\$(IFS=,; echo "\${tools[*]}")
  local body=\$(python3 -c "
import json
tools=list(filter(None,'\$tools_str'.split(',')))
print(json.dumps({'hostname':'\$AGENT_HOSTNAME','os':'\$os_name','os_version':'\$os_ver','arch':'\$arch','agent_version':'\$AGENT_VERSION','username':'\$AGENT_USERNAME','installed_tools':tools,'running_tools':[]}))" 2>/dev/null)
  [ -n "\$body" ] && curl -sf -X POST "\$AGENTS_API?action=inventory-report" \\
    -H "Content-Type: application/json" -H "x-ai-sentinel-key: \$AGENT_KEY" -d "\$body" >/dev/null 2>&1
}
_inventory_report &

api_value() { curl -sf -H "x-ai-sentinel-key: \$AGENT_KEY" "\$1" 2>/dev/null | tr -d '"'; }

BLOCKED=\$(api_value "\$API?check-block=1&hostname=\$AGENT_HOSTNAME&username=\$AGENT_USERNAME&tool=\$TOOL")
if [ "\$BLOCKED" = "true" ]; then
  echo "[EINSGUARD AI] 보안 정책에 따라 이 계정의 AI 실행이 차단되었습니다." >&2
  echo "관리자에게 장비명 \$AGENT_HOSTNAME, 사용자 \$AGENT_USERNAME을 알려주십시오." >&2; exit 1
fi

POLICY_RESULT=\$(api_value "\$API?check-policy=1&hostname=\$AGENT_HOSTNAME&username=\$AGENT_USERNAME&tool=\$TOOL")
if [ "\$POLICY_RESULT" != "ok" ] && [ -n "\$POLICY_RESULT" ]; then
  echo "[EINSGUARD AI] 보안 정책에 따라 실행이 중단되었습니다." >&2
  echo "중단 사유: \$POLICY_RESULT" >&2; exit 1
fi

APPROVAL_REQUIRED=\$(api_value "\$API?check-approval=1&hostname=\$AGENT_HOSTNAME&username=\$AGENT_USERNAME&tool=\$TOOL")
if [ "\$APPROVAL_REQUIRED" = "true" ]; then
  REQUEST_ID="POL-\$(date +%Y%m%d%H%M%S)-\$\$"
  echo "[EINSGUARD AI] 정책에 따라 실행 전 보안 검토가 필요합니다." >&2
  echo "요청 ID: \$REQUEST_ID" >&2
  echo "관리자가 이번 실행의 예외 허용 여부를 검토합니다. 민감정보가 포함됐다면 취소 후 제거하십시오." >&2
  TOKEN=\$(openssl rand -hex 16)
  curl -sf -X POST "\$API?action=request-approval" -H "Content-Type: application/json" -H "x-ai-sentinel-key: \$AGENT_KEY" \\
    -d "\$(python3 -c "import json; print(json.dumps({'session_id':'\$SESSION_ID','hostname':'\$AGENT_HOSTNAME','username':'\$AGENT_USERNAME','tool':'\$TOOL','work_dir':'\$WORK_DIR','args':'요청 ID \$REQUEST_ID · 명령 \${*:-대화형 실행}','token':'\$TOKEN'}))")" >/dev/null 2>&1
  for i in \$(seq 1 60); do
    sleep 5; STATUS=\$(api_value "\$API?approval-status=1&token=\$TOKEN")
    [ "\$STATUS" = "approved" ] && break
    [ "\$STATUS" = "rejected" ] && { echo "[EINSGUARD AI] 관리자가 이번 실행의 예외 허용을 거부했습니다. 요청 ID: \$REQUEST_ID" >&2; exit 1; }
  done
  [ "\$STATUS" != "approved" ] && { echo "[EINSGUARD AI] 보안 검토 시간이 초과되어 실행하지 않았습니다. 요청 ID: \$REQUEST_ID" >&2; exit 1; }
fi

GIT_BRANCH=\$(git -C "\$WORK_DIR" rev-parse --abbrev-ref HEAD 2>/dev/null || true)
GIT_COMMIT_BEFORE=\$(git -C "\$WORK_DIR" rev-parse HEAD 2>/dev/null || true)
logger -t ai-monitor "SESSION_START|\$SESSION_ID|\$AGENT_HOSTNAME|\$AGENT_USERNAME|\$TOOL|\$WORK_DIR|\$(date '+%Y-%m-%d %H:%M:%S')|\$GIT_BRANCH|\$*" 2>/dev/null

"\$REAL_BIN" "\$@" &
AI_PID=\$!
curl -sf -X POST "\$API?action=register-pid" -H "Content-Type: application/json" -H "x-ai-sentinel-key: \$AGENT_KEY" \\
  -d "\$(python3 -c "import json; print(json.dumps({'session_id':'\$SESSION_ID','hostname':'\$AGENT_HOSTNAME','username':'\$AGENT_USERNAME','tool':'\$TOOL','pid':\$AI_PID}))")" >/dev/null 2>&1

(PAUSED=false; while kill -0 "\$AI_PID" 2>/dev/null; do
  CTRL=\$(api_value "\$API?check-control=1&session_id=\$SESSION_ID")
  case "\$CTRL" in
    pause) [ "\$PAUSED"=false ] && kill -STOP "\$AI_PID" 2>/dev/null && PAUSED=true ;;
    resume) [ "\$PAUSED"=true ] && kill -CONT "\$AI_PID" 2>/dev/null && PAUSED=false ;;
    kill) kill "\$AI_PID" 2>/dev/null; break ;;
  esac; sleep 3
done) &
WATCHER_PID=\$!

wait "\$AI_PID"; EXIT_CODE=\$?
kill "\$WATCHER_PID" 2>/dev/null || true

START_TS=\$(echo "\$SESSION_ID" | awk -F'-' '{print \$(NF-1)}')
GIT_COMMIT_AFTER=\$(git -C "\$WORK_DIR" rev-parse HEAD 2>/dev/null || true)
FILES_CHANGED=""; GIT_COMMITS=""
if [ -n "\$GIT_COMMIT_BEFORE" ] && [ "\$GIT_COMMIT_BEFORE" != "\$GIT_COMMIT_AFTER" ]; then
  FILES_CHANGED=\$(git -C "\$WORK_DIR" diff --stat "\$GIT_COMMIT_BEFORE" "\$GIT_COMMIT_AFTER" 2>/dev/null | tail -1)
  GIT_COMMITS=\$(git -C "\$WORK_DIR" log --oneline "\$GIT_COMMIT_BEFORE".."$GIT_COMMIT_AFTER" 2>/dev/null | head -5 | tr '\\n' '|')
fi
logger -t ai-monitor "SESSION_END|\$SESSION_ID|\$AGENT_HOSTNAME|\$AGENT_USERNAME|\$TOOL|\$WORK_DIR|\$(date '+%Y-%m-%d %H:%M:%S')|\$(( \$(date +%s)-\${START_TS:-0} ))s|\$FILES_CHANGED|\$GIT_COMMITS" 2>/dev/null
exit "\$EXIT_CODE"
`;
}

function buildInstallScript(apiBase: string, agentKey: string): string {
  return `#!/bin/bash
# AI Sentinel Agent v${AGENT_VERSION} 설치 스크립트
set -e
API_BASE="${apiBase}"
AGENT_KEY="${agentKey}"
KEY_FILE="\$HOME/.config/ai-sentinel/agent.key"
WRAPPER_URL="\$API_BASE/api/install?script=wrapper&key=\$AGENT_KEY"

echo "[AI Sentinel] 설치 시작..."
mkdir -p "\$HOME/.config/ai-sentinel" "\$HOME/.local/share/ai-sentinel"
printf '%s' "\$AGENT_KEY" > "\$KEY_FILE"; chmod 600 "\$KEY_FILE"

curl -sf "\$WRAPPER_URL" -o "\$HOME/.local/share/ai-sentinel/wrapper.sh"
chmod +x "\$HOME/.local/share/ai-sentinel/wrapper.sh"

INSTALLED=()
for TOOL in claude codex gemini; do
  FOUND=""
  for p in "\$HOME/.local/bin/\$TOOL" "/usr/local/bin/\$TOOL" "\$HOME/.npm-global/bin/\$TOOL"; do
    [ -x "\$p" ] && ! head -1 "\$p" 2>/dev/null | grep -q 'AI Sentinel' && FOUND="\$p" && break
  done
  [ -z "\$FOUND" ] && continue
  REAL="\$(dirname "\$FOUND")/\${TOOL}.real"
  [ -f "\$REAL" ] || { cp "\$FOUND" "\$REAL"; chmod +x "\$REAL"; }
  DEST="\$HOME/.local/share/ai-sentinel/\${TOOL}-wrapper.sh"
  cp "\$HOME/.local/share/ai-sentinel/wrapper.sh" "\$DEST"
  if [ -L "\$FOUND" ]; then ln -sf "\$DEST" "\$FOUND"
  else cp "\$DEST" "\$FOUND"; chmod +x "\$FOUND"; fi
  INSTALLED+=("\$TOOL")
  echo "  ✓ \$TOOL → 래퍼 설치 완료"
done

[ \${#INSTALLED[@]} -eq 0 ] && echo "[AI Sentinel] claude/codex/gemini를 찾을 수 없습니다. AI 도구 설치 후 재실행하세요." && exit 1

OS_NAME=\$(uname -s | tr '[:upper:]' '[:lower:]' | sed 's/darwin/macos/')
ARCH=\$(uname -m); OS_VER=\$(uname -r); HOSTNAME=\$(hostname); USER=\$(whoami)
TOOLS_STR=\$(IFS=,; echo "\${INSTALLED[*]}")
BODY=\$(python3 -c "
import json
tools=list(filter(None,'\$TOOLS_STR'.split(',')))
print(json.dumps({'hostname':'\$HOSTNAME','os':'\$OS_NAME','os_version':'\$OS_VER','arch':'\$ARCH','agent_version':'${AGENT_VERSION}','username':'\$USER','installed_tools':tools,'running_tools':[]}))" 2>/dev/null)
HTTP=\$(curl -s -o /tmp/_ai_inv.txt -w "%{http_code}" -X POST "\$API_BASE/api/agents?action=inventory-report" \\
  -H "Content-Type: application/json" -H "x-ai-sentinel-key: \$AGENT_KEY" -d "\$BODY")
case "\$HTTP" in
  200) echo "[AI Sentinel] ✅ 대시보드 등록 완료" ;;
  402) echo "[AI Sentinel] ⚠️  라이선스 에이전트 수 초과 — 관리자에게 문의하세요" ;;
  *)   echo "[AI Sentinel] ⚠️  서버 응답 HTTP \$HTTP: \$(cat /tmp/_ai_inv.txt 2>/dev/null)" ;;
esac

echo ""
echo "✅ 설치 완료: \${INSTALLED[*]}"
echo "대시보드: \$API_BASE"
`;
}

export async function GET(req: NextRequest) {
  const script = req.nextUrl.searchParams.get('script');
  const keyParam = req.nextUrl.searchParams.get('key');
  const proto = req.headers.get('x-forwarded-proto') ?? req.nextUrl.protocol.replace(':','');
  const hostHeader = req.headers.get('x-forwarded-host') ?? req.headers.get('host') ?? req.nextUrl.host;
  const apiBase = `${proto}://${hostHeader}`;

  // ── 래퍼 스크립트 제공 (에이전트 자동 업데이트용) ───────────────────────
  if (script === 'wrapper') {
    const agentKey = req.headers.get('x-ai-sentinel-key') ?? keyParam ?? '';
    if (!agentKey) return new NextResponse('키가 필요합니다', { status: 401 });
    const verified=await verifyAgentKey(agentKey);
    if(!verified.valid)return new NextResponse('유효하지 않거나 해제된 Agent 키입니다.',{status:401});
    return new NextResponse(buildWrapperScript(apiBase), {
      headers: { 'Content-Type': 'text/plain; charset=utf-8' },
    });
  }

  // ── 설치 스크립트 제공 (고객사 배포용, curl | bash) ───────────────────
  if (script === 'install') {
    return new NextResponse('Agent 1.3.0부터 키가 포함된 curl 설치는 사용하지 않습니다. /api/install 안내에서 OS별 배포 파일을 내려받으세요.',{status:410});
  }

  // ── HTML 설치 가이드 페이지 (대시보드 관리자용) ───────────────────────
  const auth = await requireRole(req, ['admin', 'security']);
  if (auth.response) return auth.response;
  const serverHost = new URL(apiBase).host;
  const linuxCmd = `tar -xzf einsguard-ai-agent-1.4.0-linux.tar.gz && cd einsguard-ai-agent-1.4.0-linux && sudo ./install.sh ${serverHost}`;
  const macCmd = `tar -xzf einsguard-ai-agent-1.4.0-macos.tar.gz && cd einsguard-ai-agent-1.4.0-macos && sudo ./install-system.sh ${serverHost}`;
  const windowsCmd = `Set-ExecutionPolicy -Scope Process Bypass; .\\Install-AI-Sentinel.ps1 -ApiBase '${serverHost}'`;

  const html = `<!DOCTYPE html><html lang="ko"><head><meta charset="utf-8">
<title>AI Sentinel 설치</title>
<style>body{font-family:monospace;background:#0f172a;color:#e2e8f0;padding:2rem;max-width:860px;margin:auto}
h1{color:#34d399}h2{color:#94a3b8;font-size:.9rem;margin-top:1.8rem;text-transform:uppercase;letter-spacing:.05em}
.box{background:#1e293b;border:1px solid #334155;border-radius:8px;padding:1.2rem;margin:.5rem 0;font-size:.85rem;word-break:break-all}
.green{border-color:#34d399;color:#34d399}.note{color:#64748b;font-size:.75rem;margin-top:.4rem}</style></head>
<body>
<h1>AI Sentinel Agent v${AGENT_VERSION} 설치</h1>
<p style="color:#94a3b8">고객사 서버/PC 터미널에서 아래 명령어를 실행하세요. SSH 접속 불필요.</p>
<h2>Linux</h2><div class="box green">${linuxCmd}</div>
<h2>macOS</h2><div class="box green">${macCmd}</div>
<h2>Windows 관리자 PowerShell</h2><div class="box green">${windowsCmd}</div>
<div class="note">Agent 키는 명령에 넣지 않습니다. 설치 요청을 관리자가 승인하면 장비 전용 키를 자동 수령합니다.</div>
<h2>설치 과정</h2>
<div class="box">1. 장비 등록 요청<br>2. 관리 화면의 장비·사용자에서 승인<br>3. 장비 전용 키 자동 저장<br>4. 서비스 시작 및 상태 점검</div>
<h2>대시보드</h2>
<div class="box">${apiBase}</div>
</body></html>`;

  return new NextResponse(html, { headers: { 'Content-Type': 'text/html; charset=utf-8' } });
}
