import { NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/db';
import { verifyAgentKey } from '@/lib/agent-auth';
import { requireActiveLicense } from '@/lib/license';
import {AI_CATALOG} from '@/lib/ai-catalog';
import {getActivePolicySnapshot,getAgentPolicyState} from '@/lib/agent-policy';

function maskAgentArgs(value: unknown) {
  return String(value || '')
    .replace(/((?:api[_-]?key|token|password|secret)\s*[=:]\s*)\S+/gi, '$1***')
    .replace(/\b(?:sk|sk-ant)-[A-Za-z0-9_-]{12,}\b/g, '***');
}

function supportsSafeMonitorMode(version:unknown){
  const match=String(version||'').match(/^(\d+)\.(\d+)/);
  if(!match)return false;
  const major=Number(match[1]);const minor=Number(match[2]);
  return major>1||(major===1&&minor>=2);
}

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const action = searchParams.get('action') || req.nextUrl.pathname.split('/').pop();
  const hostname = searchParams.get('hostname') || '';
  const username = searchParams.get('username') || '';
  const tool = searchParams.get('tool') || '';
  const sessionId = searchParams.get('session_id') || '';
  const token = searchParams.get('token') || '';
  const agentAuth = await verifyAgentKey(req.headers.get('x-ai-sentinel-key'));
  if (!agentAuth.configured || !agentAuth.valid || !agentAuth.tenantId) return NextResponse.json({ error: 'Unauthorized agent' }, { status: 401 });
  const tenantId = agentAuth.tenantId;
  const licenseCheck=await requireActiveLicense(tenantId); if(licenseCheck.response)return licenseCheck.response;
  if(hostname){
    if(agentAuth.hostname&&agentAuth.hostname.toLowerCase()!==hostname.toLowerCase())return NextResponse.json({error:'Agent key does not match this device',code:'AGENT_KEY_DEVICE_MISMATCH'},{status:403});
    const retired=await pool.query(`SELECT 1 FROM ai_agents WHERE tenant_id=$1 AND LOWER(hostname)=LOWER($2) AND status='retired'`,[tenantId,hostname]);
    if(retired.rowCount)return NextResponse.json({error:'이 장비는 관리 해제되었습니다. 다시 등록 승인을 받아야 합니다.',code:'AGENT_RETIRED'},{status:403});
  }
  const policyState=await getAgentPolicyState(tenantId);

  if (action === 'policy-profile') {
    const [{rows},settings,managedCatalog,activeSnapshot]=await Promise.all([
      pool.query(`SELECT approved_tools,agent_version FROM ai_agents WHERE tenant_id=$1 AND hostname=$2`,[tenantId,hostname]),
      pool.query(`SELECT setting_key,setting_value FROM ai_settings WHERE tenant_id=$1 AND setting_key IN ('dlp_policy','custom_ai_catalog')`,[tenantId]),
      pool.query(`SELECT tool_key key,display_name name,processes,commands,domains FROM ai_catalog_entries WHERE tenant_id=$1 AND status='active'`,[tenantId]),
      getActivePolicySnapshot(tenantId),
    ]);
    const values=Object.fromEntries(settings.rows.map((x:any)=>[x.setting_key,x.setting_value]));
    const configuredDlp=activeSnapshot?.dlp_policy||values.dlp_policy||{enabled:true,blockCritical:true,storeRawChat:false,inspectInternalFingerprints:true,inspectContentWithLocalAi:true,aiVerification:true,evidenceRetentionDays:90,scanPromptText:true,scanClipboard:true,scanCliArguments:true,scanFileUploads:true};
    const monitorSafe=supportsSafeMonitorMode(rows[0]?.agent_version);
    const updateRequired=policyState.mode==='monitor'&&!monitorSafe;
    const dlp={...configuredDlp,enabled:configuredDlp.enabled!==false&&!updateRequired,blockCritical:policyState.mode==='enforce'&&configuredDlp.blockCritical!==false};
    return NextResponse.json({...policyState,approved_tools:rows[0]?.approved_tools||['claude','codex'],catalog:[...AI_CATALOG,...managedCatalog.rows,...(Array.isArray(values.custom_ai_catalog)?values.custom_ai_catalog:[])],catalog_version:'2026.08.17',dlp,classification_rules:activeSnapshot?.classification_rules||[],compatibility:{agent_version:rows[0]?.agent_version||'unknown',monitor_safe_agent:monitorSafe,update_required:updateRequired}});
  }

  // 차단 확인
  if (searchParams.has('check-block') || req.url.includes('check-block')) {
    if(policyState.mode!=='enforce')return NextResponse.json('false');
    const { rows } = await pool.query(
      `SELECT id FROM ai_blocks WHERE enabled = TRUE AND tenant_id=$4
       AND (hostname = '*' OR LOWER(hostname) = LOWER($1))
       AND (username = '*' OR LOWER(username) = LOWER($2))
       AND (tool = '*' OR LOWER(tool) = LOWER($3))
       LIMIT 1`,
      [hostname, username, tool, tenantId]
    );
    return NextResponse.json(rows.length > 0 ? 'true' : 'false');
  }

  // 정책 확인
  if (searchParams.has('check-policy') || req.url.includes('check-policy')) {
    if(policyState.mode!=='enforce')return NextResponse.json('ok');
    const hour = new Date().getHours();
    const { rows } = await pool.query(
      `SELECT id,allow_start,allow_end,max_per_hour,template_key FROM ai_policies WHERE enabled = TRUE AND tenant_id=$4
       AND (hostname = '*' OR LOWER(hostname) = LOWER($1))
       AND (username = '*' OR LOWER(username) = LOWER($2))
       AND (tool = '*' OR LOWER(tool) = LOWER($3))
       ORDER BY (hostname<>'*') DESC,(username<>'*') DESC,(tool<>'*') DESC,id DESC LIMIT 1`,
      [hostname, username, tool, tenantId]
    );
    if (rows.length > 0) {
      const p = rows[0];
      if (p.template_key === 'blocked') return NextResponse.json('AI 사용 금지 정책 적용');
      if (hour < p.allow_start || hour > p.allow_end) {
        return NextResponse.json(`허용 시간 외 사용 (허용: ${p.allow_start}시~${p.allow_end}시)`);
      }
      if(p.max_per_hour>0){
        const { rows: cnt } = await pool.query(
          `SELECT COUNT(*) as c FROM ai_usage WHERE LOWER(hostname)=LOWER($1) AND LOWER(username)=LOWER($2) AND tenant_id=$3
           AND logged_at > NOW() - INTERVAL '1 hour'`,
          [hostname, username, tenantId]
        );
        if (parseInt(cnt[0].c) >= p.max_per_hour) {
          return NextResponse.json(`시간당 최대 사용 횟수 초과 (최대: ${p.max_per_hour}회)`);
        }
      }
    }
    return NextResponse.json('ok');
  }

  // 승인 필요 여부
  if (searchParams.has('check-approval') || req.url.includes('check-approval')) {
    if(policyState.mode!=='enforce')return NextResponse.json('false');
    const { rows } = await pool.query(
      `SELECT id FROM ai_policies WHERE enabled = TRUE AND max_per_hour = 0 AND tenant_id=$4
       AND COALESCE(template_key,'') <> 'blocked'
       AND (hostname = '*' OR LOWER(hostname) = LOWER($1))
       AND (username = '*' OR LOWER(username) = LOWER($2))
       AND (tool = '*' OR LOWER(tool) = LOWER($3)) LIMIT 1`,
      [hostname, username, tool, tenantId]
    );
    return NextResponse.json(rows.length > 0 ? 'true' : 'false');
  }

  // 승인 상태 확인
  if (searchParams.has('approval-status') || req.url.includes('approval-status')) {
    const { rows } = await pool.query(
      `SELECT status FROM ai_approvals WHERE token = $1 AND tenant_id=$2`, [token, tenantId]
    );
    return NextResponse.json(rows[0]?.status || 'pending');
  }

  // 세션 제어 명령 확인 (기존 check-kill도 하위 호환)
  if (searchParams.has('check-control') || req.url.includes('check-control') || searchParams.has('check-kill') || req.url.includes('check-kill')) {
    await pool.query(`UPDATE ai_commands SET heartbeat_at=NOW(),status='active'
      WHERE session_id=$1 AND tenant_id=$2 AND command='registered' AND status IN ('active','stale')`,[sessionId,tenantId]);
    if(policyState.mode!=='enforce'){
      await pool.query(`UPDATE ai_commands SET status='ignored',executed_at=NOW()
        WHERE session_id=$1 AND tenant_id=$2 AND command IN ('pause','resume','kill') AND status='pending'`,[sessionId,tenantId]);
      return NextResponse.json('ok');
    }
    const { rows } = await pool.query(
      `SELECT id, command FROM ai_commands
       WHERE session_id = $1 AND tenant_id=$2 AND command IN ('pause', 'resume', 'kill') AND status = 'pending'
       ORDER BY CASE command WHEN 'kill' THEN 1 WHEN 'pause' THEN 2 ELSE 3 END, created_at
       LIMIT 1`,
      [sessionId, tenantId]
    );
    if (rows.length > 0) {
      await pool.query(`UPDATE ai_commands SET status='executed', executed_at=NOW() WHERE id=$1`, [rows[0].id]);
      return NextResponse.json(rows[0].command);
    }
    return NextResponse.json('ok');
  }

  return NextResponse.json({ error: 'unknown action' }, { status: 400 });
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const action = req.nextUrl.searchParams.get('action') || body.action || '';
  const agentAuth = await verifyAgentKey(req.headers.get('x-ai-sentinel-key'));
  if (!agentAuth.configured || !agentAuth.valid || !agentAuth.tenantId) return NextResponse.json({ error: 'Unauthorized agent' }, { status: 401 });
  const tenantId = agentAuth.tenantId;
  const licenseCheck=await requireActiveLicense(tenantId); if(licenseCheck.response)return licenseCheck.response;
  const postedHostname=String(body.hostname||'').slice(0,255);
  if(postedHostname){
    if(agentAuth.hostname&&agentAuth.hostname.toLowerCase()!==postedHostname.toLowerCase())return NextResponse.json({error:'Agent key does not match this device',code:'AGENT_KEY_DEVICE_MISMATCH'},{status:403});
    const retired=await pool.query(`SELECT 1 FROM ai_agents WHERE tenant_id=$1 AND LOWER(hostname)=LOWER($2) AND status='retired'`,[tenantId,postedHostname]);
    if(retired.rowCount)return NextResponse.json({error:'이 장비는 관리 해제되었습니다. 다시 등록 승인을 받아야 합니다.',code:'AGENT_RETIRED'},{status:403});
  }

  // 승인 요청 등록
  if (action === 'request-approval') {
    const approvalArgs=String(body.args||'').trim();
    if(/^(--version|-V|version|--help|-h)$/i.test(approvalArgs)){
      return NextResponse.json({ok:true,ignored:true,reason:'METADATA_COMMAND'});
    }
    await pool.query(
      `INSERT INTO ai_approvals (session_id, hostname, username, tool, work_dir, args, token, tenant_id)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
      [body.session_id, body.hostname, body.username, body.tool, body.work_dir, approvalArgs, body.token, tenantId]
    );
    return NextResponse.json({ ok: true });
  }

  // PID 등록
  if (action === 'register-pid') {
    await pool.query(
      `INSERT INTO ai_commands (session_id, hostname, username, tool, pid, command, status, heartbeat_at, tenant_id)
       VALUES ($1,$2,$3,$4,$5,'registered','active',NOW(),$6)
       ON CONFLICT DO NOTHING`,
      [body.session_id, body.hostname, body.username, body.tool, body.pid, tenantId]
    );
    return NextResponse.json({ ok: true });
  }

  // Windows 등 rsyslog를 사용하지 않는 에이전트의 세션 감사 수집
  if (action === 'session-start') {
    const sessionId = String(body.session_id || '').slice(0, 200);
    const hostname = String(body.hostname || '').slice(0, 100);
    const username = String(body.username || '').slice(0, 100);
    const tool = String(body.tool || '').slice(0, 50);
    if (!sessionId || !hostname || !tool) return NextResponse.json({ error: 'Missing session fields' }, { status: 400 });
    const args = maskAgentArgs(body.args).slice(0, 8000);
    await pool.query(
      `INSERT INTO ai_sessions(session_id,hostname,username,tool,work_dir,started_at,git_branch,args,tenant_id)
       VALUES($1,$2,$3,$4,$5,COALESCE($6::timestamptz,NOW()),$7,$8,$9)
       ON CONFLICT(session_id) DO NOTHING`,
      [sessionId,hostname,username,tool,String(body.work_dir||'').slice(0,2000),body.started_at||null,String(body.git_branch||'').slice(0,200),args,tenantId]
    );
    await pool.query(
      `INSERT INTO ai_usage(logged_at,hostname,username,tool,pid,args,tenant_id)
       SELECT COALESCE($1::timestamptz,NOW()),$2::varchar,$3::varchar,$4::varchar,$5::integer,$6::text,$7::bigint
       WHERE NOT EXISTS(SELECT 1 FROM ai_usage WHERE hostname=$2::varchar AND username=$3::varchar AND tool=$4::varchar AND args=$6::text AND logged_at>NOW()-INTERVAL '5 seconds')`,
      [body.started_at||null,hostname,username,tool,Number(body.pid)||null,args,tenantId]
    );
    return NextResponse.json({ ok:true });
  }

  if (action === 'session-end') {
    const sessionId = String(body.session_id || '').slice(0, 200);
    if (!sessionId) return NextResponse.json({ error: 'Missing session_id' }, { status: 400 });
    await pool.query(
      `UPDATE ai_sessions SET ended_at=COALESCE($1::timestamptz,NOW()),duration_sec=$2,
       files_changed=$3,git_commits=$4 WHERE session_id=$5 AND tenant_id=$6`,
      [body.ended_at||null,Math.max(0,Number(body.duration_sec)||0),String(body.files_changed||'').slice(0,4000),String(body.git_commits||'').slice(0,4000),sessionId,tenantId]
    );
    await pool.query(`UPDATE ai_commands SET status='ended',executed_at=NOW()
      WHERE session_id=$1 AND tenant_id=$2 AND command='registered' AND status IN ('active','stale')`,[sessionId,tenantId]);
    return NextResponse.json({ ok:true });
  }

  if (action === 'security-event') {
    const hostname=String(body.hostname||'').slice(0,100); const tool=String(body.tool||'unknown').slice(0,50);
    const eventType=String(body.event_type||'WINDOWS_SECURITY_EVENT').slice(0,80);
    const eventLabels:Record<string,string>={UNAPPROVED_AI_RUNNING:'승인되지 않은 AI 실행 감지',UNAPPROVED_AI_BLOCKED:'승인되지 않은 AI 앱·CLI 실행 차단',UNAPPROVED_WEB_AI_BLOCKED:'승인되지 않은 웹 AI 접속 차단',AI_WINDOW_DETECTED:'AI 앱 창 실행 감지',WINDOWS_SECURITY_EVENT:'Windows 보안 이벤트'};
    const receivedDetail=maskAgentArgs(body.detail).slice(0,4000);
    const detail=/\?{2,}/.test(receivedDetail)?`${eventLabels[eventType]||'AI 보안 이벤트'}: ${tool}`:receivedDetail;
    const result=await pool.query(`INSERT INTO ai_shadow_events(hostname,username,tool,event_type,detail,tenant_id)
      SELECT $1::varchar,$2::varchar,$3::varchar,$4::varchar,$5::text,$6::bigint WHERE NOT EXISTS(
        SELECT 1 FROM ai_shadow_events WHERE tenant_id=$6::bigint AND hostname=$1::varchar AND tool=$3::varchar AND event_type=$4::varchar
        AND resolved=false AND created_at>NOW()-INTERVAL '1 hour') RETURNING id`,
      [hostname,String(body.username||'').slice(0,100),tool,eventType,detail,tenantId]);
    if(eventType==='AI_WINDOW_DETECTED'&&result.rowCount){
      await pool.query(`INSERT INTO ai_usage(logged_at,hostname,username,tool,args,tenant_id) VALUES(NOW(),$1,$2,$3,'앱/브라우저 창 실행 감지',$4)`,[hostname,String(body.username||'').slice(0,100),tool,tenantId]);
    }
    return NextResponse.json({ok:true,deduplicated:result.rowCount===0});
  }

  // CLI hook/수집기가 제공하는 실제 토큰·비용 텔레메트리
  if (action === 'usage-report') {
    const inputTokens = Math.max(0, Number(body.input_tokens) || 0);
    const outputTokens = Math.max(0, Number(body.output_tokens) || 0);
    const costUsd = Math.max(0, Number(body.cost_usd) || 0);
    await pool.query(
      `UPDATE ai_usage SET model=COALESCE($1,model), input_tokens=$2, output_tokens=$3, cost_usd=$4
       WHERE id=(SELECT id FROM ai_usage WHERE hostname=$5 AND username=$6 AND tool=$7 AND tenant_id=$8 ORDER BY logged_at DESC LIMIT 1)`,
      [body.model || null, inputTokens, outputTokens, costUsd, body.hostname, body.username, body.tool, tenantId]
    );
    return NextResponse.json({ ok: true });
  }

  return NextResponse.json({ error: 'unknown action' }, { status: 400 });
}
