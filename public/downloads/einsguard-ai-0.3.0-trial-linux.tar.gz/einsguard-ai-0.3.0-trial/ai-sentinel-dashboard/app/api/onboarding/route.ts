import {NextRequest,NextResponse} from 'next/server';
import pool from '@/lib/db';
import type {PoolClient} from 'pg';
import path from 'node:path';
import {requireRole} from '@/lib/auth';
import {getLocalAiPublicConfig} from '@/lib/local-ai';
import {
  auditConfiguration,OnboardingInputError,onboardingSnapshot,remoteIp,validateClassificationRules,
  validateDataSources,validateDestinations,validateDlpPolicy,validateOrganization,
} from '@/lib/onboarding';
import {fingerprintConfigStatus} from '@/lib/fingerprint-match';

async function loadOnboarding(tenantId:number){
  const [state,profile,destinations,rules,sources,versions,audit,indexJobs,dlpSettings]=await Promise.all([
    pool.query('SELECT * FROM ai_onboarding_state WHERE tenant_id=$1',[tenantId]),
    pool.query('SELECT * FROM ai_organization_profiles WHERE tenant_id=$1',[tenantId]),
    pool.query(`SELECT id,name,destination_type,match_type,match_value,decision,notes,enabled,updated_at FROM ai_destinations WHERE tenant_id=$1 ORDER BY id`,[tenantId]),
    pool.query(`SELECT id,name,classification_level,rule_type,pattern,action,weight,case_sensitive,enabled,updated_at FROM ai_classification_rules WHERE tenant_id=$1 ORDER BY id`,[tenantId]),
    pool.query(`SELECT id,name,source_type,location,status,config,last_indexed_at,last_error,enabled,updated_at FROM ai_data_sources WHERE tenant_id=$1 ORDER BY id`,[tenantId]),
    pool.query(`SELECT version,status,notes,created_at,created_by,activated_at FROM ai_policy_versions WHERE tenant_id=$1 ORDER BY version DESC LIMIT 10`,[tenantId]),
    pool.query(`SELECT created_at,username,action,object_type,summary FROM ai_configuration_audit WHERE tenant_id=$1 ORDER BY created_at DESC LIMIT 25`,[tenantId]),
    pool.query(`SELECT j.id,j.data_source_id,s.name data_source_name,j.status,j.requested_by,j.requested_at,j.started_at,j.completed_at,
      j.files_indexed,j.files_skipped,j.fingerprints_indexed,j.error FROM ai_index_jobs j
      JOIN ai_data_sources s ON s.id=j.data_source_id AND s.tenant_id=j.tenant_id
      WHERE j.tenant_id=$1 ORDER BY j.requested_at DESC LIMIT 25`,[tenantId]),
    pool.query(`SELECT setting_value FROM ai_settings WHERE tenant_id=$1 AND setting_key='dlp_policy'`,[tenantId]),
  ]);
  const onboarding=state.rows[0];const organization=profile.rows[0];
  if(!onboarding||!organization)throw new Error('온보딩 데이터베이스 초기화가 필요합니다.');
  const progress={
    organization:Boolean(organization.company_name&&(organization.company_domains.length||organization.internal_cidrs.length)),
    destinations:destinations.rows.some(row=>row.enabled),
    classification:rules.rows.some(row=>row.enabled),
    data_sources:sources.rows.some(row=>row.enabled)||onboarding.acknowledge_no_data_source,
    completed:onboarding.status==='completed',
  };
  const dlpPolicy=validateDlpPolicy(dlpSettings.rows[0]?.setting_value||{});
  const contentHandling={
    inspect_internal_fingerprints:dlpPolicy.inspectInternalFingerprints!==false,
    inspect_content_with_local_ai:dlpPolicy.inspectContentWithLocalAi!==false,
    ai_verification:dlpPolicy.aiVerification!==false,
    store_raw_content:dlpPolicy.storeRawChat===true,
    evidence_retention_days:Math.max(7,Math.min(3650,Number(dlpPolicy.evidenceRetentionDays)||90)),
    raw_retention_days:Math.max(1,Math.min(30,Number(dlpPolicy.rawRetentionDays)||7)),
  };
  return {onboarding,organization,destinations:destinations.rows,classification_rules:rules.rows,dlp_policy:dlpPolicy,data_sources:sources.rows,policy_versions:versions.rows,audit:audit.rows,index_jobs:indexJobs.rows,progress,draft_pending:onboarding.config_revision!==onboarding.active_revision,local_ai:getLocalAiPublicConfig(),fingerprinting:fingerprintConfigStatus(),content_handling:contentHandling};
}

function indexLocationAllowed(location:string){
  const target=path.resolve(location);const roots=String(process.env.DATA_SOURCE_ALLOWED_ROOTS||'/data-sources').split(',').map(value=>path.resolve(value.trim())).filter(Boolean);
  return roots.some(root=>{const relative=path.relative(root,target);return relative===''||(!relative.startsWith(`..${path.sep}`)&&relative!=='..'&&!path.isAbsolute(relative));});
}

async function markStep(client:PoolClient,tenantId:number,step:number){
  await client.query(`UPDATE ai_onboarding_state SET current_step=GREATEST(current_step,$2),
    status=CASE WHEN status='completed' THEN status ELSE 'configuring' END,
    config_revision=config_revision+1,updated_at=NOW() WHERE tenant_id=$1`,[tenantId,step]);
}

async function activatePolicy(client:PoolClient,tenantId:number,username:string,mode:'monitor'|'enforce',notes:string){
  const snapshot=await onboardingSnapshot(client,tenantId,mode);
  const {rows}=await client.query('SELECT COALESCE(MAX(version),0)+1 version FROM ai_policy_versions WHERE tenant_id=$1',[tenantId]);
  await client.query(`UPDATE ai_policy_versions SET status='retired' WHERE tenant_id=$1 AND status='active'`,[tenantId]);
  await client.query(`INSERT INTO ai_policy_versions(tenant_id,version,status,snapshot,notes,created_by,activated_at)
    VALUES($1,$2,'active',$3,$4,$5,NOW())`,[tenantId,rows[0].version,snapshot,notes,username]);
  await client.query(`UPDATE ai_onboarding_state SET enforcement_mode=$2,active_revision=config_revision,
    last_validated_at=NOW(),updated_at=NOW() WHERE tenant_id=$1`,[tenantId,mode]);
  return Number(rows[0].version);
}

export async function GET(req:NextRequest){
  const auth=await requireRole(req,['admin','security','auditor']);if(auth.response)return auth.response;
  try{return NextResponse.json(await loadOnboarding(auth.user!.tenantId));}
  catch(error){return NextResponse.json({error:error instanceof Error?error.message:'온보딩 설정 조회 실패'},{status:500});}
}

export async function PATCH(req:NextRequest){
  const auth=await requireRole(req,['admin']);if(auth.response)return auth.response;
  const contentLength=Number(req.headers.get('content-length')||0);
  if(contentLength>250_000)return NextResponse.json({error:'설정 요청이 너무 큽니다.'},{status:413});
  const body=await req.json().catch(()=>null);
  if(!body||typeof body!=='object')return NextResponse.json({error:'JSON 설정이 필요합니다.'},{status:400});
  const tenantId=auth.user!.tenantId;const username=auth.user!.username;const ip=remoteIp(req.headers);
  const client=await pool.connect();
  try{
    await client.query('BEGIN');
    if(body.action==='save_organization'){
      const value=validateOrganization(body.organization);
      await client.query(`UPDATE ai_organization_profiles SET company_name=$2,company_domains=$3,internal_cidrs=$4,
        timezone=$5,data_residency=$6,updated_at=NOW(),updated_by=$7 WHERE tenant_id=$1`,
        [tenantId,value.companyName,value.domains,value.cidrs,value.timezone,value.dataResidency,username]);
      await client.query('UPDATE ai_tenants SET name=$2 WHERE id=$1',[tenantId,value.companyName]);
      await markStep(client,tenantId,2);
      await auditConfiguration(client,{tenantId,username,action:'SAVE_ORGANIZATION',objectType:'onboarding',summary:'회사 기본정보와 내부망 범위를 저장함',details:{domain_count:value.domains.length,cidr_count:value.cidrs.length},remoteIp:ip});
    }else if(body.action==='replace_destinations'){
      const values=validateDestinations(body.destinations);
      await client.query('DELETE FROM ai_destinations WHERE tenant_id=$1',[tenantId]);
      for(const value of values)await client.query(`INSERT INTO ai_destinations
        (tenant_id,name,destination_type,match_type,match_value,decision,notes,enabled,updated_by)
        VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9)`,[tenantId,value.name,value.destinationType,value.matchType,value.matchValue,value.decision,value.notes||null,value.enabled,username]);
      await markStep(client,tenantId,3);
      await auditConfiguration(client,{tenantId,username,action:'REPLACE_DESTINATIONS',objectType:'onboarding',summary:'AI 목적지 정책을 저장함',details:{count:values.length},remoteIp:ip});
    }else if(body.action==='replace_classification_rules'){
      const values=validateClassificationRules(body.classification_rules);
      const dlpPolicy=validateDlpPolicy(body.dlp_policy||{});
      await client.query('DELETE FROM ai_classification_rules WHERE tenant_id=$1',[tenantId]);
      for(const value of values)await client.query(`INSERT INTO ai_classification_rules
        (tenant_id,name,classification_level,rule_type,pattern,action,weight,case_sensitive,enabled,updated_by)
        VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,[tenantId,value.name,value.level,value.ruleType,value.pattern,value.action,value.weight,value.caseSensitive,value.enabled,username]);
      await client.query(`INSERT INTO ai_settings(tenant_id,setting_key,setting_value,updated_by) VALUES($1,'dlp_policy',$2,$3)
        ON CONFLICT(tenant_id,setting_key) DO UPDATE SET setting_value=EXCLUDED.setting_value,updated_at=NOW(),updated_by=EXCLUDED.updated_by`,[tenantId,dlpPolicy,username]);
      await markStep(client,tenantId,4);
      await auditConfiguration(client,{tenantId,username,action:'REPLACE_CLASSIFICATION_RULES',objectType:'onboarding',summary:'회사 데이터 분류 규칙과 내장 DLP 모듈 설정을 저장함',details:{count:values.length,dlp_channels:{prompt:dlpPolicy.scanPromptText,clipboard:dlpPolicy.scanClipboard,cli:dlpPolicy.scanCliArguments,file_upload:dlpPolicy.scanFileUploads}},remoteIp:ip});
    }else if(body.action==='replace_data_sources'){
      const values=validateDataSources(body.data_sources);
      const keepIds:number[]=[];
      for(const value of values){
        if(value.id){
          const existing=await client.query(`SELECT id,(source_type IS DISTINCT FROM $3 OR location IS DISTINCT FROM $4 OR config IS DISTINCT FROM $5::jsonb) changed
            FROM ai_data_sources WHERE id=$1 AND tenant_id=$2 FOR UPDATE`,[value.id,tenantId,value.sourceType,value.location,value.config]);
          if(!existing.rows.length)throw new OnboardingInputError(`데이터 원본을 찾을 수 없습니다: ${value.name}`);
          const changed=Boolean(existing.rows[0].changed);
          await client.query(`UPDATE ai_data_sources SET name=$3,source_type=$4,location=$5,config=$6,enabled=$7,updated_by=$8,updated_at=NOW(),
            status=CASE WHEN $9 THEN 'draft' ELSE status END,last_error=CASE WHEN $9 THEN NULL ELSE last_error END WHERE id=$1 AND tenant_id=$2`,
            [value.id,tenantId,value.name,value.sourceType,value.location,value.config,value.enabled,username,changed]);
          if(changed){
            await client.query(`DELETE FROM ai_document_fingerprints WHERE tenant_id=$1 AND document_id IN (SELECT id FROM ai_indexed_documents WHERE data_source_id=$2)`,[tenantId,value.id]);
            await client.query(`UPDATE ai_indexed_documents SET deleted_at=NOW(),fingerprint_count=0 WHERE tenant_id=$1 AND data_source_id=$2`,[tenantId,value.id]);
          }
          keepIds.push(value.id);
        }else{
          const inserted=await client.query(`INSERT INTO ai_data_sources
            (tenant_id,name,source_type,location,status,config,enabled,updated_by)
            VALUES($1,$2,$3,$4,'draft',$5,$6,$7) RETURNING id`,[tenantId,value.name,value.sourceType,value.location,value.config,value.enabled,username]);
          keepIds.push(Number(inserted.rows[0].id));
        }
      }
      if(keepIds.length)await client.query('DELETE FROM ai_data_sources WHERE tenant_id=$1 AND NOT(id=ANY($2::bigint[]))',[tenantId,keepIds]);
      else await client.query('DELETE FROM ai_data_sources WHERE tenant_id=$1',[tenantId]);
      await client.query(`UPDATE ai_onboarding_state SET acknowledge_no_data_source=$2 WHERE tenant_id=$1`,[tenantId,Boolean(body.acknowledge_no_data_source)]);
      await markStep(client,tenantId,5);
      await auditConfiguration(client,{tenantId,username,action:'REPLACE_DATA_SOURCES',objectType:'onboarding',summary:'내부 데이터 원본 메타데이터를 저장함',details:{count:values.length,no_source_acknowledged:Boolean(body.acknowledge_no_data_source)},remoteIp:ip});
    }else if(body.action==='set_step'){
      const step=Number(body.step);if(!Number.isInteger(step)||step<1||step>5)throw new OnboardingInputError('설정 단계가 올바르지 않습니다.');
      await client.query(`UPDATE ai_onboarding_state SET current_step=$2,status=CASE WHEN status='completed' THEN status ELSE 'configuring' END,updated_at=NOW() WHERE tenant_id=$1`,[tenantId,step]);
    }else if(body.action==='complete_onboarding'){
      const profile=await client.query('SELECT company_name,company_domains,internal_cidrs FROM ai_organization_profiles WHERE tenant_id=$1',[tenantId]);
      const destinations=await client.query('SELECT COUNT(*)::int count FROM ai_destinations WHERE tenant_id=$1 AND enabled=true',[tenantId]);
      const rules=await client.query('SELECT COUNT(*)::int count FROM ai_classification_rules WHERE tenant_id=$1 AND enabled=true',[tenantId]);
      const sources=await client.query('SELECT COUNT(*)::int count FROM ai_data_sources WHERE tenant_id=$1 AND enabled=true',[tenantId]);
      const state=await client.query('SELECT status,acknowledge_no_data_source FROM ai_onboarding_state WHERE tenant_id=$1 FOR UPDATE',[tenantId]);
      if(state.rows[0]?.status==='completed'){
        await client.query('COMMIT');
        return NextResponse.json({ok:true,...await loadOnboarding(tenantId)});
      }
      const organization=profile.rows[0];
      if(!organization?.company_name||(!organization.company_domains.length&&!organization.internal_cidrs.length))throw new OnboardingInputError('회사 도메인 또는 내부 IP 대역을 등록해야 합니다.');
      if(!destinations.rows[0].count)throw new OnboardingInputError('AI 목적지를 하나 이상 등록해야 합니다.');
      if(!rules.rows[0].count)throw new OnboardingInputError('데이터 분류 규칙을 하나 이상 등록해야 합니다.');
      if(!sources.rows[0].count&&!state.rows[0].acknowledge_no_data_source)throw new OnboardingInputError('데이터 원본을 등록하거나 수동 분류만 사용할 것인지 확인해야 합니다.');
      const version=await activatePolicy(client,tenantId,username,'monitor','초기 온보딩 완료: 모니터링 전용');
      await client.query(`UPDATE ai_onboarding_state SET status='completed',current_step=6,completed_at=NOW(),completed_by=$2,updated_at=NOW() WHERE tenant_id=$1`,[tenantId,username]);
      await auditConfiguration(client,{tenantId,username,action:'COMPLETE_ONBOARDING',objectType:'onboarding',objectId:String(version),summary:'초기 설정을 완료하고 모니터링 전용 정책을 활성화함',details:{policy_version:version},remoteIp:ip});
    }else if(body.action==='set_enforcement_mode'){
      const mode=body.mode==='enforce'?'enforce':body.mode==='monitor'?'monitor':null;if(!mode)throw new OnboardingInputError('운영 모드가 올바르지 않습니다.');
      const {rows}=await client.query('SELECT status,enforcement_mode FROM ai_onboarding_state WHERE tenant_id=$1 FOR UPDATE',[tenantId]);
      if(rows[0]?.status!=='completed')throw new OnboardingInputError('초기 설정을 완료한 후 운영 모드를 변경할 수 있습니다.');
      if(mode==='enforce'&&body.confirmation!=='ENABLE_ENFORCEMENT')throw new OnboardingInputError('차단 모드 전환 확인 문자열이 필요합니다.');
      if(rows[0].enforcement_mode===mode){
        await client.query('COMMIT');
        return NextResponse.json({ok:true,...await loadOnboarding(tenantId)});
      }
      const version=await activatePolicy(client,tenantId,username,mode,mode==='enforce'?'관리자 승인 차단 모드':'관리자 승인 모니터링 모드');
      await auditConfiguration(client,{tenantId,username,action:'SET_ENFORCEMENT_MODE',objectType:'policy',objectId:String(version),summary:`운영 모드를 ${mode}로 변경함`,details:{policy_version:version,mode},remoteIp:ip});
    }else if(body.action==='publish_policy'){
      const {rows}=await client.query('SELECT status,enforcement_mode,config_revision,active_revision FROM ai_onboarding_state WHERE tenant_id=$1 FOR UPDATE',[tenantId]);
      if(rows[0]?.status!=='completed')throw new OnboardingInputError('초기 설정을 완료한 후 정책을 배포할 수 있습니다.');
      if(rows[0].config_revision===rows[0].active_revision){
        await client.query('COMMIT');
        return NextResponse.json({ok:true,...await loadOnboarding(tenantId)});
      }
      const mode=rows[0].enforcement_mode as 'monitor'|'enforce';
      const notes=String(body.notes||'관리자 설정 변경 배포').trim().slice(0,500)||'관리자 설정 변경 배포';
      const version=await activatePolicy(client,tenantId,username,mode,notes);
      await auditConfiguration(client,{tenantId,username,action:'PUBLISH_POLICY',objectType:'policy',objectId:String(version),summary:'변경된 보호 설정을 현재 운영 모드로 배포함',details:{policy_version:version,mode},remoteIp:ip});
    }else if(body.action==='start_index'){
      if(!fingerprintConfigStatus().configured)throw new Error('문서 지문 비밀키가 설정되지 않았습니다.');
      const sourceId=Number(body.data_source_id);if(!Number.isInteger(sourceId)||sourceId<1)throw new OnboardingInputError('데이터 원본 ID가 올바르지 않습니다.');
      const {rows}=await client.query(`SELECT id,name,source_type,location,enabled FROM ai_data_sources WHERE id=$1 AND tenant_id=$2 FOR UPDATE`,[sourceId,tenantId]);
      const source=rows[0];if(!source)throw new OnboardingInputError('데이터 원본을 찾을 수 없습니다.');
      if(!source.enabled)throw new OnboardingInputError('비활성화된 데이터 원본은 인덱싱할 수 없습니다.');
      if(!['filesystem','nas'].includes(source.source_type))throw new OnboardingInputError('현재 파일시스템과 NAS 인덱싱만 지원합니다.');
      if(!indexLocationAllowed(source.location))throw new OnboardingInputError('인덱싱 경로는 허용된 읽기 전용 루트(/data-sources) 아래여야 합니다.');
      const job=await client.query(`INSERT INTO ai_index_jobs(tenant_id,data_source_id,requested_by) VALUES($1,$2,$3) RETURNING id`,[tenantId,sourceId,username]);
      await client.query(`UPDATE ai_data_sources SET status='connected',last_error=NULL,updated_at=NOW() WHERE id=$1`,[sourceId]);
      await auditConfiguration(client,{tenantId,username,action:'START_INDEX',objectType:'data_source',objectId:String(sourceId),summary:'내부 문서 지문 인덱싱을 요청함',details:{job_id:Number(job.rows[0].id)},remoteIp:ip});
    }else if(body.action==='cancel_index'){
      const jobId=Number(body.job_id);if(!Number.isInteger(jobId)||jobId<1)throw new OnboardingInputError('인덱싱 작업 ID가 올바르지 않습니다.');
      const cancelled=await client.query(`UPDATE ai_index_jobs SET status='cancelled',completed_at=NOW(),error='관리자가 대기 작업을 취소함'
        WHERE id=$1 AND tenant_id=$2 AND status='queued' RETURNING data_source_id`,[jobId,tenantId]);
      if(!cancelled.rowCount)throw new OnboardingInputError('대기 중인 인덱싱 작업만 취소할 수 있습니다.');
      await auditConfiguration(client,{tenantId,username,action:'CANCEL_INDEX',objectType:'index_job',objectId:String(jobId),summary:'대기 중인 문서 인덱싱을 취소함',remoteIp:ip});
    }else throw new OnboardingInputError('지원하지 않는 온보딩 작업입니다.');
    await client.query('COMMIT');
    return NextResponse.json({ok:true,...await loadOnboarding(tenantId)});
  }catch(error:any){
    await client.query('ROLLBACK').catch(()=>{});
    const message=error instanceof Error?error.message:'온보딩 설정 저장 실패';
    if(error?.code==='23505')return NextResponse.json({error:'중복된 설정이 있습니다.'},{status:409});
    if(error instanceof OnboardingInputError)return NextResponse.json({error:message},{status:400});
    console.error('Onboarding update failed',error);
    return NextResponse.json({error:'온보딩 설정을 저장하지 못했습니다.'},{status:500});
  }finally{client.release();}
}
