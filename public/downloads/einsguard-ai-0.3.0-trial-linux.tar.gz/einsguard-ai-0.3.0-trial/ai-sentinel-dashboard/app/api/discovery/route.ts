import { NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/db';
import { requireRole } from '@/lib/auth';
import { requireActiveLicense } from '@/lib/license';
import { runDiscoveryScan } from '@/lib/scanner';

export async function GET(req: NextRequest) {
  const auth = await requireRole(req, ['admin', 'security', 'auditor', 'viewer']);
  if (auth.response) return auth.response;
  const tenantId = auth.user!.tenantId;

  const [settings, scopes, activeRun, recentRuns, installedAgents, uninstalledAssets] = await Promise.all([
    pool.query(`SELECT * FROM ai_discovery_settings WHERE tenant_id=$1`, [tenantId]),
    pool.query(`SELECT id, network::text, enabled, created_at FROM ai_discovery_scopes WHERE tenant_id=$1 ORDER BY created_at`, [tenantId]),
    pool.query(`SELECT * FROM ai_discovery_runs WHERE tenant_id=$1 AND status IN ('queued','running') ORDER BY requested_at DESC LIMIT 1`, [tenantId]),
    pool.query(`SELECT * FROM ai_discovery_runs WHERE tenant_id=$1 ORDER BY requested_at DESC LIMIT 5`, [tenantId]),
    // 등록된 IP 범위 내에 있는 에이전트 → 항상 "설치됨"으로 표시 (IPv4-mapped IPv6 정규화)
    pool.query(
      `SELECT DISTINCT ON (ag.hostname) ag.hostname,
              replace(host(ag.last_ip), '::ffff:', '') AS ip,
              ag.os, ag.os_version, ag.agent_version, ag.username, ag.last_seen AS agent_last_seen
       FROM ai_agents ag, ai_discovery_scopes sc
       WHERE ag.tenant_id=$1 AND sc.tenant_id=$1 AND sc.enabled=true
         AND replace(host(ag.last_ip), '::ffff:', '')::inet << sc.network::inet`,
      [tenantId]
    ),
    // 스캔으로 발견됐지만 어떤 에이전트와도 매칭 안 되는 호스트 → "미설치"
    pool.query(
      `SELECT DISTINCT ON (a.ip) a.id, host(a.ip) AS ip, a.hostname, a.first_seen, a.last_seen
       FROM ai_discovered_assets a
       WHERE a.tenant_id=$1
         AND NOT EXISTS (
           SELECT 1 FROM ai_agents ag
           WHERE ag.tenant_id=a.tenant_id
             AND replace(host(ag.last_ip), '::ffff:', '')=host(a.ip)
         )
       ORDER BY a.ip, a.last_seen DESC`,
      [tenantId]
    ),
  ]);

  return NextResponse.json({
    settings: settings.rows[0] ?? null,
    scopes: scopes.rows,
    activeRun: activeRun.rows[0] ?? null,
    recentRuns: recentRuns.rows,
    installed: installedAgents.rows,
    uninstalled: uninstalledAssets.rows,
  });
}

export async function POST(req: NextRequest) {
  const auth = await requireRole(req, ['admin', 'security']);
  if (auth.response) return auth.response;
  const licenseCheck = await requireActiveLicense(auth.user!.tenantId);
  if (licenseCheck.response) return licenseCheck.response;

  const body = await req.json();
  const tenantId = auth.user!.tenantId;

  if (body.action === 'add_scope') {
    const network = String(body.network ?? '').trim();
    if (!network) return NextResponse.json({ error: 'CIDR 범위를 입력하세요' }, { status: 400 });
    if (!/^\d{1,3}(\.\d{1,3}){3}\/\d{1,2}$/.test(network))
      return NextResponse.json({ error: '올바른 CIDR 형식으로 입력하세요 (예: 192.168.0.0/24)' }, { status: 400 });
    const [, prefix] = network.split('/');
    if (parseInt(prefix) < 8) return NextResponse.json({ error: '/8 이상의 범위만 허용됩니다' }, { status: 400 });
    try {
      await pool.query(
        `INSERT INTO ai_discovery_scopes(tenant_id,network,updated_by) VALUES($1,$2::cidr,$3) ON CONFLICT(tenant_id,network) DO UPDATE SET enabled=true,updated_at=NOW(),updated_by=EXCLUDED.updated_by`,
        [tenantId, network, auth.user!.username]
      );
    } catch {
      return NextResponse.json({ error: '유효하지 않은 CIDR입니다' }, { status: 400 });
    }
    return NextResponse.json({ ok: true });
  }

  if (body.action === 'remove_scope') {
    await pool.query(`DELETE FROM ai_discovery_scopes WHERE id=$1 AND tenant_id=$2`, [body.id, tenantId]);
    return NextResponse.json({ ok: true });
  }

  if (body.action === 'toggle_scope') {
    await pool.query(`UPDATE ai_discovery_scopes SET enabled=NOT enabled, updated_at=NOW(), updated_by=$1 WHERE id=$2 AND tenant_id=$3`, [auth.user!.username, body.id, tenantId]);
    return NextResponse.json({ ok: true });
  }

  if (body.action === 'update_settings') {
    const interval = parseInt(body.scan_interval_minutes ?? 1440);
    const timeout = parseInt(body.timeout_ms ?? 800);
    const concurrency = parseInt(body.concurrency ?? 24);
    await pool.query(
      `INSERT INTO ai_discovery_settings(tenant_id,scan_interval_minutes,timeout_ms,concurrency,updated_by,updated_at)
       VALUES($1,$2,$3,$4,$5,NOW())
       ON CONFLICT(tenant_id) DO UPDATE SET scan_interval_minutes=$2,timeout_ms=$3,concurrency=$4,updated_by=$5,updated_at=NOW()`,
      [tenantId, interval, timeout, concurrency, auth.user!.username]
    );
    return NextResponse.json({ ok: true });
  }

  if (body.action === 'start_scan') {
    const scopeCount = await pool.query(
      `SELECT COUNT(*)::int cnt FROM ai_discovery_scopes WHERE tenant_id=$1 AND enabled=true`,
      [tenantId]
    );
    if (Number(scopeCount.rows[0].cnt) === 0)
      return NextResponse.json({ error: '활성화된 IP 범위가 없습니다. 먼저 IP 대역을 추가하세요.' }, { status: 400 });

    const existing = await pool.query(
      `SELECT id FROM ai_discovery_runs WHERE tenant_id=$1 AND status IN ('queued','running') LIMIT 1`,
      [tenantId]
    );
    if (existing.rows.length > 0)
      return NextResponse.json({ error: '이미 스캔이 진행 중입니다' }, { status: 409 });

    const runRes = await pool.query(
      `INSERT INTO ai_discovery_runs(tenant_id,requested_by,status) VALUES($1,$2,'queued') RETURNING id`,
      [tenantId, auth.user!.username]
    );
    const runId: string = String(runRes.rows[0].id);

    // Run scan in background (fire and forget)
    runDiscoveryScan(runId, tenantId).catch(console.error);

    return NextResponse.json({ ok: true, runId: String(runId) });
  }

  if (body.action === 'clear_assets') {
    await pool.query(`DELETE FROM ai_discovered_assets WHERE tenant_id=$1`, [tenantId]);
    return NextResponse.json({ ok: true });
  }

  return NextResponse.json({ error: 'unknown action' }, { status: 400 });
}
