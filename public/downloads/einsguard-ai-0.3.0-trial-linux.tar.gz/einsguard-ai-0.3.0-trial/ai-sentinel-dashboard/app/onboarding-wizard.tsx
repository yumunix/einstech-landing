'use client';

import {useCallback,useEffect,useState} from 'react';

type Role='admin'|'security'|'auditor'|'viewer';
type Props={role?:Role;forceOpen:boolean;initialStep?:number;onCompleted:()=>void};
type Destination={name:string;destination_type:string;match_type:string;match_value:string;decision:string;notes?:string;enabled:boolean};
type ClassificationRule={name:string;classification_level:string;rule_type:string;pattern:string;action:string;weight:number;case_sensitive:boolean;enabled:boolean;user_message?:string};
type DlpPolicy={enabled:boolean;blockCritical:boolean;scanPromptText:boolean;scanClipboard:boolean;scanCliArguments:boolean;scanFileUploads:boolean;inspectInternalFingerprints:boolean;inspectContentWithLocalAi:boolean;aiVerification:boolean;storeRawChat:boolean;evidenceRetentionDays:number;rawRetentionDays:number};
type DataSource={id?:string;name:string;source_type:string;location:string;status?:string;last_indexed_at?:string|null;last_error?:string|null;config:Record<string,any>;enabled:boolean};

const steps=['회사·내부망','AI 목적지','데이터 분류','내부 원본','검토·배포'];
const inputClass='w-full rounded-lg border border-slate-600 bg-slate-950 px-3 py-2.5 text-sm text-white outline-none focus:border-emerald-400 disabled:cursor-not-allowed disabled:opacity-60';
const smallButton='rounded-lg border border-slate-600 px-3 py-2 text-xs font-bold text-slate-200 hover:border-slate-400 hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-40';
const defaultDlpPolicy:DlpPolicy={enabled:true,blockCritical:true,scanPromptText:true,scanClipboard:true,scanCliArguments:true,scanFileUploads:true,inspectInternalFingerprints:true,inspectContentWithLocalAi:true,aiVerification:true,storeRawChat:false,evidenceRetentionDays:90,rawRetentionDays:7};
const recommendedRules:ClassificationRule[]=[
  {name:'비밀번호·인증정보',classification_level:'RESTRICTED',rule_type:'dictionary',pattern:'비밀번호,password,passwd,credential,private key',action:'block',weight:100,case_sensitive:false,enabled:true},
  {name:'API 키·토큰',classification_level:'RESTRICTED',rule_type:'dictionary',pattern:'api_key,api key,access_token,secret_key,bearer token',action:'block',weight:100,case_sensitive:false,enabled:true},
  {name:'금융·결제정보',classification_level:'RESTRICTED',rule_type:'dictionary',pattern:'계좌번호,카드번호,CVC,CVV,유효기간',action:'block',weight:100,case_sensitive:false,enabled:true},
  {name:'개인 식별정보',classification_level:'CONFIDENTIAL',rule_type:'dictionary',pattern:'주민등록번호,여권번호,운전면허번호,개인정보',action:'block',weight:90,case_sensitive:false,enabled:true},
  {name:'회사 기밀 표시',classification_level:'RESTRICTED',rule_type:'dictionary',pattern:'대외비,기밀,confidential,영업비밀',action:'block',weight:100,case_sensitive:false,enabled:true},
  {name:'사내 전용 표시',classification_level:'INTERNAL',rule_type:'dictionary',pattern:'사내용,내부 전용,internal use only',action:'audit',weight:60,case_sensitive:false,enabled:true},
];

function lines(value:string){return [...new Set(value.split(/[\n,]/).map(x=>x.trim()).filter(Boolean))];}
function levelLabel(level:string){return ({PUBLIC:'공개 정보',INTERNAL:'사내 정보',CONFIDENTIAL:'기밀 정보',RESTRICTED:'절대 외부 전송 금지'} as Record<string,string>)[level]||level;}
function Tip({text,wide}:{text:string;wide?:boolean}){
  return (
    <span className="group relative ml-1 inline-block cursor-help align-middle">
      <span className="inline-flex h-3.5 w-3.5 items-center justify-center rounded-full border border-slate-600 text-[9px] font-bold text-slate-500 group-hover:border-slate-400 group-hover:text-slate-300">?</span>
      <span className={`pointer-events-none absolute bottom-full left-1/2 z-50 mb-1.5 -translate-x-1/2 rounded-lg border border-slate-600 bg-slate-800 p-2.5 text-[11px] leading-relaxed text-slate-200 opacity-0 shadow-xl transition-opacity duration-150 group-hover:opacity-100 ${wide?'w-72':'w-56'}`}>
        {text}
        <span className="absolute left-1/2 top-full -translate-x-1/2 border-4 border-transparent border-t-slate-600"/>
      </span>
    </span>
  );
}

export default function OnboardingWizard({role,forceOpen,initialStep,onCompleted}:Props){
  const [data,setData]=useState<any>(null);
  const [loading,setLoading]=useState(false);
  const [saving,setSaving]=useState(false);
  const [error,setError]=useState('');
  const [message,setMessage]=useState('');
  const [step,setStep]=useState(1);
  const [organization,setOrganization]=useState({company_name:'',company_domains:'',internal_cidrs:'',timezone:'Asia/Seoul',data_residency:'onpremise'});
  const [destinations,setDestinations]=useState<Destination[]>([]);
  const [rules,setRules]=useState<ClassificationRule[]>([]);
  const [policyTestText,setPolicyTestText]=useState('');
  const [selectedRuleTest,setSelectedRuleTest]=useState<number|null>(null);
  const [ruleTestInputs,setRuleTestInputs]=useState<Record<number,string>>({});
  const [expandedRule,setExpandedRule]=useState<number|null>(null);
  const [dlpPolicy,setDlpPolicy]=useState<DlpPolicy>(defaultDlpPolicy);
  const [sources,setSources]=useState<DataSource[]>([]);
  const [acknowledgeNoSource,setAcknowledgeNoSource]=useState(false);
  const [enforcementConfirmation,setEnforcementConfirmation]=useState('');
  const canView=Boolean(role&&['admin','security','auditor'].includes(role));
  const editable=role==='admin';

  const hydrate=useCallback((next:any,resetStep=false)=>{
    setData(next);
    const org=next.organization||{};
    setOrganization({
      company_name:org.company_name||'',
      company_domains:(org.company_domains||[]).join('\n'),
      internal_cidrs:(org.internal_cidrs||[]).join('\n'),
      timezone:org.timezone||'Asia/Seoul',
      data_residency:org.data_residency||'onpremise',
    });
    const configured:Destination[]=next.destinations||[];
    if(configured.length)setDestinations(configured.map((x:any)=>({...x,enabled:x.enabled!==false})));
    else if(next.local_ai?.baseUrl)setDestinations([{name:`내부 ${String(next.local_ai.provider||'AI').toUpperCase()}`,destination_type:'internal_ai',match_type:'url',match_value:next.local_ai.baseUrl,decision:'allow',notes:`${next.local_ai.model||''} 설치 시 연결`,enabled:true}]);
    else setDestinations([]);
    setRules((next.classification_rules||[]).map((x:any)=>({...x,weight:Number(x.weight),case_sensitive:Boolean(x.case_sensitive),enabled:x.enabled!==false})));
    setDlpPolicy({...defaultDlpPolicy,...(next.dlp_policy||{})});
    setSources((next.data_sources||[]).map((x:any)=>({...x,config:x.config||{},enabled:x.enabled!==false})));
    setAcknowledgeNoSource(Boolean(next.onboarding?.acknowledge_no_data_source));
    if(resetStep)setStep(next.onboarding?.status==='completed'?5:Math.min(5,Number(next.onboarding?.current_step||1)));
  },[]);

  const load=useCallback(async()=>{
    if(!canView)return;
    setLoading(true);setError('');
    try{
      const response=await fetch('/api/onboarding',{cache:'no-store'});
      const body=await response.json();
      if(!response.ok)throw new Error(body.error||'보호 설정을 불러오지 못했습니다.');
      hydrate(body,true);
      if(forceOpen&&initialStep)setStep(Math.max(1,Math.min(5,initialStep)));
    }catch(cause){setError(cause instanceof Error?cause.message:'보호 설정을 불러오지 못했습니다.');}
    finally{setLoading(false);}
  },[canView,forceOpen,hydrate,initialStep]);

  useEffect(()=>{load();},[load]);

  const request=async(action:string,payload:Record<string,unknown>={})=>{
    setSaving(true);setError('');setMessage('');
    try{
      const response=await fetch('/api/onboarding',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({action,...payload})});
      const body=await response.json();
      if(!response.ok)throw new Error(body.error||'설정을 저장하지 못했습니다.');
      hydrate(body);
      return body;
    }catch(cause){setError(cause instanceof Error?cause.message:'설정을 저장하지 못했습니다.');return null;}
    finally{setSaving(false);}
  };

  const saveAndNext=async()=>{
    let result:any=null;
    if(step===1)result=await request('save_organization',{organization:{...organization,company_domains:lines(organization.company_domains),internal_cidrs:lines(organization.internal_cidrs)}});
    if(step===2)result=await request('replace_destinations',{destinations});
    if(step===3)result=await request('replace_classification_rules',{classification_rules:rules,dlp_policy:dlpPolicy});
    if(step===4)result=await request('replace_data_sources',{data_sources:sources.map(({id,name,source_type,location,config,enabled})=>({id,name,source_type,location,config,enabled})),acknowledge_no_data_source:acknowledgeNoSource});
    if(result){setStep(Math.min(5,step+1));setMessage('저장했습니다. 배포 전까지는 Agent 정책이 바뀌지 않습니다.');}
  };

  const finish=async()=>{
    const completed=data?.onboarding?.status==='completed';
    const result=await request(completed?'publish_policy':'complete_onboarding',{notes:'보호 설정 마법사 검토 후 배포'});
    if(result){setMessage(completed?'변경 정책을 배포했습니다.':'초기 설정을 완료했습니다. 모니터링 전용으로 시작합니다.');if(!completed)onCompleted();}
  };

  const changeMode=async(mode:'monitor'|'enforce')=>{
    const result=await request('set_enforcement_mode',{mode,confirmation:mode==='enforce'?enforcementConfirmation:undefined});
    if(result){setEnforcementConfirmation('');setMessage(mode==='enforce'?'차단 모드 정책을 배포했습니다.':'모니터링 전용 정책을 배포했습니다.');}
  };

  const startIndex=async(source:DataSource)=>{
    if(!source.id){setError('먼저 데이터 원본 설정을 저장하십시오.');return;}
    const result=await request('start_index',{data_source_id:Number(source.id)});
    if(result)setMessage('인덱싱 작업을 대기열에 등록했습니다. 원문은 저장하지 않고 HMAC 지문만 생성합니다.');
  };

  const updateDestination=(index:number,key:keyof Destination,value:unknown)=>setDestinations(items=>items.map((item,i)=>i===index?{...item,[key]:value}:item));
  const updateRule=(index:number,key:keyof ClassificationRule,value:unknown)=>setRules(items=>items.map((item,i)=>i===index?{...item,[key]:value}:item));
  const updateSource=(index:number,key:keyof DataSource,value:unknown)=>setSources(items=>items.map((item,i)=>i===index?{...item,[key]:value}:item));
  const updateDlp=(key:keyof DlpPolicy,value:boolean|number)=>setDlpPolicy(current=>({...current,[key]:value}));
  const addRecommendedRules=()=>setRules(current=>{
    const existing=new Set(current.map(item=>item.name.trim().toLowerCase()));
    return [...current,...recommendedRules.filter(item=>!existing.has(item.name.toLowerCase()))];
  });
  const ruleUserMessage=(rule:ClassificationRule)=>rule.user_message||(
    rule.action==='block'?`EINSGUARD AI가 전송을 중단합니다. 탐지 규칙: ${rule.name||'(이름 없음)'}. 민감정보를 삭제하거나 마스킹한 뒤 다시 시도하십시오.`
    :rule.action==='warn'?`민감정보 가능성이 감지되었습니다. 탐지 규칙: ${rule.name||'(이름 없음)'}. 전송 전에 내용을 다시 확인하십시오.`
    :rule.action==='audit'?`이 내용은 보안 감사 로그에 기록됩니다. 적용 규칙: ${rule.name||'(이름 없음)'}.`
    :`전송이 허용됩니다. 적용 규칙: ${rule.name||'(이름 없음)'}.`
  );
  const ruleMatchTest=(rule:ClassificationRule,text:string)=>{
    if(!text.trim()||!rule.enabled)return null;
    const haystack=rule.case_sensitive?text:text.toLowerCase();
    const matched=lines(rule.pattern).find(term=>haystack.includes(rule.case_sensitive?term:term.toLowerCase()));
    return matched?{matched,message:ruleUserMessage(rule)}:null;
  };
  const addBlankRule=()=>setRules(x=>[...x,{name:'',classification_level:'CONFIDENTIAL',rule_type:'keyword',pattern:'',action:'warn',weight:70,case_sensitive:false,enabled:true,user_message:''}]);

  if(!canView)return null;
  if(loading&&!data)return forceOpen||role==='admin'?<div className="rounded-xl border border-slate-700 bg-slate-900 p-8 text-center text-sm text-slate-300">보호 설정을 확인하는 중입니다.</div>:null;
  if(error&&!data)return <div className="rounded-xl border border-red-500/40 bg-red-500/10 p-4 text-sm text-red-200">{error}<button onClick={load} className="ml-3 underline">다시 시도</button></div>;
  if(!data)return null;

  const completed=data.onboarding?.status==='completed';
  const allReady=Boolean(data.progress?.organization&&data.progress?.destinations&&data.progress?.classification&&data.progress?.data_sources);
  const policyTestMatches=rules.flatMap(rule=>{
    if(!rule.enabled||!policyTestText.trim())return [];
    const haystack=rule.case_sensitive?policyTestText:policyTestText.toLowerCase();
    const matched=lines(rule.pattern).find(term=>haystack.includes(rule.case_sensitive?term:term.toLowerCase()));
    return matched?[{rule,matched}]:[];
  }).sort((a,b)=>b.rule.weight-a.rule.weight);
  const policyTestTop=policyTestMatches[0];
  const policyTestMessage=policyTestTop?ruleUserMessage(policyTestTop.rule):'현재 활성화된 키워드·사전 규칙과 일치하지 않습니다.';
  const local=data.local_ai||{};
  function renderRuleCard(item:ClassificationRule,index:number){
    const open=expandedRule===index;
    const testOpen=selectedRuleTest===index;
    const testText=ruleTestInputs[index]||'';
    const testResult=ruleMatchTest(item,testText);
    const actionColor=item.action==='block'?'bg-red-500/20 text-red-300 border-red-500/30':item.action==='warn'?'bg-amber-500/20 text-amber-300 border-amber-500/30':item.action==='audit'?'bg-blue-500/20 text-blue-300 border-blue-500/30':'bg-slate-700 text-slate-300 border-slate-600';
    const actionLabel=item.action==='block'?'차단':item.action==='warn'?'경고':item.action==='audit'?'기록':'허용';
    const levelColor=item.classification_level==='RESTRICTED'?'text-red-400':item.classification_level==='CONFIDENTIAL'?'text-amber-400':item.classification_level==='INTERNAL'?'text-blue-400':'text-slate-400';
    const autoPlaceholder=item.action==='block'?'자동: EINSGUARD AI가 전송을 중단합니다. 민감정보를 삭제하거나 마스킹한 뒤 다시 시도하십시오.':item.action==='warn'?'자동: 민감정보 가능성이 감지되었습니다. 전송 전에 내용을 다시 확인하십시오.':item.action==='audit'?'자동: 이 내용은 보안 감사 로그에 기록됩니다.':'자동: 전송이 허용됩니다.';
    return (
      <div key={index} className={`rounded-xl border ${item.enabled?'border-slate-700':'border-slate-800 opacity-50'} bg-slate-950/40`}>
        {/* ── 요약 행 ── */}
        <div className="flex cursor-pointer items-center gap-3 px-4 py-3" onClick={()=>setExpandedRule(open?null:index)}>
          <input disabled={!editable} type="checkbox" checked={item.enabled} onClick={e=>e.stopPropagation()} onChange={e=>updateRule(index,'enabled',e.target.checked)} className="shrink-0" />
          <span className="min-w-0 flex-1 truncate text-sm font-bold text-white">{item.name||<span className="text-slate-500 italic">이름 없음</span>}</span>
          <span className={`shrink-0 rounded border px-2 py-0.5 text-[11px] font-black ${actionColor}`}>{actionLabel}</span>
          <span className={`hidden shrink-0 text-[11px] font-bold sm:block ${levelColor}`}>{levelLabel(item.classification_level)}</span>
          <span className="hidden max-w-[180px] truncate text-[11px] text-slate-500 md:block">{item.pattern}</span>
          <span className="ml-1 shrink-0 text-slate-500">{open?'▲':'▼'}</span>
        </div>
        {/* ── 펼침 편집 ── */}
        {open&&<div className="border-t border-slate-800 px-4 pb-4 pt-3 space-y-3">
          <div className="grid gap-3 md:grid-cols-12">
            <div className="md:col-span-4">
              <div className="mb-1 text-[10px] font-bold text-slate-400">규칙 이름<Tip text="관리자가 알아볼 수 있는 이름입니다. 사용자에게는 보이지 않습니다." /></div>
              <input disabled={!editable} value={item.name} onChange={e=>updateRule(index,'name',e.target.value)} placeholder="예: 고객 계좌정보" className={inputClass} />
            </div>
            <div className="md:col-span-3">
              <div className="mb-1 text-[10px] font-bold text-slate-400">정보의 중요도<Tip text="공개: 외부 전송 허용 / 사내: 기록만 / 기밀: 경고 후 검토 / 절대금지: 즉시 차단" /></div>
              <select disabled={!editable} value={item.classification_level} onChange={e=>updateRule(index,'classification_level',e.target.value)} className={inputClass}>
                <option value="PUBLIC">공개 정보</option><option value="INTERNAL">사내 정보</option><option value="CONFIDENTIAL">기밀 정보</option><option value="RESTRICTED">절대 외부 전송 금지</option>
              </select>
            </div>
            <div className="md:col-span-2">
              <div className="mb-1 text-[10px] font-bold text-slate-400">발견 시 처리<Tip text="허용: 아무 조치 없음 / 기록만: 관리자 로그 / 경고: 사용자에게 확인 요청 / 차단: 전송 즉시 중단" /></div>
              <select disabled={!editable} value={item.action} onChange={e=>updateRule(index,'action',e.target.value)} className={inputClass}>
                <option value="allow">허용</option><option value="audit">기록만</option><option value="warn">경고</option><option value="block">차단</option>
              </select>
            </div>
            <div className="flex flex-wrap items-end gap-3 md:col-span-2">
              <label className="flex items-center gap-1.5 text-xs"><input disabled={!editable} type="number" min="1" max="100" value={item.weight} onChange={e=>updateRule(index,'weight',Number(e.target.value))} className="w-14 rounded border border-slate-600 bg-slate-950 px-2 py-1 text-xs" /><span className="text-slate-400">우선순위</span></label>
              <label className="flex items-center gap-1.5 text-xs"><input disabled={!editable} type="checkbox" checked={item.case_sensitive} onChange={e=>updateRule(index,'case_sensitive',e.target.checked)} /><span className="text-slate-400">대소문자 구분</span></label>
            </div>
            {editable&&<div className="flex items-end md:col-span-1"><button onClick={()=>{setRules(x=>x.filter((_,i)=>i!==index));setExpandedRule(null);}} className="rounded-lg border border-red-500/30 px-3 py-2 text-xs text-red-300">삭제</button></div>}
          </div>
          <div className="grid gap-3 md:grid-cols-12">
            <div className="md:col-span-3">
              <div className="mb-1 text-[10px] font-bold text-slate-400">찾는 방법<Tip text="문장 내 단어: 지정 단어가 포함되면 탐지 / 여러 단어 중 하나: 목록 중 하나라도 있으면 탐지 / 문서 분류: 등록된 분류 태그로 판단" /></div>
              <select disabled={!editable} value={item.rule_type} onChange={e=>updateRule(index,'rule_type',e.target.value)} className={inputClass}>
                <option value="keyword">문장 내 단어</option><option value="dictionary">여러 단어 중 하나</option><option value="source_label">등록된 문서 분류</option>
              </select>
            </div>
            <div className="md:col-span-9">
              <div className="mb-1 text-[10px] font-bold text-slate-400">찾을 단어 <span className="font-normal text-slate-500">(쉼표로 구분)</span></div>
              <input disabled={!editable} value={item.pattern} onChange={e=>updateRule(index,'pattern',e.target.value)} placeholder="예: 계좌번호, 입금계좌" className={inputClass} />
            </div>
          </div>
          <div>
            <div className="mb-1 text-[10px] font-bold text-slate-400">사용자에게 표시할 문구<Tip wide text="규칙이 걸렸을 때 사용자 화면에 표시되는 메시지입니다. 비워두면 처리 방식에 맞는 문구가 자동으로 생성됩니다." /></div>
            <input disabled={!editable} value={item.user_message||''} onChange={e=>updateRule(index,'user_message',e.target.value)} placeholder={autoPlaceholder} className={inputClass} />
          </div>
          <div className="border-t border-slate-800 pt-2">
            <button type="button" onClick={()=>setSelectedRuleTest(testOpen?null:index)} className={`text-[11px] font-bold ${testOpen?'text-cyan-300':'text-slate-500 hover:text-slate-300'}`}>{testOpen?'▼ 테스트 닫기':'▶ 표시 문구 테스트'}</button>
            {testOpen&&<div className="mt-2 space-y-2">
              <input value={testText} onChange={e=>setRuleTestInputs(prev=>({...prev,[index]:e.target.value}))} placeholder="테스트할 문장을 입력하십시오" className={inputClass} />
              <div className={`rounded-lg border p-3 text-xs ${testResult&&item.action==='block'?'border-red-500/40 bg-red-500/10 text-red-100':testResult?'border-amber-500/40 bg-amber-500/10 text-amber-100':'border-slate-700 bg-slate-950/50 text-slate-400'}`}>
                {testResult?(<><div className="mb-1 text-[10px] text-slate-400">일치 단어: <b className="text-white">{testResult.matched}</b></div><div className="font-bold text-white">사용자에게 표시될 문구</div><div className="mt-1">{testResult.message}</div></>):testText.trim()?'이 규칙과 일치하는 단어가 없습니다.':'테스트할 문장을 입력하십시오.'}
              </div>
            </div>}
          </div>
        </div>}
      </div>
    );
  }
  const panel=(
    <section className="mx-auto w-full max-w-6xl rounded-2xl border border-slate-600 bg-slate-900 shadow-2xl shadow-black/40">
      <header className="border-b border-slate-700 p-5 md:p-7">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div><div className="text-xs font-bold tracking-[0.22em] text-emerald-400">EINSGUARD AI PROTECTION SETUP</div><h1 className="mt-2 text-xl font-black text-white">{completed?'보호 정책 설정':'보호 정책 초기 설정'}</h1><p className="mt-2 max-w-3xl text-sm text-slate-300">AI 사용 기준과 민감정보 보호 규칙을 설정합니다. 초기 완료 후에도 여기서 수정할 수 있으며, 검토 후 '정책 배포'를 눌러야 Agent에 반영됩니다.</p></div>
          <div className={`rounded-full border px-3 py-1.5 text-xs font-bold ${data.onboarding.enforcement_mode==='enforce'?'border-red-400 bg-red-500/15 text-red-200':'border-blue-400 bg-blue-500/15 text-blue-200'}`}>{data.onboarding.enforcement_mode==='enforce'?'차단 모드':'모니터링 전용'}</div>
        </div>
        <div className="mt-5 grid grid-cols-2 gap-2 md:grid-cols-5">{steps.map((label,index)=><button key={label} type="button" onClick={()=>setStep(index+1)} className={`rounded-lg border px-3 py-2.5 text-xs font-bold ${step===index+1?'border-emerald-400 bg-emerald-500/15 text-emerald-200':'border-slate-700 text-slate-400 hover:bg-slate-800'}`}><span className="mr-2">{index+1}</span>{label}</button>)}</div>
        {step===4&&<div className="mt-4 flex justify-end"><button disabled={loading||saving} className={smallButton} onClick={load}>인덱싱 상태 새로고침</button></div>}
        {step===5&&<div className="mt-4 grid gap-3 rounded-xl border border-slate-700 bg-slate-950/40 p-4 text-xs md:grid-cols-3">
          <div><div className="font-bold text-white">설치 단계</div><p className="mt-1 text-slate-400">DB·비밀키·읽기 전용 마운트와 고객사가 선택한 Local AI 제공자·모델·주소를 설정합니다.</p></div>
          <div><div className="font-bold text-white">설치 후 설정</div><p className="mt-1 text-slate-400">회사 범위·AI 목적지·분류 등급·내부 원본을 정하고 검토 후 정책을 배포합니다.</p></div>
          <div><div className="font-bold text-white">원문 처리</div><p className="mt-1 text-slate-400">지문 비교는 고객사 서버에서 일시 처리하며 원문 저장은 기본 꺼짐입니다. 현재 원문 저장: {data.content_handling?.store_raw_content?'사용':'사용 안 함'}.</p></div>
        </div>}
      </header>

      <div className="p-5 md:p-7">
        {!editable&&<div className="mb-5 rounded-lg border border-yellow-500/30 bg-yellow-500/10 p-3 text-sm text-yellow-200">열람 모드입니다. 설정 변경과 정책 배포는 관리자만 할 수 있습니다.</div>}
        {data.draft_pending&&<div className="mb-5 rounded-lg border border-amber-500/40 bg-amber-500/10 p-3 text-sm font-bold text-amber-200">저장됐지만 아직 배포되지 않은 변경이 있습니다.</div>}
        {error&&<div className="mb-5 rounded-lg border border-red-500/40 bg-red-500/10 p-3 text-sm text-red-200">{error}</div>}
        {message&&<div className="mb-5 rounded-lg border border-emerald-500/40 bg-emerald-500/10 p-3 text-sm text-emerald-200">{message}</div>}

        {step===1&&<div className="space-y-5"><div><h2 className="text-lg font-bold">회사와 내부 네트워크</h2><p className="mt-1 text-sm text-slate-400">내부 데이터와 외부 전송을 구분하는 최소 기준입니다. 도메인 또는 CIDR을 하나 이상 입력하십시오.</p></div><div className="grid gap-4 md:grid-cols-2"><label>회사명<input disabled={!editable} value={organization.company_name} onChange={e=>setOrganization(x=>({...x,company_name:e.target.value}))} className={`${inputClass} mt-1`} /></label><label>시간대<input disabled={!editable} value={organization.timezone} onChange={e=>setOrganization(x=>({...x,timezone:e.target.value}))} placeholder="Asia/Seoul" className={`${inputClass} mt-1`} /></label><label>회사 도메인 · 한 줄에 하나<textarea disabled={!editable} value={organization.company_domains} onChange={e=>setOrganization(x=>({...x,company_domains:e.target.value}))} placeholder={'example.com\nsubsidiary.co.kr'} className={`${inputClass} mt-1 h-32`} /></label><label>내부 IP 대역(CIDR) · 한 줄에 하나<textarea disabled={!editable} value={organization.internal_cidrs} onChange={e=>setOrganization(x=>({...x,internal_cidrs:e.target.value}))} placeholder={'10.0.0.0/8\n192.168.0.0/16'} className={`${inputClass} mt-1 h-32`} /></label><label>데이터 보관 위치<select disabled={!editable} value={organization.data_residency} onChange={e=>setOrganization(x=>({...x,data_residency:e.target.value}))} className={`${inputClass} mt-1`}><option value="onpremise">고객사 내부</option><option value="private_cloud">전용 클라우드</option><option value="hybrid">하이브리드</option></select></label></div></div>}

        {step===2&&<div className="space-y-5"><div className="flex flex-wrap items-start justify-between gap-3"><div><h2 className="text-lg font-bold">AI 목적지 정책</h2><p className="mt-1 text-sm text-slate-400">내부 AI, 승인된 외부 AI, 미승인 AI를 별도로 정의합니다.</p></div>{editable&&<button className={smallButton} onClick={()=>setDestinations(x=>[...x,{name:'',destination_type:'approved_external_ai',match_type:'domain',match_value:'',decision:'audit',notes:'',enabled:true}])}>+ 목적지 추가</button>}</div><div className="space-y-3">{destinations.length===0&&<div className="rounded-lg border border-slate-700 p-5 text-sm text-slate-400">목적지가 없습니다.</div>}{destinations.map((item,index)=><div key={index} className="grid gap-2 rounded-xl border border-slate-700 bg-slate-950/40 p-4 md:grid-cols-12"><input disabled={!editable} value={item.name} onChange={e=>updateDestination(index,'name',e.target.value)} placeholder="표시 이름" className={`${inputClass} md:col-span-2`} /><select disabled={!editable} value={item.destination_type} onChange={e=>updateDestination(index,'destination_type',e.target.value)} className={`${inputClass} md:col-span-2`}><option value="internal_ai">내부 AI</option><option value="approved_external_ai">승인 외부 AI</option><option value="unapproved_external_ai">미승인 외부 AI</option><option value="other">기타</option></select><select disabled={!editable} value={item.match_type} onChange={e=>updateDestination(index,'match_type',e.target.value)} className={`${inputClass} md:col-span-2`}><option value="domain">도메인</option><option value="url">URL</option><option value="application">앱/프로세스</option><option value="ip">IP</option><option value="cidr">CIDR</option></select><input disabled={!editable} value={item.match_value} onChange={e=>updateDestination(index,'match_value',e.target.value)} placeholder="ai.example.com" className={`${inputClass} md:col-span-3`} /><select disabled={!editable} value={item.decision} onChange={e=>updateDestination(index,'decision',e.target.value)} className={`${inputClass} md:col-span-2`}><option value="allow">허용 · 아무 조치 없음</option><option value="audit">감사</option><option value="block">차단 · 전송 중단</option></select>{editable&&<button onClick={()=>setDestinations(x=>x.filter((_,i)=>i!==index))} className="rounded-lg border border-red-500/30 text-xs text-red-300 md:col-span-1">삭제</button>}<input disabled={!editable} value={item.notes||''} onChange={e=>updateDestination(index,'notes',e.target.value)} placeholder="메모" className={`${inputClass} md:col-span-12`} /></div>)}</div></div>}

        {step===3&&<div className="space-y-5">
          <div><h2 className="text-lg font-bold">민감정보·내부자료 보호 정책</h2><p className="mt-1 text-sm text-slate-400">개인정보, 계좌·카드번호, 비밀번호·API 키, 회사 기밀이 AI로 전송되지 않도록 분류하고 차단합니다.</p></div>
          <div className="rounded-xl border border-slate-700 bg-slate-950/40 p-4">
            <div className="mb-3 text-xs font-bold text-slate-300">어디에서 확인할까요?<Tip wide text="선택한 위치에서 키워드나 민감 패턴이 발견되면 규칙에 따라 차단·경고·기록합니다. 카드번호·비밀번호는 패턴으로 자동 탐지합니다." /></div>
            <div className="grid gap-2 md:grid-cols-2 lg:grid-cols-4">
              {([
                ['scanPromptText','AI 대화 입력창','사용자가 AI에 입력하거나 붙여넣은 내용'],
                ['scanClipboard','클립보드','복사해서 AI로 전달하는 내용'],
                ['scanCliArguments','터미널 명령','Codex 등 명령줄로 전달하는 내용'],
                ['scanFileUploads','첨부 파일','AI에 첨부하는 문서와 텍스트 파일'],
              ] as const).map(([key,label,desc])=><label key={key} className="flex items-start gap-2 rounded-lg border border-slate-700 bg-slate-900 px-3 py-2.5 text-xs cursor-pointer hover:border-slate-500"><input disabled={!editable} type="checkbox" checked={Boolean(dlpPolicy[key as keyof DlpPolicy])} onChange={e=>updateDlp(key as keyof DlpPolicy,e.target.checked)} className="mt-0.5 shrink-0" /><span><span className="font-bold text-white">{label}</span><span className="block text-slate-500 mt-0.5">{desc}</span></span></label>)}
            </div>
            <div className="mt-3 grid gap-2 md:grid-cols-3 border-t border-slate-800 pt-3">
              <label className="flex items-center gap-2 text-xs cursor-pointer"><input disabled={!editable} type="checkbox" checked={dlpPolicy.blockCritical} onChange={e=>updateDlp('blockCritical',e.target.checked)} />비밀번호·결제정보 즉시 차단<Tip text="비밀번호·카드번호·API 키 패턴이 탐지되면 경고 없이 바로 전송을 막습니다." /></label>
              <label className="flex items-center gap-2 text-xs cursor-pointer"><input disabled={!editable} type="checkbox" checked={dlpPolicy.inspectInternalFingerprints} onChange={e=>updateDlp('inspectInternalFingerprints',e.target.checked)} />내부 문서 지문 비교<Tip text="등록된 내부 문서와 내용이 유사하면 기밀 자료로 간주해 처리합니다." /></label>
              <label className="flex items-center gap-2 text-xs cursor-pointer"><input disabled={!editable} type="checkbox" checked={dlpPolicy.aiVerification} onChange={e=>updateDlp('aiVerification',e.target.checked)} />내부 AI 2차 판정<Tip text="패턴 탐지 후 내부 LLM이 실제 민감정보인지 한 번 더 확인해 오탐을 줄입니다." /></label>
              <label className="flex items-center gap-2 text-xs"><span>보안 기록 보관<Tip text="탐지된 이벤트 로그를 며칠 동안 보관할지 설정합니다. 최소 7일." /></span><input disabled={!editable} type="number" min="7" max="3650" value={dlpPolicy.evidenceRetentionDays} onChange={e=>updateDlp('evidenceRetentionDays',Number(e.target.value))} className="ml-2 w-20 rounded border border-slate-600 bg-slate-950 px-2 py-1 text-xs" /><span className="text-slate-500">일</span></label>
              <label className="flex items-center gap-2 text-xs cursor-pointer md:col-span-2"><input disabled={!editable} type="checkbox" checked={dlpPolicy.storeRawChat} onChange={e=>updateDlp('storeRawChat',e.target.checked)} /><span className="text-red-300 font-bold">사용자 입력 원문 보관</span><Tip wide text="민감정보 자체가 DB에 저장될 수 있습니다. 꼭 필요한 경우에만 개인정보 담당자 확인 후 켜십시오." /></label>
            </div>
          </div>
          <div className="flex flex-wrap items-center justify-between gap-3"><div><h3 className="text-sm font-bold">보호 규칙 목록<Tip wide text="규칙 이름: 관리자가 구분하는 이름 / 정보의 중요도: 공개·사내·기밀·절대금지 중 하나 / 발견 시 처리: 허용·기록·경고·차단 / 찾을 단어: 탐지할 키워드를 쉼표로 구분 / 사용자 문구: 비워두면 자동, 직접 쓰면 그 문구가 표시됨" /></h3></div>{editable&&<div className="flex gap-2"><button className={smallButton} onClick={addRecommendedRules}>기본 규칙 자동 추가</button><button className={smallButton} onClick={addBlankRule}>+ 규칙 추가</button></div>}</div>
          <div className="space-y-3">{rules.map(renderRuleCard)}</div>
          <div className="rounded-xl border border-cyan-500/30 bg-cyan-500/5 p-4">
            <h3 className="text-sm font-black text-cyan-100">정책 문구 테스트</h3>
            <p className="mt-1 text-xs text-slate-400">사용자가 입력할 예시 문장을 넣으면 어떤 정책과 문구가 작동하는지 미리 확인합니다. 입력 내용은 저장하거나 서버로 전송하지 않습니다.</p>
            <textarea value={policyTestText} onChange={e=>setPolicyTestText(e.target.value)} placeholder="예: 이 문서에는 대외비 내용이 있습니다" className={`${inputClass} mt-3 h-24`} />
            <div className={`mt-3 rounded-lg border p-3 text-xs ${policyTestTop?.rule.action==='block'?'border-red-500/40 bg-red-500/10 text-red-100':policyTestTop?'border-amber-500/40 bg-amber-500/10 text-amber-100':'border-slate-700 bg-slate-950/50 text-slate-300'}`}>
              {policyTestTop&&<div className="mb-2 flex flex-wrap gap-2"><span className="font-black">{policyTestTop.rule.name}</span><span>{levelLabel(policyTestTop.rule.classification_level)}</span><span>처리: {policyTestTop.rule.action==='block'?'차단':policyTestTop.rule.action==='warn'?'경고':policyTestTop.rule.action==='audit'?'기록':'허용'}</span><span>일치 문구: {policyTestTop.matched}</span></div>}
              <div className="font-bold">사용자에게 표시될 문구</div><div className="mt-1">{policyTestText.trim()?policyTestMessage:'테스트할 문장을 입력하십시오.'}</div>
              {policyTestMatches.length>1&&<div className="mt-2 text-slate-400">추가로 일치한 정책: {policyTestMatches.slice(1).map(item=>item.rule.name).join(', ')}</div>}
            </div>
          </div>
        </div>}

        {step===4&&<div className="space-y-5"><div className="flex flex-wrap items-start justify-between gap-3"><div><h2 className="text-lg font-bold">내부 데이터 원본</h2><p className="mt-1 text-sm text-slate-400">경로와 인덱싱 범위만 저장합니다. 비밀번호·토큰·API 키는 DB에 저장하지 않고 호스트 마운트나 Secret Manager에 두어야 합니다. 인덱싱 경로는 읽기 전용 <code>/data-sources</code> 아래만 허용됩니다.</p></div>{editable&&<button className={smallButton} onClick={()=>setSources(x=>[...x,{name:'',source_type:'nas',location:'/data-sources/',config:{recursive:true,maxFileSizeMb:25,classificationLevel:'INTERNAL'},enabled:true}])}>+ 원본 추가</button>}</div>{!data.fingerprinting?.configured&&<div className="rounded-lg border border-red-500/40 bg-red-500/10 p-3 text-sm text-red-200">문서 지문 비밀키가 설정되지 않아 인덱싱을 시작할 수 없습니다.</div>}<div className="space-y-3">{sources.map((item,index)=><div key={index} className="grid gap-2 rounded-xl border border-slate-700 bg-slate-950/40 p-4 md:grid-cols-12"><input disabled={!editable} value={item.name} onChange={e=>updateSource(index,'name',e.target.value)} placeholder="회사 문서 NAS" className={`${inputClass} md:col-span-3`} /><select disabled={!editable} value={item.source_type} onChange={e=>updateSource(index,'source_type',e.target.value)} className={`${inputClass} md:col-span-2`}><option value="nas">NAS</option><option value="filesystem">파일시스템</option><option value="webdav">WebDAV(예정)</option><option value="sharepoint">SharePoint(예정)</option><option value="database">Database(예정)</option><option value="custom">기타(예정)</option></select><input disabled={!editable} value={item.location} onChange={e=>updateSource(index,'location',e.target.value)} placeholder="/data-sources/company-docs" className={`${inputClass} md:col-span-5`} /><label className="flex items-center gap-2 px-2 text-xs md:col-span-1"><input disabled={!editable} type="checkbox" checked={item.config?.recursive!==false} onChange={e=>updateSource(index,'config',{...item.config,recursive:e.target.checked})} /> 하위</label>{editable&&<button onClick={()=>setSources(x=>x.filter((_,i)=>i!==index))} className="rounded-lg border border-red-500/30 text-xs text-red-300 md:col-span-1">삭제</button>}<label className="md:col-span-3">문서 분류<select disabled={!editable} value={item.config?.classificationLevel||'INTERNAL'} onChange={e=>updateSource(index,'config',{...item.config,classificationLevel:e.target.value})} className={`${inputClass} mt-1`}><option value="INTERNAL">내부</option><option value="CONFIDENTIAL">기밀</option><option value="RESTRICTED">최고 기밀</option><option value="PUBLIC">공개</option></select></label><label className="md:col-span-2">최대 파일(MB)<input disabled={!editable} type="number" min="1" max="100" value={item.config?.maxFileSizeMb||25} onChange={e=>updateSource(index,'config',{...item.config,maxFileSizeMb:Number(e.target.value)})} className={`${inputClass} mt-1`} /></label><label className="md:col-span-4">확장자(쉼표)<input disabled={!editable} value={Array.isArray(item.config?.includeExtensions)?item.config.includeExtensions.join(', '):''} onChange={e=>updateSource(index,'config',{...item.config,includeExtensions:e.target.value.split(',').map(value=>value.trim()).filter(Boolean)})} placeholder="pdf, docx, xlsx, md, txt" className={`${inputClass} mt-1`} /></label><div className="flex items-end gap-2 md:col-span-3"><div className="flex-1 text-xs text-slate-400">상태: <span className="font-bold text-white">{item.status||'저장 전'}</span>{item.last_indexed_at&&<span className="block mt-1">{new Date(item.last_indexed_at).toLocaleString('ko-KR')}</span>}{item.last_error&&<span className="block mt-1 text-red-300">{item.last_error}</span>}</div>{editable&&<button disabled={!item.id||!data.fingerprinting?.configured||['connected','indexing'].includes(item.status||'')} onClick={()=>startIndex(item)} className={smallButton}>지문 인덱싱</button>}</div></div>)}{sources.length===0&&<label className="flex items-start gap-3 rounded-xl border border-amber-500/30 bg-amber-500/5 p-4 text-sm text-amber-100"><input disabled={!editable} type="checkbox" checked={acknowledgeNoSource} onChange={e=>setAcknowledgeNoSource(e.target.checked)} className="mt-1" /><span>현재 내부 데이터 원본을 연결하지 않고, 키워드와 목적지 정책만으로 모니터링하는 것을 확인합니다.</span></label>}</div>{(data.index_jobs||[]).length>0&&<div className="rounded-xl border border-slate-700 p-4"><div className="mb-2 text-sm font-bold">최근 인덱싱 작업</div><div className="space-y-2">{data.index_jobs.slice(0,5).map((job:any)=><div key={job.id} className="grid gap-2 border-b border-slate-700 py-2 text-xs md:grid-cols-5"><span>{job.data_source_name}</span><span className="font-bold">{job.status}</span><span>파일 {job.files_indexed} / 건너뜀 {job.files_skipped}</span><span>지문 {job.fingerprints_indexed}</span><span className="text-red-300">{job.error||''}</span></div>)}</div></div>}</div>}

        {step===5&&<div className="space-y-5"><div><h2 className="text-lg font-bold">검토와 정책 배포</h2><p className="mt-1 text-sm text-slate-400">초기 배포는 오탐지와 업무 중단을 피하기 위해 반드시 모니터링 전용으로 시작합니다.</p></div><div className="grid gap-3 md:grid-cols-4">{[['회사·내부망',data.progress.organization],['AI 목적지',data.progress.destinations],['분류 규칙',data.progress.classification],['데이터 원본/확인',data.progress.data_sources]].map(([label,ready]:any)=><div key={label} className={`rounded-xl border p-4 ${ready?'border-emerald-500/30 bg-emerald-500/5':'border-red-500/30 bg-red-500/5'}`}><div className="text-xs text-slate-400">{label}</div><div className={`mt-2 text-sm font-bold ${ready?'text-emerald-300':'text-red-300'}`}>{ready?'준비 완료':'확인 필요'}</div></div>)}</div><div className="rounded-xl border border-slate-700 bg-slate-950/40 p-5"><div className="grid gap-3 text-sm md:grid-cols-2"><div><span className="text-slate-400">회사</span><span className="float-right font-bold">{data.organization.company_name}</span></div><div><span className="text-slate-400">목적지</span><span className="float-right font-bold">{data.destinations.length}개</span></div><div><span className="text-slate-400">분류 규칙</span><span className="float-right font-bold">{data.classification_rules.length}개</span></div><div><span className="text-slate-400">데이터 원본</span><span className="float-right font-bold">{data.data_sources.length}개</span></div><div><span className="text-slate-400">설정 리비전</span><span className="float-right font-bold">{data.onboarding.config_revision}</span></div><div><span className="text-slate-400">활성 리비전</span><span className="float-right font-bold">{data.onboarding.active_revision}</span></div></div></div>
<div className="rounded-xl border border-blue-500/20 bg-blue-500/5 p-4"><div className="mb-2 text-xs font-bold text-blue-300">시스템 설치 정보</div><div className="grid gap-2 text-sm md:grid-cols-3"><div><span className="text-slate-400">Local AI 제공자</span><div className="mt-0.5 font-bold text-white">{local.provider||'미설정'}</div></div><div><span className="text-slate-400">모델</span><div className="mt-0.5 font-bold text-white">{local.model||'-'}</div></div><div><span className="text-slate-400">연결 위치</span><div className="mt-0.5 break-all text-xs font-bold text-white">{local.baseUrl||'-'}</div></div></div></div>{editable&&<button disabled={saving||(!completed&&!allReady)||(!data.draft_pending&&completed)} onClick={finish} className="w-full rounded-xl border border-emerald-400 bg-emerald-500/20 px-5 py-3 text-sm font-black text-emerald-100 hover:bg-emerald-500/30 disabled:opacity-40">{saving?'처리 중...':completed?'변경 정책 배포':'초기 설정 완료 · 모니터링 시작'}</button>}{completed&&editable&&<div className="rounded-xl border border-red-500/30 bg-red-500/5 p-5"><div className="font-bold text-red-200">차단 모드 전환</div><p className="mt-2 text-sm text-slate-300">먼저 모니터링 기록을 검토한 후 전환하십시오. 전환 시 현재 저장된 정책도 함께 배포됩니다.</p>{data.onboarding.enforcement_mode==='monitor'?<div className="mt-4 flex flex-col gap-2 md:flex-row"><input value={enforcementConfirmation} onChange={e=>setEnforcementConfirmation(e.target.value)} placeholder="ENABLE_ENFORCEMENT 입력" className={inputClass}/><button disabled={saving||enforcementConfirmation!=='ENABLE_ENFORCEMENT'} onClick={()=>changeMode('enforce')} className="shrink-0 rounded-lg border border-red-400 bg-red-500/20 px-5 py-2 text-sm font-bold text-red-100 disabled:opacity-40">차단 모드 활성화</button></div>:<button disabled={saving} onClick={()=>changeMode('monitor')} className="mt-4 rounded-lg border border-blue-400 bg-blue-500/20 px-5 py-2 text-sm font-bold text-blue-100">모니터링 전용으로 복귀</button>}</div>}</div>}

        {step<5&&editable&&<div className="mt-7 flex items-center justify-between border-t border-slate-700 pt-5"><button disabled={step===1||saving} onClick={()=>setStep(x=>Math.max(1,x-1))} className={smallButton}>← 이전</button><button disabled={saving} onClick={saveAndNext} className="rounded-lg border border-emerald-400 bg-emerald-500/20 px-5 py-2.5 text-sm font-bold text-emerald-100 hover:bg-emerald-500/30 disabled:opacity-40">{saving?'저장 중...':'저장하고 다음 →'}</button></div>}
      </div>
    </section>
  );

  if(!completed&&role==='admin')return <div className="fixed inset-0 z-[60] overflow-y-auto bg-slate-950/95 p-3 py-6 md:p-8">{panel}</div>;
  if(forceOpen)return panel;
  if(!completed)return <div className="mb-4 rounded-lg border border-yellow-500/40 bg-yellow-500/10 p-4 text-sm text-yellow-100">관리자가 보호 정책을 설정하는 중입니다. 설정 완료 전에는 Agent가 모니터링 전용으로 동작합니다.</div>;
  return null;
}
