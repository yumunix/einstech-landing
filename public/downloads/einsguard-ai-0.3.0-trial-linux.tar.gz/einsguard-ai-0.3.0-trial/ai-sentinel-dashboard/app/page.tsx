'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, Legend } from 'recharts';
import { formatDistanceToNow, format } from 'date-fns';
import { ko } from 'date-fns/locale';
import OnboardingWizard from './onboarding-wizard';

const TOOL_COLOR: Record<string, string> = { claude: '#16c79a', codex: '#6366f1' };
const SEV_COLOR: Record<string, string> = { HIGH: '#ef4444', MED: '#f59e0b', LOW: '#3b82f6' };
const SEV_LABEL:Record<string,string>={CRITICAL:'Critical',HIGH:'High',MED:'Med',LOW:'Low'};
const SEV_BADGE:Record<string,string>={CRITICAL:'border-fuchsia-300 bg-fuchsia-400 text-slate-950',HIGH:'border-red-300 bg-red-400 text-slate-950',MED:'border-amber-200 bg-amber-300 text-slate-950',LOW:'border-blue-200 bg-blue-300 text-slate-950'};
const CURRENT_AGENT_VERSION='1.4.0';

type Tab = 'overview' | 'tasks' | 'analytics' | 'agents' | 'reports' | 'sessions' | 'alerts' | 'control' | 'governance' | 'protection' | 'catalog' | 'license' | 'backup';
type ControlTab = 'blocks' | 'policies' | 'approvals' | 'active';
type NavGroupKey = 'home' | 'assets' | 'security' | 'policy' | 'operations';

const TAB_META:Record<Tab,{label:string;description:string}>={
  overview:{label:'한눈에 보기',description:'오늘의 위험과 필요한 조치'},
  tasks:{label:'처리할 일',description:'관리자가 결정해야 하는 요청과 문제'},
  agents:{label:'장비·사용자',description:'Agent 장비, 사용자, AI 사용 현황'},
  alerts:{label:'위험 알림',description:'보안 위험과 해결 상태'},
  control:{label:'차단·보안 검토',description:'차단 정책과 보안 검토 요청'},
  sessions:{label:'사용 기록',description:'사용자와 서버의 AI 실행 기록'},
  governance:{label:'조직·권한',description:'관리자 역할과 운영 정책'},
  protection:{label:'민감정보 보호',description:'보호할 문구와 차단 방법 입력'},
  catalog:{label:'AI 서비스 관리',description:'탐지할 AI 서비스 목록'},
  reports:{label:'보고서',description:'주간 운영·보안 보고서'},
  analytics:{label:'사용량·비용',description:'AI 사용량과 구독 비용'},
  license:{label:'라이선스·장비',description:'사용 기간, 관리 장비 수, Agent 키'},
  backup:{label:'백업·복구',description:'설정 정기 백업과 복구 준비'},
};

const NAV_GROUPS:{key:NavGroupKey;label:string;description:string;tabs:Tab[]}[]=[
  {key:'home',label:'홈',description:'현황과 처리할 일',tabs:['overview','tasks']},
  {key:'assets',label:'장비·사용자',description:'PC·서버와 사용자',tabs:['agents']},
  {key:'security',label:'보안',description:'위험·차단·사용 기록',tabs:['alerts','control','sessions']},
  {key:'policy',label:'정책',description:'민감정보 보호와 AI 사용 기준',tabs:['protection','governance','catalog']},
  {key:'operations',label:'운영',description:'보고·비용·백업',tabs:['reports','analytics','license','backup']},
];

function AgentAiAccess({agent,tools,canEdit,onChange}:{agent:any;tools:string[];canEdit:boolean;onChange:(agent:any,tool:string,allow:boolean)=>void}){
  const approved:string[]=Array.isArray(agent.approved_tools)?agent.approved_tools:[];
  const allowed=tools.filter(tool=>approved.includes(tool));
  const blocked=tools.filter(tool=>!approved.includes(tool));
  const row=(label:string,items:string[],allow:boolean)=><div className={`rounded-lg border p-2 ${allow?'border-emerald-500/30 bg-emerald-500/5':'border-red-500/30 bg-red-500/5'}`}>
    <div className={`mb-1 text-[10px] font-black ${allow?'text-emerald-300':'text-red-300'}`}>{label} {items.length}개</div>
    <div className="flex flex-wrap gap-1">{items.length?items.map(tool=>{
      const running=(agent.running_tools||[]).includes(tool);
      return <button key={tool} disabled={!canEdit} onClick={()=>onChange(agent,tool,!allow)} title={canEdit?`${tool}를 ${allow?'차단':'허용'}으로 변경`:'열람만 가능'} className={`rounded border px-2 py-1 text-[10px] font-bold disabled:cursor-default ${allow?'border-emerald-600 bg-emerald-700 text-white':'border-red-600 bg-red-700 text-white'}`}>{tool}{running?' · 실행 중':''}</button>;
    }):<span className="text-[10px] text-slate-500">없음</span>}</div>
  </div>;
  return <div className="grid min-w-72 gap-2 md:grid-cols-2">{row('허용된 AI',allowed,true)}{row('차단된 AI',blocked,false)}</div>;
}

export default function Dashboard() {
  const [tab, setTab] = useState<Tab>('overview');
  const [controlTab, setControlTab] = useState<ControlTab>('blocks');
  const [stats, setStats] = useState<any>(null);
  const [sessions, setSessions] = useState<any>(null);
  const [alerts, setAlerts] = useState<any>(null);
  const [controls, setControls] = useState<any>(null);
  const [analytics, setAnalytics] = useState<any>(null);
  const [governance, setGovernance] = useState<any>(null);
  const [agents, setAgents] = useState<any>(null);
  const [reports, setReports] = useState<any>(null);
  const [tenants, setTenants] = useState<any>(null);
  const [license, setLicense] = useState<any>(null);
  const [catalog,setCatalog]=useState<any>(null);
  const [backup,setBackup]=useState<any>(null);
  const [backupForm,setBackupForm]=useState({enabled:true,frequency:'daily',time:'02:00',dayOfWeek:0,storagePath:'/einstech-ai/05-backups/ai-sentinel',includeDatabase:true,includeEnvironment:true,includeApplicationConfig:true,description:'AI GUARD 운영 설정 정기 백업',retentionDays:365,automaticCleanup:false});
  const [backupNotes,setBackupNotes]=useState('AI GUARD 운영 설정 수동 백업');
  const [backupMsg,setBackupMsg]=useState('');
  const [backupBusy,setBackupBusy]=useState(false);
  const [backupBrowser,setBackupBrowser]=useState<any>(null);
  const [showBackupBrowser,setShowBackupBrowser]=useState(false);
  const [selectedRestoreBackup,setSelectedRestoreBackup]=useState<any>(null);
  const [restoreValidation,setRestoreValidation]=useState<any>(null);
  const [restoreConfirmation,setRestoreConfirmation]=useState('');
  const [restorePlan,setRestorePlan]=useState<any>(null);
  const [selectedAlertIds,setSelectedAlertIds]=useState<number[]>([]);
  const [alertSeverityFilter,setAlertSeverityFilter]=useState<'ALL'|'CRITICAL'|'HIGH'|'MED'|'LOW'>('ALL');
  const [catalogForm,setCatalogForm]=useState({key:'',name:'',process:'',domain:'',notes:''});
  const [subscriptionForm,setSubscriptionForm]=useState({service_key:'chatgpt',service_name:'ChatGPT',plan_name:'Pro',seats:1,unit_price:0,currency:'USD'});
  const [licenseKey, setLicenseKey] = useState('');
  const [licenseMsg, setLicenseMsg] = useState('');
  const [tenantForm, setTenantForm] = useState({name:'',code:'',admin_username:'',admin_email:'',admin_password:''});
  const [newAgentKey, setNewAgentKey] = useState('');
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [lastUpdated, setLastUpdated] = useState(new Date());
  const [formMsg, setFormMsg] = useState('');
  const [showSettings, setShowSettings] = useState(false);
  const [showAppearance,setShowAppearance]=useState(false);
  const [appearance,setAppearance]=useState<'light'|'navy'|'dark'|'high-contrast'>('high-contrast');
  const [agentSearch,setAgentSearch]=useState('');
  const [agentStatus,setAgentStatus]=useState<'all'|'online'|'offline'>('all');
  const [agentSort,setAgentSort]=useState<'running'|'online'|'recent'|'hostname'>('running');
  const [agentPage,setAgentPage]=useState(1);
  const [agentPageSize,setAgentPageSize]=useState(10);
  const [shadowEventFilter,setShadowEventFilter]=useState<'all'|'detected'|'blocked'|'information'|'error'|'other'>('all');
  const [shadowEventPage,setShadowEventPage]=useState(1);
  const [settingsForm, setSettingsForm] = useState({ currentPassword: '', newUsername: '', newPassword: '', confirmPassword: '' });
  const [settingsMsg, setSettingsMsg] = useState('');
  const [discovery, setDiscovery] = useState<any>(null);
  const [discoveryNetwork, setDiscoveryNetwork] = useState('');
  const [discoveryMsg, setDiscoveryMsg] = useState('');
  const [scanLoading, setScanLoading] = useState(false);
  const router = useRouter();

  const logout = async () => {
    await fetch('/api/auth', { method: 'DELETE' });
    router.push('/login');
  };

  const saveSettings = async () => {
    setSettingsMsg('');
    if (settingsForm.newPassword && settingsForm.newPassword !== settingsForm.confirmPassword) {
      setSettingsMsg('❌ 새 비밀번호가 일치하지 않습니다');
      return;
    }
    const r = await fetch('/api/auth', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        currentPassword: settingsForm.currentPassword,
        newUsername: settingsForm.newUsername || undefined,
        newPassword: settingsForm.newPassword || undefined,
      }),
    });
    const d = await r.json();
    if (d.ok) {
      setSettingsMsg('✅ 변경 완료');
      setSettingsForm({ currentPassword: '', newUsername: '', newPassword: '', confirmPassword: '' });
    } else {
      setSettingsMsg('❌ ' + d.error);
    }
  };

  const [blockForm, setBlockForm] = useState({ hostname: '*', tool: 'claude', reason: '' });
  const [blockUsernames,setBlockUsernames]=useState<string[]>(['*']);
  const [blockClientSearch,setBlockClientSearch]=useState('');
  const [blockUserSearch,setBlockUserSearch]=useState('');
  const [blockToolSearch, setBlockToolSearch] = useState('');
  const [customAiForm,setCustomAiForm]=useState({key:'',name:'',process:'',domain:''});
  const [policyForm, setPolicyForm] = useState({ hostname: '', username: '', allow_start: 9, allow_end: 18, max_per_hour: 10, template_key: '', tool: '*' });

  const fetchAll = async () => {
    const [s, se, al, an, ag, rep, gov, me, ten, lic, cat] = await Promise.all([
      fetch('/api/stats').then(r => r.json()),
      fetch('/api/sessions').then(r => r.json()),
      fetch('/api/alerts').then(r => r.json()),
      fetch('/api/analytics').then(r => r.json()),
      fetch('/api/agents').then(r => r.json()),
      fetch('/api/reports').then(r => r.json()),
      fetch('/api/governance').then(r => r.json()),
      fetch('/api/auth').then(r => r.json()),
      fetch('/api/tenants').then(r => r.json()),
      fetch('/api/license').then(r => r.json()),
      fetch('/api/catalog').then(r=>r.json()),
    ]);
    setStats(s); setSessions(se); setAlerts(al); setAnalytics(an); setAgents(ag); setReports(rep); setGovernance(gov); setCurrentUser(me); setTenants(ten); setLicense(lic.license);setCatalog(cat);
    setLastUpdated(new Date());
  };

  const fetchControls = async () => {
    const c = await fetch('/api/control').then(r => r.json());
    setControls(c);
  };

  const fetchDiscovery = async () => {
    const d = await fetch('/api/discovery').then(r => r.json());
    setDiscovery(d);
  };

  const fetchBackup=async()=>{
    const response=await fetch('/api/backup',{cache:'no-store'});const data=await response.json();
    if(response.ok){setBackup(data);setBackupForm(current=>({...current,...data.policy}));}
    else setBackupMsg('❌ '+(data.error||'백업 상태를 확인하지 못했습니다.'));
  };

  useEffect(() => {
    const saved=window.localStorage.getItem('aiguard-appearance') as typeof appearance|null;if(saved&&['light','navy','dark','high-contrast'].includes(saved))setAppearance(saved);
    fetchAll();
    fetchControls();
    fetchDiscovery();
    const t = setInterval(() => { fetchAll(); fetchControls(); }, 15000);
    const td = setInterval(() => { fetchDiscovery(); }, 8000);
    return () => { clearInterval(t); clearInterval(td); };
  }, []);
  useEffect(()=>{if(currentUser?.platform_admin)void fetchBackup();},[currentUser?.platform_admin]);
  const changeAppearance=(value:typeof appearance)=>{setAppearance(value);window.localStorage.setItem('aiguard-appearance',value)};

  const resolveAlert = async (id: number) => {
    await fetch('/api/alerts', { method: 'PATCH', body: JSON.stringify({ id }), headers: { 'Content-Type': 'application/json' } });
    fetchAll();
  };
  const openAlerts=async()=>{setTab('alerts');if((alerts?.unread||0)>0){await fetch('/api/alerts',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'mark_read'})});setAlerts((prev:any)=>prev?{...prev,unread:0,alerts:(prev.alerts||[]).map((a:any)=>({...a,read_at:a.read_at||new Date().toISOString()}))}:prev);}};
  const deleteAlert=async(id:number)=>{if(!window.confirm('이 알림을 화면에서 삭제하시겠습니까? 삭제 이력은 감사 기록에 남습니다.'))return;await fetch('/api/alerts',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'delete',id,reason:'대시보드 사용자 삭제'})});fetchAll();};
  const toggleAlertSelection=(id:number)=>setSelectedAlertIds(ids=>ids.includes(id)?ids.filter(x=>x!==id):[...ids,id]);
  const visibleAlerts=(alerts?.alerts||[]).filter((a:any)=>alertSeverityFilter==='ALL'||a.severity===alertSeverityFilter);
  const toggleAllAlerts=()=>{const ids=visibleAlerts.map((a:any)=>Number(a.id));const allSelected=ids.length>0&&ids.every((id:number)=>selectedAlertIds.includes(id));setSelectedAlertIds(current=>allSelected?current.filter(id=>!ids.includes(id)):Array.from(new Set([...current,...ids])))};
  const deleteSelectedAlerts=async()=>{if(!selectedAlertIds.length)return;if(!window.confirm(`선택한 보안 알림 ${selectedAlertIds.length}건을 삭제하시겠습니까? 삭제 이력은 감사 기록에 남습니다.`))return;const r=await fetch('/api/alerts',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'delete_many',ids:selectedAlertIds})});const d=await r.json();if(d.ok){setSelectedAlertIds([]);setFormMsg(`✅ 보안 알림 ${d.deleted}건 삭제 완료`);fetchAll();}else setFormMsg('❌ '+d.error)};

  const addBlock = async () => {
    setFormMsg('');
    const r = await fetch('/api/control', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'add_block', ...blockForm, usernames:blockUsernames }),
    });
    const d = await r.json();
    if(d.ok){
      setFormMsg(d.created>0?`✅ 차단 ${d.created}건 등록 완료`:'ℹ️ 동일한 차단 정책이 이미 등록되어 있습니다.');
      setBlockForm(f=>({...f,reason:''}));
    }else setFormMsg('❌ 실패: ' + d.error);
    fetchControls();
  };

  const removeBlock = async (id: number) => {
    await fetch('/api/control', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'remove_block', id }) });
    fetchControls();
  };

  const addCustomAi = async () => {
    setFormMsg('');
    const r=await fetch('/api/control',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'add_custom_ai',...customAiForm})});
    const d=await r.json();
    if(d.ok){setBlockForm(f=>({...f,tool:d.key}));setBlockToolSearch(customAiForm.name||d.key);setCustomAiForm({key:'',name:'',process:'',domain:''});setFormMsg('✅ 사용자 정의 AI 등록 완료 — 차단 등록을 누르세요.');fetchControls();}
    else setFormMsg('❌ 실패: '+d.error);
  };
  const addCatalogCandidate=async()=>{const r=await fetch('/api/catalog',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'add_candidate',...catalogForm})});const d=await r.json();if(d.ok){setFormMsg('✅ 신규 AI 후보가 검토함에 등록됐습니다.');setCatalogForm({key:'',name:'',process:'',domain:'',notes:''});fetchAll();}else setFormMsg('❌ '+d.error)};
  const setCatalogStatus=async(id:number,status:string)=>{await fetch('/api/catalog',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'set_status',id,status})});fetchAll();fetchControls();};
  const addSubscription=async()=>{const r=await fetch('/api/analytics',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'add_subscription',...subscriptionForm})});const d=await r.json();if(d.ok){setFormMsg('✅ 구독 비용 등록 완료');fetchAll();}else setFormMsg('❌ '+d.error)};
  const removeSubscription=async(id:number)=>{await fetch('/api/analytics',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'remove_subscription',id})});fetchAll();};

  const backupRequest=async(action:string,payload:Record<string,unknown>={})=>{
    setBackupBusy(true);setBackupMsg('');
    try{const response=await fetch('/api/backup',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action,...payload})});const data=await response.json();if(!response.ok)throw new Error(data.error||'백업 작업에 실패했습니다.');await fetchBackup();return data;}
    catch(error){setBackupMsg('❌ '+(error instanceof Error?error.message:'백업 작업에 실패했습니다.'));return null;}
    finally{setBackupBusy(false);}
  };
  const saveBackupPolicy=async()=>{const data=await backupRequest('save_policy',{policy:backupForm});if(data)setBackupMsg('✅ 정기 백업 위치·대상·주기를 저장했습니다.');};
  const runBackup=async()=>{const data=await backupRequest('run_backup',{notes:backupNotes});if(data)setBackupMsg(`✅ 백업 완료: ${data.backup.backupName}`);};
  const validateBackup=async(backupName:string)=>{const data=await backupRequest('validate_backup',{backupName});if(data)setBackupMsg(data.validation.ok?`✅ ${backupName} 무결성 검증 정상`:`❌ ${backupName} 손상 파일 ${data.validation.failures.length}개`);};
  const openBackupBrowser=async(path?:string)=>{setBackupBusy(true);try{const response=await fetch(`/api/backup?action=browse&path=${encodeURIComponent(path||backupForm.storagePath)}`);const data=await response.json();if(!response.ok)throw new Error(data.error);setBackupBrowser(data);setShowBackupBrowser(true);}catch(error){setBackupMsg('❌ '+(error instanceof Error?error.message:'저장소를 열지 못했습니다.'));}finally{setBackupBusy(false);}};
  const chooseBackupFolder=()=>{if(!backupBrowser?.current)return;setBackupForm(form=>({...form,storagePath:backupBrowser.current}));setShowBackupBrowser(false);setBackupMsg(`ℹ️ 저장 위치 선택: ${backupBrowser.current} · 설정 저장을 눌러 적용하십시오.`);};
  const selectRestore=async(item:any)=>{setSelectedRestoreBackup(item);setRestoreValidation(null);setRestoreConfirmation('');setRestorePlan(null);const data=await backupRequest('validate_backup',{backupName:item.backupName});if(data){setRestoreValidation(data.validation);setBackupMsg(data.validation.ok?'✅ 복구 파일 무결성 검증 정상':'❌ 복구 파일이 손상되었습니다.');}};
  const prepareRestore=async()=>{if(!selectedRestoreBackup)return;const data=await backupRequest('prepare_restore',{backupName:selectedRestoreBackup.backupName,confirmation:restoreConfirmation});if(data){setRestorePlan(data);setBackupMsg('✅ 복구 대상과 절차를 준비했습니다. 유지보수 승인 후 서버 콘솔에서 실행하십시오.');}};
  const importBackup=async(file:File)=>{setBackupBusy(true);setBackupMsg('');try{const form=new FormData();form.set('action','import_backup');form.set('file',file);const response=await fetch('/api/backup',{method:'POST',body:form});const data=await response.json();if(!response.ok)throw new Error(data.error||'가져오기 실패');await fetchBackup();setBackupMsg(`✅ 백업 파일 가져오기 완료: ${data.imported.backupName}`);}catch(error){setBackupMsg('❌ '+(error instanceof Error?error.message:'가져오기 실패'));}finally{setBackupBusy(false);}};

  const addPolicy = async () => {
    setFormMsg('');
    const r = await fetch('/api/control', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'add_policy', ...policyForm }),
    });
    const d = await r.json();
    setFormMsg(d.ok ? `✅ 정책 적용 완료${d.replaced?` · 같은 대상의 기존 정책 ${d.replaced}개 교체`:''}` : '❌ 실패: ' + d.error);
    fetchControls();
  };

  const selectTemplate = (key: string) => {
    const template = governance?.templates?.find((item: any) => item.template_key === key);
    if (!template) return;
    setPolicyForm(f => ({ ...f, template_key: key, allow_start: template.allow_start, allow_end: template.allow_end, max_per_hour: template.max_per_hour, tool: template.tool }));
  };

  const updateRole = async (id: number, role: string) => {
    const r = await fetch('/api/governance', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'update_role', id, role }) });
    const d = await r.json();
    setFormMsg(d.ok ? '✅ 역할 변경 완료' : '❌ 실패: ' + d.error);
    fetchAll();
  };

  const resolveShadowEvent = async (id: number) => {
    await fetch('/api/agents', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({action:'resolve_event',id}) });
    fetchAll();
  };

  const toggleApprovedTool = async (agent: any, tool: string) => {
    const current: string[] = agent.approved_tools || [];
    const tools = current.includes(tool) ? current.filter(item => item !== tool) : [...current, tool];
    await fetch('/api/agents', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({action:'set_approved_tools',hostname:agent.hostname,tools}) });
    fetchAll();
  };

  const setToolAccess = async (agent:any,tool:string,allow:boolean) => {
    const current:string[]=agent.approved_tools||[];
    const tools=allow
      ?Array.from(new Set([...current,tool]))
      :current.filter(item=>item!==tool);
    const response=await fetch('/api/agents',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'set_approved_tools',hostname:agent.hostname,tools})});
    const result=await response.json();
    setFormMsg(result.ok?`✅ ${agent.hostname} · ${tool}: ${allow?'허용':'차단'}으로 변경했습니다.`:`❌ 변경 실패: ${result.error||'알 수 없는 오류'}`);
    fetchAll();
  };

  const retireAgent = async (hostname:string) => {
    if(!window.confirm(`${hostname} 장비를 관리 해제하시겠습니까?\nAgent 연결 키가 폐기되고 관리 가능 장비 수 1대가 복구됩니다.`))return;
    const response=await fetch('/api/agents',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'retire_agent',hostname})});
    const data=await response.json();
    setFormMsg(data.ok?`✅ ${hostname} 관리 해제 완료 · 관리 가능 장비 수 1대 복구`:`❌ 관리 해제 실패: ${data.error||'알 수 없는 오류'}`);
    fetchAll();
  };

  const decideEnrollment = async (id:number, action:'approve'|'reject') => {
    await fetch('/api/enroll',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,action})});
    fetchAll();
  };
  const issueRemovalToken = async (hostname:string) => {
    if(!window.confirm(`${hostname} 장비의 제거를 승인하고 이메일 전달용 제거 토큰을 발급합니다.\n(홈페이지 제거 요청을 받은 경우에만 사용하세요)`))return;
    const response=await fetch('/api/agents',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'issue_removal_token',hostname})});
    const data=await response.json();
    if(!data.ok){setFormMsg(`❌ 토큰 발급 실패: ${data.error||'알 수 없는 오류'}`);return;}
    window.prompt(`${hostname} 제거 명령 (2시간 유효) — 고객사에 EINSGUARD-AI-Windows-Cleanup 파일과 함께 전달하세요:`,data.windows_command);
    setFormMsg(`✅ ${hostname} 제거 토큰 발급 완료 (2시간 유효)`);
    fetchAll();
  };
  const decideRemoval = async (id:number, decision:'approve'|'reject') => {
    if(decision==='approve'&&!window.confirm('이 장비의 에이전트 제거를 승인하시겠습니까?\n승인하면 해당 장비에서 제거가 진행되고 관리 대상에서 해제됩니다.'))return;
    const response=await fetch('/api/agents',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'decide_removal',id,decision})});
    const data=await response.json();
    setFormMsg(data.ok?`✅ 제거 요청 ${decision==='approve'?'승인':'거부'} 완료`:`❌ 처리 실패: ${data.error||'알 수 없는 오류'}`);
    fetchAll();
  };

  const saveWeeklyReport = async () => {
    const r=await fetch('/api/reports',{method:'POST'}); const d=await r.json();
    setFormMsg(d.ok?'✅ 주간 보고서 초안 저장 완료':'❌ 실패: '+d.error); fetchAll();
  };

  const createTenant = async () => {
    setNewAgentKey(''); const r=await fetch('/api/tenants',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(tenantForm)});const d=await r.json();
    if(d.ok){setFormMsg('✅ 고객사 생성 완료');setNewAgentKey(d.agent_key);setTenantForm({name:'',code:'',admin_username:'',admin_email:'',admin_password:''});fetchAll();}else setFormMsg('❌ 실패: '+d.error);
  };

  const activateLicense = async () => {
    setLicenseMsg('');
    const r=await fetch('/api/license',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key:licenseKey})});
    const d=await r.json();
    if(d.ok){setLicense(d.license);setLicenseKey('');setLicenseMsg('✅ 라이선스 인증 완료');fetchAll();}
    else setLicenseMsg('❌ '+(d.error||'인증 실패'));
  };

  const removePolicy = async (id: number) => {
    await fetch('/api/control', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'remove_policy', id }) });
    fetchControls();
  };

  const killSession = async (sessionId: string) => {
    const r = await fetch('/api/control', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'kill_session', session_id: sessionId }),
    });
    const d = await r.json();
    setFormMsg(d.ok ? '🛑 강제종료 명령 전송됨' : '❌ 실패: ' + d.error);
    fetchControls();
  };

  const toggleSession = async (sessionId: string, paused: boolean) => {
    const r = await fetch('/api/control', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: paused ? 'resume_session' : 'pause_session', session_id: sessionId }),
    });
    const d = await r.json();
    setFormMsg(d.ok ? (paused ? '▶️ 세션 재개 명령 전송됨' : '⏸️ 세션 일시정지 명령 전송됨') : '❌ 실패: ' + d.error);
    fetchControls();
  };

  const reviewApproval = async (id: number, approved: boolean) => {
    await fetch('/api/control', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'review_approval', id, approved }),
    });
    fetchControls();
  };

  const unreadAlertCount = alerts?.unread ?? alerts?.alerts?.filter((a:any)=>!a.read_at).length ?? 0;
  const highRiskAlerts = alerts?.alerts?.filter((a: any) => !a.resolved && a.severity === 'HIGH') ?? [];
  const pendingApprovals = controls?.approvals?.filter((a: any) => a.status === 'pending').length ?? 0;
  const pendingEnrollments = agents?.enrollments?.filter((e: any) => e.status === 'pending').length ?? 0;
  const pendingRemovals = agents?.removal_requests?.filter((e: any) => e.status === 'pending').length ?? 0;
  const activeSessionCount = controls?.activeSessions?.length ?? 0;
  const blockedTargetCount = controls?.blocks?.length ?? 0;
  const licenseNeedsAction = Boolean(license && (!license.active || (!license.perpetual && license.days_remaining !== null && license.days_remaining <= 7)));
  const connectedAgentKeys=(license?.agent_keys||[]).filter((key:any)=>Boolean(key.last_used_at));
  const unusedAgentKeyCount=(license?.agent_keys||[]).filter((key:any)=>!key.last_used_at).length;
  const agentKeyConnectionState=(key:any)=>{
    if(!key.enabled)return {label:'인증 해제',className:'bg-slate-700 text-slate-200'};
    const lastUsed=new Date(key.last_used_at).getTime();
    if(Number.isFinite(lastUsed)&&Date.now()-lastUsed<=10*60*1000)return {label:'연결 정상',className:'bg-emerald-500/20 text-emerald-200'};
    return {label:'최근 통신 없음',className:'bg-yellow-500/20 text-yellow-200'};
  };
  const actionItemCount = pendingEnrollments + pendingRemovals + pendingApprovals + highRiskAlerts.length + (licenseNeedsAction ? 1 : 0);
  const aiCatalog=[...(controls?.catalog||[]),...(controls?.customCatalog||[])];
  const filteredAiCatalog=aiCatalog.filter((x:any)=>`${x.name} ${x.key}`.toLowerCase().includes(blockToolSearch.toLowerCase())).slice(0,80);
  const blockTargets=controls?.blockTargets||[];
  const selectedBlockTarget=blockTargets.find((target:any)=>target.hostname===blockForm.hostname);
  const filteredBlockTargets=blockTargets.filter((target:any)=>`${target.hostname} ${(target.ips||[]).join(' ')} ${target.os||''}`.toLowerCase().includes(blockClientSearch.trim().toLowerCase())).slice(0,50);
  const blockUserRows:any[]=blockForm.hostname==='*'?blockTargets.flatMap((target:any)=>target.users||[]):selectedBlockTarget?.users||[];
  const availableBlockUsers:string[]=Array.from(new Set<string>(blockUserRows.map((user:any)=>String(user.username)))).sort((a,b)=>a.localeCompare(b));
  const filteredBlockUsers=availableBlockUsers.filter((username:string)=>username.toLowerCase().includes(blockUserSearch.trim().toLowerCase())).slice(0,80);
  const selectedPolicyTemplate=(governance?.templates||[]).find((template:any)=>template.template_key===policyForm.template_key);
  const protectionSetting=(governance?.settings||[]).find((setting:any)=>setting.setting_key==='dlp_policy')?.setting_value||{};
  const protectionChannels=[
    ['AI 대화 입력창',protectionSetting.scanPromptText],
    ['클립보드',protectionSetting.scanClipboard],
    ['터미널 명령',protectionSetting.scanCliArguments],
    ['첨부 파일',protectionSetting.scanFileUploads],
  ];
  const policyTargetSummary=`${policyForm.hostname.trim()||'전체 장비'} / ${policyForm.username.trim()||'전체 사용자'} / ${policyForm.tool==='*'?'전체 AI':policyForm.tool}`;
  const policyEffectSummary=policyForm.template_key==='blocked'
    ? '선택한 대상의 AI 실행을 항상 차단합니다.'
    : policyForm.max_per_hour===0
      ? `허용 시간(${policyForm.allow_start}시~${policyForm.allow_end}시) 안에서도 실행할 때마다 관리자 승인을 요청합니다.`
      : `${policyForm.allow_start}시~${policyForm.allow_end}시에만 허용하고, 최근 1시간 실행을 최대 ${policyForm.max_per_hour}회로 제한합니다.`;
  const policyHighImpact=(policyForm.hostname.trim()===''||policyForm.hostname.trim()==='*')&&(policyForm.username.trim()===''||policyForm.username.trim()==='*')&&(policyForm.template_key==='blocked'||policyForm.max_per_hour===0);
  const chooseBlockTarget=(hostname:string)=>{setBlockForm(f=>({...f,hostname}));setBlockUsernames(['*']);setBlockUserSearch('');};
  const toggleBlockUsername=(username:string)=>setBlockUsernames(current=>{
    if(username==='*')return ['*'];
    const withoutAll=current.filter(value=>value!=='*');
    return withoutAll.includes(username)?(withoutAll.filter(value=>value!==username).length?withoutAll.filter(value=>value!==username):['*']):[...withoutAll,username];
  });
  const observedAgentTools=(agent:any)=>Array.from(new Set<string>([
    ...(Array.isArray(agent.installed_tools)?agent.installed_tools:[]),
    ...(Array.isArray(agent.running_tools)?agent.running_tools:[]),
  ])).sort((a,b)=>{
    const runningA=(agent.running_tools||[]).includes(a)?1:0;
    const runningB=(agent.running_tools||[]).includes(b)?1:0;
    return runningB-runningA||a.localeCompare(b);
  });
  const agentRunningCount=(agent:any)=>new Set(Array.isArray(agent.running_tools)?agent.running_tools:[]).size;
  const agentLastSeen=(agent:any)=>{const value=new Date(agent.last_seen).getTime();return Number.isFinite(value)?value:0;};
  const agentOnline=(agent:any)=>Date.now()-agentLastSeen(agent)<300000;
  const agentVersionLatest=(agent:any)=>String(agent?.agent_version||'')===CURRENT_AGENT_VERSION;
  const allAgentRows=agents?.agents||[];
  const outdatedAgentCount=allAgentRows.filter((agent:any)=>!agentVersionLatest(agent)).length;
  const filteredAgentRows=allAgentRows.filter((agent:any)=>{
    const online=agentOnline(agent);
    const matchesStatus=agentStatus==='all'||(agentStatus==='online'?online:!online);
    const haystack=`${agent.hostname} ${agent.username||''} ${(agent.users||[]).map((user:any)=>user.username).join(' ')} ${agent.os||''} ${observedAgentTools(agent).join(' ')}`.toLowerCase();
    return matchesStatus&&haystack.includes(agentSearch.trim().toLowerCase());
  }).sort((a:any,b:any)=>{
    if(agentSort==='hostname')return String(a.hostname||'').localeCompare(String(b.hostname||''));
    if(agentSort==='recent')return agentLastSeen(b)-agentLastSeen(a);
    if(agentSort==='online')return Number(agentOnline(b))-Number(agentOnline(a))||agentRunningCount(b)-agentRunningCount(a)||agentLastSeen(b)-agentLastSeen(a);
    return agentRunningCount(b)-agentRunningCount(a)||Number(agentOnline(b))-Number(agentOnline(a))||agentLastSeen(b)-agentLastSeen(a)||String(a.hostname||'').localeCompare(String(b.hostname||''));
  });
  const agentPageCount=Math.max(1,Math.ceil(filteredAgentRows.length/agentPageSize));
  const safeAgentPage=Math.min(agentPage,agentPageCount);
  const pagedAgentRows=filteredAgentRows.slice((safeAgentPage-1)*agentPageSize,safeAgentPage*agentPageSize);
  const compactAgentView=allAgentRows.length>=25;
  const shadowEvents=agents?.events||[];
  const filteredShadowEvents=shadowEvents.filter((event:any)=>shadowEventFilter==='all'||event.action_state===shadowEventFilter);
  const shadowEventCount=(category:typeof shadowEventFilter)=>category==='all'?shadowEvents.length:shadowEvents.filter((event:any)=>event.action_state===category).length;
  const shadowPageSize=10;
  const shadowPageCount=Math.max(1,Math.ceil(filteredShadowEvents.length/shadowPageSize));
  const safeShadowPage=Math.min(shadowEventPage,shadowPageCount);
  const pagedShadowEvents=filteredShadowEvents.slice((safeShadowPage-1)*shadowPageSize,safeShadowPage*shadowPageSize);
  const agentUserAccess=(agents?.agents||[]).flatMap((agent:any)=>(agent.users||[]).filter((user:any)=>user.status==='active').map((user:any)=>{
    const blocked=(controls?.blocks||[]).some((block:any)=>(block.hostname==='*'||String(block.hostname).toLowerCase()===String(agent.hostname).toLowerCase())&&(block.username==='*'||String(block.username).toLowerCase()===String(user.username).toLowerCase())&&(block.tool==='*'||!block.tool));
    return {hostname:agent.hostname,username:user.username,blocked};
  }));
  const allowedAgentUsers=agentUserAccess.filter((item:any)=>!item.blocked);
  const blockedAgentUsers=agentUserAccess.filter((item:any)=>item.blocked);
  const chartTheme=appearance==='light'
    ? {text:'#334155',tooltip:'#ffffff',border:'#64748b'}
    : appearance==='navy'
      ? {text:'#e2e8f0',tooltip:'#102348',border:'#6b86ad'}
      : appearance==='high-contrast'
        ? {text:'#fff7ed',tooltip:'#2d2335',border:'#d6bd91'}
        : {text:'#e4e4e7',tooltip:'#18181b',border:'#71717a'};
  const normalizedRole=String(currentUser?.role||'').trim().toLowerCase();
  const canViewProtection=!currentUser||Boolean(currentUser?.platform_admin)||['admin','security','auditor'].includes(normalizedRole);
  const visibleNavGroups=NAV_GROUPS.map(group=>({...group,tabs:group.tabs.filter(item=>(item!=='protection'||canViewProtection)&&(item!=='backup'||Boolean(currentUser?.platform_admin)))}));
  const activeNavGroup=visibleNavGroups.find(group=>group.tabs.includes(tab))||visibleNavGroups[0];
  const goToTab=(next:Tab)=>{if(next==='alerts')void openAlerts();else setTab(next);};
  const openNavGroup=(key:NavGroupKey)=>{const group=visibleNavGroups.find(item=>item.key===key);if(group?.tabs[0])goToTab(group.tabs[0]);};
  const navGroupBadge=(key:NavGroupKey)=>key==='home'?actionItemCount:key==='assets'?pendingEnrollments+pendingRemovals:key==='security'?unreadAlertCount+pendingApprovals:0;

  useEffect(()=>{setAgentPage(1)},[agentSearch,agentStatus,agentSort,agentPageSize]);

  const openControl = (next: ControlTab) => {
    setControlTab(next);
    setTab('control');
  };

  const openEnrollmentRequests = () => {
    setTab('agents');
    window.setTimeout(()=>document.getElementById('agent-enrollment-requests')?.scrollIntoView({behavior:'smooth',block:'center'}),80);
  };

  const openTasks = () => setTab('tasks');

  return (
    <div className="dashboard-shell min-h-screen text-white font-mono" data-appearance={appearance}>
      <div className="sticky top-0 z-40 border-b border-slate-700 bg-[#0a0f1e]/95 px-4 py-3 shadow-lg shadow-black/20 backdrop-blur md:px-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex min-w-0 flex-1 items-center gap-5">
          <button type="button" onClick={() => setTab('overview')} aria-label="AI GUARD 개요로 이동"
            className="group shrink-0 rounded-lg border-r border-slate-700 px-2 py-1 pr-5 text-left transition-colors hover:bg-slate-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400">
            <div className="text-emerald-400 text-[10px] tracking-widest">EINSTECH</div>
            <div className="text-lg font-bold tracking-tight group-hover:text-emerald-200">AI GUARD</div>
          </button>
          <nav aria-label="주 메뉴" className="dashboard-nav flex min-w-0 flex-1 items-center gap-1 overflow-x-auto py-1">
            {visibleNavGroups.map(group=>{const active=activeNavGroup.key===group.key;const badge=navGroupBadge(group.key);return <button key={group.key} onClick={()=>openNavGroup(group.key)} aria-current={active?'page':undefined} title={group.description}
              className={`group relative flex min-h-11 shrink-0 flex-col items-start justify-center rounded-lg border px-4 py-1.5 text-left transition-all ${active?'border-emerald-400 bg-emerald-500/20 text-emerald-100 shadow-[inset_0_-3px_0_#34d399]':'border-transparent text-slate-300 hover:border-slate-600 hover:bg-slate-800 hover:text-white'}`}>
              <span className="text-[13px] font-black">{group.label}</span><span className={`text-[9px] ${active?'text-emerald-300':'text-slate-500'}`}>{group.description}</span>
              {badge>0&&<span className={`absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full px-1 text-[10px] font-black text-white ${group.key==='assets'?'bg-blue-500':'bg-red-500'}`}>{badge}</span>}
            </button>})}
          </nav>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          <div className="flex min-h-10 items-center gap-3 whitespace-nowrap rounded-lg border border-slate-700 bg-slate-900 px-3">
            <div><div className="text-[9px] text-slate-500">마지막 갱신</div><div className="text-xs font-bold tabular-nums text-white">{format(lastUpdated, 'yyyy-MM-dd HH:mm:ss')}</div></div>
            <span className="text-xs font-bold text-emerald-400 animate-pulse">● 자동 갱신</span>
          </div>
          <button onClick={() => setShowSettings(true)} title={`${currentUser?.tenant_name||''} · ${currentUser?.role||''}`}
            className="min-h-10 rounded-lg border border-slate-700 px-3 text-xs font-bold text-slate-300 hover:border-emerald-500/50 hover:bg-slate-800 hover:text-emerald-200">[{currentUser?.username||'확인 중'}] 내 계정</button>
          <button onClick={()=>setShowAppearance(true)} title="화면 색상 설정" aria-label="화면 색상 설정" className="flex min-h-10 min-w-10 items-center justify-center rounded-lg border border-slate-700 text-lg text-slate-200 hover:border-emerald-500/50 hover:bg-slate-800">⚙</button>
          <button onClick={logout} className="min-h-10 rounded-lg border border-transparent px-3 text-xs font-bold text-slate-400 hover:border-red-500/40 hover:bg-red-500/10 hover:text-red-300">로그아웃</button>
        </div>
        </div>
        <div className="mt-2 flex flex-wrap items-center gap-2 border-t border-slate-800 pt-2">
          <div className="mr-2 min-w-32"><div className="text-[10px] font-black tracking-wider text-emerald-400">{activeNavGroup.label}</div><div className="text-[9px] text-slate-500">{activeNavGroup.description}</div></div>
          <nav aria-label={`${activeNavGroup.label} 하위 메뉴`} className="dashboard-subnav flex flex-wrap gap-2">{activeNavGroup.tabs.map(item=>{const active=tab===item;return <button key={item} onClick={()=>goToTab(item)} title={TAB_META[item].description} aria-current={active?'page':undefined} className={`min-h-9 rounded-lg border px-3 py-1.5 text-left ${active?'border-white bg-white text-slate-950':'border-slate-700 bg-slate-900 text-slate-300 hover:border-slate-500 hover:bg-slate-800'}`}><span className="block text-xs font-black">{TAB_META[item].label}</span><span className={`block text-[9px] ${active?'text-slate-600':'text-slate-500'}`}>{TAB_META[item].description}</span></button>})}</nav>
          <div className="ml-auto hidden text-right lg:block"><div className="text-[10px] text-slate-500">현재 위치</div><div className="text-xs font-bold text-slate-300">{activeNavGroup.label} › {TAB_META[tab].label}</div></div>
        </div>
      </div>

      <div className="p-6">
        <OnboardingWizard role={currentUser?.role} forceOpen={tab==='protection'} initialStep={3} onCompleted={()=>{setTab('overview');fetchAll();}} />
        {actionItemCount > 0 && <button onClick={openTasks} className="mb-4 w-full rounded-lg border-2 border-blue-400 bg-blue-500/15 p-4 text-left text-sm font-bold text-blue-100 shadow-lg shadow-blue-500/10"><span className="mr-2 rounded bg-blue-400 px-2 py-1 text-xs text-slate-950">미처리 작업</span>관리자 확인 또는 결정이 필요한 항목이 {actionItemCount}건 있습니다. <span className="float-right rounded border border-blue-300 px-3 py-1 text-xs text-blue-100">처리할 일 열기 →</span></button>}
        {/* 개요 */}
        {tab === 'overview' && stats && (
          <div className="overview-page space-y-6">
            <div className="flex flex-col gap-1">
              <div className="text-xl font-semibold">보안 운영 현황</div>
              <div className="text-xs text-slate-500">위험을 확인하고 필요한 조치를 바로 실행하세요.</div>
            </div>
            <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
              {[
                { label: '고위험 알림', value: highRiskAlerts.length, color: highRiskAlerts.length ? 'text-red-400' : 'text-slate-400', action: openAlerts },
                { label: '보안 검토 대기', value: pendingApprovals, color: pendingApprovals ? 'text-yellow-400' : 'text-slate-400', action: () => openControl('approvals') },
                { label: '활성 세션', value: activeSessionCount, color: 'text-emerald-400', action: () => openControl('active') },
                { label: '차단 대상', value: blockedTargetCount, color: 'text-orange-400', action: () => openControl('blocks') },
                { label: '오늘 실행', value: stats.summary?.today_usage ?? 0, color: 'text-blue-400' },
              ].map(({ label, value, color, action }) => (
                <button key={label} onClick={action} disabled={!action}
                  className={`bg-slate-900 border border-slate-800 rounded-lg p-4 text-left transition-colors ${action ? 'hover:border-slate-600 hover:bg-slate-800/70 cursor-pointer' : 'cursor-default'}`}>
                  <div className="text-slate-400 text-xs mb-1">{label}</div>
                  <div className={`text-3xl font-bold ${color}`}>{value}</div>
                  {action && <div className="text-[10px] text-slate-600 mt-2">클릭하여 확인 →</div>}
                </button>
              ))}
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <div className="text-sm font-semibold">즉시 확인이 필요한 위험</div>
                    <div className="text-[11px] text-slate-500 mt-1">미해결 고위험 이벤트와 탐지 근거</div>
                  </div>
                  <button onClick={openAlerts} className="text-xs text-emerald-400 hover:text-emerald-300">전체 알림 보기</button>
                </div>
                {highRiskAlerts.length === 0 ? (
                  <div className="rounded-lg border border-emerald-500/20 bg-emerald-500/5 px-4 py-5 text-sm text-emerald-300">현재 미해결 고위험 알림이 없습니다.</div>
                ) : (
                  <div className="space-y-2">
                    {highRiskAlerts.slice(0, 4).map((a: any) => (
                      <button key={a.id} onClick={openAlerts} className="w-full flex items-start gap-3 rounded-lg border border-red-500/25 bg-red-500/5 p-3 text-left hover:bg-red-500/10">
                        <span className="mt-1 h-2 w-2 rounded-full bg-red-500 flex-shrink-0" />
                        <span className="flex-1 min-w-0">
                          <span className="flex items-center gap-2 text-xs">
                            <span className="font-bold text-red-400">HIGH</span>
                            <span className="rounded bg-red-500/15 px-1.5 py-0.5 text-[10px] text-red-300">위험도 {a.risk_score ?? 80}점</span>
                            <span className="text-white">{a.alert_type}</span>
                            <span className="text-slate-500">{a.hostname} / {a.username}</span>
                          </span>
                          <span className="block mt-1 text-xs text-slate-400 truncate">탐지 근거: {a.risk_reason || a.detail || '상세 정보 없음'}</span>
                        </span>
                        <span className="text-[10px] text-slate-600">{formatDistanceToNow(new Date(a.created_at), { addSuffix: true, locale: ko })}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                <div className="text-sm font-semibold">빠른 조치</div>
                <div className="text-[11px] text-slate-500 mt-1 mb-4">운영 화면을 찾지 않고 바로 이동합니다.</div>
                <div className="space-y-2">
                  <button onClick={() => openControl('approvals')} className="w-full rounded-lg border border-yellow-500/25 bg-yellow-500/5 px-3 py-2.5 text-left text-xs text-yellow-300 hover:bg-yellow-500/10">보안 검토 요청 확인 <span className="float-right">{pendingApprovals}건 →</span></button>
                  <button onClick={() => openControl('active')} className="w-full rounded-lg border border-red-500/25 bg-red-500/5 px-3 py-2.5 text-left text-xs text-red-300 hover:bg-red-500/10">활성 세션 제어 <span className="float-right">{activeSessionCount}건 →</span></button>
                  <button onClick={() => openControl('blocks')} className="w-full rounded-lg border border-slate-700 bg-slate-800/60 px-3 py-2.5 text-left text-xs text-slate-300 hover:bg-slate-800">사용자·서버 차단 <span className="float-right">→</span></button>
                  <button onClick={() => openControl('policies')} className="w-full rounded-lg border border-slate-700 bg-slate-800/60 px-3 py-2.5 text-left text-xs text-slate-300 hover:bg-slate-800">사용 정책 관리 <span className="float-right">→</span></button>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                <div className="text-xs text-slate-400 mb-3">시간대별 AI 사용량</div>
                <ResponsiveContainer width="100%" height={200}>
                  <LineChart data={stats.timeline ?? []}>
                    <XAxis dataKey="hour" tick={{ fill: chartTheme.text, fontSize: 12 }} />
                    <YAxis tick={{ fill: chartTheme.text, fontSize: 12 }} />
                    <Tooltip contentStyle={{ background: chartTheme.tooltip, border: `1px solid ${chartTheme.border}`, borderRadius: 6, color: chartTheme.text }} labelStyle={{color:chartTheme.text}} itemStyle={{color:chartTheme.text}} />
                    <Legend wrapperStyle={{color:chartTheme.text}} />
                    <Line type="monotone" dataKey="count" stroke="#16c79a" dot={false} name="실행 횟수" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                <div className="text-xs text-slate-400 mb-3">서버별 사용량</div>
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={stats.byServer ?? []}>
                    <XAxis dataKey="hostname" tick={{ fill: chartTheme.text, fontSize: 12 }} />
                    <YAxis tick={{ fill: chartTheme.text, fontSize: 12 }} />
                    <Tooltip contentStyle={{ background: chartTheme.tooltip, border: `1px solid ${chartTheme.border}`, borderRadius: 6, color: chartTheme.text }} labelStyle={{color:chartTheme.text}} itemStyle={{color:chartTheme.text}} />
                    <Bar dataKey="count" fill="#6366f1" name="횟수" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                <div className="text-xs text-slate-400 mb-3">도구별 사용량</div>
                <div className="space-y-2">
                  {(stats.byTool ?? []).map((t: any) => (
                    <div key={t.tool} className="flex items-center gap-2">
                      <span className="w-16 text-xs" style={{ color: TOOL_COLOR[t.tool] ?? '#94a3b8' }}>{t.tool}</span>
                      <div className="flex-1 bg-slate-800 rounded-full h-2">
                        <div className="h-2 rounded-full" style={{ width: `${Math.min(100, (t.count / (stats.summary?.total_usage || 1)) * 100)}%`, background: TOOL_COLOR[t.tool] ?? '#94a3b8' }} />
                      </div>
                      <span className="text-xs text-slate-400">{t.count}회</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                <div className="text-xs text-slate-400 mb-3">최근 실행</div>
                <div className="space-y-1">
                  {(stats.recent ?? []).slice(0, 8).map((r: any, i: number) => (
                    <div key={i} className="flex items-center gap-2 text-xs text-slate-400 py-1 border-b border-slate-800">
                      <span className="text-emerald-400">{format(new Date(r.logged_at), 'HH:mm:ss')}</span>
                      <span className="text-blue-400">{r.hostname}</span>
                      <span>{r.username}</span>
                      <span style={{ color: TOOL_COLOR[r.tool] ?? '#94a3b8' }}>{r.tool}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 관리자 처리할 일 */}
        {tab === 'tasks' && (
          <div className="space-y-6">
            <div className="flex flex-wrap items-end justify-between gap-3">
              <div><div className="text-xl font-semibold">관리자 처리할 일</div><div className="mt-1 text-xs text-slate-500">알림은 사실을 알려주고, 이 화면에서는 승인·거부·해결 같은 실제 결정을 합니다.</div></div>
              <div className={`rounded-lg border px-4 py-2 text-sm font-black ${actionItemCount?'border-yellow-500/40 bg-yellow-500/10 text-yellow-300':'border-emerald-500/40 bg-emerald-500/10 text-emerald-300'}`}>{actionItemCount?`미처리 ${actionItemCount}건`:'처리할 항목 없음'}</div>
            </div>

            {actionItemCount===0&&<div className="rounded-xl border border-emerald-500/30 bg-emerald-500/5 p-8 text-center"><div className="text-lg font-black text-emerald-300">현재 처리할 일이 없습니다.</div><div className="mt-2 text-xs text-slate-400">새 요청이나 보안 문제가 발생하면 이 화면에 자동으로 표시됩니다.</div></div>}

            {pendingEnrollments>0&&<section className="rounded-xl border-2 border-blue-500/50 bg-slate-900 p-5"><div className="mb-4 flex items-start justify-between gap-3"><div><div className="text-sm font-black text-blue-200">장비 등록 승인</div><div className="mt-1 text-xs text-slate-400">새 Agent의 호스트명·사용자·IP·운영체제를 검토한 뒤 등록 여부를 결정합니다.</div></div><span className="rounded bg-blue-500 px-2 py-1 text-xs font-black text-white">{pendingEnrollments}건</span></div><div className="space-y-3">{(agents?.enrollments||[]).filter((e:any)=>e.status==='pending').map((e:any)=><div key={e.id} className="flex flex-wrap items-center gap-3 rounded-lg border border-blue-400/30 bg-slate-950 p-4 text-xs"><div className="min-w-56 flex-1"><div className="font-black text-blue-200">{e.hostname}</div><div className="mt-1 text-slate-400">사용자 {e.username||'-'} · IP {e.remote_ip||'-'} · {e.os_version||'OS 미확인'}</div><div className="mt-1 text-slate-600">요청 {formatDistanceToNow(new Date(e.created_at),{addSuffix:true,locale:ko})}</div></div><div className="flex gap-2"><button onClick={()=>decideEnrollment(e.id,'approve')} className="min-h-10 rounded-lg border border-blue-300 bg-blue-500 px-4 font-black text-white">장비 등록 승인</button><button onClick={()=>decideEnrollment(e.id,'reject')} className="min-h-10 rounded-lg border border-red-500/40 bg-red-500/10 px-4 font-bold text-red-300">등록 거부</button></div></div>)}</div><button onClick={openEnrollmentRequests} className="mt-4 text-xs font-bold text-blue-300 hover:text-blue-200">등록 이력과 전체 장비 보기 →</button></section>}
            {pendingRemovals>0&&<section className="rounded-xl border-2 border-amber-500/50 bg-slate-900 p-5"><div className="mb-4 flex items-start justify-between gap-3"><div><div className="text-sm font-black text-amber-200">에이전트 제거 승인</div><div className="mt-1 text-xs text-slate-400">장비에서 에이전트 제거를 요청했습니다. 승인해야 해당 장비에서 제거가 진행되고 관리 대상에서 해제됩니다.</div></div><span className="rounded bg-amber-500 px-2 py-1 text-xs font-black text-white">{pendingRemovals}건</span></div><div className="space-y-3">{(agents?.removal_requests||[]).filter((e:any)=>e.status==='pending').map((e:any)=><div key={e.id} className="flex flex-wrap items-center gap-3 rounded-lg border border-amber-400/30 bg-slate-950 p-4 text-xs"><div className="min-w-56 flex-1"><div className="font-black text-amber-200">{e.hostname}</div><div className="mt-1 text-slate-400">사용자 {e.username||'-'} · IP {e.remote_ip||'-'} · {e.os_version||'OS 미확인'}</div>{e.reason&&<div className="mt-1 text-slate-400">사유: {e.reason}</div>}<div className="mt-1 text-slate-600">요청 {formatDistanceToNow(new Date(e.created_at),{addSuffix:true,locale:ko})}</div></div><div className="flex gap-2"><button onClick={()=>decideRemoval(e.id,'approve')} className="min-h-10 rounded-lg border border-amber-300 bg-amber-500 px-4 font-black text-white">제거 승인</button><button onClick={()=>decideRemoval(e.id,'reject')} className="min-h-10 rounded-lg border border-red-500/40 bg-red-500/10 px-4 font-bold text-red-300">제거 거부</button></div></div>)}</div></section>}

            {pendingApprovals>0&&<section className="rounded-xl border-2 border-yellow-500/40 bg-slate-900 p-5"><div className="mb-4 flex items-start justify-between gap-3"><div><div className="text-sm font-black text-yellow-200">보안 검토 필요</div><div className="mt-1 text-xs text-slate-400">정책에 의해 일시 중단된 실행입니다. 요청 사유와 명령을 확인한 뒤 이번 한 번만 예외 허용하거나 차단을 유지하십시오.</div></div><span className="rounded bg-yellow-500 px-2 py-1 text-xs font-black text-slate-950">{pendingApprovals}건</span></div><div className="space-y-3">{(controls?.approvals||[]).filter((a:any)=>a.status==='pending').map((a:any)=><div key={a.id} className="flex flex-wrap items-center gap-3 rounded-lg border border-yellow-500/30 bg-slate-950 p-4 text-xs"><div className="min-w-56 flex-1"><div><span className="font-black text-yellow-200">{a.tool}</span><span className="ml-2 text-blue-300">{a.hostname}</span><span className="ml-2 text-slate-300">{a.username}</span></div><div className="mt-1 text-slate-500">{a.work_dir||'실행 경로 미확인'} {a.args||''}</div><div className="mt-1 text-slate-600">요청 {formatDistanceToNow(new Date(a.created_at),{addSuffix:true,locale:ko})}</div></div><div className="flex gap-2"><button onClick={()=>reviewApproval(a.id,true)} className="min-h-10 rounded-lg border border-emerald-500/50 bg-emerald-500/15 px-4 font-black text-emerald-300">이번 실행 예외 허용</button><button onClick={()=>reviewApproval(a.id,false)} className="min-h-10 rounded-lg border border-red-500/40 bg-red-500/10 px-4 font-bold text-red-300">차단 유지</button></div></div>)}</div><button onClick={()=>openControl('approvals')} className="mt-4 text-xs font-bold text-yellow-300 hover:text-yellow-200">처리 이력 보기 →</button></section>}

            {highRiskAlerts.length>0&&<section className="rounded-xl border-2 border-red-500/40 bg-slate-900 p-5"><div className="mb-4 flex items-start justify-between gap-3"><div><div className="text-sm font-black text-red-200">미해결 고위험 문제</div><div className="mt-1 text-xs text-slate-400">원인과 탐지 근거를 확인하고 위험 알림 화면에서 해결 처리합니다.</div></div><span className="rounded bg-red-500 px-2 py-1 text-xs font-black text-white">{highRiskAlerts.length}건</span></div><div className="space-y-2">{highRiskAlerts.slice(0,10).map((a:any)=><button key={a.id} onClick={openAlerts} className="w-full rounded-lg border border-red-500/25 bg-slate-950 p-3 text-left text-xs hover:bg-red-500/5"><span className="font-black text-red-300">{a.alert_type}</span><span className="ml-2 text-blue-300">{a.hostname}</span><span className="ml-2 text-slate-400">{a.username}</span><div className="mt-1 truncate text-slate-500">{a.risk_reason||a.detail||'상세 정보 없음'}</div></button>)}</div><button onClick={openAlerts} className="mt-4 text-xs font-bold text-red-300 hover:text-red-200">위험 검토·해결 화면 열기 →</button></section>}

            {licenseNeedsAction&&<section className="rounded-xl border-2 border-orange-500/40 bg-slate-900 p-5"><div className="flex flex-wrap items-center gap-3"><div className="flex-1"><div className="text-sm font-black text-orange-200">라이선스 확인 필요</div><div className="mt-1 text-xs text-slate-400">{license?.active?`만료까지 ${license.days_remaining}일 남았습니다.`:`제품 기능이 잠겼습니다: ${license?.reason||'라이선스 비활성'}`}</div></div><button onClick={()=>setTab('license')} className="min-h-10 rounded-lg border border-orange-500/50 bg-orange-500/10 px-4 text-xs font-black text-orange-300">라이선스 관리 열기</button></div></section>}
          </div>
        )}

        {/* 비용·사용량 분석 */}
        {tab === 'analytics' && analytics && (
          <div className="space-y-6">
            <div>
              <div className="text-xl font-semibold">사용량·비용</div>
              <div className="text-xs text-slate-500 mt-1">API 종량제 실사용 비용과 구독형 월 고정 비용을 분리해 표시합니다.</div>
            </div>
            <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
              {[
                ['총 실행', Number(analytics.summary?.executions || 0).toLocaleString() + '회', 'text-emerald-400'],
                ['AI가 읽은 양 (입력 토큰)', Number(analytics.summary?.input_tokens || 0)>0?Number(analytics.summary.input_tokens).toLocaleString():'수집 불가', 'text-blue-400'],
                ['AI가 생성한 양 (출력 토큰)', Number(analytics.summary?.output_tokens || 0)>0?Number(analytics.summary.output_tokens).toLocaleString():'수집 불가', 'text-purple-400'],
                ['API 종량제 비용', '$' + Number(analytics.summary?.cost_usd || 0).toFixed(2), 'text-yellow-400'],
                ['구독 월 비용', (analytics.subscriptionTotals||[]).length?(analytics.subscriptionTotals||[]).map((x:any)=>x.currency==='KRW'?`₩${Number(x.monthly_total).toLocaleString()}`:`$${Number(x.monthly_total).toFixed(2)}`).join(' + '):'미등록', 'text-orange-400'],
              ].map(([label, value, color]) => <div key={label} className="bg-slate-900 border border-slate-800 rounded-lg p-4"><div className="text-xs text-slate-400">{label}</div><div className={`text-2xl font-bold mt-1 ${color}`}>{value}</div></div>)}
            </div>
            {Number(analytics.summary?.input_tokens || 0) + Number(analytics.summary?.output_tokens || 0) === 0 && (
              <div className="rounded-lg border border-blue-500/25 bg-blue-500/5 p-4 text-xs text-blue-300">현재 구독형 앱·CLI는 정확한 토큰값을 제공하지 않습니다. 토큰 0이 아니라 ‘수집 불가’이며, 월 구독료는 아래에서 별도로 등록합니다. API 응답에서 실제 사용량이 들어오면 API 비용에 자동 반영됩니다.</div>
            )}
            <div className="grid gap-6 lg:grid-cols-2"><div className="rounded-lg border border-slate-800 bg-slate-900 p-4"><div className="mb-3 text-sm font-bold">구독형 월 비용 등록</div><div className="grid grid-cols-2 gap-2"><input value={subscriptionForm.service_name} onChange={e=>setSubscriptionForm(f=>({...f,service_name:e.target.value,service_key:e.target.value.toLowerCase().replace(/[^a-z0-9]+/g,'-')}))} placeholder="서비스 (ChatGPT)" className="rounded border border-slate-700 bg-slate-800 px-3 py-2 text-xs"/><input value={subscriptionForm.plan_name} onChange={e=>setSubscriptionForm(f=>({...f,plan_name:e.target.value}))} placeholder="요금제 (Pro/Max)" className="rounded border border-slate-700 bg-slate-800 px-3 py-2 text-xs"/><input type="number" min="1" value={subscriptionForm.seats} onChange={e=>setSubscriptionForm(f=>({...f,seats:Number(e.target.value)}))} placeholder="좌석" className="rounded border border-slate-700 bg-slate-800 px-3 py-2 text-xs"/><div className="flex"><select value={subscriptionForm.currency} onChange={e=>setSubscriptionForm(f=>({...f,currency:e.target.value}))} className="rounded-l border border-slate-700 bg-slate-800 px-2 text-xs"><option>USD</option><option>KRW</option></select><input type="number" min="0" step="0.01" value={subscriptionForm.unit_price} onChange={e=>setSubscriptionForm(f=>({...f,unit_price:Number(e.target.value)}))} placeholder="월 단가" className="min-w-0 flex-1 rounded-r border border-l-0 border-slate-700 bg-slate-800 px-3 py-2 text-xs"/></div></div><button disabled={!['admin','security'].includes(currentUser?.role)} onClick={addSubscription} className="mt-3 w-full rounded border border-orange-500/40 bg-orange-500/10 py-2 text-xs font-bold text-orange-300 disabled:opacity-40">구독 비용 등록</button></div><div className="rounded-lg border border-slate-800 bg-slate-900 p-4"><div className="mb-3 text-sm font-bold">현재 구독</div>{(analytics.subscriptions||[]).length===0?<div className="text-xs text-slate-500">등록된 구독 없음</div>:<div className="space-y-2">{analytics.subscriptions.map((s:any)=><div key={s.id} className="flex items-center gap-2 rounded border border-slate-800 p-2 text-xs"><span className="font-bold">{s.service_name} {s.plan_name}</span><span className="text-slate-500">{s.seats}석 × {s.currency==='KRW'?'₩'+Number(s.unit_price).toLocaleString():'$'+Number(s.unit_price).toFixed(2)}</span><span className="ml-auto font-bold text-orange-300">{s.currency==='KRW'?'₩'+Number(s.seats*s.unit_price).toLocaleString():'$'+Number(s.seats*s.unit_price).toFixed(2)}/월</span>{['admin','security'].includes(currentUser?.role)&&<button onClick={()=>removeSubscription(s.id)} className="text-red-300">삭제</button>}</div>)}</div>}</div></div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6"><div className="bg-slate-900 border border-slate-800 rounded-lg p-4"><div className="text-sm font-semibold mb-3">서비스·사용자별 실행</div><div className="space-y-2">{(analytics.byUser||[]).map((row:any)=><div key={row.username} className="grid grid-cols-3 text-xs border-b border-slate-800 pb-2"><span>{row.username}</span><span className="text-slate-400 text-right">{row.executions}회</span><span className="text-slate-500 text-right">{Number(row.tokens)>0?Number(row.tokens).toLocaleString()+' tokens':'토큰 미수집'}</span></div>)}</div></div><div className="bg-slate-900 border border-slate-800 rounded-lg p-4"><div className="text-sm font-semibold">API 실제 모델별 사용</div><div className="mb-3 mt-1 text-[11px] text-slate-500">API 응답에서 모델 ID와 토큰이 확인된 기록만 표시합니다.</div>{(analytics.byModel||[]).length===0?<div className="rounded border border-slate-700 bg-slate-800/60 p-4 text-xs text-slate-300">확인된 API 모델 사용 기록이 없습니다.<div className="mt-2 text-slate-500">모델 미확인 실행: {Number(analytics.unknownModelExecutions||0).toLocaleString()}회 · 구독형 앱·CLI 실행은 여기에 포함되지 않습니다.</div></div>:<div className="space-y-2">{analytics.byModel.map((row:any)=><div key={row.model} className="grid grid-cols-3 border-b border-slate-800 pb-2 text-xs"><span>{row.model}</span><span className="text-right text-slate-400">{row.executions}회 · {Number(row.tokens).toLocaleString()} tokens</span><span className="text-right text-yellow-400">${Number(row.cost_usd).toFixed(4)}</span></div>)}</div>}</div></div>
          </div>
        )}

        {/* 장비·사용자 */}
        {tab === 'agents' && agents && (
          <div className="space-y-6">
            <div><div className="text-xl font-semibold">장비·사용자와 미승인 AI</div><div className="text-xs text-slate-500 mt-1">Windows·macOS·Linux 장비, 사용자, 허용되지 않은 AI 실행을 확인합니다.</div></div>
            <div className="grid grid-cols-3 gap-4">
              {[['등록 에이전트',agents.summary?.agents||0,'text-blue-400'],['온라인',agents.summary?.online||0,'text-emerald-400'],['미해결 Shadow AI',(agents.events||[]).filter((e:any)=>!e.resolved).length,'text-red-400']].map(([label,value,color]:any)=><div key={label} className="bg-slate-900 border border-slate-800 rounded-lg p-4"><div className="text-xs text-slate-400">{label}</div><div className={`text-2xl font-bold mt-1 ${color}`}>{value}</div></div>)}
            </div>
            <div id="agent-enrollment-requests" className="scroll-mt-28 rounded-lg border-2 border-blue-500/50 bg-slate-900 p-4 shadow-lg shadow-blue-500/5"><div className="mb-1 text-sm font-black text-blue-200">관리자 조치 · 신규 Agent 장비 등록</div><div className="mb-3 text-[11px] text-slate-400">알림에서 이동한 실제 승인 화면입니다. 호스트명·사용자·IP·운영체제를 검토한 뒤 아래의 장비 등록 승인 또는 등록 거부를 선택하세요. AI 사용 승인은 Client 목록에서 별도로 처리합니다.</div><div className="space-y-2">{(agents.enrollments||[]).length===0?<div className="text-xs text-slate-600">최근 장비 등록 요청 없음</div>:(agents.enrollments||[]).map((e:any)=><div key={e.id} className={`flex flex-wrap items-center gap-3 rounded border p-3 text-xs ${e.status==='pending'?'border-blue-400 bg-blue-500/10':e.status==='claimed'?'border-emerald-500/30 bg-emerald-500/5':'border-slate-700 bg-slate-800/40'}`}><span className="rounded bg-slate-700 px-2 py-1 font-black text-slate-200">요청 정보</span><span className="font-semibold text-blue-300">{e.hostname}</span><span>{e.username}</span><span className="text-slate-500">{e.remote_ip} · {e.os_version}</span><span className={`rounded px-2 py-1 font-bold ${e.status==='pending'?'bg-blue-500/20 text-blue-200':e.status==='claimed'?'bg-emerald-500/15 text-emerald-300':e.status==='approved'?'bg-yellow-500/15 text-yellow-300':e.status==='rejected'?'bg-red-500/15 text-red-300':'bg-slate-700 text-slate-300'}`}>{e.status==='pending'?'관리자 결정 대기':e.status==='claimed'?'장비 등록 완료 · 키 수령':e.status==='approved'?'장비 승인 완료 · Agent 수령 대기':e.status==='rejected'?'장비 등록 거부':e.status==='revoked'?'장비 관리 해제':e.status}</span><span className="ml-auto text-slate-500">{formatDistanceToNow(new Date(e.created_at),{addSuffix:true,locale:ko})}</span>{e.status==='pending'&&<div className="flex items-center gap-2 rounded border border-blue-400/30 bg-slate-950 p-2"><span className="font-black text-blue-200">관리자 조치</span><button onClick={()=>decideEnrollment(e.id,'approve')} className="rounded border border-blue-400 bg-blue-500 px-4 py-2 font-black text-white shadow">장비 등록 승인</button><button onClick={()=>decideEnrollment(e.id,'reject')} className="rounded border border-red-500/40 bg-red-500/10 px-3 py-2 font-bold text-red-300">등록 거부</button></div>}</div>)}</div>
              <div className="mt-4 border-t border-slate-800 pt-3"><div className="mb-1 text-sm font-black text-amber-200">관리자 조치 · 에이전트 제거 요청</div><div className="mb-3 text-[11px] text-slate-400">장비에서 제거를 요청하면 여기에 표시됩니다. 승인해야 해당 장비에서 제거가 진행되고 관리 대상·인증 키가 해제됩니다.</div><div className="space-y-2">{(agents.removal_requests||[]).length===0?<div className="text-xs text-slate-600">최근 제거 요청 없음</div>:(agents.removal_requests||[]).map((e:any)=><div key={e.id} className={`flex flex-wrap items-center gap-3 rounded border p-3 text-xs ${e.status==='pending'?'border-amber-400 bg-amber-500/10':e.status==='completed'?'border-emerald-500/30 bg-emerald-500/5':'border-slate-700 bg-slate-800/40'}`}><span className="rounded bg-slate-700 px-2 py-1 font-black text-slate-200">제거 요청</span><span className="font-semibold text-amber-300">{e.hostname}</span><span>{e.username}</span><span className="text-slate-500">{e.remote_ip} · {e.os_version}</span><span className={`rounded px-2 py-1 font-bold ${e.status==='pending'?'bg-amber-500/20 text-amber-200':e.status==='approved'?'bg-yellow-500/15 text-yellow-300':e.status==='completed'?'bg-emerald-500/15 text-emerald-300':e.status==='rejected'?'bg-red-500/15 text-red-300':'bg-slate-700 text-slate-300'}`}>{e.status==='pending'?'관리자 결정 대기':e.status==='approved'?'승인 완료 · 제거 진행 대기':e.status==='completed'?'제거 완료':e.status==='rejected'?'제거 거부':e.status==='expired'?'만료':e.status}</span>{e.decided_by&&<span className="text-slate-500">결정 {e.decided_by}</span>}<span className="ml-auto text-slate-500">{formatDistanceToNow(new Date(e.created_at),{addSuffix:true,locale:ko})}</span>{e.status==='pending'&&<div className="flex items-center gap-2 rounded border border-amber-400/30 bg-slate-950 p-2"><span className="font-black text-amber-200">관리자 조치</span><button onClick={()=>decideRemoval(e.id,'approve')} className="rounded border border-amber-400 bg-amber-500 px-4 py-2 font-black text-white shadow">제거 승인</button><button onClick={()=>decideRemoval(e.id,'reject')} className="rounded border border-red-500/40 bg-red-500/10 px-3 py-2 font-bold text-red-300">제거 거부</button></div>}</div>)}</div></div>
            </div>
            <div className="grid gap-4 xl:grid-cols-3 xl:items-start">
              {/* ── 왼쪽: Client 목록 ── */}
              <section className="rounded-lg border border-slate-800 bg-slate-900 p-4">
                <div className="mb-3">
                  <div className="text-sm font-semibold">Client 목록</div>
                  <div className="mt-1 text-xs text-slate-500">전체 {allAgentRows.length}대 · 검색 결과 {filteredAgentRows.length}대 · Agent 최신 {allAgentRows.length-outdatedAgentCount}대 · 업데이트 필요 {outdatedAgentCount}대</div>
                </div>
                <div className="mb-3 flex flex-wrap gap-2">
                  <input value={agentSearch} onChange={e=>setAgentSearch(e.target.value)} placeholder="PC명·사용자·OS·AI 검색" className="min-h-10 w-full rounded border border-slate-700 bg-slate-800 px-3 text-xs"/>
                  <select value={agentStatus} onChange={e=>setAgentStatus(e.target.value as typeof agentStatus)} className="min-h-10 rounded border border-slate-700 bg-slate-800 px-3 text-xs"><option value="all">전체 상태</option><option value="online">온라인</option><option value="offline">오프라인</option></select>
                  <select value={agentSort} onChange={e=>setAgentSort(e.target.value as typeof agentSort)} aria-label="Client 정렬" className="min-h-10 rounded border border-slate-700 bg-slate-800 px-3 text-xs"><option value="running">실행 중 AI 많은 순</option><option value="online">온라인 우선</option><option value="recent">최근 통신 순</option><option value="hostname">Client 이름 순</option></select>
                  <select value={agentPageSize} onChange={e=>setAgentPageSize(Number(e.target.value))} className="min-h-10 rounded border border-slate-700 bg-slate-800 px-3 text-xs"><option value="10">10개씩</option><option value="50">50개씩</option><option value="100">100개씩</option></select>
                </div>
                {pagedAgentRows.length===0?<div className="rounded border border-slate-700 p-6 text-center text-xs text-slate-500">조건에 맞는 Client가 없습니다.</div>:compactAgentView?<div className="overflow-x-auto"><table className="w-full text-left text-xs"><thead><tr className="border-b border-slate-700"><th className="px-2 py-3">상태</th><th className="px-2 py-3">Client / 사용자</th><th className="px-2 py-3">Agent</th><th className="px-2 py-3">발견 AI</th><th className="px-2 py-3 text-right">마지막 통신</th></tr></thead><tbody>{pagedAgentRows.map((agent:any)=>{const online=agentOnline(agent);const detected=observedAgentTools(agent);return <tr key={agent.hostname} className="border-b border-slate-800 hover:bg-slate-800"><td className="px-2 py-3"><span className={`inline-flex items-center gap-1 font-bold ${online?'text-emerald-400':'text-slate-500'}`}><span className={`h-2 w-2 rounded-full ${online?'bg-emerald-400':'bg-slate-600'}`}/>{online?'온':'오프'}</span></td><td className="px-2 py-3"><div className="font-bold">{agent.hostname}</div><div className="text-slate-500">{agent.username||'-'} · 실행 {agentRunningCount(agent)}개</div></td><td className="px-2 py-3"><div className="font-bold">{agent.agent_version||'-'}</div><span className={`mt-1 inline-flex rounded px-1 py-0.5 text-[10px] font-black ${agentVersionLatest(agent)?'bg-emerald-500/20 text-emerald-200':'bg-amber-500/20 text-amber-200'}`}>{agentVersionLatest(agent)?'최신':'업데이트'}</span></td><td className="px-2 py-3"><AgentAiAccess agent={agent} tools={detected} canEdit={currentUser?.role!=="auditor"&&currentUser?.role!=="viewer"} onChange={setToolAccess}/></td><td className="px-2 py-3 text-right text-slate-500">{formatDistanceToNow(new Date(agent.last_seen),{addSuffix:true,locale:ko})}</td></tr>})}</tbody></table></div>:<div className="space-y-3">{pagedAgentRows.map((agent:any)=>{const online=agentOnline(agent);const detected=observedAgentTools(agent);return <div key={agent.hostname} className="rounded-lg border border-slate-800 bg-slate-900 p-3"><div className="mb-2 flex flex-wrap items-center gap-2 text-xs"><span className={`h-2 w-2 rounded-full ${online?'bg-emerald-400':'bg-slate-600'}`}/><span className="font-semibold">{agent.hostname}</span><span className={`rounded px-2 py-1 text-[10px] font-black ${agentVersionLatest(agent)?'bg-emerald-500/20 text-emerald-200':'bg-amber-500/20 text-amber-200'}`}>Agent {agent.agent_version||'-'}</span><span className="ml-auto text-slate-500">{formatDistanceToNow(new Date(agent.last_seen),{addSuffix:true,locale:ko})}</span></div><AgentAiAccess agent={agent} tools={detected} canEdit={currentUser?.role!=="auditor"&&currentUser?.role!=="viewer"} onChange={setToolAccess}/></div>})}</div>}
                <div className="mt-4 flex items-center justify-between text-xs"><span className="text-slate-500">{filteredAgentRows.length?`${(safeAgentPage-1)*agentPageSize+1}–${Math.min(safeAgentPage*agentPageSize,filteredAgentRows.length)} / ${filteredAgentRows.length}`:'0 / 0'}</span><div className="flex items-center gap-2"><button disabled={safeAgentPage<=1} onClick={()=>setAgentPage(p=>Math.max(1,p-1))} className="min-h-9 rounded border border-slate-700 px-3 disabled:opacity-30">이전</button><span className="min-w-16 text-center">{safeAgentPage} / {agentPageCount}</span><button disabled={safeAgentPage>=agentPageCount} onClick={()=>setAgentPage(p=>Math.min(agentPageCount,p+1))} className="min-h-9 rounded border border-slate-700 px-3 disabled:opacity-30">다음</button></div></div>
              </section>
              {/* ── 가운데: Shadow AI 이벤트 ── */}
              <section className="rounded-lg border border-slate-800 bg-slate-900 p-4">
                <div className="mb-1 flex items-center justify-between"><div className="text-sm font-semibold">Shadow AI 이벤트</div><span className="rounded bg-red-500/20 px-2 py-1 text-[10px] font-black text-red-200">미해결 {shadowEvents.filter((e:any)=>!e.resolved).length}</span></div>
                <div className="mb-3 text-xs text-slate-500">상태별 필터 후 이벤트를 선택하면 원인·권장 조치를 확인할 수 있습니다.</div>
                <div className="mb-3 flex flex-wrap items-center gap-1.5" aria-label="Shadow AI 이벤트 필터">
                  {([
                    ['all','전체'],
                    ['detected','확인 필요'],
                    ['blocked','차단'],
                    ['information','정보'],
                    ['error','오류'],
                    ['other','기타'],
                  ] as const).map(([key,label])=><button key={key} onClick={()=>{setShadowEventFilter(key);setShadowEventPage(1);}} aria-pressed={shadowEventFilter===key} className={`min-h-9 rounded-lg border px-2.5 text-xs font-bold ${shadowEventFilter===key?'border-emerald-400 bg-emerald-500/20 text-emerald-200':'border-slate-600 bg-slate-800 text-slate-300 hover:border-slate-400'}`}>{label} <span className="ml-0.5">{shadowEventCount(key)}</span></button>)}
                  <span className="ml-auto text-[10px] font-bold text-slate-400">{filteredShadowEvents.length}건</span>
                </div>
                <div className="space-y-2">
                  {filteredShadowEvents.length===0?<div className="rounded border border-slate-700 p-5 text-center text-xs text-slate-500">선택한 분류의 이벤트가 없습니다.</div>:pagedShadowEvents.map((e:any)=><details key={e.id} className={`group rounded border p-3 text-xs ${e.resolved?'border-slate-800 opacity-60':e.action_state==='blocked'?'border-orange-500/40 bg-orange-500/5':e.action_state==='detected'?'border-red-500/30 bg-red-500/5':e.action_state==='error'?'border-fuchsia-500/40 bg-fuchsia-500/5':e.action_state==='information'?'border-blue-500/30 bg-blue-500/5':'border-slate-600 bg-slate-800/40'}`}>
                    <summary className="flex cursor-pointer list-none flex-wrap items-center gap-2">
                      <span className={`shrink-0 rounded px-2 py-1 font-black ${e.action_state==='blocked'?'bg-orange-500/20 text-orange-300':e.action_state==='detected'?'bg-red-500/20 text-red-300':e.action_state==='error'?'bg-fuchsia-500/20 text-fuchsia-300':e.action_state==='information'?'bg-blue-500/20 text-blue-300':'bg-slate-700 text-slate-200'}`}>{e.action_state==='blocked'?'차단':e.action_state==='detected'?'확인 필요':e.action_state==='error'?'오류':e.action_state==='information'?'정보':'기타'}</span>
                      <span className={`font-bold ${e.action_state==='error'?'text-fuchsia-300':e.action_state==='blocked'?'text-orange-300':e.action_state==='information'?'text-blue-300':e.action_state==='other'?'text-slate-300':'text-red-400'}`}>{e.event_label||e.event_type}</span>
                      <span className="font-bold text-yellow-300">{e.tool}</span>
                      <span className="ml-auto shrink-0 text-right text-slate-500">{format(new Date(e.created_at),'MM-dd HH:mm')} ▾</span>
                      <span className="w-full text-slate-400">{e.hostname} / {e.username}</span>
                    </summary>
                    <div className="mt-3 grid gap-3 border-t border-slate-700 pt-3 lg:grid-cols-3"><div className="rounded border border-slate-700 bg-slate-800 p-3"><div className="mb-1 font-black">발생 의미</div><div className="text-slate-300">{e.meaning}</div></div><div className="rounded border border-slate-700 bg-slate-800 p-3"><div className="mb-1 font-black">가능한 원인</div><div className="text-slate-300">{e.cause}</div></div><div className="rounded border border-blue-500/40 bg-blue-500/5 p-3"><div className="mb-1 font-black text-blue-300">권장 조치</div><div className="text-slate-300">{e.recommendation}</div></div></div>
                    <div className="mt-3 grid gap-2 rounded border-2 border-blue-500/50 p-4"><div><span className="font-black text-blue-300">발생 위치: </span><span>{e.occurrence}</span></div><div><span className="font-black text-blue-300">현재 조치: </span><span>{e.current_action}</span></div><div><span className="font-black text-blue-300">처리 방법: </span><span>{e.resolution}</span></div><div className="mt-2 flex flex-wrap gap-2"><button onClick={()=>{setAgentSearch(e.hostname||"");setAgentStatus("all");setAgentPage(1);window.scrollTo({top:0,behavior:"smooth"})}} className="min-h-10 rounded border border-blue-500/50 px-4 font-bold text-blue-300">해당 Client 보기</button><button onClick={()=>openControl("blocks")} className="min-h-10 rounded border border-orange-500/50 px-4 font-bold text-orange-300">차단 관리 열기</button></div></div>
                    {e.encoding_warning&&<div className="mt-2 rounded border border-yellow-500/40 p-2 text-yellow-300">표시 보정: {e.encoding_warning}</div>}
                    <div className="mt-3 flex items-center justify-between"><span className="text-slate-500">원본 코드: {e.event_type}</span>{!e.resolved&&<button onClick={()=>resolveShadowEvent(e.id)} className="min-h-9 rounded border border-emerald-500/40 px-4 font-bold text-emerald-400">확인 후 해결 처리</button>}</div>
                  </details>)}
                </div>
                {filteredShadowEvents.length>shadowPageSize&&<div className="mt-3 flex items-center justify-between text-xs"><span className="text-slate-500">{(safeShadowPage-1)*shadowPageSize+1}–{Math.min(safeShadowPage*shadowPageSize,filteredShadowEvents.length)} / {filteredShadowEvents.length}건</span><div className="flex items-center gap-2"><button disabled={safeShadowPage<=1} onClick={()=>setShadowEventPage(p=>Math.max(1,p-1))} className="min-h-9 rounded border border-slate-700 px-3 disabled:opacity-30">이전</button><span className="min-w-12 text-center">{safeShadowPage} / {shadowPageCount}</span><button disabled={safeShadowPage>=shadowPageCount} onClick={()=>setShadowEventPage(p=>Math.min(shadowPageCount,p+1))} className="min-h-9 rounded border border-slate-700 px-3 disabled:opacity-30">다음</button></div></div>}
              </section>
              {/* ── 오른쪽: 허용·차단 사용자 ── */}
              <section className="rounded-lg border border-emerald-500/30 bg-slate-900 p-4">
                <div className="text-sm font-black text-emerald-200">허용·차단 사용자</div>
                <div className="mt-1 text-[11px] text-slate-500">전체 AI 사용 차단 정책 기준</div>
                <div className="mt-3 space-y-3">
                  <div className="rounded border border-emerald-500/30 bg-emerald-500/5 p-3"><div className="mb-2 text-xs font-black text-emerald-300">허용된 사용자 {allowedAgentUsers.length}명</div><div className="max-h-64 space-y-1 overflow-y-auto">{allowedAgentUsers.length?allowedAgentUsers.map((item:any)=><div key={`${item.hostname}:${item.username}`} className="rounded bg-slate-800 p-2 text-xs"><b>{item.username}</b><span className="block text-[10px] text-slate-500">{item.hostname}</span></div>):<span className="text-xs text-slate-500">없음</span>}</div></div>
                  <div className="rounded border border-red-500/30 bg-red-500/5 p-3"><div className="mb-2 text-xs font-black text-red-300">차단된 사용자 {blockedAgentUsers.length}명</div><div className="max-h-64 space-y-1 overflow-y-auto">{blockedAgentUsers.length?blockedAgentUsers.map((item:any)=><div key={`${item.hostname}:${item.username}`} className="rounded bg-slate-800 p-2 text-xs"><b>{item.username}</b><span className="block text-[10px] text-slate-500">{item.hostname}</span></div>):<span className="text-xs text-slate-500">없음</span>}</div></div>
                </div>
                <button onClick={()=>openControl('blocks')} className="mt-3 w-full rounded border border-emerald-500/40 bg-emerald-500/10 px-3 py-2 text-xs font-black text-emerald-200">사용자 허용·차단 변경 →</button>
              </section>
            </div>
            <div className="rounded-lg border border-slate-800 bg-slate-900 p-4">
              <div className="text-sm font-semibold">관리 장비 및 사용자</div>
              <div className="mt-1 text-xs text-slate-500">장비 1대가 관리 가능 장비 수 1대를 사용합니다. 같은 장비의 사용자가 추가·변경되어도 사용 수량은 늘어나지 않습니다.</div>
              <div className="mt-4 overflow-x-auto"><table className="w-full min-w-[800px] text-left text-xs"><thead><tr className="border-b border-slate-700 text-slate-400"><th className="px-3 py-2">라이선스 사용 장비</th><th className="px-3 py-2">발견 사용자</th><th className="px-3 py-2">마지막 통신</th><th className="px-3 py-2 text-right">장비 관리</th></tr></thead><tbody>{allAgentRows.map((agent:any)=><tr key={agent.hostname} className="border-b border-slate-800"><td className="px-3 py-3"><div className="font-bold text-slate-100">{agent.hostname}</div><div className="text-slate-500">{agent.os} · {agent.last_ip||'-'}</div></td><td className="px-3 py-3"><div className="flex flex-wrap gap-1">{(agent.users||[]).length?(agent.users||[]).map((user:any)=><span key={user.username} className={`rounded border px-2 py-1 ${user.status==='active'?'border-emerald-500/30 bg-emerald-500/10 text-emerald-300':'border-slate-700 bg-slate-800 text-slate-500'}`}>{user.username} · {user.status==='active'?'사용 중':'사라짐'}</span>):<span className="text-slate-500">아직 사용자 목록 없음</span>}</div></td><td className="px-3 py-3 text-slate-400">{formatDistanceToNow(new Date(agent.last_seen),{addSuffix:true,locale:ko})}</td><td className="px-3 py-3 text-right"><div className="flex justify-end gap-2"><button disabled={!['admin','security'].includes(currentUser?.role)} onClick={()=>issueRemovalToken(agent.hostname)} className="min-h-9 rounded border border-amber-500/40 bg-amber-500/10 px-3 font-bold text-amber-300 disabled:opacity-30">제거 토큰 발급</button><button disabled={!['admin','security'].includes(currentUser?.role)} onClick={()=>retireAgent(agent.hostname)} className="min-h-9 rounded border border-red-500/40 bg-red-500/10 px-3 font-bold text-red-300 disabled:opacity-30">관리 해제·라이선스 반환</button></div></td></tr>)}</tbody></table></div>
              {(agents.retired||[]).length>0&&<details className="mt-4 rounded border border-slate-700 bg-slate-800/40 p-3"><summary className="cursor-pointer text-xs font-bold text-slate-300">관리 해제된 장비 {(agents.retired||[]).length}대 · 감사 이력 보기</summary><div className="mt-3 space-y-2">{(agents.retired||[]).map((agent:any)=><div key={agent.hostname} className="flex flex-wrap items-center gap-3 border-t border-slate-700 pt-2 text-xs"><span className="font-bold text-slate-300">{agent.hostname}</span><span className="text-slate-500">{agent.os} · 마지막 통신 {formatDistanceToNow(new Date(agent.last_seen),{addSuffix:true,locale:ko})}</span><span className="ml-auto text-slate-500">{agent.retired_by||'-'} · {agent.retired_at?new Date(agent.retired_at).toLocaleString('ko-KR'):'-'}</span></div>)}</div></details>}
            </div>
          </div>
        )}

        {/* 주간 보고서 */}
        {tab === 'reports' && reports?.preview && (()=>{const r=reports.preview;return <div className="space-y-6">
          <div className="flex items-end justify-between"><div><div className="text-xl font-semibold">주간 운영·보안 보고서</div><div className="text-xs text-slate-500 mt-1">{r.periodStart} ~ {r.periodEnd} · 실시간 미리보기</div></div><button onClick={saveWeeklyReport} className="rounded border border-emerald-500/40 bg-emerald-500/10 px-4 py-2 text-xs text-emerald-300">초안 저장</button></div>
          <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">{[['실행',r.usage.executions,'text-blue-400'],['사용자',r.usage.users,'text-emerald-400'],['세션',r.sessions.total,'text-purple-400'],['Shadow AI',r.shadow.unresolved,'text-red-400'],['비용','$'+Number(r.usage.cost_usd).toFixed(2),'text-yellow-400']].map(([l,v,c]:any)=><div key={l} className="bg-slate-900 border border-slate-800 rounded-lg p-4"><div className="text-xs text-slate-400">{l}</div><div className={`text-2xl font-bold mt-1 ${c}`}>{v}</div></div>)}</div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6"><div className="bg-slate-900 border border-slate-800 rounded-lg p-4"><div className="text-sm font-semibold mb-3">보안 알림</div>{r.alerts.length===0?<div className="text-xs text-slate-500">이번 주 알림 없음</div>:r.alerts.map((a:any)=><div key={a.severity} className="flex justify-between border-b border-slate-800 py-2 text-xs"><span style={{color:SEV_COLOR[a.severity]}}>{a.severity}</span><span>{a.count}건 · 미해결 {a.unresolved}건</span></div>)}</div><div className="bg-slate-900 border border-slate-800 rounded-lg p-4"><div className="text-sm font-semibold mb-3">권장 조치</div>{r.recommendations.map((x:string,i:number)=><div key={i} className="border-b border-slate-800 py-2 text-xs text-slate-300">{i+1}. {x}</div>)}</div></div>
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-4"><div className="text-sm font-semibold mb-3">저장된 보고서</div>{(reports.reports||[]).length===0?<div className="text-xs text-slate-500">저장된 초안 없음</div>:(reports.reports||[]).map((x:any)=><div key={x.id} className="flex justify-between border-b border-slate-800 py-2 text-xs"><span>{x.title}</span><span className="text-slate-500">{x.delivery_status} · {format(new Date(x.created_at),'yyyy-MM-dd HH:mm')}</span></div>)}</div>
        </div>})()}

        {/* 세션 활동 */}
        {tab === 'sessions' && sessions && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                <div className="text-xs text-slate-400 mb-3">Top 사용자</div>
                {(sessions.topUsers ?? []).map((u: any, i: number) => (
                  <div key={i} className="flex justify-between text-xs py-1.5 border-b border-slate-800">
                    <span>{u.username}</span>
                    <span className="text-slate-400">{u.session_count}세션 / {Math.round((u.avg_duration ?? 0) / 60)}분 평균</span>
                  </div>
                ))}
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                <div className="text-xs text-slate-400 mb-3">Top 서버</div>
                {(sessions.topServers ?? []).map((s: any, i: number) => (
                  <div key={i} className="flex justify-between text-xs py-1.5 border-b border-slate-800">
                    <span className="text-blue-400">{s.hostname}</span>
                    <span className="text-slate-400">{s.session_count}세션 / {s.user_count}명</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
              <div className="text-xs text-slate-400 mb-3">세션 상세 로그</div>
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="text-slate-500 border-b border-slate-800">
                      <th className="text-left py-2 pr-4">시작</th>
                      <th className="text-left py-2 pr-4">서버</th>
                      <th className="text-left py-2 pr-4">사용자</th>
                      <th className="text-left py-2 pr-4">도구</th>
                      <th className="text-left py-2 pr-4">경로</th>
                      <th className="text-left py-2 pr-4">소요</th>
                      <th className="text-left py-2">변경</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(sessions.sessions ?? []).map((s: any, i: number) => (
                      <tr key={i} className="border-b border-slate-800/50 hover:bg-slate-800/30">
                        <td className="py-2 pr-4 text-emerald-400">{format(new Date(s.started_at), 'MM/dd HH:mm')}</td>
                        <td className="py-2 pr-4 text-blue-400">{s.hostname}</td>
                        <td className="py-2 pr-4">{s.username}</td>
                        <td className="py-2 pr-4" style={{ color: TOOL_COLOR[s.tool] ?? '#94a3b8' }}>{s.tool}</td>
                        <td className="py-2 pr-4 text-slate-400 max-w-[200px] truncate">{s.work_dir}</td>
                        <td className="py-2 pr-4 text-slate-400">{s.duration_sec ? `${Math.round(s.duration_sec / 60)}분` : '-'}</td>
                        <td className="py-2 text-slate-400">{s.files_changed || '-'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* 보안 알림 */}
        {tab === 'alerts' && alerts && (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-2 rounded-xl border border-slate-600 bg-slate-800 p-3 shadow-lg"><span className="mr-1 text-sm font-bold text-white">심각도 필터</span>{(['ALL','CRITICAL','HIGH','MED','LOW'] as const).map(sev=><button key={sev} onClick={()=>setAlertSeverityFilter(sev)} aria-pressed={alertSeverityFilter===sev} className={`min-h-10 rounded-lg border-2 px-4 text-sm font-extrabold tracking-wide ${sev==='ALL'?(alertSeverityFilter===sev?'border-white bg-white text-slate-950':'border-slate-500 bg-slate-700 text-white hover:border-white'):(alertSeverityFilter===sev?SEV_BADGE[sev]:'border-slate-500 bg-slate-900 text-slate-200 hover:border-slate-300')}`}>{sev==='ALL'?'전체':SEV_LABEL[sev]} <span className="ml-1">{sev==='ALL'?(alerts.alerts||[]).length:(alerts.alerts||[]).filter((a:any)=>a.severity===sev).length}</span></button>)}<span className="ml-auto text-sm font-bold text-white">표시 {visibleAlerts.length}건</span></div>
            <div className="grid grid-cols-3 gap-4">
              {['HIGH', 'MED', 'LOW'].map(sev => (
                <div key={sev} className="rounded-xl border border-slate-600 bg-slate-800 p-4 shadow-md">
                  <div className={`mb-2 inline-flex rounded-md border px-3 py-1 text-sm font-black ${SEV_BADGE[sev]}`}>{SEV_LABEL[sev]}</div>
                  <div className="text-3xl font-black text-white">{alerts.summary?.[sev.toLowerCase()] ?? 0}</div>
                </div>
              ))}
            </div>
            {['admin','security'].includes(currentUser?.role)&&<div className="flex flex-wrap items-center gap-2 rounded-lg border border-slate-800 bg-slate-900 p-3"><label className="flex min-h-9 cursor-pointer items-center gap-2 rounded px-2 text-xs text-slate-300 hover:bg-slate-800"><input type="checkbox" checked={visibleAlerts.length>0&&visibleAlerts.every((a:any)=>selectedAlertIds.includes(Number(a.id)))} onChange={toggleAllAlerts} className="h-4 w-4 accent-emerald-500"/>현재 필터 전체 선택</label><span className="text-xs text-slate-500">{selectedAlertIds.length}건 선택</span><button disabled={!selectedAlertIds.length} onClick={deleteSelectedAlerts} className="ml-auto min-h-9 rounded border border-red-500/40 bg-red-500/10 px-4 text-xs font-bold text-red-300 disabled:cursor-not-allowed disabled:opacity-40">선택 삭제</button></div>}
            <div className="space-y-3 rounded-xl border border-slate-600 bg-slate-800 p-4 shadow-lg">
              {visibleAlerts.map((a: any) => (
                <div key={a.id} className={`flex items-start gap-3 rounded-lg border p-4 ${a.resolved ? 'border-slate-600 bg-slate-900/60 opacity-60' : 'border-slate-500 bg-slate-900'}`}>
                  {['admin','security'].includes(currentUser?.role)&&<input type="checkbox" aria-label={`알림 ${a.id} 선택`} checked={selectedAlertIds.includes(Number(a.id))} onChange={()=>toggleAlertSelection(Number(a.id))} className="mt-0.5 h-4 w-4 shrink-0 accent-emerald-500"/>}
                  <div className="w-2 h-2 rounded-full mt-1 flex-shrink-0" style={{ background: SEV_COLOR[a.severity] }} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`rounded-md border px-2.5 py-1 text-xs font-black ${SEV_BADGE[a.severity]||'border-slate-300 bg-slate-200 text-slate-950'}`}>{SEV_LABEL[a.severity]||a.severity}</span>
                      <span className="rounded bg-slate-700 px-2 py-1 text-xs font-bold text-white">위험도 {a.risk_score ?? 0}점</span>
                      <span className="text-sm font-bold text-white">{a.alert_type}</span>
                      <span className="text-xs text-slate-300">{a.hostname} / {a.username}</span>
                      <span className="ml-auto text-xs text-slate-300">{formatDistanceToNow(new Date(a.created_at), { addSuffix: true, locale: ko })}</span>
                    </div>
                    <div className="text-sm leading-6 text-slate-100">{a.detail}</div>
                    {a.risk_reason && <div className="mt-1 text-xs text-slate-300">점수 근거: {a.risk_reason}</div>}
                    {a.auto_action === 'pause_requested' && <div className="mt-1 text-[10px] text-yellow-400">자동 조치: 세션 일시정지 및 관리자 승인 요청</div>}
                  </div>
                  {!a.resolved && (
                    <button onClick={() => resolveAlert(a.id)} className="text-xs text-emerald-400 hover:text-emerald-300">해결</button>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 에이전트 제어 */}
        {tab === 'control' && (
          <div className="space-y-4">
            {formMsg && <div className="bg-slate-800 border border-slate-700 rounded px-4 py-2 text-sm">{formMsg}</div>}

            <div className="dashboard-nav flex flex-wrap gap-2 rounded-xl border border-slate-800 bg-slate-900/60 p-2">
              {([
                { key: 'blocks', label: '🚫 차단 관리' },
                { key: 'policies', label: '📋 사용 정책' },
                { key: 'approvals', label: `✅ 보안 검토 요청${pendingApprovals > 0 ? ` (${pendingApprovals})` : ''}` },
                { key: 'active', label: '🔴 활성 세션' },
              ] as { key: ControlTab; label: string }[]).map(({ key, label }) => (
                <button key={key} onClick={() => setControlTab(key)} aria-pressed={controlTab === key}
                  className={`min-h-11 rounded-lg border px-4 py-2 text-xs font-bold transition-all ${controlTab === key ? 'border-emerald-400 bg-emerald-500/20 text-emerald-200 shadow-[inset_0_-3px_0_#34d399]' : 'border-transparent text-slate-300 hover:border-slate-600 hover:bg-slate-800 hover:text-white'}`}>
                  {label}
                </button>
              ))}
            </div>

            {/* 차단 관리 */}
            {controlTab === 'blocks' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                  <div className="text-xs text-slate-400 mb-3">새 차단 등록</div>
                  <div className="space-y-2">
                    <div className="rounded-lg border border-slate-700 bg-slate-800 p-2">
                      <div className="mb-2 text-[11px] font-bold text-slate-300">1. Client 선택</div>
                      <input placeholder="호스트명 또는 IP 검색" value={blockClientSearch} onChange={e=>setBlockClientSearch(e.target.value)} className="w-full rounded border border-slate-600 bg-slate-900 px-3 py-2 text-xs text-white placeholder-slate-500 focus:border-emerald-500 focus:outline-none" />
                      <div className="mt-2 max-h-44 space-y-1 overflow-y-auto">
                        <button onClick={()=>chooseBlockTarget('*')} className={`w-full rounded px-3 py-2 text-left text-xs ${blockForm.hostname==='*'?'bg-red-500/20 text-red-200':'hover:bg-slate-700'}`}>전체 Client</button>
                        {filteredBlockTargets.map((target:any)=><button key={target.hostname} onClick={()=>chooseBlockTarget(target.hostname)} className={`w-full rounded px-3 py-2 text-left text-xs ${blockForm.hostname===target.hostname?'bg-emerald-500/20 text-emerald-200':'text-slate-300 hover:bg-slate-700'}`}><span className="font-bold">{target.hostname}</span><span className="ml-2 text-slate-500">{(target.ips||[]).join(', ')||'IP 미확인'}</span><span className="block text-[10px] text-slate-500">{target.os||''} {target.os_version||''} · 확인 사용자 {(target.users||[]).length}명</span></button>)}
                        {filteredBlockTargets.length===0&&<div className="px-2 py-3 text-xs text-yellow-300">일치하는 등록 Agent가 없습니다.</div>}
                      </div>
                      <div className="mt-2 text-[11px] text-emerald-300">선택됨: {blockForm.hostname==='*'?'전체 Client':blockForm.hostname}</div>
                    </div>
                    <div className="rounded-lg border border-slate-700 bg-slate-800 p-2">
                      <div className="mb-2 text-[11px] font-bold text-slate-300">2. 사용자 선택 · 복수 선택 가능</div>
                      <input placeholder="사용자명 검색" value={blockUserSearch} onChange={e=>setBlockUserSearch(e.target.value)} className="w-full rounded border border-slate-600 bg-slate-900 px-3 py-2 text-xs text-white placeholder-slate-500 focus:border-emerald-500 focus:outline-none" />
                      <div className="mt-2 max-h-40 space-y-1 overflow-y-auto">
                        <button onClick={()=>toggleBlockUsername('*')} className={`w-full rounded px-3 py-2 text-left text-xs ${blockUsernames.includes('*')?'bg-red-500/20 text-red-200':'hover:bg-slate-700'}`}>{blockForm.hostname==='*'?'모든 Client의 전체 사용자':'이 Client의 전체 사용자'}</button>
                        {filteredBlockUsers.map((username:string)=><button key={username} onClick={()=>toggleBlockUsername(username)} className={`w-full rounded px-3 py-2 text-left text-xs ${blockUsernames.includes(username)?'bg-emerald-500/20 text-emerald-200':'text-slate-300 hover:bg-slate-700'}`}>{username}{blockForm.hostname==='*'&&<span className="ml-2 text-[10px] text-slate-500">모든 Client에서 적용</span>}</button>)}
                        {blockUserSearch.trim()&&!availableBlockUsers.some((username:string)=>username.toLowerCase()===blockUserSearch.trim().toLowerCase())&&<button onClick={()=>{toggleBlockUsername(blockUserSearch.trim());setBlockUserSearch('')}} className="w-full rounded border border-blue-500/30 px-3 py-2 text-left text-xs text-blue-300">‘{blockUserSearch.trim()}’ 사용자 직접 추가</button>}
                      </div>
                      <div className="mt-2 flex flex-wrap gap-1">{blockUsernames.map(username=><span key={username} className="rounded bg-emerald-500/15 px-2 py-1 text-[10px] text-emerald-300">{username==='*'?'전체 사용자':username}</span>)}</div>
                    </div>
                    <div className="rounded-lg border border-slate-700 bg-slate-800 p-2">
                      <div className="mb-2 text-[11px] font-bold text-slate-300">3. 차단할 AI 선택</div>
                      <input placeholder="AI 이름 검색 (예: Copilot, ChatGPT, Gemini)" value={blockToolSearch}
                        onChange={e=>setBlockToolSearch(e.target.value)} className="w-full rounded border border-slate-600 bg-slate-900 px-3 py-2 text-xs text-white placeholder-slate-500 focus:border-emerald-500 focus:outline-none" />
                      <div className="mt-2 max-h-48 space-y-1 overflow-y-auto">
                        <button onClick={()=>{setBlockForm(f=>({...f,tool:'*'}));setBlockToolSearch('전체 AI')}} className={`w-full rounded px-3 py-2 text-left text-xs ${blockForm.tool==='*'?'bg-red-500/20 text-red-200':'hover:bg-slate-700'}`}>전체 AI 도구 차단</button>
                        {filteredAiCatalog.map((tool:any)=><button key={tool.key} onClick={()=>{setBlockForm(f=>({...f,tool:tool.key}));setBlockToolSearch(tool.name)}} className={`w-full rounded px-3 py-2 text-left text-xs ${blockForm.tool===tool.key?'bg-emerald-500/20 text-emerald-200':'text-slate-300 hover:bg-slate-700'}`}><span className="font-bold">{tool.name}</span><span className="ml-2 text-slate-500">{tool.key}</span></button>)}
                        {filteredAiCatalog.length===0&&<div className="px-2 py-3 text-xs text-yellow-300">검색 결과가 없습니다. 아래에서 사용자 정의 AI를 등록하세요.</div>}
                      </div>
                      <div className="mt-2 text-[11px] text-emerald-300">선택됨: {blockForm.tool}</div>
                    </div>
                    <details className="rounded-lg border border-slate-700 bg-slate-800 p-3">
                      <summary className="text-xs font-bold text-blue-300">목록에 없는 AI 직접 등록</summary>
                      <div className="mt-3 grid grid-cols-2 gap-2">
                        <input placeholder="식별자 (예: new-ai)" value={customAiForm.key} onChange={e=>setCustomAiForm(f=>({...f,key:e.target.value}))} className="rounded border border-slate-600 bg-slate-900 px-2 py-2 text-xs" />
                        <input placeholder="표시 이름" value={customAiForm.name} onChange={e=>setCustomAiForm(f=>({...f,name:e.target.value}))} className="rounded border border-slate-600 bg-slate-900 px-2 py-2 text-xs" />
                        <input placeholder="프로세스명 (선택)" value={customAiForm.process} onChange={e=>setCustomAiForm(f=>({...f,process:e.target.value}))} className="rounded border border-slate-600 bg-slate-900 px-2 py-2 text-xs" />
                        <input placeholder="도메인 (선택)" value={customAiForm.domain} onChange={e=>setCustomAiForm(f=>({...f,domain:e.target.value}))} className="rounded border border-slate-600 bg-slate-900 px-2 py-2 text-xs" />
                      </div>
                      <button onClick={addCustomAi} className="mt-2 w-full rounded border border-blue-500/40 bg-blue-500/15 px-3 py-2 text-xs font-bold text-blue-300">AI 식별 규칙 추가</button>
                    </details>
                    <input placeholder="차단 사유" value={blockForm.reason}
                      onChange={e => setBlockForm(f => ({ ...f, reason: e.target.value }))}
                      className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500" />
                    <button onClick={addBlock}
                      className="w-full bg-red-500/20 hover:bg-red-500/30 border border-red-500/40 text-red-400 rounded px-3 py-2 text-xs transition-colors">
                      차단 등록{blockUsernames.includes('*')?'':` (${blockUsernames.length}명)`}
                    </button>
                  </div>
                </div>
                <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                  <div className="text-xs text-slate-400 mb-3">현재 차단 목록</div>
                  {(controls?.blocks ?? []).length === 0 ? (
                    <div className="text-xs text-slate-600">등록된 차단 없음</div>
                  ) : (
                    <div className="space-y-2">
                      {controls.blocks.map((b: any) => (
                        <div key={b.id} className="flex items-center gap-2 text-xs p-2 bg-slate-800 rounded">
                          <div className="flex-1">
                            <span className="text-red-400">{b.hostname || '*'}</span>
                            <span className="text-slate-500 mx-1">/</span>
                            <span className="text-white">{b.username || '*'}</span>
                            <span className="text-slate-500 mx-1">/</span>
                            <span style={{ color: TOOL_COLOR[b.tool] ?? '#94a3b8' }}>{b.tool}</span>
                            {b.reason && <div className="text-slate-500 mt-0.5">{b.reason}</div>}
                          </div>
                          <button onClick={() => removeBlock(b.id)} className="text-slate-500 hover:text-red-400">✕</button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* 정책 설정 */}
            {controlTab === 'policies' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                  <div className="text-sm font-bold">AI 사용 범위 정하기</div>
                  <div className="mt-1 text-xs text-slate-400">누가 어떤 장비에서 어떤 AI를 언제, 몇 번 실행할 수 있는지 정합니다.</div>
                  <div className="mt-3 rounded-lg border border-blue-500/40 bg-blue-500/10 p-3 text-xs text-blue-100">
                    <div className="font-black">여기에서 정하는 내용</div>
                    <div className="mt-1">사용 가능한 시간, 한 시간 동안 사용할 횟수, 매번 관리자 확인 여부를 정합니다.</div>
                    <div className="mt-2 text-blue-200">같은 사용자에게 여러 설정이 있으면 특정 장비와 특정 AI를 선택한 설정이 먼저 적용됩니다.</div>
                  </div>
                  <div className="mt-3 rounded-lg border border-amber-500/40 bg-amber-500/10 p-3 text-xs text-amber-100">
                    <div className="font-black">개인정보·회사 기밀을 막는 정책은 별도입니다.</div>
                    <div className="mt-1">주민번호·계좌·카드·비밀번호·API 키·내부 문서는 이 화면이 아니라 정보 보호 정책에서 분류하고 차단합니다.</div>
                    <button onClick={()=>setTab('protection')} className="mt-2 rounded border border-amber-300 px-3 py-2 font-bold text-amber-100">보호할 문구 입력 →</button>
                  </div>
                  <div className="mt-4 space-y-3">
                    <label className="block">1. 원하는 사용 방법<select value={policyForm.template_key} onChange={e => selectTemplate(e.target.value)} className="mt-1 w-full rounded border border-slate-700 bg-slate-800 px-3 py-2 text-xs text-white">
                      <option value="">시간과 횟수를 직접 정하기</option>
                      {(governance?.templates || []).map((t: any) => <option key={t.template_key} value={t.template_key}>{t.name} — {t.description}</option>)}
                    </select></label>
                    {selectedPolicyTemplate&&<div className="rounded border border-emerald-500/30 bg-emerald-500/10 p-3 text-xs"><div className="font-black text-emerald-200">{selectedPolicyTemplate.name}</div><div className="mt-1 text-slate-300">{selectedPolicyTemplate.description}</div></div>}
                    <div className="grid gap-2 md:grid-cols-2">
                      <label>2. 어느 장비에 적용할까요?<input placeholder="비우면 전체 장비" value={policyForm.hostname} onChange={e => setPolicyForm(f => ({ ...f, hostname: e.target.value }))} className="mt-1 w-full rounded border border-slate-700 bg-slate-800 px-3 py-2 text-xs text-white placeholder-slate-500 focus:border-emerald-500 focus:outline-none" /></label>
                      <label>3. 누구에게 적용할까요?<input placeholder="비우면 전체 사용자" value={policyForm.username} onChange={e => setPolicyForm(f => ({ ...f, username: e.target.value }))} className="mt-1 w-full rounded border border-slate-700 bg-slate-800 px-3 py-2 text-xs text-white placeholder-slate-500 focus:border-emerald-500 focus:outline-none" /></label>
                    </div>
                    <label className="block">4. 어떤 AI에 적용할까요?<select value={policyForm.tool} onChange={e => setPolicyForm(f => ({ ...f, tool: e.target.value }))} className="mt-1 w-full rounded border border-slate-700 bg-slate-800 px-3 py-2 text-xs text-white"><option value="*">전체 AI 도구</option>{aiCatalog.map((tool:any)=><option key={tool.key} value={tool.key}>{tool.name} ({tool.key})</option>)}</select></label>
                    <div className="grid grid-cols-3 gap-2">
                      <label>사용 시작 시각 (0~23)<input type="number" min={0} max={23} value={policyForm.allow_start} onChange={e => setPolicyForm(f => ({ ...f, allow_start: parseInt(e.target.value) }))} className="mt-1 w-full rounded border border-slate-700 bg-slate-800 px-3 py-2 text-xs text-white focus:border-emerald-500 focus:outline-none" /></label>
                      <label>사용 종료 시각 (0~23)<input type="number" min={0} max={23} value={policyForm.allow_end} onChange={e => setPolicyForm(f => ({ ...f, allow_end: parseInt(e.target.value) }))} className="mt-1 w-full rounded border border-slate-700 bg-slate-800 px-3 py-2 text-xs text-white focus:border-emerald-500 focus:outline-none" /></label>
                      <label>한 시간에 몇 번까지?<input type="number" min={0} max={10000} value={policyForm.max_per_hour} onChange={e => setPolicyForm(f => ({ ...f, max_per_hour: parseInt(e.target.value) }))} className="mt-1 w-full rounded border border-slate-700 bg-slate-800 px-3 py-2 text-xs text-white focus:border-emerald-500 focus:outline-none" /></label>
                    </div>
                    <div className="text-xs text-slate-500">횟수를 0으로 입력하면 사용할 때마다 관리자가 확인한 뒤 한 번만 허용합니다.</div>
                    <div className={`rounded-lg border p-3 text-xs ${policyHighImpact?'border-red-500/50 bg-red-500/10':'border-slate-600 bg-slate-800'}`}><div className="font-black">적용 미리보기</div><div className="mt-1">대상: {policyTargetSummary}</div><div className="mt-1">동작: {policyEffectSummary}</div>{policyHighImpact&&<div className="mt-2 font-bold text-red-200">전체 장비·전체 사용자에 적용되는 고영향 정책입니다. 대상을 다시 확인하십시오.</div>}</div>
                    <button onClick={addPolicy} className="w-full rounded border border-blue-500/40 bg-blue-500/20 px-3 py-2 text-xs font-bold text-blue-300 hover:bg-blue-500/30">이 사용 범위 저장</button>
                  </div>
                </div>
                <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                  <div className="text-xs text-slate-400 mb-3">현재 정책 목록</div>
                  {(controls?.policies ?? []).length === 0 ? (
                    <div className="text-xs text-slate-600">등록된 정책 없음</div>
                  ) : (
                    <div className="space-y-2">
                      {controls.policies.map((p: any) => (
                        <div key={p.id} className="flex items-start gap-2 text-xs p-2 bg-slate-800 rounded">
                          <div className="flex-1">
                            <span className="text-blue-400">{p.hostname==='*'?'전체 장비':p.hostname}</span>
                            <span className="text-slate-500 mx-1">/</span>
                            <span className="text-white">{p.username==='*'?'전체 사용자':p.username}</span>
                            <span className="text-slate-500 mx-1">/</span><span className="text-yellow-300">{p.tool==='*'?'전체 AI':p.tool}</span>
                            <div className="text-slate-500 mt-0.5">
                              {p.template_key==='blocked'?'항상 차단':`${p.allow_start}시~${p.allow_end}시 · ${p.max_per_hour===0?'실행할 때마다 관리자 승인':`최근 1시간 최대 ${p.max_per_hour}회`}`}
                            </div>
                          </div>
                          <button onClick={() => removePolicy(p.id)} className="text-slate-500 hover:text-red-400">✕</button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* 승인 큐 */}
            {controlTab === 'approvals' && (
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                <div className="text-xs text-slate-400 mb-3">보안 검토 대기 목록</div>
                {(controls?.approvals ?? []).length === 0 ? (
                  <div className="text-xs text-slate-600">대기 중인 보안 검토 요청 없음</div>
                ) : (
                  <div className="space-y-3">
                    {controls.approvals.map((a: any) => (
                      <div key={a.id} className={`p-3 rounded border ${a.status === 'pending' ? 'border-yellow-500/40 bg-yellow-500/5' : a.status === 'approved' ? 'border-emerald-500/30 opacity-50' : 'border-red-500/30 opacity-50'}`}>
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1 space-y-1 text-xs">
                            <div className="flex gap-3">
                              <span className="text-yellow-400">{a.status === 'pending' ? '⏳ 대기' : a.status === 'approved' ? '✅ 승인됨' : '❌ 거부됨'}</span>
                              {a.token?.startsWith('risk-pause:') && <span className="rounded bg-red-500/15 px-1.5 py-0.5 text-[10px] text-red-300">위험 세션 자동정지</span>}
                              <span className="text-blue-400">{a.hostname}</span>
                              <span>{a.username}</span>
                              <span style={{ color: TOOL_COLOR[a.tool] ?? '#94a3b8' }}>{a.tool}</span>
                            </div>
                            <div className="text-slate-400">{a.work_dir}</div>
                            {a.args && <div className="text-slate-500">args: {a.args}</div>}
                            <div className="text-slate-600">{formatDistanceToNow(new Date(a.created_at), { addSuffix: true, locale: ko })}</div>
                          </div>
                          {a.status === 'pending' && (
                            <div className="flex gap-2 flex-shrink-0">
                              <button onClick={() => reviewApproval(a.id, true)}
                                className="bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-400 rounded px-3 py-1 text-xs">이번 실행 예외 허용</button>
                              <button onClick={() => reviewApproval(a.id, false)}
                                className="bg-red-500/20 hover:bg-red-500/30 border border-red-500/40 text-red-400 rounded px-3 py-1 text-xs">거부</button>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* 활성 세션 */}
            {controlTab === 'active' && (
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                <div className="text-xs text-slate-400 mb-3">활성 세션 (강제종료 가능)</div>
                {(controls?.activeSessions ?? []).length === 0 ? (
                  <div className="text-xs text-slate-600">현재 활성 세션 없음</div>
                ) : (
                  <div className="space-y-2">
                    {controls.activeSessions.map((s: any) => (
                      <div key={s.session_id} className="flex items-center gap-3 p-3 bg-slate-800 rounded border border-slate-700">
                        <div className={`w-2 h-2 rounded-full flex-shrink-0 ${s.state === 'paused' ? 'bg-yellow-400' : 'bg-green-400 animate-pulse'}`} />
                        <div className="flex-1 text-xs space-y-0.5">
                          <div className="flex gap-3">
                            <span className="text-blue-400">{s.hostname}</span>
                            <span>{s.username}</span>
                            <span style={{ color: TOOL_COLOR[s.tool] ?? '#94a3b8' }}>{s.tool}</span>
                            <span className="text-slate-500">PID: {s.pid}</span>
                            <span className={s.state === 'paused' ? 'text-yellow-400' : 'text-emerald-400'}>{s.state === 'paused' ? '일시정지' : '실행 중'}</span>
                          </div>
                          <div className="text-slate-500">{s.work_dir || '-'}</div>
                          <div className="text-slate-600">{s.started_at&&Number.isFinite(new Date(s.started_at).getTime())?`${formatDistanceToNow(new Date(s.started_at), { addSuffix: true, locale: ko })} 시작`:'시작 시각 확인 중'}</div>
                        </div>
                        <button onClick={() => toggleSession(s.session_id, s.state === 'paused')}
                          className="bg-yellow-500/20 hover:bg-yellow-500/30 border border-yellow-500/40 text-yellow-300 rounded px-3 py-1.5 text-xs flex-shrink-0">
                          {s.state === 'paused' ? '▶ 재개' : '⏸ 일시정지'}
                        </button>
                        <button
                          onClick={() => { if (confirm(`${s.hostname}/${s.username} 세션을 강제 종료하시겠습니까?`)) killSession(s.session_id); }}
                          className="bg-red-500/20 hover:bg-red-500/30 border border-red-500/40 text-red-400 rounded px-3 py-1.5 text-xs flex-shrink-0">
                          🛑 강제종료
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* 거버넌스 */}
      {tab === 'governance' && governance && (
        <div className="space-y-6 p-6">
          <div><div className="text-xl font-semibold">조직·권한 설정</div><div className="text-xs text-slate-500 mt-1">관리자 역할, 운영 정책, 데이터 보호 상태를 관리합니다.</div></div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
              <div className="text-sm font-semibold mb-3">간편 설정 선택</div>
              <div className="space-y-2">{(governance.templates || []).map((t: any) => <button key={t.template_key} onClick={() => { selectTemplate(t.template_key); openControl('policies'); }} className="w-full rounded-lg border border-slate-700 p-3 text-left hover:bg-slate-800"><span className="text-xs text-white">{t.name}</span><span className="float-right text-[10px] text-slate-500">{t.risk_level}</span><span className="block text-[10px] text-slate-500 mt-1">{t.description}</span></button>)}</div>
            </div>
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
              <div className="text-sm font-semibold">민감정보 보호</div>
              <div className="mt-1 text-xs text-slate-400">비밀번호·계좌번호·개인정보·회사 기밀을 어디서 찾고 어떻게 처리할지 설정합니다.</div>
              <div className="mt-4 grid grid-cols-2 gap-2 text-xs">
                {protectionChannels.map(([label,enabled]:any)=><div key={label} className={`rounded border p-3 ${enabled?'border-emerald-500/30 bg-emerald-500/10':'border-slate-700 bg-slate-800'}`}><div className="font-bold text-white">{label}</div><div className={`mt-1 ${enabled?'text-emerald-300':'text-slate-500'}`}>{enabled?'보호 중':'확인 안 함'}</div></div>)}
              </div>
              <div className="mt-3 rounded border border-slate-700 bg-slate-800 p-3 text-xs text-slate-300">
                <div>비밀번호·결제정보 즉시 차단: <b className={protectionSetting.blockCritical?'text-emerald-300':'text-yellow-300'}>{protectionSetting.blockCritical?'사용':'사용 안 함'}</b></div>
                <div className="mt-1">보안 기록 보관: <b>{protectionSetting.evidenceRetentionDays||90}일</b></div>
                <div className="mt-1">사용자 입력 원문 보관: <b className={protectionSetting.storeRawChat?'text-red-300':'text-emerald-300'}>{protectionSetting.storeRawChat?'보관함 · 주의':'보관하지 않음'}</b></div>
              </div>
              <button onClick={()=>setTab('protection')} className="mt-4 w-full rounded-lg border border-emerald-500/40 bg-emerald-500/15 px-4 py-3 text-sm font-black text-emerald-200 hover:bg-emerald-500/25">보호할 문구 입력·수정 →</button>
              <div className="mt-2 text-[11px] text-slate-500">버튼을 누른 뒤 ‘3. 데이터 분류’에서 일반 문장으로 시험할 수 있습니다.</div>
            </div>
          </div>
          {currentUser?.platform_admin && <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4"><div className="text-sm font-semibold mb-3">고객사 관리</div><div className="space-y-2">{(tenants?.tenants||[]).map((t:any)=><div key={t.id} className="flex justify-between border-b border-slate-800 py-2 text-xs"><span>{t.name}<span className="ml-2 text-slate-500">{t.code}</span></span><span className="text-slate-500">관리자 {t.admins} · 에이전트 {t.agents}</span></div>)}</div></div>
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4"><div className="text-sm font-semibold mb-3">새 고객사 생성</div><div className="grid grid-cols-2 gap-2">{[['고객사명','name','text'],['고객사 코드','code','text'],['관리자 아이디','admin_username','text'],['관리자 이메일','admin_email','email'],['초기 비밀번호','admin_password','password']].map(([label,key,type])=><input key={key} type={type} placeholder={label} value={(tenantForm as any)[key]} onChange={e=>setTenantForm(f=>({...f,[key]:e.target.value}))} className="bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs"/>)}<button onClick={createTenant} className="col-span-2 rounded border border-emerald-500/40 bg-emerald-500/10 py-2 text-xs text-emerald-300">고객사 생성</button></div>{newAgentKey&&<div className="mt-3 rounded border border-yellow-500/30 bg-yellow-500/5 p-3 text-xs"><div className="text-yellow-300">에이전트 키는 지금 한 번만 표시됩니다.</div><code className="mt-2 block break-all text-slate-300">{newAgentKey}</code></div>}</div>
          </div>}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
            <div className="text-sm font-semibold mb-3">관리자 역할</div>
            {(governance.users || []).map((u: any) => <div key={u.id} className="flex items-center gap-3 border-b border-slate-800 py-2 text-xs"><span className="flex-1">{u.username}<span className="ml-2 text-slate-500">{u.email}</span></span><select value={u.role} disabled={currentUser?.role !== 'admin'} onChange={e => updateRole(u.id, e.target.value)} className="bg-slate-800 border border-slate-700 rounded px-2 py-1"><option value="admin">관리자</option><option value="security">보안담당자</option><option value="auditor">감사자</option><option value="viewer">열람자</option></select></div>)}
          </div>
        </div>
      )}

      {tab==='catalog'&&catalog&&(
        <div className="space-y-6 p-6">
          <div><div className="text-xl font-semibold">AI 서비스 관리</div><div className="mt-1 text-xs text-slate-500">탐지할 AI 서비스를 검토하고 승인된 규칙을 모든 Agent에 자동 배포합니다.</div></div>
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">{[['기본 카탈로그',catalog.builtIn?.length||0,'text-blue-400'],['검토 중',(catalog.entries||[]).filter((x:any)=>x.status==='review').length,'text-yellow-400'],['활성 사용자 규칙',(catalog.entries||[]).filter((x:any)=>x.status==='active').length,'text-emerald-400'],['종료·오탐',(catalog.entries||[]).filter((x:any)=>['retired','false_positive'].includes(x.status)).length,'text-slate-400']].map(([l,v,c]:any)=><div key={l} className="rounded-lg border border-slate-800 bg-slate-900 p-4"><div className="text-xs text-slate-400">{l}</div><div className={`mt-1 text-2xl font-bold ${c}`}>{v}</div></div>)}</div>
          <div className="grid gap-5 lg:grid-cols-2">
            <div className="rounded-lg border border-slate-800 bg-slate-900 p-4"><div className="mb-3 text-sm font-bold">신규 AI 후보 등록</div><div className="grid grid-cols-2 gap-2"><input placeholder="식별자" value={catalogForm.key} onChange={e=>setCatalogForm(f=>({...f,key:e.target.value}))} className="rounded border border-slate-700 bg-slate-800 px-3 py-2 text-xs"/><input placeholder="표시 이름" value={catalogForm.name} onChange={e=>setCatalogForm(f=>({...f,name:e.target.value}))} className="rounded border border-slate-700 bg-slate-800 px-3 py-2 text-xs"/><input placeholder="프로세스명" value={catalogForm.process} onChange={e=>setCatalogForm(f=>({...f,process:e.target.value}))} className="rounded border border-slate-700 bg-slate-800 px-3 py-2 text-xs"/><input placeholder="도메인" value={catalogForm.domain} onChange={e=>setCatalogForm(f=>({...f,domain:e.target.value}))} className="rounded border border-slate-700 bg-slate-800 px-3 py-2 text-xs"/><input placeholder="검토 메모" value={catalogForm.notes} onChange={e=>setCatalogForm(f=>({...f,notes:e.target.value}))} className="col-span-2 rounded border border-slate-700 bg-slate-800 px-3 py-2 text-xs"/></div><button onClick={addCatalogCandidate} className="mt-3 w-full rounded border border-blue-500/40 bg-blue-500/15 py-2 text-xs font-bold text-blue-300">검토함에 추가</button></div>
            <div className="rounded-lg border border-slate-800 bg-slate-900 p-4"><div className="mb-2 text-sm font-bold">운영 주기</div><div className="space-y-2 text-xs text-slate-300"><div>검토 주기: <span className="text-emerald-300">{catalog.schedule?.reviewCycle==='monthly'?'매월':'분기'}</span></div><div>신규 후보 자동 수집: {catalog.schedule?.candidateAutoCollect?'사용':'중지'}</div><div>승인 규칙 Agent 자동 배포: {catalog.schedule?.autoDeployApproved?'사용':'중지'}</div><div className="rounded border border-blue-500/20 bg-blue-500/5 p-3 text-blue-200">서비스가 사라져도 삭제하지 않고 ‘서비스 종료’로 전환해 과거 감사 기록을 보존합니다.</div></div></div>
          </div>
          <div className="rounded-lg border border-slate-800 bg-slate-900 p-4"><div className="mb-3 text-sm font-bold">검토·사용자 정의 목록</div>{(catalog.entries||[]).length===0?<div className="text-xs text-slate-500">등록된 후보가 없습니다.</div>:<div className="space-y-2">{catalog.entries.map((x:any)=><div key={x.id} className="flex flex-wrap items-center gap-2 rounded border border-slate-800 bg-slate-950/40 p-3 text-xs"><span className="font-bold text-white">{x.display_name}</span><span className="text-slate-500">{x.tool_key}</span><span className={`rounded px-2 py-1 ${x.status==='active'?'bg-emerald-500/15 text-emerald-300':x.status==='review'?'bg-yellow-500/15 text-yellow-300':'bg-slate-700 text-slate-300'}`}>{x.status==='active'?'활성':x.status==='review'?'검토 중':x.status==='retired'?'서비스 종료':'오탐'}</span><span className="flex-1 text-slate-500">{(x.processes||[]).filter(Boolean).join(', ')} {(x.domains||[]).filter(Boolean).join(', ')}</span>{x.status!=='active'&&<button onClick={()=>setCatalogStatus(x.id,'active')} className="rounded border border-emerald-500/40 px-2 py-1 text-emerald-300">승인·배포</button>}{x.status!=='retired'&&<button onClick={()=>setCatalogStatus(x.id,'retired')} className="rounded border border-slate-600 px-2 py-1 text-slate-300">서비스 종료</button>}{x.status!=='false_positive'&&<button onClick={()=>setCatalogStatus(x.id,'false_positive')} className="rounded border border-red-500/30 px-2 py-1 text-red-300">오탐</button>}</div>)}</div>}</div>
          <div className="rounded-lg border border-slate-800 bg-slate-900 p-4"><div className="mb-3 text-sm font-bold">최근 변경 이력</div><div className="space-y-1">{(catalog.history||[]).slice(0,20).map((h:any,i:number)=><div key={i} className="flex justify-between border-b border-slate-800 py-2 text-xs"><span><span className="text-blue-300">{h.tool_key}</span> · {h.action}</span><span className="text-slate-500">{h.changed_by} · {format(new Date(h.changed_at),'yyyy-MM-dd HH:mm')}</span></div>)}</div></div>
        </div>
      )}

      {tab === 'protection' && canViewProtection && (
        <div className="space-y-6 p-6">
          <div>
            <div className="text-xl font-semibold">정보 보호 · Agent 설치</div>
            <div className="mt-1 text-xs text-slate-500">정보 보호 설정과 Windows·macOS·Linux Agent 설치 상태를 관리합니다.</div>
          </div>

          {/* 에이전트 설치 명령어 */}
          {['admin','security'].includes(currentUser?.role||'') && (()=>{
            const server=typeof window!=='undefined'?window.location.host:'192.168.0.102:3100';
            const installCommands=[
              {platform:'Linux',command:`tar -xzf einsguard-ai-agent-1.3.0-linux.tar.gz && cd einsguard-ai-agent-1.3.0-linux && sudo ./install.sh ${server}`},
              {platform:'macOS',command:`tar -xzf einsguard-ai-agent-1.3.0-macos.tar.gz && cd einsguard-ai-agent-1.3.0-macos && sudo ./install-system.sh ${server}`},
              {platform:'Windows',command:`Set-ExecutionPolicy -Scope Process Bypass; .\\Install-AI-Sentinel.ps1 -ApiBase '${server}'`},
            ];
            return (
              <div className="rounded-lg border border-blue-500/30 bg-slate-900 p-5">
                <div className="mb-3 flex items-center gap-2">
                  <span className="text-sm font-bold text-blue-300">Agent 1.3.0 설치</span>
                  <span className="rounded bg-blue-500/15 px-2 py-0.5 text-[10px] text-blue-400">Agent 키 입력 불필요</span>
                </div>
                <div className="space-y-2">{installCommands.map(item=><div key={item.platform} className="flex items-center gap-2"><span className="w-16 shrink-0 text-xs font-black text-white">{item.platform}</span><code className="flex-1 overflow-x-auto whitespace-nowrap rounded border border-blue-500/20 bg-slate-950 px-3 py-2 text-xs text-blue-200">{item.command}</code><button onClick={()=>navigator.clipboard?.writeText(item.command)} className="shrink-0 rounded border border-blue-500/40 bg-blue-500/15 px-3 py-2 text-xs font-bold text-blue-300 hover:bg-blue-500/25">복사</button></div>)}</div>
                <div className="mt-3 text-[11px] text-slate-400">설치 후 이 화면에 장비 등록 요청이 표시됩니다. 관리자가 승인하면 장비 전용 키를 자동 수령하고 서비스가 시작됩니다.</div>
              </div>
            );
          })()}

          {/* 스캔 요약 */}
          {discovery && (
            <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
              {[
                ['등록 IP 범위', (discovery.scopes||[]).filter((s:any)=>s.enabled).length + '개', 'text-blue-400'],
                ['에이전트 설치됨', (discovery.installed||[]).length + '대', 'text-emerald-400'],
                ['미설치 탐지', (discovery.uninstalled||[]).length + '대', (discovery.uninstalled||[]).length > 0 ? 'text-red-400' : 'text-slate-400'],
                ['마지막 스캔', discovery.recentRuns?.[0] ? format(new Date(discovery.recentRuns[0].requested_at),'MM-dd HH:mm') : '없음', 'text-slate-300'],
              ].map(([l,v,c]:any) => (
                <div key={l} className="rounded-lg border border-slate-800 bg-slate-900 p-4">
                  <div className="text-xs text-slate-400">{l}</div>
                  <div className={`mt-1 text-2xl font-bold ${c}`}>{v}</div>
                </div>
              ))}
            </div>
          )}

          {/* IP 범위 관리 */}
          <div className="rounded-lg border border-slate-800 bg-slate-900 p-5">
            <div className="mb-4 text-sm font-bold">스캔 대상 IP 대역 (CIDR)</div>
            {canViewProtection && ['admin','security'].includes(currentUser?.role||'') && (
              <div className="mb-4 flex gap-2">
                <input
                  value={discoveryNetwork}
                  onChange={e=>setDiscoveryNetwork(e.target.value)}
                  placeholder="예: 192.168.0.0/24"
                  className="flex-1 rounded border border-slate-700 bg-slate-800 px-3 py-2 text-xs text-white placeholder-slate-500 focus:border-emerald-500 focus:outline-none"
                  onKeyDown={async e=>{
                    if(e.key!=='Enter')return;
                    const r=await fetch('/api/discovery',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'add_scope',network:discoveryNetwork.trim()})});
                    const d=await r.json();
                    if(d.ok){setDiscoveryNetwork('');setDiscoveryMsg('✅ IP 범위 추가됨');fetchDiscovery();}
                    else setDiscoveryMsg('❌ '+d.error);
                  }}
                />
                <button
                  onClick={async()=>{
                    const r=await fetch('/api/discovery',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'add_scope',network:discoveryNetwork.trim()})});
                    const d=await r.json();
                    if(d.ok){setDiscoveryNetwork('');setDiscoveryMsg('✅ IP 범위 추가됨');fetchDiscovery();}
                    else setDiscoveryMsg('❌ '+d.error);
                  }}
                  className="rounded border border-emerald-500/40 bg-emerald-500/15 px-4 py-2 text-xs font-bold text-emerald-300 hover:bg-emerald-500/25"
                >추가</button>
              </div>
            )}
            {discoveryMsg && <div className="mb-3 text-xs">{discoveryMsg}</div>}
            {(discovery?.scopes||[]).length === 0
              ? <div className="text-xs text-slate-500">등록된 IP 범위가 없습니다.</div>
              : <div className="space-y-2">
                  {(discovery?.scopes||[]).map((s:any)=>(
                    <div key={s.id} className="flex items-center gap-3 rounded border border-slate-800 bg-slate-950/40 px-3 py-2 text-xs">
                      <span className={`h-2 w-2 rounded-full ${s.enabled?'bg-emerald-400':'bg-slate-600'}`}/>
                      <span className="font-mono font-bold text-white">{s.network}</span>
                      <span className="flex-1 text-slate-500">{s.enabled?'활성':'비활성'}</span>
                      {['admin','security'].includes(currentUser?.role||'') && <>
                        <button onClick={async()=>{await fetch('/api/discovery',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'toggle_scope',id:s.id})});fetchDiscovery();}} className="rounded border border-slate-600 px-2 py-1 text-slate-300 hover:text-white">{s.enabled?'비활성화':'활성화'}</button>
                        <button onClick={async()=>{if(!window.confirm(`${s.network} 범위를 삭제하시겠습니까?`))return;await fetch('/api/discovery',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'remove_scope',id:s.id})});fetchDiscovery();}} className="rounded border border-red-500/30 px-2 py-1 text-red-300 hover:text-red-100">삭제</button>
                      </>}
                    </div>
                  ))}
                </div>
            }
          </div>

          {/* 스캔 실행 */}
          {['admin','security'].includes(currentUser?.role||'') && (
            <div className="flex items-center gap-4">
              <button
                disabled={scanLoading || discovery?.activeRun != null}
                onClick={async()=>{
                  setScanLoading(true);setDiscoveryMsg('');
                  const r=await fetch('/api/discovery',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'start_scan'})});
                  const d=await r.json();
                  setScanLoading(false);
                  if(d.ok){setDiscoveryMsg('🔍 스캔을 시작했습니다. 완료까지 수십 초~수 분 소요됩니다.');fetchDiscovery();}
                  else setDiscoveryMsg('❌ '+d.error);
                }}
                className="rounded border border-blue-500/40 bg-blue-500/15 px-5 py-2 text-xs font-bold text-blue-300 hover:bg-blue-500/25 disabled:opacity-40"
              >
                {discovery?.activeRun ? '⏳ 스캔 진행 중...' : '🔍 네트워크 스캔 시작'}
              </button>
              {discovery?.activeRun && (
                <div className="text-xs text-slate-400">
                  {discovery.activeRun.hosts_probed} / {discovery.activeRun.hosts_planned}개 처리 · {discovery.activeRun.hosts_responded}개 응답
                </div>
              )}
              {discovery?.recentRuns?.[0] && !discovery.activeRun && (
                <div className="text-xs text-slate-500">
                  마지막 스캔: {format(new Date(discovery.recentRuns[0].requested_at),'MM-dd HH:mm')} · {discovery.recentRuns[0].hosts_responded}개 응답
                </div>
              )}
            </div>
          )}

          {/* 에이전트 설치 확인 — 스캔 없이 IP 범위 내 등록 에이전트를 항상 표시 */}
          {(discovery?.installed||[]).length > 0 && (
            <div className="rounded-lg border border-emerald-500/20 bg-slate-900 p-5">
              <div className="mb-3 flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-emerald-400"/>
                <div className="text-sm font-bold text-emerald-300">에이전트 설치 확인 ({(discovery.installed||[]).length}대)</div>
                <span className="text-xs text-slate-500">— 등록된 IP 범위 내 Agent 통신 중인 PC</span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full min-w-[600px] text-left text-xs">
                  <thead><tr className="border-b border-slate-700 text-slate-400">
                    <th className="px-3 py-2">IP 주소</th>
                    <th className="px-3 py-2">호스트명</th>
                    <th className="px-3 py-2">OS</th>
                    <th className="px-3 py-2">Agent 버전</th>
                    <th className="px-3 py-2">마지막 통신</th>
                  </tr></thead>
                  <tbody>{(discovery.installed||[]).map((a:any)=>(
                    <tr key={a.hostname} className="border-b border-slate-800 hover:bg-slate-800">
                      <td className="px-3 py-2 font-mono font-bold text-white">{a.ip||'-'}</td>
                      <td className="px-3 py-2 text-slate-300">{a.hostname||'-'}</td>
                      <td className="px-3 py-2 text-slate-500">{a.os||'-'} {a.os_version||''}</td>
                      <td className="px-3 py-2"><span className="font-bold text-slate-200">{a.agent_version||'-'}</span><span className={`ml-2 rounded px-2 py-1 text-[10px] font-black ${agentVersionLatest(a)?'bg-emerald-500/20 text-emerald-200':'bg-amber-500/20 text-amber-200'}`}>{agentVersionLatest(a)?'최신':'업데이트 필요'}</span></td>
                      <td className="px-3 py-2 text-slate-500">{a.agent_last_seen?formatDistanceToNow(new Date(a.agent_last_seen),{addSuffix:true,locale:ko}):'-'}</td>
                    </tr>
                  ))}</tbody>
                </table>
              </div>
            </div>
          )}

          {/* 에이전트 미설치 호스트 — 네트워크 스캔 결과 기반 */}
          {(discovery?.uninstalled||[]).length > 0 && (
            <div className="rounded-lg border border-red-500/30 bg-slate-900 p-5">
              <div className="mb-3 flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-red-400"/>
                <div className="text-sm font-bold text-red-300">에이전트 미설치 호스트 ({(discovery.uninstalled||[]).length}대)</div>
                <span className="text-xs text-slate-500">— 스캔에서 응답했지만 Agent 미등록</span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full min-w-[600px] text-left text-xs">
                  <thead><tr className="border-b border-slate-700 text-slate-400">
                    <th className="px-3 py-2">IP 주소</th>
                    <th className="px-3 py-2">호스트명</th>
                    <th className="px-3 py-2">최초 발견</th>
                    <th className="px-3 py-2">마지막 확인</th>
                    <th className="px-3 py-2">상태</th>
                  </tr></thead>
                  <tbody>{(discovery.uninstalled||[]).map((a:any)=>(
                    <tr key={a.id} className="border-b border-slate-800 hover:bg-slate-800">
                      <td className="px-3 py-2 font-mono font-bold text-white">{a.ip}</td>
                      <td className="px-3 py-2 text-slate-300">{a.hostname||'-'}</td>
                      <td className="px-3 py-2 text-slate-500">{format(new Date(a.first_seen),'MM-dd HH:mm')}</td>
                      <td className="px-3 py-2 text-slate-500">{formatDistanceToNow(new Date(a.last_seen),{addSuffix:true,locale:ko})}</td>
                      <td className="px-3 py-2"><span className="rounded border border-red-500/30 bg-red-500/15 px-2 py-1 text-red-300">미설치</span></td>
                    </tr>
                  ))}</tbody>
                </table>
              </div>
            </div>
          )}

          {(discovery?.installed||[]).length === 0 && (discovery?.uninstalled||[]).length === 0 && (
            <div className="rounded-lg border border-slate-700 p-8 text-center text-xs text-slate-500">
              IP 범위를 등록하면 범위 내 에이전트가 자동으로 표시됩니다.<br/>
              스캔을 시작하면 미설치 PC도 탐지됩니다.
            </div>
          )}
        </div>
      )}

      {tab === 'backup' && currentUser?.platform_admin && (
        <div className="space-y-6 p-6">
          <div><div className="text-xl font-semibold">설정 백업·복구</div><div className="mt-1 text-xs text-slate-500">장기간 구성한 정책과 운영 설정을 NAS에 정기 보관하고, 서버 재구성 전에 복구 가능 여부를 검증합니다.</div></div>
          {backupMsg&&<div className="rounded-lg border border-blue-500/30 bg-blue-500/10 p-3 text-xs text-blue-100">{backupMsg}</div>}
          <div className="grid gap-5 lg:grid-cols-2">
            <div className="rounded-lg border border-slate-700 bg-slate-900 p-5">
              <div className="mb-4 text-sm font-black">정기 백업 설정</div>
              <div className="grid gap-4 md:grid-cols-2">
                <label className="flex items-center gap-2 text-xs font-bold"><input type="checkbox" checked={backupForm.enabled} onChange={e=>setBackupForm(f=>({...f,enabled:e.target.checked}))}/>정기 백업 사용</label>
                <label className="text-xs">실행 주기<select value={backupForm.frequency} onChange={e=>setBackupForm(f=>({...f,frequency:e.target.value}))} className="mt-1 w-full rounded border border-slate-600 bg-slate-950 px-3 py-2 text-white"><option value="daily">매일</option><option value="weekly">매주</option></select></label>
                {backupForm.frequency==='weekly'&&<label className="text-xs">요일<select value={backupForm.dayOfWeek} onChange={e=>setBackupForm(f=>({...f,dayOfWeek:Number(e.target.value)}))} className="mt-1 w-full rounded border border-slate-600 bg-slate-950 px-3 py-2 text-white">{['일','월','화','수','목','금','토'].map((label,index)=><option key={label} value={index}>{label}요일</option>)}</select></label>}
                <label className="text-xs">실행 시각(KST)<input type="time" value={backupForm.time} onChange={e=>setBackupForm(f=>({...f,time:e.target.value}))} className="mt-1 w-full rounded border border-slate-600 bg-slate-950 px-3 py-2 text-white"/></label>
                <div className="text-xs md:col-span-2"><span>서버/NAS 저장 위치</span><div className="mt-1 flex gap-2"><input value={backupForm.storagePath} readOnly className="min-w-0 flex-1 rounded border border-slate-600 bg-slate-950 px-3 py-2 font-mono text-white"/><button type="button" disabled={backupBusy} onClick={()=>openBackupBrowser()} className="shrink-0 rounded border border-blue-500/40 bg-blue-500/15 px-3 font-bold text-blue-200">파일 탐색기</button></div><span className="mt-1 block text-[10px] text-slate-500">Windows SMB·macOS 공유·NFS도 Linux 서버에 연결된 뒤 이 탐색기에 표시됩니다.</span></div>
                {showBackupBrowser&&backupBrowser&&<div className="rounded-lg border border-blue-500/30 bg-slate-950 p-4 md:col-span-2"><div className="flex items-center justify-between gap-2"><div><div className="text-xs font-black text-blue-200">서버/NAS 파일 탐색기</div><code className="mt-1 block break-all text-[10px] text-slate-400">{backupBrowser.current}</code></div><button onClick={()=>setShowBackupBrowser(false)} className="text-slate-400">✕</button></div><div className="mt-3 max-h-48 space-y-1 overflow-y-auto">{backupBrowser.parent&&<button onClick={()=>openBackupBrowser(backupBrowser.parent)} className="block w-full rounded px-3 py-2 text-left text-xs hover:bg-slate-800">↰ 상위 폴더</button>}{backupBrowser.directories.filter((item:any)=>!item.backup).map((item:any)=><button key={item.path} onClick={()=>openBackupBrowser(item.path)} className="block w-full rounded px-3 py-2 text-left text-xs hover:bg-slate-800">📁 {item.name}</button>)}</div><button onClick={chooseBackupFolder} className="mt-3 w-full rounded border border-emerald-500/40 bg-emerald-500/15 py-2 text-xs font-black text-emerald-200">현재 폴더를 백업 위치로 선택</button></div>}
                <label className="text-xs md:col-span-2">백업 설명<input value={backupForm.description} onChange={e=>setBackupForm(f=>({...f,description:e.target.value}))} className="mt-1 w-full rounded border border-slate-600 bg-slate-950 px-3 py-2 text-white"/></label>
              </div>
              <div className="mt-4 rounded-lg border border-slate-700 bg-slate-950/50 p-4"><div className="mb-3 text-xs font-black">백업 대상</div><div className="space-y-3 text-xs">
                <label className="flex items-start gap-2"><input type="checkbox" checked={backupForm.includeDatabase} onChange={e=>setBackupForm(f=>({...f,includeDatabase:e.target.checked}))}/><span><b>운영 데이터베이스</b><span className="block text-slate-400">정책, 사용자, 장비, 라이선스, 감사·이벤트 설정</span></span></label>
                <label className="flex items-start gap-2"><input type="checkbox" checked={backupForm.includeEnvironment} onChange={e=>setBackupForm(f=>({...f,includeEnvironment:e.target.checked}))}/><span><b>필수 환경설정·비밀키</b><span className="block text-red-300">DB 연결과 암호화 키가 포함되므로 해당 저장소의 NAS ACL·접근권한으로 보호해야 합니다.</span></span></label>
                <label className="flex items-start gap-2"><input type="checkbox" checked={backupForm.includeApplicationConfig} onChange={e=>setBackupForm(f=>({...f,includeApplicationConfig:e.target.checked}))}/><span><b>애플리케이션 구성</b><span className="block text-slate-400">버전, DB 마이그레이션, 배포 설정</span></span></label>
              </div></div>
              <div className="mt-4 flex items-end gap-3"><label className="flex-1 text-xs">보관 기준(일)<input type="number" min="7" max="3650" value={backupForm.retentionDays} onChange={e=>setBackupForm(f=>({...f,retentionDays:Number(e.target.value)}))} className="mt-1 w-full rounded border border-slate-600 bg-slate-950 px-3 py-2 text-white"/></label><label className="mb-2 flex items-center gap-2 text-xs"><input type="checkbox" checked={backupForm.automaticCleanup} onChange={e=>setBackupForm(f=>({...f,automaticCleanup:e.target.checked}))}/>기간 경과본 자동 정리</label></div>
              <div className="mt-2 text-[10px] text-amber-300">자동 정리는 현재 안전을 위해 기록만 저장하며 실제 삭제는 비활성 상태입니다.</div>
              <button disabled={backupBusy} onClick={saveBackupPolicy} className="mt-4 w-full rounded border border-emerald-500/40 bg-emerald-500/15 py-2.5 text-xs font-black text-emerald-200 disabled:opacity-40">정기 백업 설정 저장</button>
            </div>
            <div className="space-y-5">
              <div className="rounded-lg border border-blue-500/30 bg-slate-900 p-5"><div className="text-sm font-black">지금 백업</div><p className="mt-1 text-xs text-slate-400">저장된 위치와 백업 대상을 사용하며, 아래 실행 메모가 백업 기록에 남습니다.</p><textarea value={backupNotes} onChange={e=>setBackupNotes(e.target.value)} className="mt-3 h-20 w-full rounded border border-slate-600 bg-slate-950 p-3 text-xs text-white"/><button disabled={backupBusy||!backupNotes.trim()} onClick={runBackup} className="mt-3 w-full rounded border border-blue-500/40 bg-blue-500/15 py-2.5 text-xs font-black text-blue-200 disabled:opacity-40">{backupBusy?'처리 중...':'수동 백업 실행'}</button></div>
              <div className="rounded-lg border border-cyan-500/30 bg-slate-900 p-5"><div className="text-sm font-black">Windows·macOS·Linux 백업 파일</div><p className="mt-1 text-xs text-slate-400">아래 백업 기록의 ‘내 PC에 저장’을 누르면 운영체제의 저장 창으로 내려받습니다. 다른 PC에 보관한 백업은 여기서 다시 가져올 수 있습니다.</p><label className="mt-3 flex cursor-pointer items-center justify-center rounded border border-cyan-500/40 bg-cyan-500/15 py-2.5 text-xs font-black text-cyan-100"><input type="file" accept=".tar.gz,application/gzip" className="hidden" disabled={backupBusy} onChange={e=>{const file=e.target.files?.[0];if(file)void importBackup(file);e.currentTarget.value='';}}/>백업 파일 가져오기</label></div>
              <div className="rounded-lg border border-slate-700 bg-slate-900 p-5"><div className="text-sm font-black">저장소 상태</div><div className="mt-3 space-y-2 text-xs"><div><span className="text-slate-400">위치</span><code className="float-right max-w-[70%] break-all text-right text-white">{backup?.storage?.path||backupForm.storagePath}</code></div><div><span className="text-slate-400">여유 공간</span><span className="float-right font-bold">{backup?.storage?`${(backup.storage.freeBytes/1024/1024/1024).toFixed(1)} GB`:'확인 중'}</span></div><div><span className="text-slate-400">등록 백업</span><span className="float-right font-bold">{backup?.backups?.length||0}개</span></div></div></div>
              <div className="rounded-lg border border-amber-500/30 bg-amber-500/5 p-5"><div className="text-sm font-black text-amber-200">복구 원칙</div><p className="mt-2 text-xs text-slate-300">복구는 기존 DB를 교체하고 서비스를 중단하므로 화면에서 자동 실행하지 않습니다. 먼저 아래 목록에서 무결성을 검증한 뒤 유지보수 승인 하에 서버의 복구 스크립트를 실행합니다.</p><code className="mt-3 block break-all rounded bg-slate-950 p-3 text-[10px] text-amber-100">{backup?.restoreCommand||'sudo ./scripts/restore-config-backup.sh --validate-only <백업경로>'}</code></div>
            </div>
          </div>
          <div className="rounded-lg border border-slate-700 bg-slate-900 p-5"><div className="mb-4 text-sm font-black">백업 파일 선택</div>{(backup?.backups||[]).length===0?<div className="text-xs text-slate-500">아직 생성된 백업이 없습니다.</div>:<div className="overflow-x-auto"><table className="w-full min-w-[1080px] text-left text-xs"><thead><tr className="border-b border-slate-700 text-slate-400"><th className="px-3 py-2">선택</th><th className="px-3 py-2">일시·방식</th><th className="px-3 py-2">실행자</th><th className="px-3 py-2">저장 위치</th><th className="px-3 py-2">백업 내용</th><th className="px-3 py-2">설명</th><th className="px-3 py-2">보관·복구</th></tr></thead><tbody>{backup.backups.map((item:any)=><tr key={item.backupName} className={`border-b align-top ${selectedRestoreBackup?.backupName===item.backupName?'border-blue-400 bg-blue-500/10':'border-slate-800 hover:bg-slate-800'}`}><td className="px-3 py-3"><input type="radio" name="restore-backup" checked={selectedRestoreBackup?.backupName===item.backupName} onChange={()=>selectRestore(item)} aria-label={`${item.backupName} 복구 대상으로 선택`}/></td><td className="px-3 py-3"><span className="font-bold text-white">{new Date(item.createdAt).toLocaleString('ko-KR')}</span><span className="mt-1 block text-slate-500">{item.trigger==='scheduled'?'정기':'수동'} · {item.backupName}</span></td><td className="px-3 py-3">{item.createdBy}</td><td className="max-w-xs break-all px-3 py-3 font-mono text-[10px] text-blue-200">{item.storagePath}</td><td className="px-3 py-3">{(item.content||[]).map((value:string)=><span key={value} className="block">• {value}</span>)}</td><td className="max-w-xs px-3 py-3 text-slate-300">{item.description||'-'}</td><td className="space-y-2 px-3 py-3"><a href={`/api/backup?action=download&backupName=${encodeURIComponent(item.backupName)}`} className="block rounded border border-cyan-500/40 px-3 py-1.5 text-center font-bold text-cyan-100">내 PC에 저장</a><button disabled={backupBusy} onClick={()=>selectRestore(item)} className="w-full rounded border border-emerald-500/40 px-3 py-1.5 font-bold text-emerald-200 disabled:opacity-40">선택·검증</button></td></tr>)}</tbody></table></div>}</div>
          {selectedRestoreBackup&&<div className="rounded-lg border-2 border-amber-500/50 bg-amber-500/5 p-5"><div className="text-sm font-black text-amber-200">선택한 백업으로 복구 준비</div><div className="mt-4 grid gap-3 text-xs md:grid-cols-3"><div><span className="text-slate-400">선택 파일</span><code className="mt-1 block break-all text-white">{selectedRestoreBackup.backupName}</code></div><div><span className="text-slate-400">생성 일시</span><span className="mt-1 block font-bold">{new Date(selectedRestoreBackup.createdAt).toLocaleString('ko-KR')}</span></div><div><span className="text-slate-400">무결성</span><span className={`mt-1 block font-bold ${restoreValidation?.ok?'text-emerald-300':'text-amber-300'}`}>{restoreValidation?.ok?`${restoreValidation.checkedFiles}개 파일 정상`:'검증 중 또는 실패'}</span></div></div><p className="mt-4 text-xs text-slate-300">이 백업으로 복구하면 현재 데이터베이스와 환경설정이 선택 시점으로 돌아갑니다. 아래 문구를 정확히 입력해야 복구 절차를 준비할 수 있습니다.</p><div className="mt-3 flex flex-col gap-2 md:flex-row"><input value={restoreConfirmation} onChange={e=>setRestoreConfirmation(e.target.value)} placeholder={`RESTORE ${selectedRestoreBackup.backupName}`} className="min-w-0 flex-1 rounded border border-amber-500/40 bg-slate-950 px-3 py-2 text-xs text-white"/><button disabled={backupBusy||!restoreValidation?.ok||restoreConfirmation!==`RESTORE ${selectedRestoreBackup.backupName}`} onClick={prepareRestore} className="rounded border border-amber-500/50 bg-amber-500/15 px-4 py-2 text-xs font-black text-amber-100 disabled:opacity-40">이 파일로 복구 절차 준비</button></div>{restorePlan&&<div className="mt-4 rounded border border-red-500/40 bg-red-500/10 p-4"><div className="font-black text-red-200">유지보수 콘솔 실행 명령</div><ol className="mt-2 list-inside list-decimal space-y-1 text-xs text-slate-300">{restorePlan.steps.map((step:string)=><li key={step}>{step}</li>)}</ol><code className="mt-3 block break-all rounded bg-slate-950 p-3 text-[10px] text-red-100">{restorePlan.command}</code></div>}</div>}
        </div>
      )}

      {tab === 'license' && license && (
        <div className="space-y-6 p-6">
          <div><div className="text-xl font-semibold">라이선스·관리 장비</div><div className="mt-1 text-xs text-slate-500">사용 기간, 등록 장비 수, Agent 연결 키 상태를 확인합니다.</div></div>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="rounded-lg border border-slate-600 bg-slate-800 p-4"><div className="text-sm font-bold text-slate-200">상태</div><div className={`mt-2 text-2xl font-black ${license.active?'text-emerald-400':'text-red-400'}`}>{license.active?'사용 가능':'기능 잠김'}</div><div className="mt-1 text-xs text-slate-300">{license.perpetual?'사내 영구 라이선스':license.plan}</div></div>
            <div className="rounded-lg border border-slate-600 bg-slate-800 p-4"><div className="text-sm font-bold text-slate-200">사용 기간</div><div className="mt-2 text-2xl font-black text-white">{license.perpetual?'영구':`${license.days_remaining}일`}</div><div className="mt-1 text-xs text-slate-300">{license.perpetual?'만료 없음':`만료 ${new Date(license.expires_at).toLocaleString('ko-KR')}`}</div></div>
            <div className="rounded-lg border border-slate-600 bg-slate-800 p-4"><div className="text-sm font-bold text-slate-200">관리 대상</div><div className="mt-2 text-2xl font-black text-white">{license.agent_count} / {license.agent_limit===0?'무제한':`${license.agent_limit}대`}</div><div className="mt-1 text-xs text-slate-300">{license.agent_limit===0?'장비 수 제한 없음':'OS와 관계없이 장비 ID 기준'}</div></div>
          </div>
          {license.perpetual ? <div className="rounded-lg border border-emerald-500/30 bg-emerald-500/5 p-4">
            <div className="text-sm font-semibold text-emerald-300">내부 영구 라이선스</div>
            <div className="mt-1 text-xs text-slate-400">별도 라이선스 키 인증이나 기간 갱신 없이 계속 사용할 수 있습니다.</div>
            <div className="mt-2 text-[10px] text-slate-500">설치 ID: {license.installation_id}</div>
          </div> : <div className="rounded-lg border border-slate-800 bg-slate-900 p-4">
            <div className="text-sm font-semibold">구독 키 인증</div><div className="mt-1 text-[10px] text-slate-500">설치 ID: {license.installation_id}</div>
            <textarea value={licenseKey} onChange={e=>setLicenseKey(e.target.value)} placeholder="EINSTECH에서 발급받은 라이선스 키를 입력하세요" className="mt-4 h-24 w-full rounded border border-slate-700 bg-slate-800 p-3 text-xs" />
            {licenseMsg&&<div className="mt-2 text-xs">{licenseMsg}</div>}
            <button disabled={currentUser?.role!=='admin'||!licenseKey.trim()} onClick={activateLicense} className="mt-3 rounded border border-emerald-500/40 bg-emerald-500/10 px-4 py-2 text-xs text-emerald-300 disabled:opacity-40">라이선스 인증</button>
          </div>}
          <div className="rounded-lg border border-slate-700 bg-slate-900 p-4">
            <div className="text-sm font-semibold">장비 인증 키 현황</div>
            <div className="mt-1 text-xs text-slate-400">장비 1대당 현재 인증 키 1개를 사용합니다. 같은 장비에서 사용자·AI·세션이 여러 개 실행돼도 인증 키 수는 늘어나지 않습니다.</div>
            <div className="mt-1 text-xs text-slate-500">한 번 이상 정상 인증된 키만 표시하며, 재발급하면 같은 장비의 이전 키는 자동으로 인증 해제됩니다.</div>
            {unusedAgentKeyCount>0&&<div className="mt-2 text-xs text-slate-500">정상 연결 이력이 없는 미사용 발급 키 {unusedAgentKeyCount}개는 목록에서 숨겼습니다.</div>}
            <div className="mt-4 overflow-x-auto"><table className="w-full min-w-[700px] text-left text-xs"><thead><tr className="border-b border-slate-700 text-slate-400"><th className="px-3 py-2">관리 장비</th><th className="px-3 py-2">장비 인증 키</th><th className="px-3 py-2">발급일</th><th className="px-3 py-2">마지막 인증</th><th className="px-3 py-2">연결 상태</th></tr></thead><tbody>{connectedAgentKeys.map((key:any)=>{const state=agentKeyConnectionState(key);return <tr key={key.id} className="border-b border-slate-800"><td className="px-3 py-2 text-slate-200"><div className="font-bold">{key.hostname||key.key_name}</div><div className="text-slate-500">{key.platform||'Agent'}</div></td><td className="px-3 py-2 font-mono text-slate-400">…{key.fingerprint}</td><td className="px-3 py-2 text-slate-400">{new Date(key.created_at).toLocaleString('ko-KR')}</td><td className="px-3 py-2 text-slate-400">{new Date(key.last_used_at).toLocaleString('ko-KR')}</td><td className="px-3 py-2"><span className={`rounded px-2 py-1 font-bold ${state.className}`}>{state.label}</span></td></tr>})}</tbody></table>{connectedAgentKeys.length===0&&<div className="py-6 text-center text-xs text-slate-500">정상 연결 이력이 있는 장비 인증 키가 없습니다.</div>}</div>
          </div>
        </div>
      )}

      {/* 사용자 프로필 모달 */}
      {showAppearance&&<div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70" onClick={()=>setShowAppearance(false)}><div className="w-full max-w-md rounded-xl border border-slate-500 bg-slate-900 p-6 shadow-2xl" onClick={e=>e.stopPropagation()}><div className="mb-5 flex items-start justify-between"><div><div className="text-lg font-bold text-white">화면 색상 설정</div><div className="mt-1 text-xs text-slate-300">서로 확실히 다른 화면을 선택합니다. 이 브라우저에 저장됩니다.</div></div><button onClick={()=>setShowAppearance(false)} className="text-xl text-slate-200">✕</button></div><div className="grid grid-cols-2 gap-3">{([{key:'light',name:'그레이',desc:'중간 회색 · 진한 글자',preview:'bg-slate-300 text-slate-950 border-slate-600'},{key:'navy',name:'네이비',desc:'파란 배경 · 밝은 글자',preview:'bg-blue-950 text-blue-50 border-blue-500'},{key:'dark',name:'다크',desc:'무채색 검정 · 흰 글자',preview:'bg-zinc-950 text-white border-zinc-500'},{key:'high-contrast',name:'고대비',desc:'차분한 자주 · 선명한 흰 글자',preview:'bg-purple-950 text-white border-amber-500'}] as const).map(x=><button key={x.key} onClick={()=>changeAppearance(x.key)} className={`min-h-28 rounded-xl border-4 p-4 text-left ${x.preview} ${appearance===x.key?'ring-4 ring-yellow-400 ring-offset-2 ring-offset-slate-900':''}`}><div className="text-base font-black">{x.name}</div><div className="mt-2 text-xs font-bold opacity-90">{x.desc}</div><div className="mt-3 flex gap-1"><span className="h-3 w-8 rounded bg-emerald-600"/><span className="h-3 w-5 rounded bg-yellow-400"/><span className="h-3 w-4 rounded bg-red-600"/></div></button>)}</div><button onClick={()=>setShowAppearance(false)} className="mt-5 w-full rounded-lg bg-emerald-600 px-4 py-3 text-sm font-bold text-white">적용 완료</button></div></div>}
      {showSettings && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50" onClick={() => setShowSettings(false)}>
          <div className="bg-slate-900 border border-slate-700 rounded-lg p-6 w-full max-w-sm" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-center mb-4">
              <div><div className="text-sm font-bold">[{currentUser?.username||'확인 중'}] 내 계정</div><div className="mt-1 text-[11px] text-slate-500">{currentUser?.tenant_name||''} · {currentUser?.role||''} · 로그인 아이디와 비밀번호를 변경합니다.</div></div>
              <button onClick={() => setShowSettings(false)} className="text-slate-500 hover:text-white">✕</button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-xs text-slate-400 block mb-1">현재 비밀번호 *</label>
                <input type="password" value={settingsForm.currentPassword}
                  onChange={e => setSettingsForm(f => ({ ...f, currentPassword: e.target.value }))}
                  className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500" />
              </div>
              <div>
                <label className="text-xs text-slate-400 block mb-1">새 아이디 (변경 시)</label>
                <input type="text" value={settingsForm.newUsername}
                  onChange={e => setSettingsForm(f => ({ ...f, newUsername: e.target.value }))}
                  className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500" />
              </div>
              <div>
                <label className="text-xs text-slate-400 block mb-1">새 비밀번호 (변경 시)</label>
                <input type="password" value={settingsForm.newPassword}
                  onChange={e => setSettingsForm(f => ({ ...f, newPassword: e.target.value }))}
                  className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500" />
              </div>
              <div>
                <label className="text-xs text-slate-400 block mb-1">새 비밀번호 확인</label>
                <input type="password" value={settingsForm.confirmPassword}
                  onChange={e => setSettingsForm(f => ({ ...f, confirmPassword: e.target.value }))}
                  className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500" />
              </div>
              {settingsMsg && <div className="text-xs">{settingsMsg}</div>}
              <button onClick={saveSettings}
                className="w-full bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-400 rounded py-2 text-xs transition-colors">
                프로필 변경 저장
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
