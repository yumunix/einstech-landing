'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function LoginPage() {
  const router = useRouter();
  const [form, setForm] = useState({ username: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [showForgot, setShowForgot] = useState(false);
  const [forgotUsername, setForgotUsername] = useState('');
  const [forgotMsg, setForgotMsg] = useState('');

  const handleForgot = async () => {
    const r = await fetch('/api/reset-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: forgotUsername }),
    });
    await r.json();
    setForgotMsg('등록된 이메일로 재설정 링크를 발송했습니다.');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    const r = await fetch('/api/auth', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    });

    if (r.ok) {
      router.push('/');
    } else {
      const d = await r.json();
      setError(d.error);
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-[#0a0f1e] flex items-center justify-center">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <div className="text-emerald-400 text-xs tracking-widest mb-1">EINSTECH</div>
          <div className="text-2xl font-bold text-white font-mono">AI GUARD</div>
          <div className="text-slate-500 text-xs mt-1">관리자 로그인</div>
        </div>

        <form onSubmit={handleSubmit} className="bg-slate-900 border border-slate-800 rounded-lg p-6 space-y-4">
          <div>
            <label className="text-xs text-slate-400 block mb-1">아이디</label>
            <input
              type="text"
              value={form.username}
              onChange={e => setForm(f => ({ ...f, username: e.target.value }))}
              className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-emerald-500"
              autoFocus
            />
          </div>
          <div>
            <label className="text-xs text-slate-400 block mb-1">비밀번호</label>
            <input
              type="password"
              value={form.password}
              onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
              className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-emerald-500"
            />
          </div>

          {error && <div className="text-red-400 text-xs">{error}</div>}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-400 rounded py-2 text-sm transition-colors disabled:opacity-50">
            {loading ? '로그인 중...' : '로그인'}
          </button>
          <button type="button" onClick={() => setShowForgot(!showForgot)}
            className="text-xs text-slate-500 hover:text-slate-300 w-full text-center pt-1">
            비밀번호를 잊으셨나요?
          </button>
        </form>

        {showForgot && (
          <div className="mt-3 bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-3">
            <div className="text-xs text-slate-400">아이디를 입력하면 등록된 이메일로 재설정 링크를 보냅니다.</div>
            <input type="text" placeholder="아이디" value={forgotUsername}
              onChange={e => setForgotUsername(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-emerald-500" />
            {forgotMsg && <div className="text-xs text-emerald-400">{forgotMsg}</div>}
            <button onClick={handleForgot}
              className="w-full bg-blue-500/20 hover:bg-blue-500/30 border border-blue-500/40 text-blue-400 rounded py-2 text-sm transition-colors">
              재설정 링크 발송
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
