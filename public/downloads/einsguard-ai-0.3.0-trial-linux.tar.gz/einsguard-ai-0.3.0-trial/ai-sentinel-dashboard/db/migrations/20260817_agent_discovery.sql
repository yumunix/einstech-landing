BEGIN;

ALTER TABLE ai_agents ADD COLUMN IF NOT EXISTS local_ips inet[] NOT NULL DEFAULT '{}';
ALTER TABLE ai_agents ADD COLUMN IF NOT EXISTS mac_addresses macaddr[] NOT NULL DEFAULT '{}';

CREATE INDEX IF NOT EXISTS idx_ai_agents_local_ips ON ai_agents USING gin(local_ips);

CREATE TABLE IF NOT EXISTS ai_discovery_settings (
  tenant_id bigint PRIMARY KEY REFERENCES ai_tenants(id) ON DELETE CASCADE,
  enabled boolean NOT NULL DEFAULT false,
  automatic_enabled boolean NOT NULL DEFAULT false,
  scan_interval_minutes integer NOT NULL DEFAULT 1440 CHECK(scan_interval_minutes BETWEEN 60 AND 10080),
  max_hosts integer NOT NULL DEFAULT 4096 CHECK(max_hosts BETWEEN 1 AND 4096),
  timeout_ms integer NOT NULL DEFAULT 800 CHECK(timeout_ms BETWEEN 250 AND 3000),
  concurrency integer NOT NULL DEFAULT 24 CHECK(concurrency BETWEEN 1 AND 64),
  updated_at timestamptz NOT NULL DEFAULT NOW(),
  updated_by varchar(150)
);

CREATE TABLE IF NOT EXISTS ai_discovery_scopes (
  id bigserial PRIMARY KEY,
  tenant_id bigint NOT NULL REFERENCES ai_tenants(id) ON DELETE CASCADE,
  network cidr NOT NULL,
  enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT NOW(),
  updated_at timestamptz NOT NULL DEFAULT NOW(),
  updated_by varchar(150),
  UNIQUE(tenant_id,network)
);

CREATE TABLE IF NOT EXISTS ai_discovery_runs (
  id bigserial PRIMARY KEY,
  tenant_id bigint NOT NULL REFERENCES ai_tenants(id) ON DELETE CASCADE,
  status varchar(20) NOT NULL DEFAULT 'queued'
    CHECK(status IN ('queued','running','completed','failed','cancelled')),
  requested_by varchar(150) NOT NULL,
  requested_at timestamptz NOT NULL DEFAULT NOW(),
  started_at timestamptz,
  completed_at timestamptz,
  scopes text[] NOT NULL DEFAULT '{}',
  hosts_planned integer NOT NULL DEFAULT 0,
  hosts_probed integer NOT NULL DEFAULT 0,
  hosts_responded integer NOT NULL DEFAULT 0,
  error varchar(1000)
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_ai_discovery_one_active_run
  ON ai_discovery_runs(tenant_id) WHERE status IN ('queued','running');
CREATE INDEX IF NOT EXISTS idx_ai_discovery_runs_tenant_time
  ON ai_discovery_runs(tenant_id,requested_at DESC);

CREATE TABLE IF NOT EXISTS ai_discovered_assets (
  id bigserial PRIMARY KEY,
  tenant_id bigint NOT NULL REFERENCES ai_tenants(id) ON DELETE CASCADE,
  ip inet NOT NULL,
  hostname varchar(255),
  mac macaddr,
  discovery_source varchar(30) NOT NULL DEFAULT 'icmp',
  first_seen timestamptz NOT NULL DEFAULT NOW(),
  last_seen timestamptz NOT NULL DEFAULT NOW(),
  last_run_id bigint REFERENCES ai_discovery_runs(id) ON DELETE SET NULL,
  matched_agent_hostname varchar(255),
  match_method varchar(30),
  match_confidence varchar(20),
  UNIQUE(tenant_id,ip)
);
CREATE INDEX IF NOT EXISTS idx_ai_discovered_assets_tenant_seen
  ON ai_discovered_assets(tenant_id,last_seen DESC);

CREATE TABLE IF NOT EXISTS ai_agent_uninstall_approvals (
  id bigserial PRIMARY KEY,
  tenant_id bigint NOT NULL REFERENCES ai_tenants(id) ON DELETE CASCADE,
  hostname varchar(255) NOT NULL,
  token_hash char(64) UNIQUE NOT NULL,
  status varchar(20) NOT NULL DEFAULT 'approved'
    CHECK(status IN ('approved','authorized','expired','cancelled')),
  approved_by varchar(150) NOT NULL,
  approved_at timestamptz NOT NULL DEFAULT NOW(),
  expires_at timestamptz NOT NULL,
  authorized_at timestamptz,
  authorized_ip inet,
  reason varchar(500)
);
CREATE INDEX IF NOT EXISTS idx_ai_uninstall_approvals_tenant_host
  ON ai_agent_uninstall_approvals(tenant_id,hostname,approved_at DESC);

INSERT INTO ai_discovery_settings(tenant_id)
SELECT id FROM ai_tenants ON CONFLICT(tenant_id) DO NOTHING;

COMMIT;
