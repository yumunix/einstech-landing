BEGIN;
CREATE TABLE IF NOT EXISTS ai_reports (
  id bigserial PRIMARY KEY,
  report_type varchar(50) NOT NULL,
  period_start date NOT NULL,
  period_end date NOT NULL,
  title varchar(255) NOT NULL,
  content jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT NOW(),
  created_by varchar(150),
  delivery_status varchar(30) NOT NULL DEFAULT 'draft'
);
CREATE INDEX IF NOT EXISTS idx_ai_reports_period ON ai_reports(period_end DESC, report_type);
COMMIT;
