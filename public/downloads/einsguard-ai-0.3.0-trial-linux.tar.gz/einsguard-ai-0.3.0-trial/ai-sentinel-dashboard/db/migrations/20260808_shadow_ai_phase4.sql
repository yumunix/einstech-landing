BEGIN;

CREATE TABLE IF NOT EXISTS ai_agents (
  hostname varchar(255) PRIMARY KEY,
  os varchar(50) NOT NULL,
  os_version varchar(150),
  arch varchar(50),
  agent_version varchar(30) NOT NULL DEFAULT 'unknown',
  username varchar(150),
  installed_tools jsonb NOT NULL DEFAULT '[]'::jsonb,
  running_tools jsonb NOT NULL DEFAULT '[]'::jsonb,
  approved_tools jsonb NOT NULL DEFAULT '["claude","codex"]'::jsonb,
  last_ip inet,
  first_seen timestamptz NOT NULL DEFAULT NOW(),
  last_seen timestamptz NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS ai_shadow_events (
  id bigserial PRIMARY KEY,
  created_at timestamptz NOT NULL DEFAULT NOW(),
  hostname varchar(255) NOT NULL,
  username varchar(150),
  tool varchar(100) NOT NULL,
  event_type varchar(50) NOT NULL,
  detail text,
  resolved boolean NOT NULL DEFAULT false,
  resolved_at timestamptz,
  resolved_by varchar(150)
);

CREATE INDEX IF NOT EXISTS idx_ai_agents_last_seen ON ai_agents(last_seen DESC);
CREATE INDEX IF NOT EXISTS idx_ai_shadow_events_open ON ai_shadow_events(resolved, created_at DESC);

COMMIT;
