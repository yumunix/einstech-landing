BEGIN;

ALTER TABLE ai_admin_users
  ADD COLUMN IF NOT EXISTS role varchar(30) NOT NULL DEFAULT 'admin';

ALTER TABLE ai_usage
  ADD COLUMN IF NOT EXISTS model varchar(100),
  ADD COLUMN IF NOT EXISTS input_tokens bigint NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS output_tokens bigint NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS cost_usd numeric(14,6) NOT NULL DEFAULT 0;

ALTER TABLE ai_policies
  ADD COLUMN IF NOT EXISTS template_key varchar(50),
  ADD COLUMN IF NOT EXISTS tool varchar(30) NOT NULL DEFAULT '*';

CREATE TABLE IF NOT EXISTS ai_policy_templates (
  template_key varchar(50) PRIMARY KEY,
  name varchar(100) NOT NULL,
  description text NOT NULL,
  allow_start integer NOT NULL,
  allow_end integer NOT NULL,
  max_per_hour integer NOT NULL,
  tool varchar(30) NOT NULL DEFAULT '*',
  risk_level varchar(20) NOT NULL DEFAULT 'MED'
);

CREATE TABLE IF NOT EXISTS ai_settings (
  setting_key varchar(100) PRIMARY KEY,
  setting_value jsonb NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT NOW(),
  updated_by varchar(100)
);

INSERT INTO ai_policy_templates
  (template_key, name, description, allow_start, allow_end, max_per_hour, tool, risk_level)
VALUES
  ('standard', '표준 업무 정책', '업무시간 내 시간당 20회까지 허용', 8, 20, 20, '*', 'LOW'),
  ('strict', '보안 강화 정책', '업무시간 내 시간당 5회까지 허용', 9, 18, 5, '*', 'MED'),
  ('approval', '매회 승인 정책', '모든 AI 실행에 관리자 승인 필요', 0, 23, 0, '*', 'HIGH'),
  ('blocked', '사용 금지 정책', '정책 대상의 AI 실행을 사실상 제한', 0, 0, 0, '*', 'HIGH')
ON CONFLICT (template_key) DO UPDATE SET
  name=EXCLUDED.name, description=EXCLUDED.description,
  allow_start=EXCLUDED.allow_start, allow_end=EXCLUDED.allow_end,
  max_per_hour=EXCLUDED.max_per_hour, tool=EXCLUDED.tool, risk_level=EXCLUDED.risk_level;

INSERT INTO ai_settings (setting_key, setting_value, updated_by)
VALUES
  ('retention', '{"days":90,"enabled":false}'::jsonb, 'system'),
  ('data_protection', '{"maskSecrets":true,"maskEmails":true}'::jsonb, 'system')
ON CONFLICT (setting_key) DO NOTHING;

CREATE INDEX IF NOT EXISTS idx_ai_usage_model_logged_at ON ai_usage(model, logged_at);

COMMIT;
