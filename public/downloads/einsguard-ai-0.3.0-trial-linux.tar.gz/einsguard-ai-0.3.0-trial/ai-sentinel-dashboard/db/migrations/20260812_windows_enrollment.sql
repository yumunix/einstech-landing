CREATE TABLE IF NOT EXISTS ai_agent_enrollments (
  id bigserial PRIMARY KEY,
  tenant_id bigint NOT NULL REFERENCES ai_tenants(id),
  request_hash char(64) NOT NULL UNIQUE,
  hostname varchar(255) NOT NULL,
  username varchar(150),
  os_version varchar(150),
  remote_ip inet,
  status varchar(20) NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected','claimed')),
  issued_key text,
  created_at timestamptz NOT NULL DEFAULT now(),
  decided_at timestamptz,
  decided_by varchar(100),
  claimed_at timestamptz
);
CREATE INDEX IF NOT EXISTS ai_agent_enrollments_pending_idx ON ai_agent_enrollments(tenant_id,status,created_at);
