BEGIN;

ALTER TABLE ai_agents ADD COLUMN IF NOT EXISTS status varchar(20) NOT NULL DEFAULT 'active';
ALTER TABLE ai_agents ADD COLUMN IF NOT EXISTS retired_at timestamptz;
ALTER TABLE ai_agents ADD COLUMN IF NOT EXISTS retired_by varchar(150);
ALTER TABLE ai_agents DROP CONSTRAINT IF EXISTS ai_agents_status_check;
ALTER TABLE ai_agents ADD CONSTRAINT ai_agents_status_check CHECK(status IN ('active','retired'));

ALTER TABLE ai_agent_keys ADD COLUMN IF NOT EXISTS hostname varchar(255);
ALTER TABLE ai_agent_keys ADD COLUMN IF NOT EXISTS platform varchar(50);
ALTER TABLE ai_agent_keys ADD COLUMN IF NOT EXISTS revoked_at timestamptz;
ALTER TABLE ai_agent_keys ADD COLUMN IF NOT EXISTS revoked_by varchar(150);
CREATE INDEX IF NOT EXISTS idx_ai_agent_keys_tenant_hostname ON ai_agent_keys(tenant_id,hostname);

ALTER TABLE ai_agent_enrollments DROP CONSTRAINT IF EXISTS ai_agent_enrollments_status_check;
ALTER TABLE ai_agent_enrollments ADD CONSTRAINT ai_agent_enrollments_status_check
  CHECK(status IN ('pending','approved','rejected','claimed','revoked'));

CREATE TABLE IF NOT EXISTS ai_agent_users (
  tenant_id bigint NOT NULL REFERENCES ai_tenants(id) ON DELETE CASCADE,
  hostname varchar(255) NOT NULL,
  username varchar(150) NOT NULL,
  status varchar(20) NOT NULL DEFAULT 'active' CHECK(status IN ('active','inactive')),
  source varchar(30) NOT NULL DEFAULT 'agent',
  first_seen timestamptz NOT NULL DEFAULT NOW(),
  last_seen timestamptz NOT NULL DEFAULT NOW(),
  inactive_at timestamptz,
  PRIMARY KEY(tenant_id,hostname,username),
  FOREIGN KEY(tenant_id,hostname) REFERENCES ai_agents(tenant_id,hostname) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_ai_agent_users_tenant_status ON ai_agent_users(tenant_id,status,last_seen DESC);

INSERT INTO ai_agent_users(tenant_id,hostname,username,status,source,first_seen,last_seen)
SELECT tenant_id,hostname,username,'active','existing-agent',first_seen,last_seen
FROM ai_agents WHERE COALESCE(username,'')<>''
ON CONFLICT(tenant_id,hostname,username) DO NOTHING;

COMMIT;
