BEGIN;

CREATE TABLE IF NOT EXISTS ai_catalog_entries (
  id bigserial PRIMARY KEY,
  tenant_id bigint NOT NULL,
  tool_key varchar(80) NOT NULL,
  display_name varchar(150) NOT NULL,
  status varchar(30) NOT NULL DEFAULT 'review' CHECK(status IN('active','review','retired','false_positive')),
  processes jsonb NOT NULL DEFAULT '[]'::jsonb,
  commands jsonb NOT NULL DEFAULT '[]'::jsonb,
  domains jsonb NOT NULL DEFAULT '[]'::jsonb,
  aliases jsonb NOT NULL DEFAULT '[]'::jsonb,
  source varchar(50) NOT NULL DEFAULT 'manual',
  notes text,
  created_at timestamptz NOT NULL DEFAULT NOW(),
  updated_at timestamptz NOT NULL DEFAULT NOW(),
  updated_by varchar(150),
  UNIQUE(tenant_id,tool_key)
);

CREATE TABLE IF NOT EXISTS ai_catalog_history (
  id bigserial PRIMARY KEY,
  tenant_id bigint NOT NULL,
  entry_id bigint,
  tool_key varchar(80) NOT NULL,
  action varchar(50) NOT NULL,
  before_value jsonb,
  after_value jsonb,
  changed_at timestamptz NOT NULL DEFAULT NOW(),
  changed_by varchar(150) NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_ai_catalog_status ON ai_catalog_entries(tenant_id,status,updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_ai_catalog_history ON ai_catalog_history(tenant_id,changed_at DESC);

INSERT INTO ai_settings(setting_key,setting_value,updated_by,tenant_id)
SELECT 'catalog_schedule','{"enabled":true,"reviewCycle":"monthly","nextReviewDay":1,"candidateAutoCollect":true,"autoDeployApproved":true}'::jsonb,'system',id
FROM ai_tenants ON CONFLICT(tenant_id,setting_key) DO NOTHING;

COMMIT;
