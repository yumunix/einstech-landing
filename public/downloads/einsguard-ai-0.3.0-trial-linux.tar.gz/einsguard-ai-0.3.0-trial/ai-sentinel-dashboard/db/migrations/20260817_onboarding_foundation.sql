BEGIN;

CREATE TABLE IF NOT EXISTS ai_onboarding_state (
  tenant_id bigint PRIMARY KEY REFERENCES ai_tenants(id) ON DELETE CASCADE,
  status varchar(20) NOT NULL DEFAULT 'pending'
    CHECK(status IN ('pending','configuring','review','completed')),
  current_step integer NOT NULL DEFAULT 1 CHECK(current_step BETWEEN 1 AND 6),
  enforcement_mode varchar(20) NOT NULL DEFAULT 'monitor'
    CHECK(enforcement_mode IN ('monitor','enforce')),
  schema_version integer NOT NULL DEFAULT 1,
  config_revision integer NOT NULL DEFAULT 0 CHECK(config_revision >= 0),
  active_revision integer NOT NULL DEFAULT 0 CHECK(active_revision >= 0),
  acknowledge_no_data_source boolean NOT NULL DEFAULT false,
  completed_at timestamptz,
  completed_by varchar(150),
  last_validated_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT NOW(),
  updated_at timestamptz NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS ai_organization_profiles (
  tenant_id bigint PRIMARY KEY REFERENCES ai_tenants(id) ON DELETE CASCADE,
  company_name varchar(200) NOT NULL,
  company_domains text[] NOT NULL DEFAULT '{}',
  internal_cidrs text[] NOT NULL DEFAULT '{}',
  timezone varchar(80) NOT NULL DEFAULT 'Asia/Seoul',
  data_residency varchar(30) NOT NULL DEFAULT 'onpremise'
    CHECK(data_residency IN ('onpremise','private_cloud','hybrid')),
  created_at timestamptz NOT NULL DEFAULT NOW(),
  updated_at timestamptz NOT NULL DEFAULT NOW(),
  updated_by varchar(150)
);

CREATE TABLE IF NOT EXISTS ai_destinations (
  id bigserial PRIMARY KEY,
  tenant_id bigint NOT NULL REFERENCES ai_tenants(id) ON DELETE CASCADE,
  name varchar(150) NOT NULL,
  destination_type varchar(40) NOT NULL
    CHECK(destination_type IN ('internal_ai','approved_external_ai','unapproved_external_ai','other')),
  match_type varchar(20) NOT NULL
    CHECK(match_type IN ('domain','url','application','ip','cidr')),
  match_value varchar(500) NOT NULL,
  decision varchar(20) NOT NULL
    CHECK(decision IN ('allow','audit','block')),
  notes varchar(500),
  enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT NOW(),
  updated_at timestamptz NOT NULL DEFAULT NOW(),
  updated_by varchar(150)
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_ai_destinations_unique_match
  ON ai_destinations(tenant_id,match_type,lower(match_value));
CREATE INDEX IF NOT EXISTS idx_ai_destinations_policy
  ON ai_destinations(tenant_id,enabled,decision,destination_type);

CREATE TABLE IF NOT EXISTS ai_classification_rules (
  id bigserial PRIMARY KEY,
  tenant_id bigint NOT NULL REFERENCES ai_tenants(id) ON DELETE CASCADE,
  name varchar(150) NOT NULL,
  classification_level varchar(20) NOT NULL
    CHECK(classification_level IN ('PUBLIC','INTERNAL','CONFIDENTIAL','RESTRICTED')),
  rule_type varchar(30) NOT NULL
    CHECK(rule_type IN ('keyword','dictionary','source_label','fingerprint','regex')),
  pattern text NOT NULL,
  action varchar(20) NOT NULL
    CHECK(action IN ('allow','audit','warn','block')),
  weight integer NOT NULL DEFAULT 50 CHECK(weight BETWEEN 1 AND 100),
  case_sensitive boolean NOT NULL DEFAULT false,
  enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT NOW(),
  updated_at timestamptz NOT NULL DEFAULT NOW(),
  updated_by varchar(150),
  UNIQUE(tenant_id,name)
);
CREATE INDEX IF NOT EXISTS idx_ai_classification_rules_active
  ON ai_classification_rules(tenant_id,enabled,classification_level);

CREATE TABLE IF NOT EXISTS ai_data_sources (
  id bigserial PRIMARY KEY,
  tenant_id bigint NOT NULL REFERENCES ai_tenants(id) ON DELETE CASCADE,
  name varchar(150) NOT NULL,
  source_type varchar(30) NOT NULL
    CHECK(source_type IN ('filesystem','nas','webdav','sharepoint','database','custom')),
  location varchar(1000) NOT NULL,
  status varchar(20) NOT NULL DEFAULT 'draft'
    CHECK(status IN ('draft','connected','indexing','ready','error','disabled')),
  config jsonb NOT NULL DEFAULT '{}'::jsonb,
  secret_ref varchar(300),
  last_indexed_at timestamptz,
  last_error varchar(500),
  enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT NOW(),
  updated_at timestamptz NOT NULL DEFAULT NOW(),
  updated_by varchar(150),
  UNIQUE(tenant_id,name)
);
CREATE INDEX IF NOT EXISTS idx_ai_data_sources_status
  ON ai_data_sources(tenant_id,enabled,status);

CREATE TABLE IF NOT EXISTS ai_policy_versions (
  id bigserial PRIMARY KEY,
  tenant_id bigint NOT NULL REFERENCES ai_tenants(id) ON DELETE CASCADE,
  version integer NOT NULL,
  status varchar(20) NOT NULL DEFAULT 'draft'
    CHECK(status IN ('draft','active','retired')),
  snapshot jsonb NOT NULL,
  notes varchar(500),
  created_at timestamptz NOT NULL DEFAULT NOW(),
  created_by varchar(150) NOT NULL,
  activated_at timestamptz,
  UNIQUE(tenant_id,version)
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_ai_policy_versions_one_active
  ON ai_policy_versions(tenant_id) WHERE status='active';

CREATE TABLE IF NOT EXISTS ai_configuration_audit (
  id bigserial PRIMARY KEY,
  tenant_id bigint NOT NULL REFERENCES ai_tenants(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT NOW(),
  username varchar(150) NOT NULL,
  action varchar(80) NOT NULL,
  object_type varchar(80) NOT NULL,
  object_id varchar(100),
  summary varchar(500) NOT NULL,
  details jsonb NOT NULL DEFAULT '{}'::jsonb,
  remote_ip inet
);
CREATE INDEX IF NOT EXISTS idx_ai_configuration_audit_tenant_time
  ON ai_configuration_audit(tenant_id,created_at DESC);

INSERT INTO ai_onboarding_state(tenant_id)
SELECT id FROM ai_tenants ON CONFLICT(tenant_id) DO NOTHING;

INSERT INTO ai_organization_profiles(tenant_id,company_name)
SELECT id,name FROM ai_tenants ON CONFLICT(tenant_id) DO NOTHING;

INSERT INTO ai_classification_rules
  (tenant_id,name,classification_level,rule_type,pattern,action,weight,updated_by)
SELECT t.id,v.name,v.level,v.rule_type,v.pattern,v.action,v.weight,'system'
FROM ai_tenants t CROSS JOIN (VALUES
  ('기밀 표시','RESTRICTED','keyword','대외비','block',100),
  ('영문 기밀 표시','RESTRICTED','keyword','confidential','block',100),
  ('내부 전용 표시','INTERNAL','keyword','internal use only','audit',60),
  ('고객 정보 표시','CONFIDENTIAL','keyword','고객정보','warn',80)
) AS v(name,level,rule_type,pattern,action,weight)
ON CONFLICT(tenant_id,name) DO NOTHING;

COMMIT;
