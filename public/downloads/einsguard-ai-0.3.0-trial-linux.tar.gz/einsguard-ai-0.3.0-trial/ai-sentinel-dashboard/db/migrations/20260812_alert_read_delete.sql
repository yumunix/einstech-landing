BEGIN;
ALTER TABLE ai_alerts ADD COLUMN IF NOT EXISTS read_at timestamptz;
ALTER TABLE ai_alerts ADD COLUMN IF NOT EXISTS read_by varchar(150);
ALTER TABLE ai_alerts ADD COLUMN IF NOT EXISTS deleted_at timestamptz;
ALTER TABLE ai_alerts ADD COLUMN IF NOT EXISTS deleted_by varchar(150);
CREATE INDEX IF NOT EXISTS idx_ai_alerts_unread ON ai_alerts(tenant_id,read_at,created_at DESC) WHERE deleted_at IS NULL;
COMMIT;
