CREATE TABLE IF NOT EXISTS ai_licenses (
  tenant_id bigint PRIMARY KEY REFERENCES ai_tenants(id) ON DELETE CASCADE,
  installation_id uuid NOT NULL DEFAULT gen_random_uuid(),
  license_type varchar(20) NOT NULL DEFAULT 'trial',
  plan varchar(30) NOT NULL DEFAULT 'trial',
  status varchar(20) NOT NULL DEFAULT 'active',
  starts_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL DEFAULT (now() + interval '15 days'),
  agent_limit integer NOT NULL DEFAULT 5 CHECK (agent_limit >= 0),
  license_hash varchar(64),
  last_verified_at timestamptz,
  last_seen_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

INSERT INTO ai_licenses(tenant_id)
SELECT id FROM ai_tenants
ON CONFLICT(tenant_id) DO NOTHING;
