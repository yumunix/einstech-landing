BEGIN;

CREATE TABLE IF NOT EXISTS ai_dlp_events (
  id bigserial PRIMARY KEY,
  tenant_id bigint NOT NULL,
  created_at timestamptz NOT NULL DEFAULT NOW(),
  hostname varchar(255) NOT NULL,
  username varchar(150),
  tool varchar(100) NOT NULL,
  channel varchar(30) NOT NULL,
  violation_type varchar(80) NOT NULL,
  severity varchar(10) NOT NULL,
  evidence_hash char(64) NOT NULL,
  masked_evidence varchar(500),
  match_count integer NOT NULL DEFAULT 1,
  action_taken varchar(50),
  raw_content text,
  raw_expires_at timestamptz
);

ALTER TABLE ai_dlp_events
  ADD COLUMN IF NOT EXISTS ai_verified_reason varchar(300),
  ADD COLUMN IF NOT EXISTS ai_verification_status varchar(30) NOT NULL DEFAULT 'not_requested',
  ADD COLUMN IF NOT EXISTS ai_provider varchar(50),
  ADD COLUMN IF NOT EXISTS ai_model varchar(150),
  ADD COLUMN IF NOT EXISTS ai_latency_ms integer;

CREATE TABLE IF NOT EXISTS ai_audit_access_log (
  id bigserial PRIMARY KEY,
  tenant_id bigint NOT NULL,
  created_at timestamptz NOT NULL DEFAULT NOW(),
  username varchar(150) NOT NULL,
  action varchar(80) NOT NULL,
  object_type varchar(80) NOT NULL,
  object_id varchar(100),
  reason text,
  remote_ip inet
);

CREATE INDEX IF NOT EXISTS idx_ai_dlp_events_tenant_time ON ai_dlp_events(tenant_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_ai_dlp_events_hash ON ai_dlp_events(tenant_id,evidence_hash,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_ai_audit_access_tenant_time ON ai_audit_access_log(tenant_id,created_at DESC);

INSERT INTO ai_settings(setting_key,setting_value,updated_by,tenant_id)
SELECT 'dlp_policy','{"enabled":true,"blockCritical":true,"storeRawChat":false,"inspectInternalFingerprints":true,"inspectContentWithLocalAi":true,"aiVerification":true,"evidenceRetentionDays":90,"rawRetentionDays":7,"rawAccessRoles":["admin","security"],"scanClipboard":true,"scanCliArguments":true}'::jsonb,'system',id
FROM ai_tenants
ON CONFLICT(tenant_id,setting_key) DO UPDATE
SET setting_value=EXCLUDED.setting_value||ai_settings.setting_value,updated_at=NOW();

COMMIT;
