BEGIN;

ALTER TABLE ai_alerts
  ADD COLUMN IF NOT EXISTS session_id varchar(200),
  ADD COLUMN IF NOT EXISTS risk_score integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS risk_reason text,
  ADD COLUMN IF NOT EXISTS auto_action varchar(30);

CREATE INDEX IF NOT EXISTS idx_ai_alerts_session_id ON ai_alerts(session_id);
CREATE INDEX IF NOT EXISTS idx_ai_commands_session_command_status
  ON ai_commands(session_id, command, status);

COMMIT;
