BEGIN;

ALTER TABLE ai_commands ADD COLUMN IF NOT EXISTS heartbeat_at timestamptz;

UPDATE ai_commands c
SET status='ended',executed_at=COALESCE(c.executed_at,s.ended_at,NOW())
FROM ai_sessions s
WHERE c.tenant_id=s.tenant_id AND c.session_id=s.session_id
  AND c.command='registered' AND c.status='active' AND s.ended_at IS NOT NULL;

UPDATE ai_commands
SET status='stale'
WHERE command='registered' AND status='active' AND created_at<NOW()-INTERVAL '10 minutes';

UPDATE ai_commands
SET heartbeat_at=created_at
WHERE command='registered' AND status='active' AND heartbeat_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_ai_commands_live_sessions
  ON ai_commands(tenant_id,status,heartbeat_at DESC)
  WHERE command='registered';

COMMIT;
