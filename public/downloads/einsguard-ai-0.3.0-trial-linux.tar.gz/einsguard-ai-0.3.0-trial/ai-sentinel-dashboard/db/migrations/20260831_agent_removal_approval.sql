BEGIN;

-- Agent self-removal now requires management-server admin approval.
-- The agent's uninstall routine opens a removal request here, waits for an
-- admin decision in the dashboard, and only proceeds once approved.
CREATE TABLE IF NOT EXISTS ai_agent_removal_requests (
  id bigserial PRIMARY KEY,
  tenant_id bigint NOT NULL REFERENCES ai_tenants(id),
  request_hash char(64) NOT NULL UNIQUE,
  hostname varchar(255) NOT NULL,
  username varchar(150),
  os_version varchar(150),
  remote_ip inet,
  reason text,
  status varchar(20) NOT NULL DEFAULT 'pending'
    CHECK(status IN ('pending','approved','rejected','completed','expired')),
  created_at timestamptz NOT NULL DEFAULT now(),
  decided_at timestamptz,
  decided_by varchar(100),
  completed_at timestamptz
);
CREATE INDEX IF NOT EXISTS ai_agent_removal_requests_pending_idx
  ON ai_agent_removal_requests(tenant_id,status,created_at);

COMMIT;
