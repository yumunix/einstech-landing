BEGIN;
CREATE TABLE IF NOT EXISTS ai_service_subscriptions (
  id bigserial PRIMARY KEY,
  tenant_id bigint NOT NULL,
  service_key varchar(80) NOT NULL,
  service_name varchar(150) NOT NULL,
  plan_name varchar(100) NOT NULL,
  seats integer NOT NULL DEFAULT 1 CHECK(seats>0),
  unit_price numeric(14,2) NOT NULL DEFAULT 0 CHECK(unit_price>=0),
  currency varchar(3) NOT NULL DEFAULT 'USD' CHECK(currency IN('USD','KRW')),
  billing_cycle varchar(20) NOT NULL DEFAULT 'monthly',
  starts_at date NOT NULL DEFAULT CURRENT_DATE,
  ends_at date,
  enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT NOW(),
  updated_at timestamptz NOT NULL DEFAULT NOW(),
  updated_by varchar(150)
);
CREATE INDEX IF NOT EXISTS idx_ai_subscriptions_active ON ai_service_subscriptions(tenant_id,enabled,service_key);
COMMIT;
