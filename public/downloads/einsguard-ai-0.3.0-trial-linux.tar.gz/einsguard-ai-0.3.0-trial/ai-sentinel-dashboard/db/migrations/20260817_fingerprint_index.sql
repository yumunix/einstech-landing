BEGIN;

CREATE TABLE IF NOT EXISTS ai_index_jobs (
  id bigserial PRIMARY KEY,
  tenant_id bigint NOT NULL REFERENCES ai_tenants(id) ON DELETE CASCADE,
  data_source_id bigint NOT NULL REFERENCES ai_data_sources(id) ON DELETE CASCADE,
  status varchar(20) NOT NULL DEFAULT 'queued'
    CHECK(status IN ('queued','running','completed','failed','cancelled')),
  requested_by varchar(150) NOT NULL,
  requested_at timestamptz NOT NULL DEFAULT NOW(),
  started_at timestamptz,
  completed_at timestamptz,
  files_indexed integer NOT NULL DEFAULT 0,
  files_skipped integer NOT NULL DEFAULT 0,
  fingerprints_indexed integer NOT NULL DEFAULT 0,
  error varchar(1000)
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_ai_index_jobs_one_active
  ON ai_index_jobs(data_source_id) WHERE status IN ('queued','running');
CREATE INDEX IF NOT EXISTS idx_ai_index_jobs_queue
  ON ai_index_jobs(status,requested_at);

CREATE TABLE IF NOT EXISTS ai_indexed_documents (
  id bigserial PRIMARY KEY,
  tenant_id bigint NOT NULL REFERENCES ai_tenants(id) ON DELETE CASCADE,
  data_source_id bigint NOT NULL REFERENCES ai_data_sources(id) ON DELETE CASCADE,
  relative_path varchar(2000) NOT NULL,
  content_hmac varchar(64) NOT NULL,
  file_size bigint NOT NULL CHECK(file_size>=0),
  modified_at timestamptz,
  classification_level varchar(20) NOT NULL DEFAULT 'INTERNAL'
    CHECK(classification_level IN ('PUBLIC','INTERNAL','CONFIDENTIAL','RESTRICTED')),
  fingerprint_count integer NOT NULL DEFAULT 0 CHECK(fingerprint_count>=0),
  last_seen_job_id bigint REFERENCES ai_index_jobs(id) ON DELETE SET NULL,
  indexed_at timestamptz NOT NULL DEFAULT NOW(),
  deleted_at timestamptz,
  UNIQUE(data_source_id,relative_path)
);
CREATE INDEX IF NOT EXISTS idx_ai_indexed_documents_source
  ON ai_indexed_documents(tenant_id,data_source_id,deleted_at);

CREATE TABLE IF NOT EXISTS ai_document_fingerprints (
  tenant_id bigint NOT NULL REFERENCES ai_tenants(id) ON DELETE CASCADE,
  document_id bigint NOT NULL REFERENCES ai_indexed_documents(id) ON DELETE CASCADE,
  fingerprint varchar(64) NOT NULL,
  PRIMARY KEY(tenant_id,document_id,fingerprint)
);
CREATE INDEX IF NOT EXISTS idx_ai_document_fingerprints_lookup
  ON ai_document_fingerprints(tenant_id,fingerprint);

ALTER TABLE ai_dlp_events
  ADD COLUMN IF NOT EXISTS internal_match_count integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS internal_document_id bigint REFERENCES ai_indexed_documents(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS internal_data_source_id bigint REFERENCES ai_data_sources(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS internal_classification_level varchar(20);

COMMIT;
