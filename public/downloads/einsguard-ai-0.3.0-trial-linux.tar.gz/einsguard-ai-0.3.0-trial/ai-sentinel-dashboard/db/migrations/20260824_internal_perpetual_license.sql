BEGIN;

ALTER TABLE ai_licenses ALTER COLUMN license_type SET DEFAULT 'perpetual';
ALTER TABLE ai_licenses ALTER COLUMN plan SET DEFAULT 'internal';
ALTER TABLE ai_licenses ALTER COLUMN expires_at DROP DEFAULT;
ALTER TABLE ai_licenses ALTER COLUMN expires_at DROP NOT NULL;
ALTER TABLE ai_licenses ALTER COLUMN agent_limit SET DEFAULT 0;

UPDATE ai_licenses
SET license_type = 'perpetual',
    plan = 'internal',
    status = 'active',
    expires_at = NULL,
    agent_limit = 0,
    license_hash = NULL,
    last_verified_at = NOW(),
    updated_at = NOW();

COMMIT;
