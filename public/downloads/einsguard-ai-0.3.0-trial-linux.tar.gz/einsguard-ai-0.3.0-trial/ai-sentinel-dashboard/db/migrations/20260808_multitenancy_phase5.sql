BEGIN;

CREATE TABLE IF NOT EXISTS ai_tenants (
  id bigserial PRIMARY KEY,
  code varchar(50) UNIQUE NOT NULL,
  name varchar(150) NOT NULL,
  enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT NOW()
);
INSERT INTO ai_tenants(id,code,name) VALUES(1,'einstech','EINSTECH')
ON CONFLICT(code) DO UPDATE SET name=EXCLUDED.name,enabled=true;
SELECT setval(pg_get_serial_sequence('ai_tenants','id'),GREATEST((SELECT MAX(id) FROM ai_tenants),1));

CREATE TABLE IF NOT EXISTS ai_agent_keys (
  id bigserial PRIMARY KEY,
  tenant_id bigint NOT NULL REFERENCES ai_tenants(id),
  key_name varchar(100) NOT NULL,
  key_hash char(64) UNIQUE NOT NULL,
  enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT NOW(),
  last_used_at timestamptz
);
INSERT INTO ai_agent_keys(tenant_id,key_name,key_hash)
VALUES(1,'EINSTECH 기본 에이전트 키','58a951da079f3fab32d35baecfc005c77e4b0e3298c04b179058665ea4f6b1da')
ON CONFLICT(key_hash) DO NOTHING;

ALTER TABLE ai_admin_users ADD COLUMN IF NOT EXISTS tenant_id bigint NOT NULL DEFAULT 1 REFERENCES ai_tenants(id);
ALTER TABLE ai_admin_users ADD COLUMN IF NOT EXISTS platform_admin boolean NOT NULL DEFAULT false;
UPDATE ai_admin_users SET platform_admin=true WHERE username='yumunix' AND tenant_id=1;
ALTER TABLE ai_usage ADD COLUMN IF NOT EXISTS tenant_id bigint NOT NULL DEFAULT 1 REFERENCES ai_tenants(id);
ALTER TABLE ai_sessions ADD COLUMN IF NOT EXISTS tenant_id bigint NOT NULL DEFAULT 1 REFERENCES ai_tenants(id);
ALTER TABLE ai_alerts ADD COLUMN IF NOT EXISTS tenant_id bigint NOT NULL DEFAULT 1 REFERENCES ai_tenants(id);
ALTER TABLE ai_approvals ADD COLUMN IF NOT EXISTS tenant_id bigint NOT NULL DEFAULT 1 REFERENCES ai_tenants(id);
ALTER TABLE ai_blocks ADD COLUMN IF NOT EXISTS tenant_id bigint NOT NULL DEFAULT 1 REFERENCES ai_tenants(id);
ALTER TABLE ai_commands ADD COLUMN IF NOT EXISTS tenant_id bigint NOT NULL DEFAULT 1 REFERENCES ai_tenants(id);
ALTER TABLE ai_policies ADD COLUMN IF NOT EXISTS tenant_id bigint NOT NULL DEFAULT 1 REFERENCES ai_tenants(id);
ALTER TABLE ai_settings ADD COLUMN IF NOT EXISTS tenant_id bigint NOT NULL DEFAULT 1 REFERENCES ai_tenants(id);
ALTER TABLE ai_settings DROP CONSTRAINT IF EXISTS ai_settings_pkey;
ALTER TABLE ai_settings ADD CONSTRAINT ai_settings_pkey PRIMARY KEY(tenant_id,setting_key);
ALTER TABLE ai_agents ADD COLUMN IF NOT EXISTS tenant_id bigint NOT NULL DEFAULT 1 REFERENCES ai_tenants(id);
ALTER TABLE ai_agents DROP CONSTRAINT IF EXISTS ai_agents_pkey;
ALTER TABLE ai_agents ADD CONSTRAINT ai_agents_pkey PRIMARY KEY(tenant_id,hostname);
ALTER TABLE ai_shadow_events ADD COLUMN IF NOT EXISTS tenant_id bigint NOT NULL DEFAULT 1 REFERENCES ai_tenants(id);
ALTER TABLE ai_reports ADD COLUMN IF NOT EXISTS tenant_id bigint NOT NULL DEFAULT 1 REFERENCES ai_tenants(id);
ALTER TABLE ai_password_resets ADD COLUMN IF NOT EXISTS tenant_id bigint NOT NULL DEFAULT 1 REFERENCES ai_tenants(id);

CREATE INDEX IF NOT EXISTS idx_ai_usage_tenant_time ON ai_usage(tenant_id,logged_at DESC);
CREATE INDEX IF NOT EXISTS idx_ai_sessions_tenant_time ON ai_sessions(tenant_id,started_at DESC);
CREATE INDEX IF NOT EXISTS idx_ai_alerts_tenant_time ON ai_alerts(tenant_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_ai_commands_tenant_session ON ai_commands(tenant_id,session_id);
CREATE INDEX IF NOT EXISTS idx_ai_agents_tenant_seen ON ai_agents(tenant_id,last_seen DESC);
CREATE INDEX IF NOT EXISTS idx_ai_reports_tenant_period ON ai_reports(tenant_id,period_end DESC);

COMMIT;
