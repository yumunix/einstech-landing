export async function register(){
  if(process.env.NEXT_RUNTIME!=='nodejs'||process.env.NEXT_PHASE==='phase-production-build')return;
  const {runScheduledConfigBackups}=await import('./lib/config-backup');
  const start=setTimeout(()=>void runScheduledConfigBackups(),15_000);start.unref();
  const timer=setInterval(()=>void runScheduledConfigBackups(),60_000);timer.unref();
}
