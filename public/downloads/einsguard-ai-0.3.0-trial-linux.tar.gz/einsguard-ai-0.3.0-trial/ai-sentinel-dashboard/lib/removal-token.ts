import jwt from 'jsonwebtoken';

// 에이전트 제거 승인 증표. 관리 서버가 서명하고, 제거 스크립트가 검증한다.
const SECRET = process.env.SESSION_SECRET || 'development-only-session-secret-change-me';

export interface RemovalTokenClaims {
  purpose: 'agent-removal';
  hostname: string;
  tenant_id: number;
  removal_id: number;
}

export function signRemovalToken(input: { hostname: string; tenantId: number; removalId: number }) {
  return jwt.sign(
    { purpose: 'agent-removal', hostname: input.hostname, tenant_id: input.tenantId, removal_id: input.removalId },
    SECRET,
    { expiresIn: '2h' },
  );
}

export function verifyRemovalToken(token: string): RemovalTokenClaims | null {
  try {
    const decoded = jwt.verify(token, SECRET) as RemovalTokenClaims;
    return decoded.purpose === 'agent-removal' ? decoded : null;
  } catch {
    return null;
  }
}
