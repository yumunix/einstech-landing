import net from 'node:net';

export class DiscoveryInputError extends Error{
  constructor(message:string){super(message);this.name='DiscoveryInputError';}
}

function ipv4Number(value:string){
  if(net.isIP(value)!==4)throw new DiscoveryInputError('IPv4 주소만 사용할 수 있습니다.');
  return value.split('.').reduce((total,part)=>(total*256+Number(part))>>>0,0)>>>0;
}

function ipv4Text(value:number){return [24,16,8,0].map(shift=>(value>>>shift)&255).join('.');}

export function parseIpv4Cidr(value:string){
  const normalized=String(value||'').trim();
  const [address,prefixText,...extra]=normalized.split('/');
  if(extra.length||net.isIP(address)!==4||!/^(?:[0-9]|[12][0-9]|3[0-2])$/.test(prefixText||''))throw new DiscoveryInputError('검색 대역은 IPv4 CIDR 형식이어야 합니다.');
  const prefix=Number(prefixText);const addressNumber=ipv4Number(address);
  const mask=prefix===0?0:(0xffffffff<<(32-prefix))>>>0;
  const network=(addressNumber&mask)>>>0;const size=2**(32-prefix);
  return {cidr:`${ipv4Text(network)}/${prefix}`,network,prefix,size,broadcast:(network+size-1)>>>0};
}

export function isPrivateIpv4Cidr(value:string){
  const parsed=parseIpv4Cidr(value);
  const ranges=['10.0.0.0/8','172.16.0.0/12','192.168.0.0/16'].map(parseIpv4Cidr);
  return ranges.some(range=>parsed.network>=range.network&&parsed.broadcast<=range.broadcast);
}

export function cidrContains(parent:string,child:string){
  const outer=parseIpv4Cidr(parent);const inner=parseIpv4Cidr(child);
  return inner.network>=outer.network&&inner.broadcast<=outer.broadcast;
}

export function usableHostCount(value:string){
  const parsed=parseIpv4Cidr(value);
  return parsed.prefix<=30?Math.max(0,parsed.size-2):parsed.size;
}

export function enumerateIpv4Hosts(value:string,limit=4096){
  const parsed=parseIpv4Cidr(value);const count=usableHostCount(value);
  if(count>limit)throw new DiscoveryInputError(`검색 대상이 ${limit.toLocaleString()}대를 초과합니다. 대역을 더 작게 나누십시오.`);
  const start=parsed.prefix<=30?parsed.network+1:parsed.network;
  return Array.from({length:count},(_,index)=>ipv4Text((start+index)>>>0));
}

export function normalizeMac(value:unknown){
  const compact=String(value||'').trim().replace(/[^0-9a-f]/gi,'').toLowerCase();
  if(!/^[0-9a-f]{12}$/.test(compact)||compact==='000000000000')return null;
  return compact.match(/../g)!.join(':');
}

export function normalizeAgentNetworks(ips:unknown,macs:unknown){
  const localIps=[...new Set((Array.isArray(ips)?ips:[]).map(value=>String(value||'').trim()).filter(value=>net.isIP(value)===4&&!value.startsWith('127.')))].slice(0,32);
  const macAddresses=[...new Set((Array.isArray(macs)?macs:[]).map(normalizeMac).filter((value):value is string=>Boolean(value)))].slice(0,32);
  return {localIps,macAddresses};
}
