import pool from '@/lib/db';

export type AgentPolicyMode='monitor'|'enforce';

export type ActivePolicySnapshot={
  destinations?:Array<{id?:number|string;name?:string;destination_type?:string;match_type?:string;match_value?:string;decision?:string;enabled?:boolean}>;
  classification_rules?:Array<{name?:string;classification_level?:string;rule_type?:string;pattern?:string;action?:string;weight?:number;case_sensitive?:boolean;enabled?:boolean}>;
  data_sources?:Array<{id?:number|string;name?:string;source_type?:string;location?:string;enabled?:boolean}>;
  dlp_policy?:Record<string,unknown>;
};

export async function getAgentPolicyState(tenantId:number){
  const {rows}=await pool.query(`SELECT s.status,s.enforcement_mode,s.config_revision,s.active_revision,
    p.version active_policy_version
    FROM ai_onboarding_state s
    LEFT JOIN ai_policy_versions p ON p.tenant_id=s.tenant_id AND p.status='active'
    WHERE s.tenant_id=$1`,[tenantId]);
  const row=rows[0];
  const ready=Boolean(row?.status==='completed'&&row?.active_policy_version);
  return {
    mode:(ready&&row.enforcement_mode==='enforce'?'enforce':'monitor') as AgentPolicyMode,
    onboardingStatus:row?.status||'pending',
    activePolicyVersion:row?.active_policy_version?Number(row.active_policy_version):null,
    draftPending:Boolean(row&&row.config_revision!==row.active_revision),
  };
}

export async function getActivePolicySnapshot(tenantId:number):Promise<ActivePolicySnapshot|null>{
  const {rows}=await pool.query(`SELECT p.snapshot FROM ai_onboarding_state s
    JOIN ai_policy_versions p ON p.tenant_id=s.tenant_id AND p.status='active'
    WHERE s.tenant_id=$1 AND s.status='completed'`,[tenantId]);
  const snapshot=rows[0]?.snapshot;
  return snapshot&&typeof snapshot==='object'?snapshot as ActivePolicySnapshot:null;
}
