import net from 'node:net';
import type {PoolClient} from 'pg';

export const onboardingSteps=[
  'organization',
  'destinations',
  'classification',
  'data_sources',
  'review',
  'completed',
] as const;

const destinationTypes=new Set(['internal_ai','approved_external_ai','unapproved_external_ai','other']);
const matchTypes=new Set(['domain','url','application','ip','cidr']);
const decisions=new Set(['allow','audit','block']);
const levels=new Set(['PUBLIC','INTERNAL','CONFIDENTIAL','RESTRICTED']);
const ruleTypes=new Set(['keyword','dictionary','source_label']);
const actions=new Set(['allow','audit','warn','block']);
const sourceTypes=new Set(['filesystem','nas','webdav','sharepoint','database','custom']);
const residencies=new Set(['onpremise','private_cloud','hybrid']);
const allowedSourceConfigKeys=new Set(['recursive','includeExtensions','excludePaths','maxFileSizeMb','classificationLevel','library','siteUrl','databaseType']);
const allowedSourceInputKeys=new Set(['id','name','source_type','location','config','enabled']);
const secretKeyPattern=/(password|passwd|secret|token|api.?key|credential|private.?key|access.?key)/i;

export class OnboardingInputError extends Error{
  constructor(message:string){super(message);this.name='OnboardingInputError';}
}

function invalid(message:string):never{throw new OnboardingInputError(message);}

function text(value:unknown,max:number){return String(value??'').trim().slice(0,max);}
function unique(values:string[]){return [...new Set(values)];}

export function validDomain(value:string,allowWildcard=false){
  const domain=value.toLowerCase().replace(/\.$/,'');
  const normalized=allowWildcard&&domain.startsWith('*.')?domain.slice(2):domain;
  if(normalized.length<3||normalized.length>253||!normalized.includes('.'))return false;
  return normalized.split('.').every(label=>/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(label));
}

export function validCidr(value:string){
  const [address,prefix,...extra]=value.split('/');
  if(extra.length||prefix===undefined)return false;
  const family=net.isIP(address);
  if(!family||!/^[0-9]{1,3}$/.test(prefix))return false;
  const bits=Number(prefix);
  return family===4?bits>=0&&bits<=32:bits>=0&&bits<=128;
}

export function validHttpUrl(value:string){
  try{
    const url=new URL(value);
    return ['http:','https:'].includes(url.protocol)&&!url.username&&!url.password&&Boolean(url.hostname);
  }catch{return false;}
}

export function validateOrganization(input:any){
  const companyName=text(input?.company_name,200);
  if(companyName.length<2)invalid('회사명은 2자 이상이어야 합니다.');
  const domains=unique((Array.isArray(input?.company_domains)?input.company_domains:[]).map((x:unknown)=>text(x,253).toLowerCase()).filter(Boolean));
  if(domains.length>50||domains.some((x:string)=>!validDomain(x)))invalid('회사 도메인 형식이 올바르지 않습니다.');
  const cidrs=unique((Array.isArray(input?.internal_cidrs)?input.internal_cidrs:[]).map((x:unknown)=>text(x,100)).filter(Boolean));
  if(cidrs.length>100||cidrs.some((x:string)=>!validCidr(x)))invalid('내부 IP 대역은 CIDR 형식으로 입력하십시오.');
  const timezone=text(input?.timezone||'Asia/Seoul',80);
  try{new Intl.DateTimeFormat('ko-KR',{timeZone:timezone}).format();}
  catch{invalid('시간대는 올바른 IANA 시간대여야 합니다.');}
  const dataResidency=text(input?.data_residency||'onpremise',30);
  if(!residencies.has(dataResidency))invalid('데이터 보관 위치 설정이 올바르지 않습니다.');
  return {companyName,domains,cidrs,timezone,dataResidency};
}

export function validateDestinations(input:any){
  if(!Array.isArray(input)||input.length>100)invalid('AI 목적지는 최대 100개까지 등록할 수 있습니다.');
  const seen=new Set<string>();
  return input.map((item:any,index:number)=>{
    const name=text(item?.name,150);const destinationType=text(item?.destination_type,40);
    const matchType=text(item?.match_type,20);let matchValue=text(item?.match_value,500);
    const decision=text(item?.decision,20);const notes=text(item?.notes,500);
    if(name.length<2||!destinationTypes.has(destinationType)||!matchTypes.has(matchType)||!decisions.has(decision))invalid(`${index+1}번째 AI 목적지 설정이 올바르지 않습니다.`);
    if(matchType==='domain'){
      matchValue=matchValue.toLowerCase();
      if(!validDomain(matchValue,true))invalid(`${name}의 도메인 형식이 올바르지 않습니다.`);
    }else if(matchType==='url'&&!validHttpUrl(matchValue))invalid(`${name}의 URL 형식이 올바르지 않습니다.`);
    else if(matchType==='ip'&&!net.isIP(matchValue))invalid(`${name}의 IP 형식이 올바르지 않습니다.`);
    else if(matchType==='cidr'&&!validCidr(matchValue))invalid(`${name}의 CIDR 형식이 올바르지 않습니다.`);
    else if(matchType==='application'&&!/^[A-Za-z0-9._ -]{2,120}$/.test(matchValue))invalid(`${name}의 애플리케이션 식별자가 올바르지 않습니다.`);
    const key=`${matchType}:${matchValue.toLowerCase()}`;if(seen.has(key))invalid(`중복된 AI 목적지가 있습니다: ${matchValue}`);seen.add(key);
    return {name,destinationType,matchType,matchValue,decision,notes,enabled:item?.enabled!==false};
  });
}

export function validateClassificationRules(input:any){
  if(!Array.isArray(input)||input.length>250)invalid('분류 규칙은 최대 250개까지 등록할 수 있습니다.');
  const names=new Set<string>();
  return input.map((item:any,index:number)=>{
    const name=text(item?.name,150);const level=text(item?.classification_level,20).toUpperCase();
    const ruleType=text(item?.rule_type,30);const pattern=text(item?.pattern,1000);const action=text(item?.action,20);
    const weight=Number(item?.weight??50);
    if(name.length<2||!levels.has(level)||!ruleTypes.has(ruleType)||!actions.has(action)||pattern.length<2||!Number.isInteger(weight)||weight<1||weight>100)invalid(`${index+1}번째 데이터 분류 규칙이 올바르지 않습니다.`);
    const key=name.toLowerCase();if(names.has(key))invalid(`중복된 분류 규칙 이름입니다: ${name}`);names.add(key);
    return {name,level,ruleType,pattern,action,weight,caseSensitive:Boolean(item?.case_sensitive),enabled:item?.enabled!==false};
  });
}

export function validateDlpPolicy(input:any){
  if(!input||typeof input!=='object'||Array.isArray(input))invalid('내장 DLP 모듈 설정이 올바르지 않습니다.');
  const integer=(value:unknown,fallback:number,min:number,max:number,label:string)=>{
    const parsed=Number(value??fallback);
    if(!Number.isInteger(parsed)||parsed<min||parsed>max)invalid(`${label}은 ${min}~${max} 범위여야 합니다.`);
    return parsed;
  };
  return {
    enabled:input.enabled!==false,
    blockCritical:input.blockCritical!==false,
    scanPromptText:input.scanPromptText!==false,
    scanClipboard:input.scanClipboard!==false,
    scanCliArguments:input.scanCliArguments!==false,
    scanFileUploads:input.scanFileUploads!==false,
    inspectInternalFingerprints:input.inspectInternalFingerprints!==false,
    inspectContentWithLocalAi:input.inspectContentWithLocalAi!==false,
    aiVerification:input.aiVerification!==false,
    storeRawChat:input.storeRawChat===true,
    evidenceRetentionDays:integer(input.evidenceRetentionDays,90,7,3650,'증거 보관 기간'),
    rawRetentionDays:integer(input.rawRetentionDays,7,1,30,'원문 보관 기간'),
  };
}

function containsSecretKey(value:unknown):boolean{
  if(Array.isArray(value))return value.some(containsSecretKey);
  if(value&&typeof value==='object')return Object.entries(value).some(([key,item])=>secretKeyPattern.test(key)||containsSecretKey(item));
  return false;
}

export function validateDataSources(input:any){
  if(!Array.isArray(input)||input.length>50)invalid('내부 데이터 원본은 최대 50개까지 등록할 수 있습니다.');
  const names=new Set<string>();const ids=new Set<number>();
  return input.map((item:any,index:number)=>{
    const id=item?.id===undefined||item?.id===null?null:Number(item.id);
    if(id!==null&&(!Number.isInteger(id)||id<1))invalid(`${index+1}번째 데이터 원본 ID가 올바르지 않습니다.`);
    if(id!==null&&ids.has(id))invalid(`중복된 데이터 원본 ID입니다: ${id}`);if(id!==null)ids.add(id);
    const name=text(item?.name,150);const sourceType=text(item?.source_type,30);const location=text(item?.location,1000);
    const config=item?.config&&typeof item.config==='object'&&!Array.isArray(item.config)?item.config:{};
    if(name.length<2||!sourceTypes.has(sourceType)||location.length<2)invalid(`${index+1}번째 데이터 원본 설정이 올바르지 않습니다.`);
    const key=name.toLowerCase();if(names.has(key))invalid(`중복된 데이터 원본 이름입니다: ${name}`);names.add(key);
    const unknownInput=Object.keys(item||{}).filter(key=>!allowedSourceInputKeys.has(key));
    if(unknownInput.length)invalid(`지원하지 않는 데이터 원본 항목입니다: ${unknownInput.join(', ')}`);
    if(containsSecretKey(config))invalid('비밀번호·토큰·API 키는 데이터 원본 설정에 직접 저장할 수 없습니다.');
    const unknown=Object.keys(config).filter(key=>!allowedSourceConfigKeys.has(key));
    if(unknown.length)invalid(`지원하지 않는 데이터 원본 설정입니다: ${unknown.join(', ')}`);
    const sanitized:Record<string,unknown>={};
    if('recursive' in config)sanitized.recursive=Boolean(config.recursive);
    if('includeExtensions' in config){
      if(!Array.isArray(config.includeExtensions)||config.includeExtensions.length>50)invalid(`${name}의 확장자 목록이 올바르지 않습니다.`);
      const extensions=unique(config.includeExtensions.map((value:unknown)=>text(value,20).toLowerCase().replace(/^\./,'')).filter(Boolean));
      if(extensions.some(value=>!/^[a-z0-9][a-z0-9_-]{0,19}$/.test(value)))invalid(`${name}의 확장자 형식이 올바르지 않습니다.`);
      sanitized.includeExtensions=extensions;
    }
    if('excludePaths' in config){
      if(!Array.isArray(config.excludePaths)||config.excludePaths.length>100)invalid(`${name}의 제외 경로 목록이 올바르지 않습니다.`);
      const paths=unique(config.excludePaths.map((value:unknown)=>text(value,500).replaceAll('\\','/').replace(/^\.\//,'')).filter(Boolean));
      if(paths.some(value=>value.startsWith('/')||value.split('/').includes('..')))invalid(`${name}의 제외 경로는 상대경로여야 합니다.`);
      sanitized.excludePaths=paths;
    }
    if('maxFileSizeMb' in config){const size=Number(config.maxFileSizeMb);if(!Number.isInteger(size)||size<1||size>100)invalid(`${name}의 최대 파일 크기는 1~100MB여야 합니다.`);sanitized.maxFileSizeMb=size;}
    if('classificationLevel' in config){const level=text(config.classificationLevel,20).toUpperCase();if(!levels.has(level))invalid(`${name}의 분류 등급이 올바르지 않습니다.`);sanitized.classificationLevel=level;}
    if('library' in config)sanitized.library=text(config.library,200);
    if('siteUrl' in config){const siteUrl=text(config.siteUrl,1000);if(!validHttpUrl(siteUrl))invalid(`${name}의 siteUrl 형식이 올바르지 않습니다.`);sanitized.siteUrl=siteUrl;}
    if('databaseType' in config)sanitized.databaseType=text(config.databaseType,50);
    if(['filesystem','nas'].includes(sourceType)&&!(location.startsWith('/')||location.startsWith('\\\\')))invalid(`${name}의 경로는 절대경로 또는 UNC 경로여야 합니다.`);
    if(['webdav','sharepoint'].includes(sourceType)&&!validHttpUrl(location))invalid(`${name}의 URL 형식이 올바르지 않습니다.`);
    return {id,name,sourceType,location,config:sanitized,enabled:item?.enabled!==false};
  });
}

export function remoteIp(headers:Headers){
  const candidate=(headers.get('x-forwarded-for')||'').split(',')[0].trim()||headers.get('x-real-ip')||'';
  return net.isIP(candidate)?candidate:null;
}

export async function onboardingSnapshot(client:PoolClient,tenantId:number,enforcementMode:'monitor'|'enforce'){
  const profile=await client.query('SELECT company_name,company_domains,internal_cidrs,timezone,data_residency FROM ai_organization_profiles WHERE tenant_id=$1',[tenantId]);
  const destinations=await client.query(`SELECT id,name,destination_type,match_type,match_value,decision,notes,enabled FROM ai_destinations WHERE tenant_id=$1 ORDER BY id`,[tenantId]);
  const rules=await client.query(`SELECT name,classification_level,rule_type,pattern,action,weight,case_sensitive,enabled FROM ai_classification_rules WHERE tenant_id=$1 ORDER BY id`,[tenantId]);
  const sources=await client.query(`SELECT id,name,source_type,location,status,config,enabled FROM ai_data_sources WHERE tenant_id=$1 ORDER BY id`,[tenantId]);
  const dlp=await client.query(`SELECT setting_value FROM ai_settings WHERE tenant_id=$1 AND setting_key='dlp_policy'`,[tenantId]);
  return {schema_version:1,enforcement_mode:enforcementMode,organization:profile.rows[0]||null,destinations:destinations.rows,classification_rules:rules.rows,data_sources:sources.rows,dlp_policy:dlp.rows[0]?.setting_value||{}};
}

export async function auditConfiguration(client:PoolClient,input:{tenantId:number;username:string;action:string;objectType:string;objectId?:string;summary:string;details?:Record<string,unknown>;remoteIp?:string|null}){
  await client.query(`INSERT INTO ai_configuration_audit(tenant_id,username,action,object_type,object_id,summary,details,remote_ip)
    VALUES($1,$2,$3,$4,$5,$6,$7,$8::inet)`,[input.tenantId,input.username,input.action,input.objectType,input.objectId||null,input.summary,input.details||{},input.remoteIp||null]);
}
