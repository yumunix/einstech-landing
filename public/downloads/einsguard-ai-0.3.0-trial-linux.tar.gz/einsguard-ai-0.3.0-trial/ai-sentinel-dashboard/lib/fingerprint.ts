import crypto from 'node:crypto';

const SHINGLE_WORDS=5;
const WINNOW_WINDOW=8;
const MAX_TOKENS=250_000;

function masterKey(){
  const value=String(process.env.FINGERPRINT_HMAC_KEY||'').trim();
  if(!/^[a-f0-9]{64,}$/i.test(value))return null;
  return Buffer.from(value,'hex');
}

function tenantKey(tenantId:number){
  const key=masterKey();
  return key?crypto.createHmac('sha256',key).update(`einsguard-fingerprint:v1:tenant:${tenantId}`).digest():null;
}

export function normalizeFingerprintTokens(content:string){
  return String(content||'').normalize('NFKC').toLocaleLowerCase('ko-KR').match(/[\p{L}\p{N}_@.+-]+/gu)?.slice(0,MAX_TOKENS)||[];
}

function hmac(value:string,key:Buffer){return crypto.createHmac('sha256',key).update(value).digest('hex');}

function winnow(hashes:string[]){
  if(hashes.length<=WINNOW_WINDOW)return [...new Set(hashes)];
  const selected:string[]=[];let previousIndex=-1;
  for(let start=0;start<=hashes.length-WINNOW_WINDOW;start++){
    let minimumIndex=start;
    for(let index=start+1;index<start+WINNOW_WINDOW;index++){
      if(hashes[index]<=hashes[minimumIndex])minimumIndex=index;
    }
    if(minimumIndex!==previousIndex){selected.push(hashes[minimumIndex]);previousIndex=minimumIndex;}
  }
  return [...new Set(selected)];
}

export function fingerprintContent(tenantId:number,content:string){
  const key=tenantKey(tenantId);const tokens=normalizeFingerprintTokens(content);
  if(!key)return {status:'disabled' as const,tokenCount:tokens.length,fingerprints:[],contentHmac:null};
  if(tokens.length<SHINGLE_WORDS)return {status:'too_short' as const,tokenCount:tokens.length,fingerprints:[],contentHmac:hmac(tokens.join(' '),key)};
  const hashes:string[]=[];
  for(let index=0;index<=tokens.length-SHINGLE_WORDS;index++)hashes.push(hmac(tokens.slice(index,index+SHINGLE_WORDS).join('\u001f'),key));
  return {status:'ready' as const,tokenCount:tokens.length,fingerprints:winnow(hashes),contentHmac:hmac(tokens.join(' '),key)};
}

export function fingerprintConfigStatus(){return {configured:Boolean(masterKey()),algorithm:'hmac-sha256-winnowing-v1',minimumTokens:SHINGLE_WORDS};}
