import { SessionOptions } from 'iron-session';

export interface SessionData {
  user?: { username: string };
}

export const sessionOptions: SessionOptions = {
  password: process.env.SESSION_SECRET || 'development-only-iron-session-secret-change-me',
  cookieName: 'ai-sentinel-session',
  cookieOptions: {
    secure: process.env.NODE_ENV === 'production',
    httpOnly: true,
    maxAge: 60 * 60 * 8,
  },
};

export const ADMIN_CREDENTIALS = {
  username: process.env.ADMIN_USER || 'admin',
  password: process.env.ADMIN_PASS || '',
};
