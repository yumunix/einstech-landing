import { Pool } from 'pg';

const pool = new Pool({
  host: process.env.PGHOST || '127.0.0.1',
  port: Number(process.env.PGPORT || 5432),
  database: process.env.PGDATABASE || 'aisentinel',
  user: process.env.PGUSER || 'aisentinel',
  password: process.env.PGPASSWORD,
});

export default pool;
