import pool from '@/lib/db';
import {fingerprintContent,fingerprintConfigStatus} from '@/lib/fingerprint';

const levelRank:Record<string,number>={PUBLIC:0,INTERNAL:1,CONFIDENTIAL:2,RESTRICTED:3};

export async function matchInternalContent(tenantId:number,content:string){
  const generated=fingerprintContent(tenantId,content);
  if(generated.status!=='ready'||generated.fingerprints.length<2)return {status:generated.status,tokenCount:generated.tokenCount,inputFingerprintCount:generated.fingerprints.length,match:null};
  const {rows}=await pool.query(`SELECT d.id document_id,d.data_source_id,d.relative_path,d.classification_level,
    COUNT(DISTINCT f.fingerprint)::int match_count
    FROM ai_document_fingerprints f
    JOIN ai_indexed_documents d ON d.id=f.document_id AND d.tenant_id=f.tenant_id AND d.deleted_at IS NULL
    WHERE f.tenant_id=$1 AND f.fingerprint::text=ANY($2::text[])
    GROUP BY d.id,d.data_source_id,d.relative_path,d.classification_level
    HAVING COUNT(DISTINCT f.fingerprint)>=2
    ORDER BY CASE d.classification_level WHEN 'RESTRICTED' THEN 3 WHEN 'CONFIDENTIAL' THEN 2 WHEN 'INTERNAL' THEN 1 ELSE 0 END DESC,
      match_count DESC LIMIT 5`,[tenantId,generated.fingerprints]);
  const match=rows.sort((left,right)=>levelRank[right.classification_level]-levelRank[left.classification_level]||right.match_count-left.match_count)[0]||null;
  return {status:'ready' as const,tokenCount:generated.tokenCount,inputFingerprintCount:generated.fingerprints.length,match:match?{...match,documentId:Number(match.document_id),dataSourceId:Number(match.data_source_id),matchCount:Number(match.match_count)}:null};
}

export {fingerprintConfigStatus};
