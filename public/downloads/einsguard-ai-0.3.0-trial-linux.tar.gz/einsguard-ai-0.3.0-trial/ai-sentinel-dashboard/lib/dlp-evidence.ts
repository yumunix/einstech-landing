import crypto from 'node:crypto';

const cardPattern=/(?<!\d)(?:\d[ -]?){13,19}(?!\d)/g;

export function validCardNumber(value:string){
  const digits=value.replace(/\D/g,'');
  if(digits.length<13||digits.length>19||/^(\d)\1+$/.test(digits))return false;
  let sum=0;
  for(let index=digits.length-1,position=0;index>=0;index-=1,position+=1){
    let number=Number(digits[index]);
    if(position%2===1){number*=2;if(number>9)number-=9;}
    sum+=number;
  }
  return sum%10===0;
}

export function validateReportedEvidence(violationType:string,evidenceHash:string,rawContent:string){
  if(violationType!=='CARD_NUMBER')return 'valid' as const;
  if(!rawContent)return 'unverifiable' as const;
  const candidates=[...rawContent.matchAll(cardPattern)];
  const matched=candidates.find(candidate=>crypto.createHash('sha256').update(candidate[0]).digest('hex')===evidenceHash.toLowerCase());
  if(!matched)return 'mismatch' as const;
  return validCardNumber(matched[0])?'valid' as const:'invalid' as const;
}
