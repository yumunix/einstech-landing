import {createHash,randomUUID} from 'node:crypto';
import {execFile} from 'node:child_process';
import {cp,chmod,mkdir,readdir,readFile,realpath,rename,rm,stat,statfs,writeFile} from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {promisify} from 'node:util';
import pool from './db.ts';

const execFileAsync=promisify(execFile);
export const BACKUP_ROOT=process.env.AI_GUARD_BACKUP_ROOT||'/einstech-ai/05-backups/ai-sentinel';

export type BackupPolicy={
  enabled:boolean;
  frequency:'daily'|'weekly';
  time:string;
  dayOfWeek:number;
  storagePath:string;
  includeDatabase:boolean;
  includeEnvironment:boolean;
  includeApplicationConfig:boolean;
  description:string;
  retentionDays:number;
  automaticCleanup:boolean;
};

export const defaultBackupPolicy:BackupPolicy={
  enabled:true,
  frequency:'daily',
  time:'02:00',
  dayOfWeek:0,
  storagePath:BACKUP_ROOT,
  includeDatabase:true,
  includeEnvironment:true,
  includeApplicationConfig:true,
  description:'AI GUARD 운영 설정 정기 백업',
  retentionDays:365,
  automaticCleanup:false,
};

function safeText(value:unknown,max:number){return String(value??'').trim().slice(0,max);}

export function validateBackupPolicy(input:any):BackupPolicy{
  const merged={...defaultBackupPolicy,...(input&&typeof input==='object'?input:{})};
  if(!['daily','weekly'].includes(merged.frequency))throw new Error('백업 주기는 매일 또는 매주여야 합니다.');
  if(!/^([01]\d|2[0-3]):[0-5]\d$/.test(String(merged.time)))throw new Error('백업 시각 형식이 올바르지 않습니다.');
  const dayOfWeek=Number(merged.dayOfWeek);
  if(!Number.isInteger(dayOfWeek)||dayOfWeek<0||dayOfWeek>6)throw new Error('백업 요일이 올바르지 않습니다.');
  const retentionDays=Number(merged.retentionDays);
  if(!Number.isInteger(retentionDays)||retentionDays<7||retentionDays>3650)throw new Error('백업 보관 기간은 7~3650일이어야 합니다.');
  const storagePath=path.resolve(safeText(merged.storagePath,1000));
  const allowedRoot=path.resolve(/*turbopackIgnore: true*/ BACKUP_ROOT);
  if(storagePath!==allowedRoot&&!storagePath.startsWith(`${allowedRoot}${path.sep}`))throw new Error(`저장 위치는 ${allowedRoot} 내부여야 합니다.`);
  if(!merged.includeDatabase&&!merged.includeEnvironment&&!merged.includeApplicationConfig)throw new Error('백업 대상을 하나 이상 선택하십시오.');
  return {enabled:merged.enabled!==false,frequency:merged.frequency,time:String(merged.time),dayOfWeek,storagePath,
    includeDatabase:Boolean(merged.includeDatabase),includeEnvironment:Boolean(merged.includeEnvironment),includeApplicationConfig:Boolean(merged.includeApplicationConfig),
    description:safeText(merged.description,500),retentionDays,automaticCleanup:merged.automaticCleanup===true};
}

async function sha256(file:string){
  const content=await readFile(file);return createHash('sha256').update(content).digest('hex');
}

async function allFiles(directory:string,prefix=''):Promise<string[]>{
  const entries=await readdir(directory,{withFileTypes:true});const result:string[]=[];
  for(const entry of entries){
    const relative=path.join(prefix,entry.name);const absolute=path.join(directory,entry.name);
    if(entry.isDirectory())result.push(...await allFiles(absolute,relative));
    else if(entry.isFile())result.push(relative);
  }
  return result.sort();
}

async function checkedStoragePath(storagePath:string){
  await mkdir(BACKUP_ROOT,{recursive:true,mode:0o700});
  await mkdir(storagePath,{recursive:true,mode:0o700});
  const [root,target]=await Promise.all([realpath(/*turbopackIgnore: true*/ BACKUP_ROOT),realpath(/*turbopackIgnore: true*/ storagePath)]);
  if(target!==root&&!target.startsWith(`${root}${path.sep}`))throw new Error('허용된 NAS 백업 경로를 벗어났습니다.');
  await chmod(target,0o700);
  return target;
}

function stamp(date=new Date()){
  const parts=new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}).formatToParts(date);
  const values=Object.fromEntries(parts.map(item=>[item.type,item.value]));
  return `${values.year}${values.month}${values.day}-${values.hour}${values.minute}${values.second}`;
}

export async function runConfigBackup(input:{tenantId:number;username:string;trigger:'manual'|'scheduled';policy:BackupPolicy;notes?:string}){
  const policy=validateBackupPolicy(input.policy);const destination=await checkedStoragePath(policy.storagePath);
  const backupName=`${stamp()}-${input.trigger}`;const partial=path.join(destination,`.partial-${backupName}-${process.pid}`);const finalPath=path.join(destination,backupName);
  await mkdir(partial,{recursive:false,mode:0o700});
  const startedAt=new Date();
  try{
    const content:string[]=[];
    if(policy.includeDatabase){
      const output=path.join(partial,'database.dump');
      const args=['--format=custom','--no-owner','--no-privileges','--file',output,'--host',process.env.PGHOST||'127.0.0.1','--port',process.env.PGPORT||'5432','--username',process.env.PGUSER||'aisentinel',process.env.PGDATABASE||'aisentinel'];
      await execFileAsync('/usr/bin/pg_dump',args,{cwd:process.cwd(),env:process.env,maxBuffer:1024*1024*4,timeout:1000*60*30});
      await chmod(output,0o600);content.push('운영 데이터베이스(정책·사용자·장비·라이선스·감사 설정)');
    }
    if(policy.includeEnvironment){
      const envDirectory=path.join(partial,'environment');await mkdir(envDirectory,{mode:0o700});
      for(const name of ['.env.production.local','.env.local']){
        const source=path.join(/*turbopackIgnore: true*/ process.cwd(),name);
        const target=path.join(/*turbopackIgnore: true*/ envDirectory,name);
        try{await cp(/*turbopackIgnore: true*/ source,target);await chmod(/*turbopackIgnore: true*/ target,0o600);}catch(error:any){if(error?.code!=='ENOENT')throw error;}
      }
      content.push('암호화 키·DB 연결 등 운영 환경설정(민감정보 포함)');
    }
    if(policy.includeApplicationConfig){
      const configDirectory=path.join(partial,'application-config');await mkdir(configDirectory,{mode:0o700});
      for(const name of ['package.json','package-lock.json','next.config.ts','next.config.mjs','tsconfig.json','db','deploy']){
        const source=path.join(/*turbopackIgnore: true*/ process.cwd(),name);
        const target=path.join(/*turbopackIgnore: true*/ configDirectory,name);
        try{await cp(/*turbopackIgnore: true*/ source,target,{recursive:true});}catch(error:any){if(error?.code!=='ENOENT')throw error;}
      }
      content.push('애플리케이션 버전·DB 마이그레이션·배포 설정');
    }
    const metadata={schemaVersion:1,backupName,createdAt:startedAt.toISOString(),completedAt:new Date().toISOString(),trigger:input.trigger,createdBy:input.username,tenantId:input.tenantId,
      storagePath:finalPath,description:safeText(input.notes||policy.description,500),content,applicationVersion:process.env.npm_package_version||'0.1.0',database:process.env.PGDATABASE||'aisentinel',containsSecrets:policy.includeEnvironment};
    await writeFile(path.join(partial,'backup.json'),JSON.stringify(metadata,null,2),{mode:0o600});
    const files=await allFiles(partial);const checksums=[] as Array<{file:string;sha256:string;bytes:number}>;
    for(const file of files){const fileStat=await stat(path.join(partial,file));checksums.push({file,sha256:await sha256(path.join(partial,file)),bytes:fileStat.size});}
    await writeFile(path.join(partial,'manifest.json'),JSON.stringify({schemaVersion:1,algorithm:'SHA-256',files:checksums},null,2),{mode:0o600});
    await writeFile(path.join(partial,'SHA256SUMS'),checksums.map(item=>`${item.sha256}  ${item.file}`).join('\n')+'\n',{mode:0o600});
    await rename(partial,finalPath);await chmod(finalPath,0o700);
    const bytes=checksums.reduce((sum,item)=>sum+item.bytes,0);
    return {...metadata,bytes,fileCount:checksums.length+2,integrity:'recorded'};
  }catch(error){await rm(partial,{recursive:true,force:true});throw error;}
}

export async function validateBackupDirectory(directory:string){
  const storage=await checkedStoragePath(path.dirname(directory));const resolved=path.resolve(directory);
  if(!resolved.startsWith(`${storage}${path.sep}`))throw new Error('검증할 백업 경로가 올바르지 않습니다.');
  const manifest=JSON.parse(await readFile(path.join(resolved,'manifest.json'),'utf8'));
  const failures=[] as string[];let bytes=0;
  for(const item of Array.isArray(manifest.files)?manifest.files:[]){
    const file=String(item.file||'');if(!file||path.isAbsolute(file)||file.split(path.sep).includes('..')){failures.push(file||'(빈 경로)');continue;}
    try{const full=path.join(resolved,file);const fileStat=await stat(full);bytes+=fileStat.size;if(await sha256(full)!==item.sha256)failures.push(file);}catch{failures.push(file);}
  }
  return {ok:failures.length===0,checkedFiles:manifest.files?.length||0,bytes,failures};
}

export async function listConfigBackups(storagePath:string){
  const destination=await checkedStoragePath(storagePath);const entries=await readdir(destination,{withFileTypes:true});const backups=[] as any[];
  for(const entry of entries.filter(item=>item.isDirectory()&&!item.name.startsWith('.')).sort((a,b)=>b.name.localeCompare(a.name)).slice(0,100)){
    try{const metadata=JSON.parse(await readFile(path.join(destination,entry.name,'backup.json'),'utf8'));backups.push({...metadata,name:entry.name,path:path.join(destination,entry.name)});}catch{}
  }
  const disk=await statfs(destination);return {backups,storage:{path:destination,freeBytes:disk.bavail*disk.bsize,totalBytes:disk.blocks*disk.bsize}};
}

export async function browseBackupStorage(requestedPath:string){
  const root=await checkedStoragePath(BACKUP_ROOT);const requested=path.resolve(requestedPath||root);
  if(requested!==root&&!requested.startsWith(`${root}${path.sep}`))throw new Error('허용된 백업 저장소를 벗어났습니다.');
  const current=await realpath(/*turbopackIgnore: true*/ requested);
  if(current!==root&&!current.startsWith(`${root}${path.sep}`))throw new Error('허용된 백업 저장소를 벗어났습니다.');
  const entries=await readdir(current,{withFileTypes:true});const directories=[] as Array<{name:string;path:string;backup:boolean}>;
  for(const entry of entries.filter(item=>item.isDirectory()&&!item.name.startsWith('.')).sort((a,b)=>a.name.localeCompare(b.name))){
    const entryPath=path.join(current,entry.name);let backup=false;
    try{await stat(path.join(entryPath,'backup.json'));backup=true;}catch{}
    directories.push({name:entry.name,path:entryPath,backup});
  }
  return {root,current,parent:current===root?null:path.dirname(current),directories};
}

export async function createBackupArchive(storagePath:string,backupName:string){
  if(!/^\d{8}-\d{6}-(manual|scheduled)$/.test(backupName))throw new Error('백업 이름이 올바르지 않습니다.');
  const destination=await checkedStoragePath(storagePath);const directory=path.join(destination,backupName);
  const validation=await validateBackupDirectory(directory);if(!validation.ok)throw new Error('손상된 백업은 내려받을 수 없습니다.');
  const archive=path.join(os.tmpdir(),`ai-guard-${backupName}-${randomUUID()}.tar.gz`);
  await execFileAsync('/usr/bin/tar',['--create','--gzip','--file',archive,'--directory',destination,backupName],{timeout:1000*60*30,maxBuffer:1024*1024*4});
  await chmod(archive,0o600);return archive;
}

export async function importBackupArchive(storagePath:string,file:Uint8Array){
  const destination=await checkedStoragePath(storagePath);const temporary=path.join(os.tmpdir(),`ai-guard-import-${randomUUID()}.tar.gz`);
  await writeFile(temporary,file,{mode:0o600});
  try{
    const {stdout}=await execFileAsync('/usr/bin/tar',['--list','--gzip','--file',temporary],{timeout:1000*60*5,maxBuffer:1024*1024*20});
    const entries=stdout.split('\n').filter(Boolean);if(!entries.length)throw new Error('백업 파일이 비어 있습니다.');
    if(entries.some(entry=>entry.startsWith('/')||entry.split('/').includes('..')))throw new Error('안전하지 않은 백업 경로가 포함되어 있습니다.');
    const topLevels=[...new Set(entries.map(entry=>entry.split('/')[0]))];const backupName=topLevels[0];
    if(topLevels.length!==1||!/^\d{8}-\d{6}-(manual|scheduled)$/.test(backupName))throw new Error('AI GUARD 백업 묶음 형식이 아닙니다.');
    try{await stat(path.join(destination,backupName));throw new Error('같은 이름의 백업이 이미 있습니다.');}catch(error:any){if(error?.code!=='ENOENT')throw error;}
    await execFileAsync('/usr/bin/tar',['--extract','--gzip','--file',temporary,'--directory',destination,'--no-same-owner','--no-same-permissions'],{timeout:1000*60*30,maxBuffer:1024*1024*4});
    const validation=await validateBackupDirectory(path.join(destination,backupName));
    if(!validation.ok){await rm(path.join(destination,backupName),{recursive:true,force:true});throw new Error('가져온 백업의 해시 검증에 실패했습니다.');}
    return {backupName,path:path.join(destination,backupName),validation};
  }finally{await rm(temporary,{force:true});}
}

function koreaParts(date=new Date()){
  const values=Object.fromEntries(new Intl.DateTimeFormat('en-US',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit',weekday:'short',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(date).map(item=>[item.type,item.value]));
  return {date:`${values.year}-${values.month}-${values.day}`,time:`${values.hour}:${values.minute}`,day:['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].indexOf(values.weekday)};
}

let schedulerRunning=false;
export async function runScheduledConfigBackups(){
  if(schedulerRunning)return;schedulerRunning=true;
  try{
    const {rows}=await pool.query(`SELECT s.tenant_id,s.setting_value,u.username FROM ai_settings s
      JOIN LATERAL (SELECT username FROM ai_admin_users WHERE tenant_id=s.tenant_id AND platform_admin=true ORDER BY id LIMIT 1) u ON true
      WHERE s.setting_key='backup_policy'`);
    const now=koreaParts();
    for(const row of rows){
      try{
        const policy=validateBackupPolicy(row.setting_value);if(!policy.enabled||now.time<policy.time||(policy.frequency==='weekly'&&now.day!==policy.dayOfWeek))continue;
        const listed=await listConfigBackups(policy.storagePath);const alreadyRan=listed.backups.some((item:any)=>item.trigger==='scheduled'&&koreaParts(new Date(item.createdAt)).date===now.date);
        if(!alreadyRan)await runConfigBackup({tenantId:Number(row.tenant_id),username:row.username||'system',trigger:'scheduled',policy});
      }catch(error){console.error('[backup] scheduled backup failed:',error instanceof Error?error.message:error);}
    }
  }finally{schedulerRunning=false;}
}
