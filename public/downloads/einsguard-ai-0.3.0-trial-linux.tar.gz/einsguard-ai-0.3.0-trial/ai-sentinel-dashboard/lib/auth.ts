import { NextRequest, NextResponse } from 'next/server';
import jwt from 'jsonwebtoken';
import pool from '@/lib/db';

export type Role = 'admin' | 'security' | 'auditor' | 'viewer';
const SECRET = process.env.SESSION_SECRET || 'development-only-session-secret-change-me';

export async function currentUser(req: NextRequest) {
  const token = req.cookies.get('ai-sentinel-token')?.value;
  if (!token) return null;
  try {
    const decoded = jwt.verify(token, SECRET) as { username: string; role?: Role };
    const { rows } = await pool.query(`SELECT u.username,u.role,u.tenant_id,u.platform_admin,t.code tenant_code,t.name tenant_name
      FROM ai_admin_users u JOIN ai_tenants t ON t.id=u.tenant_id WHERE u.username=$1 AND t.enabled=true`, [decoded.username]);
    return rows[0] ? { username: rows[0].username, role: rows[0].role as Role, tenantId:Number(rows[0].tenant_id), tenantCode:rows[0].tenant_code, tenantName:rows[0].tenant_name, platformAdmin:Boolean(rows[0].platform_admin) } : null;
  } catch {
    return null;
  }
}

export async function requireRole(req: NextRequest, roles: Role[]) {
  const user = await currentUser(req);
  if (!user) return { user: null, response: NextResponse.json({ error: 'Unauthorized' }, { status: 401 }) };
  if (!roles.includes(user.role)) {
    return { user, response: NextResponse.json({ error: '권한이 없습니다' }, { status: 403 }) };
  }
  return { user, response: null };
}
