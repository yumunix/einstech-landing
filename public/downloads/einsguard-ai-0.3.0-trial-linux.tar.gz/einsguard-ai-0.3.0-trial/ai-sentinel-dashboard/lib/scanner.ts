import { exec } from 'child_process';
import { promisify } from 'util';
import pool from './db';

const execAsync = promisify(exec);

function cidrToIps(cidr: string): string[] {
  const [base, prefixStr] = cidr.split('/');
  const prefix = parseInt(prefixStr ?? '32', 10);
  const parts = base.split('.').map(Number);
  const baseInt = (parts[0] << 24) | (parts[1] << 16) | (parts[2] << 8) | parts[3];
  const count = Math.min(1 << (32 - prefix), 4096);
  const networkInt = baseInt & (~((1 << (32 - prefix)) - 1));
  const ips: string[] = [];
  for (let i = 1; i < count - 1; i++) {
    const n = networkInt + i;
    ips.push(`${(n >>> 24) & 255}.${(n >>> 16) & 255}.${(n >>> 8) & 255}.${n & 255}`);
  }
  return ips;
}

async function pingHost(ip: string, timeoutMs: number): Promise<boolean> {
  try {
    const timeoutSec = Math.max(1, Math.ceil(timeoutMs / 1000));
    await execAsync(`ping -c1 -W${timeoutSec} ${ip}`, { timeout: timeoutMs + 500 });
    return true;
  } catch {
    return false;
  }
}

async function resolveHostname(ip: string): Promise<string | null> {
  try {
    const { stdout } = await execAsync(`host ${ip}`, { timeout: 3000 });
    const m = stdout.match(/domain name pointer (.+)\./);
    return m ? m[1] : null;
  } catch {
    return null;
  }
}

export async function runDiscoveryScan(runId: string | number, tenantId: string | number) {
  const client = await pool.connect();
  try {
    await client.query(
      `UPDATE ai_discovery_runs SET status='running', started_at=NOW() WHERE id=$1`,
      [runId]
    );

    const [settingsRow, scopeRows] = await Promise.all([
      client.query(`SELECT timeout_ms, concurrency, max_hosts FROM ai_discovery_settings WHERE tenant_id=$1`, [tenantId]),
      client.query(`SELECT network::text FROM ai_discovery_scopes WHERE tenant_id=$1 AND enabled=true`, [tenantId]),
    ]);

    const timeoutMs: number = settingsRow.rows[0]?.timeout_ms ?? 800;
    const concurrency: number = settingsRow.rows[0]?.concurrency ?? 24;
    const maxHosts: number = settingsRow.rows[0]?.max_hosts ?? 4096;

    const allIps: string[] = [];
    for (const row of scopeRows.rows) {
      for (const ip of cidrToIps(row.network)) {
        if (allIps.length >= maxHosts) break;
        allIps.push(ip);
      }
      if (allIps.length >= maxHosts) break;
    }

    await client.query(
      `UPDATE ai_discovery_runs SET hosts_planned=$1, scopes=$2 WHERE id=$3`,
      [allIps.length, scopeRows.rows.map((r: any) => r.network), runId]
    );

    const agentIpsRow = await client.query(
      `SELECT host(last_ip) AS last_ip_host, local_ips::text[], hostname FROM ai_agents WHERE tenant_id=$1`,
      [tenantId]
    );
    // Normalize IPv4-mapped IPv6 (::ffff:a.b.c.d → a.b.c.d)
    const normalizeIp = (ip: string) => ip.replace(/^::ffff:/i, '');
    const agentByIp = new Map<string, string>();
    for (const row of agentIpsRow.rows) {
      if (row.last_ip_host) agentByIp.set(normalizeIp(row.last_ip_host), row.hostname);
      if (Array.isArray(row.local_ips)) {
        for (const lip of row.local_ips) agentByIp.set(normalizeIp(lip), row.hostname);
      }
    }

    let probed = 0;
    let responded = 0;

    // Process in batches of `concurrency`
    for (let i = 0; i < allIps.length; i += concurrency) {
      const batch = allIps.slice(i, i + concurrency);
      const results = await Promise.all(batch.map(async (ip) => {
        const alive = await pingHost(ip, timeoutMs);
        return { ip, alive };
      }));

      probed += batch.length;

      for (const { ip, alive } of results) {
        if (!alive) continue;
        responded++;

        const matchedHostname = agentByIp.get(ip) ?? null;
        const matchMethod = matchedHostname ? 'last_ip' : null;
        const matchConfidence = matchedHostname ? 'high' : null;

        let resolvedHostname: string | null = null;
        if (!matchedHostname) {
          resolvedHostname = await resolveHostname(ip);
          if (resolvedHostname) {
            const byHostname = agentIpsRow.rows.find(
              (r: any) => r.hostname?.toLowerCase() === resolvedHostname!.toLowerCase()
            );
            if (byHostname) {
              agentByIp.set(ip, byHostname.hostname);
            }
          }
        }

        const finalMatch = agentByIp.get(ip) ?? null;

        await client.query(
          `INSERT INTO ai_discovered_assets(tenant_id,ip,hostname,discovery_source,last_run_id,matched_agent_hostname,match_method,match_confidence,last_seen)
           VALUES($1,$2::inet,$3,$4,$5,$6,$7,$8,NOW())
           ON CONFLICT(tenant_id,ip) DO UPDATE SET
             hostname=COALESCE(EXCLUDED.hostname,ai_discovered_assets.hostname),
             last_seen=NOW(),
             last_run_id=EXCLUDED.last_run_id,
             matched_agent_hostname=EXCLUDED.matched_agent_hostname,
             match_method=EXCLUDED.match_method,
             match_confidence=EXCLUDED.match_confidence`,
          [tenantId, ip, resolvedHostname ?? matchedHostname, 'icmp', runId, finalMatch, finalMatch ? 'last_ip' : null, finalMatch ? 'high' : null]
        );
      }

      await client.query(
        `UPDATE ai_discovery_runs SET hosts_probed=$1, hosts_responded=$2 WHERE id=$3`,
        [probed, responded, runId]
      );
    }

    await client.query(
      `UPDATE ai_discovery_runs SET status='completed', completed_at=NOW(), hosts_probed=$1, hosts_responded=$2 WHERE id=$3`,
      [probed, responded, runId]
    );
  } catch (err: any) {
    await client.query(
      `UPDATE ai_discovery_runs SET status='failed', completed_at=NOW(), error=$1 WHERE id=$2`,
      [String(err?.message ?? err).slice(0, 999), runId]
    );
  } finally {
    client.release();
  }
}
