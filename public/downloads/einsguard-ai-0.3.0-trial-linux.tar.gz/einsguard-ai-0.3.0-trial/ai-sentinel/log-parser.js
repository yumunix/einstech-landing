#!/usr/bin/env node
// AI Sentinel v2 — Log Parser (세션 감사 + 보안 알림 + 이메일)

const fs = require('fs');
const readline = require('readline');
const crypto = require('crypto');
const { Client } = require('pg');
const nodemailer = require('nodemailer');
function readSecret(path) { try { return fs.readFileSync(path, 'utf8').trim(); } catch { return ''; } }

const SMTP = {
  host: process.env.SMTP_HOST || '',
  port: Number(process.env.SMTP_PORT || 465),
  secure: (process.env.SMTP_SECURE || 'true') === 'true',
  auth: { user: process.env.SMTP_USER || '', pass: process.env.SMTP_PASS || readSecret(process.env.SMTP_PASS_FILE || '/home/ai/.config/ai-sentinel/smtp.pass') },
};
const ALERT_TO = process.env.ALERT_TO || '';

const mailer = nodemailer.createTransport(SMTP);

async function sendAlertEmail(alert) {
  const SEV_EMOJI = { HIGH: '🔴', MED: '🟡', LOW: '🔵' };
  try {
    if (!SMTP.host || !SMTP.auth.user || !SMTP.auth.pass || !ALERT_TO) return;
    await mailer.sendMail({
      from: `EINSTECH AI Sentinel <${SMTP.auth.user}>`,
      to: ALERT_TO,
      subject: `${SEV_EMOJI[alert.severity] || '⚠️'} [AI Sentinel] ${alert.alert_type} — ${alert.hostname}`,
      html: `
        <div style="font-family:sans-serif;max-width:600px;margin:0 auto">
          <div style="background:#0a0f1e;padding:20px;border-radius:8px 8px 0 0">
            <h2 style="color:#16c79a;margin:0">AI Sentinel 보안 알림</h2>
          </div>
          <div style="background:#f8f9fa;padding:20px;border:1px solid #dee2e6;border-radius:0 0 8px 8px">
            <table style="width:100%;border-collapse:collapse">
              <tr><td style="padding:8px;color:#666">등급</td><td style="padding:8px;font-weight:bold;color:${alert.severity==='HIGH'?'#dc3545':alert.severity==='MED'?'#fd7e14':'#0d6efd'}">${alert.severity}</td></tr>
              <tr style="background:#fff"><td style="padding:8px;color:#666">유형</td><td style="padding:8px;font-weight:bold">${alert.alert_type}</td></tr>
              <tr><td style="padding:8px;color:#666">서버</td><td style="padding:8px">${alert.hostname}</td></tr>
              <tr style="background:#fff"><td style="padding:8px;color:#666">사용자</td><td style="padding:8px">${alert.username}</td></tr>
              <tr><td style="padding:8px;color:#666">도구</td><td style="padding:8px">${alert.tool}</td></tr>
              <tr style="background:#fff"><td style="padding:8px;color:#666">내용</td><td style="padding:8px">${alert.detail}</td></tr>
              <tr><td style="padding:8px;color:#666">시각</td><td style="padding:8px">${new Date().toLocaleString('ko-KR')}</td></tr>
            </table>
            <div style="margin-top:20px;padding:12px;background:#fff3cd;border-radius:4px;font-size:13px;color:#856404">
              Grafana에서 확인: <a href="https://grafana.ein.lan/d/ai-sentinel-v2">AI Sentinel 대시보드</a>
            </div>
          </div>
        </div>
      `,
    });
    console.log(`[EMAIL] 알림 발송 완료: ${alert.alert_type} → ${ALERT_TO}`);
  } catch (err) {
    console.error(`[EMAIL] 발송 실패: ${err.message}`);
  }
}

const LOG_FILE = process.env.AI_SENTINEL_LOG_FILE || '/var/log/ai-monitor/usage.log';
const DB_CONFIG = {
  host: process.env.PGHOST || '127.0.0.1', port: Number(process.env.PGPORT || 5432),
  database: process.env.PGDATABASE || 'aisentinel', user: process.env.PGUSER || 'aisentinel', password: process.env.PGPASSWORD || readSecret(process.env.PGPASSWORD_FILE || '/home/ai/.config/ai-sentinel/db.pass'),
};

const db = new Client(DB_CONFIG);
const TENANT_ID = Number(process.env.AI_SENTINEL_TENANT_ID || 1);
let licenseCache = { checkedAt: 0, active: true, reason: '' };

async function licenseIsActive() {
  if (Date.now() - licenseCache.checkedAt < 60000) return licenseCache.active;
  try {
    const { rows } = await db.query(`SELECT license_type,status,expires_at,last_seen_at FROM ai_licenses WHERE tenant_id=$1`, [TENANT_ID]);
    const item = rows[0];
    const rollback = item && new Date(item.last_seen_at).getTime() > Date.now() + 300000;
    const perpetual = item?.license_type === 'perpetual';
    const expired = !perpetual && (!item?.expires_at || new Date(item.expires_at).getTime() <= Date.now());
    const active = Boolean(item && item.status === 'active' && !expired && !rollback);
    const reason = !item ? '라이선스 없음' : rollback ? '시스템 시간 변경 감지' : expired ? '사용기간 만료' : item.status !== 'active' ? '비활성 라이선스' : '';
    if (!active && licenseCache.active) console.error(`[LICENSE] 수집 중지: ${reason}`);
    if (active && !licenseCache.active) console.log('[LICENSE] 라이선스 정상화 — 수집 재개');
    licenseCache = { checkedAt: Date.now(), active, reason };
    if (item) await db.query('UPDATE ai_licenses SET last_seen_at=GREATEST(last_seen_at,NOW()) WHERE tenant_id=$1',[TENANT_ID]);
    return active;
  } catch (error) {
    console.error(`[LICENSE] 검증 실패: ${error.message}`);
    licenseCache = { checkedAt: Date.now(), active: false, reason: '검증 실패' };
    return false;
  }
}

function maskSensitive(value) {
  if (!value) return value;
  return String(value)
    .replace(/\b(sk-[A-Za-z0-9_-]{12,}|sk-ant-[A-Za-z0-9_-]{12,})\b/g, '[SECRET_MASKED]')
    .replace(/\b(AKIA[0-9A-Z]{16})\b/g, '[AWS_KEY_MASKED]')
    .replace(/\b(password|passwd|token|api[_-]?key|secret)\s*[=:]\s*[^\s,;]+/gi, '$1=[MASKED]')
    .replace(/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi, '[EMAIL_MASKED]');
}

function detectModel(args) {
  const match = String(args || '').match(/(?:--model(?:=|\s+))([^\s]+)/i);
  return match?.[1] || null;
}

// 이상 행위 감지 규칙
const ALERT_RULES = [
  {
    name: 'NIGHT_USAGE',
    severity: 'MED',
    score: 35,
    check: (data) => {
      const h = new Date(data.started_at).getHours();
      return h >= 22 || h < 6;
    },
    detail: (data) => `심야 시간대 AI 사용: ${data.username}@${data.hostname} (${data.tool})`,
  },
  {
    name: 'UNKNOWN_USER',
    severity: 'HIGH',
    score: 80,
    check: (data) => !['ai', 'root'].includes(data.username),
    detail: (data) => `등록되지 않은 계정 사용: ${data.username}@${data.hostname}`,
  },
  {
    name: 'SENSITIVE_PATH',
    severity: 'HIGH',
    score: 90,
    check: (data) => /\/(etc|secret|passwd|shadow|key|cert|ssl|credential)/i.test(data.work_dir || ''),
    detail: (data) => `민감 경로에서 AI 사용: ${data.work_dir} (${data.username}@${data.hostname})`,
  },
];

async function checkAlerts(db, data) {
  const matched = ALERT_RULES.filter((rule) => rule.check(data));
  if (matched.length === 0) return;

  const totalRisk = Math.min(100, matched.reduce((sum, rule) => sum + rule.score, 0));
  const riskReason = matched.map((rule) => `${rule.name}(+${rule.score})`).join(', ');

  for (const rule of matched) {
      const alertData = {
        session_id: data.session_id,
        hostname: data.hostname,
        username: data.username,
        tool: data.tool,
        alert_type: rule.name,
        severity: rule.severity,
        detail: maskSensitive(rule.detail(data)),
        risk_score: totalRisk,
        risk_reason: riskReason,
        auto_action: totalRisk >= 80 ? 'pause_requested' : null,
      };
      await db.query(
        `INSERT INTO ai_alerts
           (session_id, hostname, username, tool, alert_type, severity, detail, risk_score, risk_reason, auto_action,tenant_id)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
        [alertData.session_id, alertData.hostname, alertData.username, alertData.tool,
         alertData.alert_type, alertData.severity, alertData.detail, alertData.risk_score,
         alertData.risk_reason, alertData.auto_action,TENANT_ID]
      );
      console.log(`[ALERT] ${rule.severity} | ${rule.name} | ${rule.detail(data)}`);
      await sendAlertEmail(alertData);
  }

  if (totalRisk >= 80) {
    const token = `risk-pause:${crypto.randomUUID()}`;
    await db.query(
      `INSERT INTO ai_commands (session_id, hostname, username, tool, command, status,tenant_id)
       SELECT $1,$2,$3,$4,'pause','pending',$5
       WHERE NOT EXISTS (
         SELECT 1 FROM ai_commands
         WHERE session_id=$1 AND tenant_id=$5 AND command='pause' AND status IN ('pending','executed')
       )`,
      [data.session_id, data.hostname, data.username, data.tool,TENANT_ID]
    );
    await db.query(
      `INSERT INTO ai_approvals (session_id, hostname, username, tool, work_dir, args, token, status,tenant_id)
       SELECT $1,$2,$3,$4,$5,$6,$7,'pending',$8
       WHERE NOT EXISTS (
         SELECT 1 FROM ai_approvals
         WHERE session_id=$1 AND tenant_id=$8 AND token LIKE 'risk-pause:%' AND status='pending'
       )`,
      [data.session_id, data.hostname, data.username, data.tool, data.work_dir,
       `위험도 ${totalRisk}점 · ${riskReason}`, token,TENANT_ID]
    );
    console.log(`[AUTO_PAUSE] ${data.session_id} | 위험도 ${totalRisk} | 관리자 승인 대기`);
  }
}

// 로그 파싱
// SESSION_START|id|hostname|user|tool|workdir|time|branch|args
// SESSION_END|id|hostname|user|tool|workdir|time|duration|files|commits
// 구형: hostname|user|tool|pid|args
async function parseLine(line) {
  if (!(await licenseIsActive())) return;
  // rsyslog 배포판별로 태그 뒤 PID와 콜론이 생략될 수 있다.
  const syslogMatch = line.match(/^(\w+\s+\d+\s+[\d:]+)\s+\S+\s+ai-monitor(?:\[\d+\])?:?\s+(.+)$/);
  if (!syslogMatch) return;

  const [, , body] = syslogMatch;
  const parts = body.split('|');

  if (parts[0] === 'SESSION_START') {
    const [, session_id, hostname, username, tool, work_dir, started_at, git_branch, ...argParts] = parts;
    const args = argParts.join(' ');

    const inserted = await db.query(
      `INSERT INTO ai_sessions (session_id, hostname, username, tool, work_dir, started_at, git_branch, args,tenant_id)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
       ON CONFLICT (session_id) DO NOTHING
       RETURNING session_id`,
      [session_id, hostname, username, tool, work_dir, started_at, git_branch, maskSensitive(args),TENANT_ID]
    );

    // 서비스 재시작 시 기존 로그를 다시 읽어도 사용량·알림을 중복 생성하지 않는다.
    if (inserted.rowCount === 0) return;

    await db.query(
      `INSERT INTO ai_usage (logged_at, hostname, username, tool, args, model,tenant_id)
       VALUES ($1,$2,$3,$4,$5,$6,$7)`,
      [started_at, hostname, username, tool, maskSensitive(args), detectModel(args),TENANT_ID]
    );

    await checkAlerts(db, { session_id, hostname, username, tool, work_dir, started_at, args });
    console.log(`[SESSION_START] ${username}@${hostname} | ${tool} | ${work_dir}`);

  } else if (parts[0] === 'SESSION_END') {
    const [, session_id, hostname, username, tool, work_dir, ended_at, duration, files_changed, ...commitParts] = parts;
    const git_commits = commitParts.join('|');
    const duration_sec = parseInt(duration) || 0;

    await db.query(
      `UPDATE ai_sessions SET ended_at=$1, duration_sec=$2, files_changed=$3, git_commits=$4
       WHERE session_id=$5 AND tenant_id=$6`,
      [ended_at, duration_sec, files_changed, git_commits, session_id,TENANT_ID]
    );
    await db.query(`UPDATE ai_commands SET status='ended',executed_at=NOW()
      WHERE session_id=$1 AND tenant_id=$2 AND command='registered' AND status IN ('active','stale')`,[session_id,TENANT_ID]);
    console.log(`[SESSION_END] ${username}@${hostname} | ${duration_sec}초 | ${files_changed || '변경없음'}`);

  } else {
    // 구형 포맷 호환
    const [hostname, username, tool, pid, ...argParts] = parts;
    if (hostname && tool) {
      await db.query(
        `INSERT INTO ai_usage (logged_at, hostname, username, tool, pid, args,tenant_id)
         VALUES (NOW(),$1,$2,$3,$4,$5,$6)`,
        [hostname, username, tool, parseInt(pid) || null, argParts.join(' '),TENANT_ID]
      ).catch(() => {});
    }
  }
}

async function main() {
  await db.connect();
  console.log('[AI Sentinel v2] DB 연결 완료');

  while (!fs.existsSync(LOG_FILE)) {
    console.log(`[AI Sentinel] 로그 파일 대기: ${LOG_FILE}`);
    await new Promise((resolve) => setTimeout(resolve, 2000));
  }

  let lastSize = 0;
  const lines = fs.readFileSync(LOG_FILE, 'utf8').split('\n').filter(Boolean);
  for (const line of lines) {
    await parseLine(line).catch(console.error);
  }
  lastSize = fs.statSync(LOG_FILE).size;
  console.log(`[AI Sentinel v2] 기존 로그 ${lines.length}줄 처리 완료`);

  fs.watchFile(LOG_FILE, { interval: 1000 }, async () => {
    const stat = fs.statSync(LOG_FILE);
    if (stat.size <= lastSize) return;

    const stream = fs.createReadStream(LOG_FILE, { start: lastSize, end: stat.size });
    const rl = readline.createInterface({ input: stream });
    rl.on('line', async (line) => {
      await parseLine(line).catch(console.error);
    });
    lastSize = stat.size;
  });

  console.log('[AI Sentinel v2] 실시간 모니터링 시작...');
}

main().catch(console.error);
