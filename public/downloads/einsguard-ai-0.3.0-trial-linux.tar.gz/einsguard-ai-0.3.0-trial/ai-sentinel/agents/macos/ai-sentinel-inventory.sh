#!/bin/bash
set -eu
export PATH="/opt/homebrew/bin:/usr/local/bin:$HOME/.local/bin:/usr/bin:/bin:/usr/sbin:/sbin"

API="${AI_SENTINEL_API:-http://127.0.0.1:3100/api/agents?action=inventory-report}"
KEY_FILE="${AI_SENTINEL_KEY_FILE:-$HOME/.config/ai-sentinel/agent.key}"
[ -r "$KEY_FILE" ] || { echo "AI Sentinel agent key not found: $KEY_FILE" >&2; exit 1; }
AGENT_KEY=$(tr -d '\r\n' < "$KEY_FILE")
TOOLS="claude codex cursor copilot gemini aider windsurf ollama"
installed=""
running=""
for tool in $TOOLS; do
  if command -v "$tool" >/dev/null 2>&1; then installed="${installed}${installed:+,}\"$tool\""; fi
  if pgrep -if "(^|/|[[:space:]])${tool}([[:space:]]|$)" >/dev/null 2>&1; then running="${running}${running:+,}\"$tool\""; fi
done
payload=$(printf '{"hostname":"%s","username":"%s","os":"macos","os_version":"%s","arch":"%s","agent_version":"1.4.0","installed_tools":[%s],"running_tools":[%s]}' \
  "$(hostname)" "$(id -un)" "$(sw_vers -productVersion)" "$(uname -m)" "$installed" "$running")
curl -fsS -X POST "$API" -H 'Content-Type: application/json' -H "x-ai-sentinel-key: $AGENT_KEY" -d "$payload"
