param(
  [Parameter(Mandatory=$true)][ValidateSet('claude','codex')][string]$Tool,
  [Parameter(ValueFromRemainingArguments=$true)][string[]]$ToolArgs,
  [string]$ApiBase = 'http://127.0.0.1:3100',
  [string]$KeyFile = "$env:ProgramData\EINSTECH\AI-Sentinel\agent.key",
  [string]$ConfigFile = "$env:ProgramData\EINSTECH\AI-Sentinel\config.json"
)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

function Invoke-AgentApi([string]$Method,[string]$Uri,$Body=$null) {
  $params=@{Method=$Method;Uri=$Uri;Headers=$script:Headers;TimeoutSec=15;ErrorAction='Stop'}
  if ($null -ne $Body) { $params.ContentType='application/json'; $params.Body=($Body|ConvertTo-Json -Depth 6 -Compress) }
  Invoke-RestMethod @params
}

# Windows PowerShell 5.1에는 Suspend-Process/Resume-Process가 없어 NT API를 사용한다.
if (-not ('Einsguard.NativeProcess' -as [type])) {
  Add-Type @'
using System;
using System.Runtime.InteropServices;
namespace Einsguard {
  public static class NativeProcess {
    [DllImport("ntdll.dll")] static extern int NtSuspendProcess(IntPtr h);
    [DllImport("ntdll.dll")] static extern int NtResumeProcess(IntPtr h);
    public static void Suspend(System.Diagnostics.Process p) { if (NtSuspendProcess(p.Handle) != 0) throw new InvalidOperationException("Suspend failed"); }
    public static void Resume(System.Diagnostics.Process p) { if (NtResumeProcess(p.Handle) != 0) throw new InvalidOperationException("Resume failed"); }
  }
}
'@
}

if (-not (Test-Path -LiteralPath $KeyFile)) { throw "EINSGUARD agent key not found: $KeyFile" }
$script:Headers=@{'x-ai-sentinel-key'=(Get-Content -LiteralPath $KeyFile -Raw).Trim()}
$config=Get-Content -LiteralPath $ConfigFile -Raw | ConvertFrom-Json
$realPath=[string]$config.tools.$Tool
if (-not $realPath -or -not (Test-Path -LiteralPath $realPath)) { throw "Original $Tool executable not found. Reinstall EINSGUARD AI agent." }

$hostNameValue=$env:COMPUTERNAME; $userNameValue=$env:USERNAME
$sessionId="$hostNameValue-$userNameValue-$([DateTimeOffset]::UtcNow.ToUnixTimeSeconds())-$PID"
$query="hostname=$([uri]::EscapeDataString($hostNameValue))&username=$([uri]::EscapeDataString($userNameValue))&tool=$Tool"
if ((Invoke-AgentApi GET "$ApiBase/api/agent?check-block=1&$query") -eq 'true') { throw '[EINSGUARD AI] 이 PC/계정은 AI 사용이 차단되어 있습니다.' }
$policy=Invoke-AgentApi GET "$ApiBase/api/agent?check-policy=1&$query"
if ($policy -ne 'ok') { throw "[EINSGUARD AI] 정책 위반: $policy" }

if ((Invoke-AgentApi GET "$ApiBase/api/agent?check-approval=1&$query") -eq 'true') {
  $token=[guid]::NewGuid().ToString('N')
  Invoke-AgentApi POST "$ApiBase/api/agent?action=request-approval" @{session_id=$sessionId;hostname=$hostNameValue;username=$userNameValue;tool=$Tool;work_dir=$PWD.Path;args=($ToolArgs -join ' ');token=$token}|Out-Null
  Write-Host '[EINSGUARD AI] 관리자 승인을 기다리는 중입니다.'
  $approval='pending'
  for($i=0;$i -lt 60;$i++){ Start-Sleep 5; $approval=Invoke-AgentApi GET "$ApiBase/api/agent?approval-status=1&token=$token"; if($approval -ne 'pending'){break} }
  if($approval -ne 'approved'){ throw "[EINSGUARD AI] 실행 승인 실패: $approval" }
}

$started=[DateTimeOffset]::UtcNow; $gitBranch=''
try { $gitBranch=(& git -C $PWD.Path rev-parse --abbrev-ref HEAD 2>$null) -join '' } catch {}
$process=Start-Process -FilePath $realPath -ArgumentList $ToolArgs -PassThru -NoNewWindow
try {
  Invoke-AgentApi POST "$ApiBase/api/agent?action=session-start" @{session_id=$sessionId;hostname=$hostNameValue;username=$userNameValue;tool=$Tool;pid=$process.Id;work_dir=$PWD.Path;started_at=$started.ToString('o');git_branch=$gitBranch;args=($ToolArgs -join ' ')}|Out-Null
} catch {
  # 4.0 서버와의 하위 호환: 세션 API 미배포 상태에서도 정책/제어는 계속 작동한다.
  Write-Warning "EINSGUARD session audit is not available yet: $($_.Exception.Message)"
}
Invoke-AgentApi POST "$ApiBase/api/agent?action=register-pid" @{session_id=$sessionId;hostname=$hostNameValue;username=$userNameValue;tool=$Tool;pid=$process.Id}|Out-Null

$paused=$false
try {
  while(-not $process.HasExited){
    try {
      $command=Invoke-AgentApi GET "$ApiBase/api/agent?check-control=1&session_id=$([uri]::EscapeDataString($sessionId))"
      switch($command){
        'pause'  { if(-not $paused){[Einsguard.NativeProcess]::Suspend($process);$paused=$true} }
        'resume' { if($paused){[Einsguard.NativeProcess]::Resume($process);$paused=$false} }
        'kill'   { if($paused){[Einsguard.NativeProcess]::Resume($process)};Stop-Process -Id $process.Id -Force }
      }
    } catch { Write-Warning "EINSGUARD control check failed: $($_.Exception.Message)" }
    Start-Sleep 3; $process.Refresh()
  }
} finally {
  if(-not $process.HasExited){Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue}
  $ended=[DateTimeOffset]::UtcNow
  try { Invoke-AgentApi POST "$ApiBase/api/agent?action=session-end" @{session_id=$sessionId;ended_at=$ended.ToString('o');duration_sec=[int]($ended-$started).TotalSeconds}|Out-Null } catch { Write-Warning $_.Exception.Message }
}
exit $process.ExitCode
