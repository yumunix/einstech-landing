#Requires -RunAsAdministrator
param(
  [string]$RemovalToken = $env:EINSGUARD_REMOVAL_TOKEN,
  [int]$PollLimit = 360   # 360 x 10s = 60 minutes
)
$ErrorActionPreference='Continue'
$installDir="$env:ProgramData\EINSTECH\AI-Sentinel"; $binDir=Join-Path $installDir 'bin'

# --- 관리 서버 관리자 승인 확인 ---------------------------------------------
$keyFile=Join-Path $installDir 'agent.key'
$configFile=Join-Path $installDir 'config.json'
$apiBase=$null; $agentKey=$null
if(Test-Path $keyFile){ $agentKey=(Get-Content -LiteralPath $keyFile -Raw).Trim() }
if(Test-Path $configFile){ try{ $apiBase=((Get-Content -LiteralPath $configFile -Raw)|ConvertFrom-Json).api_base }catch{} }

function Invoke-Removal([string]$Method,[string]$Path,[object]$Body){
  $uri="$apiBase$Path"
  $headers=@{'x-ai-sentinel-key'=$agentKey}
  if($Body){
    Invoke-RestMethod -Method $Method -Uri $uri -Headers $headers -ContentType 'application/json; charset=utf-8' `
      -Body ([Text.Encoding]::UTF8.GetBytes(($Body|ConvertTo-Json -Compress))) -TimeoutSec 15
  } else {
    Invoke-RestMethod -Method $Method -Uri $uri -Headers $headers -TimeoutSec 15
  }
}

if($apiBase -and $agentKey){
  if($RemovalToken){
    try{
      $v=Invoke-RestMethod -Method Get -Uri "$apiBase/api/removal?verify=$([uri]::EscapeDataString($RemovalToken))" -TimeoutSec 15
      if(-not $v.valid){ Write-Host '제공된 제거 토큰이 유효하지 않습니다.'; exit 4 }
      Write-Host '관리 서버가 제거 토큰을 확인했습니다. 제거를 진행합니다.'
    }catch{ Write-Host '제거 토큰 검증에 실패했습니다.'; exit 4 }
  } else {
    Write-Host "관리 서버($apiBase)에 제거 승인을 요청합니다..."
    $requested=$false
    try{ Invoke-Removal Post '/api/removal' @{hostname=$env:COMPUTERNAME;os_version='windows';reason="Windows agent uninstall requested on $env:COMPUTERNAME"}|Out-Null; $requested=$true }
    catch{
      $reachable=$false; try{ Invoke-RestMethod -Method Get -Uri "$apiBase/login" -TimeoutSec 10|Out-Null; $reachable=$true }catch{}
      if(-not $reachable){ Write-Host '관리 서버에 연결할 수 없습니다. 관리자가 승인하기 전에는 제거할 수 없습니다.'; exit 5 }
      Write-Host '서버가 제거 요청을 받지 않았습니다(인증 키가 이미 해제되었을 수 있음). 계속 진행합니다.'
    }
    if($requested){
      Write-Host '제거 요청을 보냈습니다. 관리자가 대시보드에서 승인할 때까지 기다립니다...'
      $approved=$false
      for($i=0;$i -lt $PollLimit;$i++){
        Start-Sleep -Seconds 10
        try{
          $s=Invoke-Removal Get '/api/removal' $null
          if($s.status -eq 'approved'){ Write-Host '관리자가 제거를 승인했습니다.'; $approved=$true; break }
          if($s.status -eq 'rejected'){ Write-Host '관리자가 제거 요청을 거부했습니다.'; exit 6 }
        }catch{}
      }
      if(-not $approved){ Write-Host '제거 승인 대기 시간이 초과됐습니다. 관리자 승인 후 다시 실행하세요.'; exit 7 }
    }
  }
} else {
  Write-Host '서버·키 구성이 없어 승인 대상이 없습니다. 로컬 제거만 진행합니다.'
}

# 제거 완료를 서버에 보고 (인증 키 삭제 전에 호출)
if($apiBase -and $agentKey){
  try{ Invoke-Removal Post '/api/removal' @{action='complete'}|Out-Null }catch{}
}

# --- 실제 제거 ------------------------------------------------------------
$removeLogDir="$env:ProgramData\EINSTECH\AI-GUARD-Logs";New-Item -ItemType Directory -Force -Path $removeLogDir|Out-Null
$removeLog=Join-Path $removeLogDir ("uninstall-{0}.log" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
Start-Transcript -Path $removeLog -Force
Write-Host "EINSGUARD AI Windows Agent removal started: $(Get-Date -Format s)"
foreach($task in @('AI Sentinel Windows Agent','EINSTECH AI Sentinel','EINSGUARD AI Agent','EINSGUARD AI Agent 1.0','EINSGUARD AI DLP User')){
  Stop-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue
  Unregister-ScheduledTask -TaskName $task -Confirm:$false -ErrorAction SilentlyContinue
}
Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
  Where-Object {$_.CommandLine -like '*AI-Sentinel-Agent.ps1*'} |
  ForEach-Object {Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue}
$machinePath=[Environment]::GetEnvironmentVariable('Path','Machine')
$newPath=(($machinePath -split ';'|Where-Object {$_ -and $_ -ne $binDir}) -join ';')
[Environment]::SetEnvironmentVariable('Path',$newPath,'Machine')
foreach($item in @(@('HKLM:\Software\Policies\Google\Chrome','chrome-policy-backup.reg'),@('HKLM:\Software\Policies\Microsoft\Edge','edge-policy-backup.reg'))){
  Remove-Item (Join-Path $item[0] 'URLBlocklist') -Recurse -Force -ErrorAction SilentlyContinue
  Remove-ItemProperty $item[0] -Name DnsOverHttpsMode -Force -ErrorAction SilentlyContinue
  $backup=Join-Path $installDir $item[1];if(Test-Path $backup){& reg.exe import $backup *> $null}
}
Remove-Item 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\EINSGUARD-AI-Agent-1.0' -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $installDir -Recurse -Force -ErrorAction SilentlyContinue
Write-Host 'EINSGUARD AI Windows Agent removal complete. Existing terminals must be reopened.'
Write-Host "Removal log: $removeLog"
Stop-Transcript
