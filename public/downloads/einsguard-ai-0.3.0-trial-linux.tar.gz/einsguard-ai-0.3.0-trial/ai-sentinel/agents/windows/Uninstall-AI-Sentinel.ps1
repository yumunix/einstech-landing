#Requires -RunAsAdministrator
$ErrorActionPreference='Continue'
$removeLogDir="$env:ProgramData\EINSTECH\AI-GUARD-Logs";New-Item -ItemType Directory -Force -Path $removeLogDir|Out-Null
$removeLog=Join-Path $removeLogDir ("uninstall-{0}.log" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
Start-Transcript -Path $removeLog -Force
Write-Host "EINSGUARD AI Windows Agent removal started: $(Get-Date -Format s)"
$installDir="$env:ProgramData\EINSTECH\AI-Sentinel"; $binDir=Join-Path $installDir 'bin'
foreach($task in @('AI Sentinel Windows Agent','EINSTECH AI Sentinel','EINSGUARD AI Agent','EINSGUARD AI Agent 1.0','EINSGUARD AI DLP User')){
  Stop-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue
  Unregister-ScheduledTask -TaskName $task -Confirm:$false -ErrorAction SilentlyContinue
}
Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
  Where-Object {$_.CommandLine -like '*AI-Sentinel-Agent.ps1*'} |
  ForEach-Object {Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue}
$machinePath=[Environment]::GetEnvironmentVariable('Path','Machine')
$newPath=(($machinePath -split ';'|Where-Object {$_ -and $_ -ne $binDir}) -join ';')
[Environment]::SetEnvironmentVariable('Path',$newPath,'Machine')
foreach($item in @(@('HKLM:\Software\Policies\Google\Chrome','chrome-policy-backup.reg'),@('HKLM:\Software\Policies\Microsoft\Edge','edge-policy-backup.reg'))){
  Remove-Item (Join-Path $item[0] 'URLBlocklist') -Recurse -Force -ErrorAction SilentlyContinue
  Remove-ItemProperty $item[0] -Name DnsOverHttpsMode -Force -ErrorAction SilentlyContinue
  $backup=Join-Path $installDir $item[1];if(Test-Path $backup){& reg.exe import $backup *> $null}
}
Remove-Item 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\EINSGUARD-AI-Agent-1.0' -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $installDir -Recurse -Force -ErrorAction SilentlyContinue
Write-Host 'EINSGUARD AI Windows Agent removal complete. Existing terminals must be reopened.'
Write-Host "Removal log: $removeLog"
Stop-Transcript
