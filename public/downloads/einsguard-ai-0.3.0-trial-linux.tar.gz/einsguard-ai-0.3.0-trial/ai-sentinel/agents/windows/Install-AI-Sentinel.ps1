#Requires -RunAsAdministrator
param([string]$AgentKey,[string]$AgentKeyFile,[string]$ApiBase='http://127.0.0.1:3100',[string]$BootstrapLog='')
$ErrorActionPreference='Stop'
$AgentKeyFileValue=''
if($AgentKeyFile -and (Test-Path -LiteralPath $AgentKeyFile)){$AgentKeyFileValue=(Get-Content -LiteralPath $AgentKeyFile -Raw).Trim()}
if(-not $AgentKey -and $AgentKeyFileValue){$AgentKey=$AgentKeyFileValue}
$installDir="$env:ProgramData\EINSTECH\AI-Sentinel"; $binDir=Join-Path $installDir 'bin'
$logDir=Join-Path $installDir 'logs'; $installLog=Join-Path $logDir 'install.log'
if($BootstrapLog){Start-Transcript -Path $BootstrapLog -Append -Force}
# 시험 버전의 중복 예약 작업/프로세스를 제거하고 단일 구성으로 전환한다.
foreach($task in @('AI Sentinel Windows Agent','EINSTECH AI Sentinel','EINSGUARD AI Agent','EINSGUARD AI Agent 1.0','EINSGUARD AI DLP User')){
  Stop-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue
  Unregister-ScheduledTask -TaskName $task -Confirm:$false -ErrorAction SilentlyContinue
}
Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
  Where-Object {$_.CommandLine -like '*AI-Sentinel-Agent.ps1*'} |
  ForEach-Object {Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue}
New-Item -ItemType Directory -Force -Path $installDir,$binDir,$logDir|Out-Null
if(-not $BootstrapLog){Start-Transcript -Path $installLog -Append -Force}
Write-Host "EINSGUARD AI Agent 1.1.0 설치 시작: $(Get-Date -Format s)"
foreach($item in @(@('Registry::HKEY_LOCAL_MACHINE\Software\Policies\Google\Chrome','HKLM\Software\Policies\Google\Chrome','chrome-policy-backup.reg'),@('Registry::HKEY_LOCAL_MACHINE\Software\Policies\Microsoft\Edge','HKLM\Software\Policies\Microsoft\Edge','edge-policy-backup.reg'))){
  if(Test-Path -LiteralPath $item[0]){& reg.exe export $item[1] (Join-Path $installDir $item[2]) /y *> $null}
}
$found=@{}
foreach($tool in @('claude','codex')){
  $cmd=Get-Command $tool -All -ErrorAction SilentlyContinue | Where-Object {$_.Source -and $_.Source -notlike "$binDir*"}|Select-Object -First 1
  if($cmd){$found[$tool]=$cmd.Source}
}
Copy-Item "$PSScriptRoot\AI-Sentinel-Agent.ps1","$PSScriptRoot\Invoke-AI-Sentinel.ps1" $installDir -Force
Copy-Item "$PSScriptRoot\Test-EINSGUARD-Agent.ps1" $installDir -Force
Copy-Item "$PSScriptRoot\Uninstall-AI-Sentinel.ps1" $installDir -Force
@{api_base=$ApiBase;tools=$found}|ConvertTo-Json -Depth 4|Set-Content (Join-Path $installDir 'config.json') -Encoding UTF8
if($AgentKey){Set-Content (Join-Path $installDir 'agent.key') $AgentKey -NoNewline -Encoding ASCII}
elseif(-not(Test-Path (Join-Path $installDir 'agent.key'))){throw '신규 설치에는 승인된 에이전트 키가 필요합니다.'}
foreach($name in @('agent.key','config.json')){
  $path=Join-Path $installDir $name; $acl=Get-Acl $path; $acl.SetAccessRuleProtection($true,$false)
  $acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule('SYSTEM','FullControl','Allow')))
  $acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule('Administrators','FullControl','Allow')))
  $acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule("$env:USERDOMAIN\$env:USERNAME",'Read','Allow')));Set-Acl $path $acl
}
foreach($tool in $found.Keys){
  $line='@echo off' + "`r`n" + 'powershell.exe -NoProfile -ExecutionPolicy Bypass -File "'+(Join-Path $installDir 'Invoke-AI-Sentinel.ps1')+'" -Tool '+$tool+' -- %*'
  Set-Content (Join-Path $binDir "$tool.cmd") $line -Encoding ASCII
}
$machinePath=[Environment]::GetEnvironmentVariable('Path','Machine')
if(($machinePath -split ';') -notcontains $binDir){[Environment]::SetEnvironmentVariable('Path',"$binDir;$machinePath",'Machine')}
$hiddenPowerShellArgs='-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass'
$action=New-ScheduledTaskAction -Execute 'PowerShell.exe' -Argument "$hiddenPowerShellArgs -File `"$installDir\AI-Sentinel-Agent.ps1`" -ApiBase `"$ApiBase`""
$trigger=New-ScheduledTaskTrigger -AtStartup; $settings=New-ScheduledTaskSettingsSet -RestartCount 10 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero)
Register-ScheduledTask -TaskName 'EINSGUARD AI Agent 1.0' -Action $action -Trigger $trigger -Settings $settings -User 'SYSTEM' -RunLevel Highest -Force|Out-Null
$userAction=New-ScheduledTaskAction -Execute 'PowerShell.exe' -Argument "$hiddenPowerShellArgs -File `"$installDir\AI-Sentinel-Agent.ps1`" -ApiBase `"$ApiBase`" -UserMode"
$userTrigger=New-ScheduledTaskTrigger -AtLogOn -User "$env:USERDOMAIN\$env:USERNAME"
$userPrincipal=New-ScheduledTaskPrincipal -UserId "$env:USERDOMAIN\$env:USERNAME" -LogonType Interactive -RunLevel Limited
Register-ScheduledTask -TaskName 'EINSGUARD AI DLP User' -Action $userAction -Trigger $userTrigger -Principal $userPrincipal -Settings $settings -Force|Out-Null
Start-ScheduledTask 'EINSGUARD AI Agent 1.0'
Start-ScheduledTask 'EINSGUARD AI DLP User'
Start-Sleep 5

# Windows의 [설치된 앱]에 제거 항목을 등록한다.
$uninstallCmd=Join-Path $installDir 'Uninstall-EINSGUARD-AI.cmd'
$uninstallScript=Join-Path $installDir 'Uninstall-AI-Sentinel.ps1'
$cmdLine='@echo off' + "`r`n" + 'powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process powershell.exe -Verb RunAs -Wait -ArgumentList ''-NoProfile'',''-ExecutionPolicy'',''Bypass'',''-File'',''' + $uninstallScript.Replace("'","''") + '''"'
Set-Content -LiteralPath $uninstallCmd -Value $cmdLine -Encoding ASCII
$arp='HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\EINSGUARD-AI-Agent-1.0'
New-Item -Path $arp -Force|Out-Null
New-ItemProperty -Path $arp -Name DisplayName -Value 'EINSGUARD AI Windows Agent' -PropertyType String -Force|Out-Null
New-ItemProperty -Path $arp -Name DisplayVersion -Value '1.1.0' -PropertyType String -Force|Out-Null
New-ItemProperty -Path $arp -Name Publisher -Value 'EINSTECH' -PropertyType String -Force|Out-Null
New-ItemProperty -Path $arp -Name InstallLocation -Value $installDir -PropertyType String -Force|Out-Null
New-ItemProperty -Path $arp -Name UninstallString -Value ('"'+$uninstallCmd+'"') -PropertyType String -Force|Out-Null
New-ItemProperty -Path $arp -Name NoModify -Value 1 -PropertyType DWord -Force|Out-Null
New-ItemProperty -Path $arp -Name NoRepair -Value 1 -PropertyType DWord -Force|Out-Null

# 느린 PC에서 Agent 시작이 늦어져도 설치 자체를 실패 처리하지 않는다.
$healthy=$false
for($i=0;$i -lt 3;$i++){
  & powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$installDir\Test-EINSGUARD-Agent.ps1" -ApiBase $ApiBase
  if($LASTEXITCODE -eq 0){$healthy=$true;break}
  Start-Sleep 2
}
if($healthy){Write-Host '설치 및 동작 점검 완료.' -ForegroundColor Green}
else{Write-Warning "설치는 완료됐지만 초기 동작 점검이 지연 중입니다. 로그: $installLog"}
Stop-Transcript
if($BootstrapLog){Copy-Item -LiteralPath $BootstrapLog -Destination $installLog -Force -ErrorAction SilentlyContinue}
exit 0
