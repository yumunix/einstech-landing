#Requires -RunAsAdministrator
param([string]$AgentKey,[string]$AgentKeyFile,[Alias('Server')][string]$ApiBase='127.0.0.1',[string]$BootstrapLog='')
$ErrorActionPreference='Stop'
$ApiBase=$ApiBase.Trim().TrimEnd('/')
if($ApiBase -notmatch '^https?://'){$ApiBase=if($ApiBase.Contains(':')){"http://$ApiBase"}else{"http://${ApiBase}:3100"}}
$AgentKeyFileValue=''
if($AgentKeyFile -and (Test-Path -LiteralPath $AgentKeyFile)){$AgentKeyFileValue=(Get-Content -LiteralPath $AgentKeyFile -Raw).Trim()}
if(-not $AgentKey -and $AgentKeyFileValue){$AgentKey=$AgentKeyFileValue}
$installDir="$env:ProgramData\EINSTECH\AI-Sentinel"; $binDir=Join-Path $installDir 'bin'
$logDir=Join-Path $installDir 'logs'; $installLog=Join-Path $logDir 'install.log'
if($BootstrapLog){Start-Transcript -Path $BootstrapLog -Append -Force}
# 시험 버전의 중복 예약 작업/프로세스를 제거하고 단일 구성으로 전환한다.
foreach($task in @('AI Sentinel Windows Agent','EINSTECH AI Sentinel','EINSGUARD AI Agent','EINSGUARD AI Agent 1.0','EINSGUARD AI DLP User')){
  Stop-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue
  Unregister-ScheduledTask -TaskName $task -Confirm:$false -ErrorAction SilentlyContinue
}
Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
  Where-Object {$_.CommandLine -like '*AI-Sentinel-Agent.ps1*'} |
  ForEach-Object {Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue}
New-Item -ItemType Directory -Force -Path $installDir,$binDir,$logDir|Out-Null
if(-not $BootstrapLog){Start-Transcript -Path $installLog -Append -Force}
Write-Host "EINSGUARD AI Agent 1.4.0 설치 시작: $(Get-Date -Format s)"
foreach($item in @(@('Registry::HKEY_LOCAL_MACHINE\Software\Policies\Google\Chrome','HKLM\Software\Policies\Google\Chrome','chrome-policy-backup.reg'),@('Registry::HKEY_LOCAL_MACHINE\Software\Policies\Microsoft\Edge','HKLM\Software\Policies\Microsoft\Edge','edge-policy-backup.reg'))){
  if(Test-Path -LiteralPath $item[0]){& reg.exe export $item[1] (Join-Path $installDir $item[2]) /y *> $null}
}
$existingTools=@{}
$existingConfig=Join-Path $installDir 'config.json'
if(Test-Path -LiteralPath $existingConfig){
  try{$existingTools=(Get-Content -LiteralPath $existingConfig -Raw|ConvertFrom-Json).tools}catch{}
}
function Find-OriginalTool([string]$tool){
  $candidates=New-Object Collections.Generic.List[string]
  $existing=[string]$existingTools.$tool
  foreach($root in @(
    (Join-Path $env:APPDATA 'npm'),
    (Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Links'),
    (Join-Path $env:USERPROFILE '.local\bin')
  )){
    foreach($ext in @('.exe','.cmd','.bat','.ps1')){$candidates.Add((Join-Path $root ($tool+$ext)))}
  }
  if($existing){$candidates.Add($existing)}
  foreach($name in @($tool+'.exe',$tool+'.cmd',$tool+'.bat',$tool)){
    foreach($cmd in @(Get-Command $name -All -ErrorAction SilentlyContinue)){
      if($cmd.Source){$candidates.Add([string]$cmd.Source)}
    }
  }
  $candidates|Where-Object {$_ -and $_ -notlike "$binDir*" -and (Test-Path -LiteralPath $_)}|Select-Object -First 1
}
$found=@{}
foreach($tool in @('claude','codex')){
  $original=Find-OriginalTool $tool
  if($original){$found[$tool]=$original}
}
Copy-Item "$PSScriptRoot\AI-Sentinel-Agent.ps1","$PSScriptRoot\Invoke-AI-Sentinel.ps1" $installDir -Force
Copy-Item "$PSScriptRoot\Test-EINSGUARD-Agent.ps1" $installDir -Force
Copy-Item "$PSScriptRoot\Uninstall-AI-Sentinel.ps1" $installDir -Force
@{api_base=$ApiBase;tools=$found}|ConvertTo-Json -Depth 4|Set-Content (Join-Path $installDir 'config.json') -Encoding UTF8
$installedKeyFile=Join-Path $installDir 'agent.key'
if(-not $AgentKey -and -not(Test-Path -LiteralPath $installedKeyFile)){
  $enrollmentBody=@{
    hostname=$env:COMPUTERNAME
    username=[Security.Principal.WindowsIdentity]::GetCurrent().Name
    os_version="windows/$env:PROCESSOR_ARCHITECTURE · $([Environment]::OSVersion.VersionString)"
  }|ConvertTo-Json -Compress
  $enrollment=Invoke-RestMethod -Method Post -Uri "$ApiBase/api/enroll" -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes($enrollmentBody)) -TimeoutSec 15
  if(-not $enrollment.token){throw '관리 서버에서 장비 등록 토큰을 받지 못했습니다.'}
  Write-Host '장비 등록 요청을 보냈습니다.' -ForegroundColor Yellow
  Write-Host 'AI GUARD의 [장비·사용자]에서 이 장비를 승인해 주세요.' -ForegroundColor Yellow
  $statusUri="$ApiBase/api/enroll?token=$([uri]::EscapeDataString([string]$enrollment.token))"
  for($poll=0;$poll -lt 120;$poll++){
    Start-Sleep 5
    try{$enrollmentStatus=Invoke-RestMethod -Method Get -Uri $statusUri -TimeoutSec 15}catch{continue}
    if($enrollmentStatus.status -eq 'approved' -and $enrollmentStatus.agent_key){$AgentKey=[string]$enrollmentStatus.agent_key;break}
    if($enrollmentStatus.status -eq 'rejected'){throw '관리자가 장비 등록을 거부했습니다.'}
  }
  if(-not $AgentKey){throw '승인 대기 시간이 초과됐습니다. 설치 명령을 다시 실행해 주세요.'}
  Write-Host '관리자 승인이 완료됐습니다. 장비 전용 키를 자동 적용합니다.' -ForegroundColor Green
}
if($AgentKey){Set-Content $installedKeyFile $AgentKey -NoNewline -Encoding ASCII}
elseif(-not(Test-Path -LiteralPath $installedKeyFile)){throw '장비 전용 Agent 키를 준비하지 못했습니다.'}
foreach($name in @('agent.key','config.json')){
  $path=Join-Path $installDir $name; $acl=Get-Acl $path; $acl.SetAccessRuleProtection($true,$false)
  $acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule('SYSTEM','FullControl','Allow')))
  $acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule('Administrators','FullControl','Allow')))
  $acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule("$env:USERDOMAIN\$env:USERNAME",'Read','Allow')));Set-Acl $path $acl
}
foreach($tool in $found.Keys){
  $line='@echo off' + "`r`n" + 'powershell.exe -NoProfile -ExecutionPolicy Bypass -File "'+(Join-Path $installDir 'Invoke-AI-Sentinel.ps1')+'" -Tool '+$tool+' %*'
  Set-Content (Join-Path $binDir "$tool.cmd") $line -Encoding ASCII
}
$machinePath=[Environment]::GetEnvironmentVariable('Path','Machine')
if(($machinePath -split ';') -notcontains $binDir){[Environment]::SetEnvironmentVariable('Path',"$binDir;$machinePath",'Machine')}
$hiddenPowerShellArgs='-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass'
$action=New-ScheduledTaskAction -Execute 'PowerShell.exe' -Argument "$hiddenPowerShellArgs -File `"$installDir\AI-Sentinel-Agent.ps1`" -ApiBase `"$ApiBase`""
$trigger=New-ScheduledTaskTrigger -AtStartup; $settings=New-ScheduledTaskSettingsSet -RestartCount 10 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero)
Register-ScheduledTask -TaskName 'EINSGUARD AI Agent' -Action $action -Trigger $trigger -Settings $settings -User 'SYSTEM' -RunLevel Highest -Force|Out-Null
$userAction=New-ScheduledTaskAction -Execute 'PowerShell.exe' -Argument "$hiddenPowerShellArgs -File `"$installDir\AI-Sentinel-Agent.ps1`" -ApiBase `"$ApiBase`" -UserMode"
$userTrigger=New-ScheduledTaskTrigger -AtLogOn -User "$env:USERDOMAIN\$env:USERNAME"
$userPrincipal=New-ScheduledTaskPrincipal -UserId "$env:USERDOMAIN\$env:USERNAME" -LogonType Interactive -RunLevel Limited
Register-ScheduledTask -TaskName 'EINSGUARD AI DLP User' -Action $userAction -Trigger $userTrigger -Principal $userPrincipal -Settings $settings -Force|Out-Null
Start-ScheduledTask 'EINSGUARD AI Agent'
Start-ScheduledTask 'EINSGUARD AI DLP User'
Start-Sleep 5

# Windows의 [설치된 앱]에 제거 항목을 등록한다.
$uninstallCmd=Join-Path $installDir 'Uninstall-EINSGUARD-AI.cmd'
$uninstallScript=Join-Path $installDir 'Uninstall-AI-Sentinel.ps1'
$cmdLine='@echo off' + "`r`n" + 'powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process powershell.exe -Verb RunAs -Wait -ArgumentList ''-NoProfile'',''-ExecutionPolicy'',''Bypass'',''-File'',''' + $uninstallScript.Replace("'","''") + '''"'
Set-Content -LiteralPath $uninstallCmd -Value $cmdLine -Encoding ASCII
$arp='HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\EINSGUARD-AI-Agent-1.0'
New-Item -Path $arp -Force|Out-Null
New-ItemProperty -Path $arp -Name DisplayName -Value 'EINSGUARD AI Windows Agent' -PropertyType String -Force|Out-Null
New-ItemProperty -Path $arp -Name DisplayVersion -Value '1.4.0' -PropertyType String -Force|Out-Null
New-ItemProperty -Path $arp -Name Publisher -Value 'EINSTECH' -PropertyType String -Force|Out-Null
New-ItemProperty -Path $arp -Name InstallLocation -Value $installDir -PropertyType String -Force|Out-Null
New-ItemProperty -Path $arp -Name UninstallString -Value ('"'+$uninstallCmd+'"') -PropertyType String -Force|Out-Null
New-ItemProperty -Path $arp -Name NoModify -Value 1 -PropertyType DWord -Force|Out-Null
New-ItemProperty -Path $arp -Name NoRepair -Value 1 -PropertyType DWord -Force|Out-Null

# 느린 PC에서 Agent 시작이 늦어져도 설치 자체를 실패 처리하지 않는다.
$healthy=$false
for($i=0;$i -lt 3;$i++){
  & powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$installDir\Test-EINSGUARD-Agent.ps1" -ApiBase $ApiBase
  if($LASTEXITCODE -eq 0){$healthy=$true;break}
  Start-Sleep 2
}
if($healthy){Write-Host '설치 및 동작 점검 완료.' -ForegroundColor Green}
else{Write-Warning "설치는 완료됐지만 초기 동작 점검이 지연 중입니다. 로그: $installLog"}
Stop-Transcript
if($BootstrapLog){Copy-Item -LiteralPath $BootstrapLog -Destination $installLog -Force -ErrorAction SilentlyContinue}
exit 0
