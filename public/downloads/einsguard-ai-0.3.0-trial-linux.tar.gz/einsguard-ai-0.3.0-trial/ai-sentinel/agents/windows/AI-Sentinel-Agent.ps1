param(
  [string]$ApiBase = "http://127.0.0.1:3100",
  [string]$KeyFile = "$env:ProgramData\EINSTECH\AI-Sentinel\agent.key",
  [switch]$UserMode,
  [switch]$Once
)
$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'
$AgentVersion='1.1.0'
$InteractiveUser=try{([string](Get-CimInstance Win32_ComputerSystem -ErrorAction Stop).UserName).Split('\')[-1]}catch{$env:USERNAME}
if(-not $InteractiveUser){$InteractiveUser=$env:USERNAME}
$DlpPolicy=@{enabled=$true;blockCritical=$true;storeRawChat=$false;inspectContentWithLocalAi=$true;aiVerification=$true;scanClipboard=$true;scanCliArguments=$true}
$DlpPatterns=@(
  @{type='PRIVATE_KEY';severity='CRITICAL';regex='-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----'},
  @{type='API_KEY';severity='CRITICAL';regex='(?i)(?:sk-[A-Za-z0-9_-]{20,}|sk-ant-[A-Za-z0-9_-]{20,}|AIza[0-9A-Za-z_-]{30,}|gh[pousr]_[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16})'},
  @{type='PASSWORD';severity='HIGH';regex='(?i)(?:password|passwd|pwd|비밀번호)\s*[:=]\s*[^\s,;]{6,}'},
  @{type='KOREAN_RRN';severity='HIGH';regex='(?<!\d)(?:\d{6})[- ]?[1-4]\d{6}(?!\d)'},
  @{type='CARD_NUMBER';severity='HIGH';regex='(?<!\d)(?:\d[ -]?){13,19}(?!\d)'},
  @{type='CUSTOMER_DATA';severity='HIGH';regex='(?i)(?:고객명|고객정보|customer(?:\s+name|\s+list)?|account(?:\s+number)?|전화번호|휴대폰)\s*[:=,]\s*.{3,}'}
)
$ToolRules=@{
  claude=@{process=@('claude','claude-desktop'); command=@('claude'); domains=@('claude.ai','*.claude.ai')}
  chatgpt=@{process=@('chatgpt'); command=@(); domains=@('chatgpt.com','*.chatgpt.com','chat.openai.com','*.openai.com')}
  codex=@{process=@('codex'); command=@('codex'); domains=@()}
  cursor=@{process=@('cursor'); command=@('cursor'); domains=@('cursor.com','*.cursor.com')}
  copilot=@{process=@('githubcopilot','copilot','m365copilot'); command=@('copilot','m365copilot','m365copilot.exe','webview-exe-name=m365copilot.exe','microsoft.microsoftofficehub','microsoft.copilot','microsoftcopilot','copilot.microsoft','8wekyb3d8bbwe!app'); domains=@('github.com/copilot','copilot.microsoft.com','copilot.cloud.microsoft','m365.cloud.microsoft','copilotstudio.microsoft.com')}
  gemini=@{process=@('gemini'); command=@('gemini'); domains=@('gemini.google.com')}
  windsurf=@{process=@('windsurf'); command=@('windsurf'); domains=@('windsurf.com','*.windsurf.com')}
  aider=@{process=@('aider'); command=@('aider'); domains=@()}
  ollama=@{process=@('ollama','ollama app'); command=@('ollama'); domains=@()}
  perplexity=@{process=@('perplexity'); command=@(); domains=@('perplexity.ai','*.perplexity.ai')}
  grok=@{process=@('grok'); command=@(); domains=@('grok.com','*.grok.com')}
  deepseek=@{process=@('deepseek'); command=@(); domains=@('chat.deepseek.com','*.deepseek.com')}
}

function Write-AgentEvent([string]$Type,[string]$Tool,[string]$Detail){
  try{Invoke-RestMethod -Method Post -Uri "$ApiBase/api/agent?action=security-event" -Headers $script:Headers -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes((@{hostname=$env:COMPUTERNAME;username=$InteractiveUser;event_type=$Type;tool=$Tool;detail=$Detail}|ConvertTo-Json -Compress))) -TimeoutSec 10|Out-Null}catch{}
}
function Update-PolicyProfile{
  $uri="$ApiBase/api/agent?action=policy-profile&hostname=$([uri]::EscapeDataString($env:COMPUTERNAME))"
  $profile=Invoke-RestMethod -Method Get -Uri $uri -Headers $script:Headers -TimeoutSec 15
  $rules=@{}
  foreach($item in @($profile.catalog)){
    $rules[[string]$item.key]=@{process=@($item.processes);command=@($item.commands);domains=@($item.domains)}
  }
  if($rules.Count -gt 0){$script:ToolRules=$rules}
  $script:Approved=@($profile.approved_tools)
  if($profile.dlp){$script:DlpPolicy=$profile.dlp}
}
function Protect-Evidence([string]$Text){
  if($Text.Length -le 8){return ('*' * [Math]::Min($Text.Length,8))}
  return $Text.Substring(0,4)+('…' * 1)+$Text.Substring($Text.Length-4)
}
function Send-DlpEvent([string]$Tool,[string]$Channel,[hashtable]$Rule,[string]$Match,[string]$RawContent,[int]$Count,[string]$Action){
  $sha=[Security.Cryptography.SHA256]::Create();try{$hash=([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($Match)))).Replace('-','').ToLowerInvariant()}finally{$sha.Dispose()}
  $event=@{hostname=$env:COMPUTERNAME;username=$InteractiveUser;tool=$Tool;channel=$Channel;violation_type=$Rule.type;severity=$Rule.severity;evidence_hash=$hash;masked_evidence=(Protect-Evidence $Match);match_count=$Count;action_taken=$Action}
  if($DlpPolicy.inspectContentWithLocalAi -ne $false -and $RawContent){$event.raw_content=$RawContent.Substring(0,[Math]::Min($RawContent.Length,12000))}
  $body=$event|ConvertTo-Json -Compress
  try{Invoke-RestMethod -Method Post -Uri "$ApiBase/api/dlp" -Headers $script:Headers -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes($body)) -TimeoutSec 5|Out-Null}catch{}
}
function Test-DlpText([string]$Text,[string]$Tool,[string]$Channel){
  if(-not $DlpPolicy.enabled -or [string]::IsNullOrWhiteSpace($Text)){return $false}
  $critical=$false
  foreach($rule in $DlpPatterns){
    $matches=@([regex]::Matches($Text,$rule.regex))
    if($matches.Count){$action=if($rule.severity-eq'CRITICAL' -and $DlpPolicy.blockCritical){'blocked'}else{'alerted'};Send-DlpEvent $Tool $Channel $rule $matches[0].Value $Text $matches.Count $action;if($rule.severity-eq'CRITICAL'){$critical=$true}}
  }
  return $critical
}
function Run-ClipboardDlp{
  Update-PolicyProfile
  Write-AgentEvent 'USER_MONITOR_STARTED' 'windows-user-monitor' 'Interactive DLP and AI window monitor started'
  $lastHash=''
  $seenWindows=@{}
  do{
    try{
      foreach($windowTool in Get-WindowTools){if(-not $seenWindows.ContainsKey($windowTool)){$seenWindows[$windowTool]=$true;Write-AgentEvent 'AI_WINDOW_DETECTED' $windowTool "AI application or browser window detected: $windowTool"}}
      $text=Get-Clipboard -Raw -Format Text -ErrorAction SilentlyContinue
      if($text){$sha=[Security.Cryptography.SHA256]::Create();try{$h=[Convert]::ToBase64String($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($text)))}finally{$sha.Dispose()};if($h-ne$lastHash){$lastHash=$h;$tool=(Get-WebActivity|Select-Object -First 1);if(-not $tool){$tool='unknown-ai'};if(Test-DlpText $text $tool 'clipboard'){Set-Clipboard -Value '';Write-AgentEvent 'DLP_CLIPBOARD_BLOCKED' $tool 'Critical secret removed from clipboard'}}}
    }catch{}
    if(-not $Once){Start-Sleep 2}
  }while(-not $Once)
}
function Get-InstalledTools{
  $out=New-Object Collections.Generic.HashSet[string]
  foreach($tool in $ToolRules.Keys){
    foreach($cmd in $ToolRules[$tool].command){if(Get-Command $cmd -ErrorAction SilentlyContinue){[void]$out.Add($tool)}}
  }
  $uninstall=@('HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*')
  $names=@(Get-ItemProperty $uninstall -ErrorAction SilentlyContinue|ForEach-Object {$_.DisplayName}) -join ' '
  $names+=' '+(@(Get-AppxPackage -AllUsers -ErrorAction SilentlyContinue|ForEach-Object {$_.Name+' '+$_.PackageFamilyName}) -join ' ')
  foreach($tool in $ToolRules.Keys){if($names -match [regex]::Escape($tool)){[void]$out.Add($tool)}}
  @($out)
}
function Get-RunningMap{
  $map=@{}; foreach($tool in $ToolRules.Keys){$map[$tool]=@()}
  foreach($p in Get-CimInstance Win32_Process -ErrorAction SilentlyContinue){
    $name=[IO.Path]::GetFileNameWithoutExtension([string]$p.Name).ToLowerInvariant()
    $cmd=[string]$p.CommandLine
    foreach($tool in $ToolRules.Keys){
      $matched=$false
      foreach($proc in $ToolRules[$tool].process){if($name -eq $proc -or $name -like "$proc*"){$matched=$true}}
      foreach($cli in $ToolRules[$tool].command){if($cli.Length -lt 3){if($name -eq $cli){$matched=$true}}elseif($cmd -match "(?i)(^|[^A-Za-z0-9_-])$([regex]::Escape($cli))(\.exe|\.cmd|\.ps1)?([^A-Za-z0-9_-]|$)"){$matched=$true}}
      if($matched){$map[$tool]+=,$p}
    }
  };$map
}
function Get-WindowTools{
  $seen=@();foreach($p in Get-Process -ErrorAction SilentlyContinue){$title=[string]$p.MainWindowTitle;if($title-match'(?i)\bCopilot\b|Microsoft 365 Copilot'){$seen+='copilot'};if($title-match'(?i)ChatGPT'){$seen+='chatgpt'};if($title-match'(?i)Claude'){$seen+='claude'};if($title-match'(?i)Gemini'){$seen+='gemini'}};@($seen|Select-Object -Unique)
}
function Get-WebActivity{
  $text=(Get-DnsClientCache -ErrorAction SilentlyContinue|ForEach-Object {$_.Entry}) -join ' '
  $seen=@();foreach($tool in $ToolRules.Keys){foreach($domain in $ToolRules[$tool].domains){$needle=$domain.Replace('*.','');if($text -match [regex]::Escape($needle)){$seen+=$tool;break}}};@($seen|Select-Object -Unique)
}
function Set-BrowserPolicy([string[]]$Approved){
  $blocked=@();foreach($tool in $ToolRules.Keys){if($Approved -notcontains $tool){$blocked+=@($ToolRules[$tool].domains)}}
  $blocked=@($blocked|Where-Object {$_}|Select-Object -Unique)
  foreach($browser in @('HKLM:\Software\Policies\Google\Chrome','HKLM:\Software\Policies\Microsoft\Edge')){
    New-Item -Path $browser -Force|Out-Null
    New-ItemProperty -Path $browser -Name DnsOverHttpsMode -Value 'off' -PropertyType String -Force|Out-Null
    $list=Join-Path $browser 'URLBlocklist';Remove-Item $list -Recurse -Force -ErrorAction SilentlyContinue;New-Item $list -Force|Out-Null
    $i=1;foreach($domain in $blocked){New-ItemProperty -Path $list -Name ([string]$i) -Value "*$domain*" -PropertyType String -Force|Out-Null;$i++}
  }
}
function Run-Cycle{
  if(-not(Test-Path -LiteralPath $KeyFile)){throw "Agent key not found: $KeyFile"}
  Update-PolicyProfile
  $runningMap=Get-RunningMap;$running=@($runningMap.Keys|Where-Object {$runningMap[$_].Count -gt 0});$web=@(Get-WebActivity)+@(Get-WindowTools)
  if($DlpPolicy.scanCliArguments){foreach($tool in $runningMap.Keys){foreach($p in $runningMap[$tool]){if($p.CommandLine){$blocked=Test-DlpText ([string]$p.CommandLine) $tool 'cli';if($blocked -and $DlpPolicy.blockCritical){Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue}}}}}
  $body=@{hostname=$env:COMPUTERNAME;username=$InteractiveUser;os='windows';os_version=[Environment]::OSVersion.VersionString;arch=$env:PROCESSOR_ARCHITECTURE;agent_version=$AgentVersion;installed_tools=Get-InstalledTools;running_tools=@($running+$web|Select-Object -Unique)}|ConvertTo-Json -Depth 5
  $response=Invoke-RestMethod -Method Post -Uri "$ApiBase/api/agents?action=inventory-report" -Headers $script:Headers -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes($body)) -TimeoutSec 15
  $approved=@($script:Approved);if($response.approved_tools){$approved=@($response.approved_tools)};Set-BrowserPolicy $approved
  foreach($tool in $runningMap.Keys){if($runningMap[$tool].Count -and $approved -notcontains $tool){foreach($p in $runningMap[$tool]){Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue};Write-AgentEvent 'UNAPPROVED_AI_BLOCKED' $tool "승인되지 않은 앱/CLI 실행 차단: $tool"}}
  foreach($tool in $web){if($approved -notcontains $tool){Write-AgentEvent 'UNAPPROVED_WEB_AI_BLOCKED' $tool "승인되지 않은 웹 AI 접속 탐지 및 브라우저 정책 차단: $tool"}}
}

$script:Headers=@{'x-ai-sentinel-key'=(Get-Content -LiteralPath $KeyFile -Raw).Trim()}
if($UserMode){Run-ClipboardDlp;exit 0}
do{try{Run-Cycle}catch{try{Write-EventLog -LogName Application -Source 'EINSGUARD AI' -EntryType Warning -EventId 5101 -Message $_.Exception.Message -ErrorAction SilentlyContinue}catch{}};if(-not $Once){Start-Sleep 5}}while(-not $Once)
