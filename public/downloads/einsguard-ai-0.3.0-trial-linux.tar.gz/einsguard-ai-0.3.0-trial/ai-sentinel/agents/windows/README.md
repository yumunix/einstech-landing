# EINSGUARD AI Windows Agent 1.4.0

관리자 PowerShell에서 설치합니다.

먼저 ZIP 파일을 로컬 폴더에 완전히 압축 해제하십시오. PowerShell을 관리자 권한으로
열고 압축 해제한 폴더로 이동한 다음 아래 명령을 실행합니다.

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\Install-AI-Sentinel.ps1 -ApiBase 'https://einsguard.example.com'
```

시험 PC에서는 고객사 관리 서버 주소를 지정합니다.

```powershell
.\Install-AI-Sentinel.ps1 -ApiBase '10.0.0.10'
```

설치 프로그램이 장비 등록을 요청하면 관리자는 AI GUARD의 `장비·사용자`에서
승인합니다. 승인 후 장비 전용 Agent 키가 자동으로 저장되므로 키를 직접 입력하지 않습니다.

설치기는 Claude/Codex CLI의 실제 경로를 보관하고 앞단에 정책 래퍼를 배치합니다.
새 터미널부터 차단, 시간/횟수 정책, 관리자 승인, 원격 일시정지·재개·종료 및
세션 감사가 적용됩니다. 자산/Shadow AI 인벤토리는 SYSTEM 예약 작업이 60초마다 보고합니다.

제거: 관리자 PowerShell에서 `.\Uninstall-AI-Sentinel.ps1` 실행.
