param([string]$ApiBase='http://127.0.0.1:3100')
$installDir="$env:ProgramData\EINSTECH\AI-Sentinel";$checks=New-Object Collections.Generic.List[object]
function Add-Check($Name,$Ok,$Detail){$checks.Add([pscustomobject]@{Check=$Name;Status=$(if($Ok){'OK'}else{'FAIL'});Detail=$Detail})}
$task=Get-ScheduledTask -TaskName 'EINSGUARD AI Agent 1.0' -ErrorAction SilentlyContinue
Add-Check 'Scheduled task' ($null -ne $task) $(if($task){$task.State}else{'missing'})
$userTask=Get-ScheduledTask -TaskName 'EINSGUARD AI DLP User' -ErrorAction SilentlyContinue
$userInfo=Get-ScheduledTaskInfo -TaskName 'EINSGUARD AI DLP User' -ErrorAction SilentlyContinue
Add-Check 'User DLP task' ($null-ne$userTask-and$userTask.State-eq'Running') $(if($userTask){"$($userTask.State), result=$($userInfo.LastTaskResult)"}else{'missing'})
$old=@('AI Sentinel Windows Agent','EINSTECH AI Sentinel','EINSGUARD AI Agent')|Where-Object {Get-ScheduledTask -TaskName $_ -ErrorAction SilentlyContinue}
Add-Check 'Legacy task duplicates' (@($old).Count -eq 0) $(if($old){$old -join ', '}else{'none'})
$files=@('AI-Sentinel-Agent.ps1','Invoke-AI-Sentinel.ps1','agent.key','config.json')
$missing=$files|Where-Object {-not(Test-Path (Join-Path $installDir $_))}
Add-Check 'Required files' (@($missing).Count -eq 0) $(if($missing){'Missing: '+($missing -join ', ')}else{'present'})
try{$acl=Get-Acl (Join-Path $installDir 'agent.key');$unsafe=@($acl.Access|Where-Object {$_.IdentityReference -notmatch 'SYSTEM|Administrators' -and $_.FileSystemRights -match 'Write|FullControl'});$userRead=@($acl.Access|Where-Object {$_.IdentityReference -eq "$env:USERDOMAIN\$env:USERNAME" -and $_.FileSystemRights -match 'Read'});Add-Check 'Key ACL' ($unsafe.Count-eq 0-and$userRead.Count-gt 0) $(if($unsafe){'unsafe write access'}elseif(-not$userRead){'interactive user read missing'}else{'protected; user read-only'})}catch{Add-Check 'Key ACL' $false $_.Exception.Message}
$proc=Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue|Where-Object {$_.CommandLine -like '*AI-Sentinel-Agent.ps1*'}
$systemProc=@($proc|Where-Object {$_.CommandLine -notlike '*-UserMode*'})
$userProc=@($proc|Where-Object {$_.CommandLine -like '*-UserMode*'})
Add-Check 'Agent processes' ($systemProc.Count-eq 1-and$userProc.Count-eq 1) "system=$($systemProc.Count), user-dlp=$($userProc.Count), total=$(@($proc).Count)"
$keyFile=Join-Path $installDir 'agent.key'
try{
  $key=(Get-Content -LiteralPath $keyFile -Raw).Trim()
  $uri="$ApiBase/api/agent?action=policy-profile&hostname=$([uri]::EscapeDataString($env:COMPUTERNAME))"
  $policy=Invoke-RestMethod -Uri $uri -Headers @{'x-ai-sentinel-key'=$key} -TimeoutSec 5
  Add-Check 'Server connection' $true 'Agent API responded'
  Add-Check 'Agent API auth' (@('monitor','enforce') -contains [string]$policy.mode) "mode=$($policy.mode), catalog=$(@($policy.catalog).Count)"
}catch{Add-Check 'Server connection' $false $_.Exception.Message;Add-Check 'Agent API auth' $false $_.Exception.Message}
$pathCount=@(([Environment]::GetEnvironmentVariable('Path','Machine')-split ';')|Where-Object {$_ -eq (Join-Path $installDir 'bin')}).Count
Add-Check 'PATH duplicates' ($pathCount -le 1) "entries: $pathCount"
$checks|Format-Table -AutoSize
if($checks.Status -contains 'FAIL'){Write-Host 'EINSGUARD AI Agent status: CHECK REQUIRED' -ForegroundColor Red;exit 1}
Write-Host 'EINSGUARD AI Agent status: HEALTHY' -ForegroundColor Green
