#!/bin/bash
# Hosts with the system Codex package use this as ~/.local/bin/codex.real.
# Call the packaged native binary directly because the system JS launcher was
# previously wrapped and its `.real` copy cannot be loaded as an ES module.
exec /usr/local/lib/node_modules/@openai/codex/node_modules/@openai/codex-linux-x64/vendor/x86_64-unknown-linux-musl/bin/codex "$@"
