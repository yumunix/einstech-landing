#!/bin/sh
set -eu
[ "$(id -u)" -eq 0 ] || { echo 'Run as root.' >&2; exit 1; }
EINSGUARD_API=${1:-${EINSGUARD_API:-}}
[ -n "$EINSGUARD_API" ] || { echo 'Usage: sudo ./install.sh SERVER_IP' >&2; exit 2; }
command -v python3 >/dev/null || { echo 'python3 is required.' >&2; exit 3; }
command -v systemctl >/dev/null || { echo 'systemd is required.' >&2; exit 3; }
src=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
agent_src="$src/einsguard-agent.py"
[ -f "$agent_src" ] || agent_src="$src/../ai-sentinel-governance.py"
[ -f "$agent_src" ] || { echo 'einsguard-agent.py is missing from the package.' >&2; exit 3; }
enroll_src="$src/enroll.py"
[ -f "$enroll_src" ] || { echo 'enroll.py is missing from the package.' >&2; exit 3; }
case "$EINSGUARD_API" in
  http://*|https://*) EINSGUARD_API=${EINSGUARD_API%/} ;;
  *:*) EINSGUARD_API="http://$EINSGUARD_API" ;;
  *) EINSGUARD_API="http://$EINSGUARD_API:3100" ;;
esac
install -d -m 0755 /opt/einsguard-ai /etc/einsguard-ai /var/log/einsguard-ai
install -m 0755 "$agent_src" /opt/einsguard-ai/einsguard-agent
install -m 0755 "$enroll_src" /opt/einsguard-ai/enroll
if [ ! -s /etc/einsguard-ai/agent.key ]; then
  /usr/bin/python3 /opt/einsguard-ai/enroll "$EINSGUARD_API" /etc/einsguard-ai/agent.key
fi
printf '%s\n' "$EINSGUARD_API" > /etc/einsguard-ai/server.url; chmod 0644 /etc/einsguard-ai/server.url
cat > /etc/systemd/system/einsguard-ai.service <<EOF
[Unit]
Description=EINSGUARD AI Governance Agent
After=network-online.target
[Service]
Type=simple
ExecStart=/usr/bin/python3 /opt/einsguard-ai/einsguard-agent --api $EINSGUARD_API --key-file /etc/einsguard-ai/agent.key
Restart=always
RestartSec=5
NoNewPrivileges=true
StandardOutput=append:/var/log/einsguard-ai/agent.log
StandardError=append:/var/log/einsguard-ai/agent-error.log
[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload;systemctl enable --now einsguard-ai.service
sleep 2
systemctl is-active --quiet einsguard-ai.service || { systemctl status einsguard-ai.service --no-pager; exit 4; }
echo 'EINSGUARD AI Linux Agent 1.2.0 installed successfully.'
echo 'Status: sudo ./status.sh'
echo 'Logs: /var/log/einsguard-ai/'
