#!/bin/sh
set -eu
[ "$(id -u)" -eq 0 ] || { echo 'Run with sudo.' >&2; exit 1; }
EINSGUARD_API=${1:-${EINSGUARD_API:-}}
[ -n "$EINSGUARD_API" ] || { echo 'Usage: sudo ./install-system.sh SERVER_IP' >&2; exit 2; }
PYTHON_BIN=$(command -v python3 || true)
[ -n "$PYTHON_BIN" ] || { echo 'python3 is required. Install Apple Command Line Tools or Python 3.' >&2; exit 3; }
src=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
agent_src="$src/einsguard-agent.py"
[ -f "$agent_src" ] || agent_src="$src/../ai-sentinel-governance.py"
[ -f "$agent_src" ] || { echo 'einsguard-agent.py is missing from the package.' >&2; exit 3; }
enroll_src="$src/enroll.py"
[ -f "$enroll_src" ] || enroll_src="$src/../linux/enroll.py"
[ -f "$enroll_src" ] || { echo 'enroll.py is missing from the package.' >&2; exit 3; }
case "$EINSGUARD_API" in
  http://*|https://*) EINSGUARD_API=${EINSGUARD_API%/} ;;
  *:*) EINSGUARD_API="http://$EINSGUARD_API" ;;
  *) EINSGUARD_API="http://$EINSGUARD_API:3100" ;;
esac
install -d -m 0755 /Library/EINSGUARD /Library/EINSGUARD/bin /Library/EINSGUARD/etc
install -m 0755 "$agent_src" /Library/EINSGUARD/bin/einsguard-agent
install -m 0755 "$enroll_src" /Library/EINSGUARD/bin/enroll
if [ ! -s /Library/EINSGUARD/etc/agent.key ]; then
  "$PYTHON_BIN" /Library/EINSGUARD/bin/enroll "$EINSGUARD_API" /Library/EINSGUARD/etc/agent.key
fi
printf '%s\n' "$EINSGUARD_API" > /Library/EINSGUARD/etc/server.url;chmod 0644 /Library/EINSGUARD/etc/server.url
cat > /Library/LaunchDaemons/com.einstech.einsguard-ai.plist <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict><key>Label</key><string>com.einstech.einsguard-ai</string><key>ProgramArguments</key><array><string>$PYTHON_BIN</string><string>/Library/EINSGUARD/bin/einsguard-agent</string><string>--api</string><string>$EINSGUARD_API</string><string>--key-file</string><string>/Library/EINSGUARD/etc/agent.key</string></array><key>RunAtLoad</key><true/><key>KeepAlive</key><true/><key>ThrottleInterval</key><integer>5</integer><key>StandardOutPath</key><string>/Library/Logs/einsguard-ai.log</string><key>StandardErrorPath</key><string>/Library/Logs/einsguard-ai-error.log</string></dict></plist>
EOF
chmod 0644 /Library/LaunchDaemons/com.einstech.einsguard-ai.plist
launchctl bootout system/com.einstech.einsguard-ai 2>/dev/null || true
if [ -s /Library/Logs/einsguard-ai-error.log ]; then
  mv /Library/Logs/einsguard-ai-error.log "/Library/Logs/einsguard-ai-error-before-install-$(date +%Y%m%d-%H%M%S).log"
fi
launchctl bootstrap system /Library/LaunchDaemons/com.einstech.einsguard-ai.plist
sleep 2
launchctl print system/com.einstech.einsguard-ai >/dev/null
echo 'EINSGUARD AI macOS Agent 1.3.0 installed successfully.'
echo 'Status: sudo ./status.sh'
echo 'Logs: /Library/Logs/einsguard-ai*.log'
