#!/usr/bin/env python3
import getpass
import json
import os
import platform
import socket
import sys
import time
import urllib.error
import urllib.parse
import urllib.request


def api_base(value: str) -> str:
    value = value.strip().rstrip("/")
    if value.startswith(("http://", "https://")):
        return value
    if ":" in value:
        return f"http://{value}"
    return f"http://{value}:3100"


def request(method: str, url: str, body=None):
    data = None
    headers = {}
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=8) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        try:
            detail = json.loads(exc.read().decode("utf-8")).get("error")
        except Exception:
            detail = None
        raise RuntimeError(detail or f"HTTP {exc.code}") from exc


def save_key(path: str, key: str):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        os.write(fd, key.encode("utf-8"))
    finally:
        os.close(fd)
    os.chmod(path, 0o600)


def main():
    if len(sys.argv) != 3:
        raise SystemExit("Usage: enroll.py SERVER_IP KEY_FILE")
    base = api_base(sys.argv[1])
    key_file = sys.argv[2]
    username = os.environ.get("SUDO_USER") or getpass.getuser()
    reply = request(
        "POST",
        f"{base}/api/enroll",
        {
            "hostname": socket.gethostname(),
            "username": username,
            "os_version": f"linux/{platform.machine()} · {platform.release()}",
        },
    )
    token = reply.get("token")
    if not token:
        raise RuntimeError(reply.get("error") or "등록 토큰을 받지 못했습니다.")

    print("등록 요청을 보냈습니다.")
    print("AI GUARD 관리 화면의 [AI 자산]에서 이 장비를 승인해 주세요.")
    print("승인되면 Agent 키를 자동으로 받아 설치를 계속합니다.")
    interval = float(os.environ.get("EINSGUARD_ENROLL_INTERVAL", "5"))
    max_polls = int(os.environ.get("EINSGUARD_ENROLL_MAX_POLLS", "120"))
    status_url = f"{base}/api/enroll?token={urllib.parse.quote(token)}"
    for _ in range(max_polls):
        time.sleep(interval)
        try:
            reply = request("GET", status_url)
        except Exception as exc:
            print(f"승인 상태 확인 재시도: {exc}", file=sys.stderr)
            continue
        status = reply.get("status")
        if status == "approved" and reply.get("agent_key"):
            save_key(key_file, reply["agent_key"])
            print("관리자 승인이 완료되었습니다.")
            return
        if status == "rejected":
            raise RuntimeError("관리자가 등록을 거부했습니다.")
        if status == "expired":
            break
    raise RuntimeError("승인 대기 시간이 초과됐습니다. install.sh를 다시 실행해 주세요.")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"등록 실패: {exc}", file=sys.stderr)
        raise SystemExit(1)
