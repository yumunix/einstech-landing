#!/bin/sh
set -u
echo 'EINSGUARD AI Linux Agent 1.0 status'
echo '-----------------------------------'
if systemctl is-active --quiet einsguard-ai.service; then echo 'Service: RUNNING'; else echo 'Service: STOPPED'; fi
systemctl status einsguard-ai.service --no-pager -l 2>/dev/null | sed -n '1,12p'
echo "Server: $(cat /etc/einsguard-ai/server.url 2>/dev/null || echo 'not configured')"
echo 'Recent log:'
tail -n 20 /var/log/einsguard-ai/agent-error.log 2>/dev/null || true
