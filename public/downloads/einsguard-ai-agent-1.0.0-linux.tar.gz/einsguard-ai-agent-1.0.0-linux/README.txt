EINSGUARD AI Linux Agent 1.0

Requirements: systemd, Python 3, root privileges, network access to the AI GUARD server.

Install:
  tar -xzf einsguard-ai-agent-1.0.0-linux.tar.gz
  cd einsguard-ai-agent-1.0.0-linux
  sudo ./install.sh http://SERVER_IP:3100 AGENT_KEY

Status:
  sudo ./status.sh

Uninstall:
  sudo ./uninstall.sh

Logs:
  /var/log/einsguard-ai/agent.log
  /var/log/einsguard-ai/agent-error.log
  /var/log/einsguard-ai/uninstall-*.log

The Agent key is issued by the AI GUARD server administrator. Do not share it publicly.
