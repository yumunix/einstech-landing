#!/bin/bash
set -eu
API="${AI_SENTINEL_API:-http://127.0.0.1:3100/api/agents?action=inventory-report}"
KEY_FILE="${AI_SENTINEL_KEY_FILE:-$HOME/.config/ai-sentinel/agent.key}"
[ -r "$KEY_FILE" ] || exit 1
key=$(tr -d '\r\n' < "$KEY_FILE")
tools="claude codex cursor copilot gemini aider windsurf ollama"
installed=""; running=""
for tool in $tools; do
  command -v "$tool" >/dev/null 2>&1 && installed="${installed}${installed:+,}\"$tool\""
  pgrep -if "(^|/|[[:space:]])${tool}([[:space:]]|$)" >/dev/null 2>&1 && running="${running}${running:+,}\"$tool\""
done
os_name=$(uname -s | tr '[:upper:]' '[:lower:]')
os_version=$(sed -n 's/^PRETTY_NAME=//p' /etc/os-release 2>/dev/null | tr -d '"' || uname -r)
payload=$(printf '{"hostname":"%s","username":"%s","os":"%s","os_version":"%s","arch":"%s","agent_version":"4.0","installed_tools":[%s],"running_tools":[%s]}' "$(hostname)" "$(id -un)" "$os_name" "$os_version" "$(uname -m)" "$installed" "$running")
curl -fsS -X POST "$API" -H 'Content-Type: application/json' -H "x-ai-sentinel-key: $key" -d "$payload"
