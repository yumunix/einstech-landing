#!/bin/bash
set -eu
SOURCE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
INSTALL_DIR="$HOME/.local/lib/ai-sentinel"
CONFIG_DIR="$HOME/.config/ai-sentinel"
SOURCE_KEY_FILE="${AI_SENTINEL_SOURCE_KEY_FILE:-}"
AGENT_KEY="${AI_SENTINEL_AGENT_KEY:-}"
if [ -z "$AGENT_KEY" ] && [ -r "$SOURCE_KEY_FILE" ]; then
  AGENT_KEY=$(tr -d '\r\n' < "$SOURCE_KEY_FILE")
fi
[ -n "$AGENT_KEY" ] || { echo 'AI_SENTINEL_AGENT_KEY or AI_SENTINEL_SOURCE_KEY_FILE is required' >&2; exit 1; }
mkdir -p "$INSTALL_DIR" "$CONFIG_DIR" "$HOME/Library/LaunchAgents"
install -m 755 "$SOURCE_DIR/ai-sentinel-wrapper-v4.sh" "$INSTALL_DIR/ai-sentinel-wrapper"
install -m 755 "$SOURCE_DIR/macos/ai-sentinel-inventory.sh" "$INSTALL_DIR/ai-sentinel-inventory"
printf '%s\n' "$AGENT_KEY" > "$CONFIG_DIR/agent.key"
chmod 600 "$CONFIG_DIR/agent.key"
sed "s|__HOME__|$HOME|g" "$SOURCE_DIR/macos/com.einstech.ai-sentinel.plist.template" > "$HOME/Library/LaunchAgents/com.einstech.ai-sentinel.plist"
launchctl bootout "gui/$(id -u)/com.einstech.ai-sentinel" 2>/dev/null || true
if ! launchctl bootstrap "gui/$(id -u)" "$HOME/Library/LaunchAgents/com.einstech.ai-sentinel.plist"; then
  cron_line="* * * * * $INSTALL_DIR/ai-sentinel-inventory >> $HOME/Library/Logs/ai-sentinel.log 2>> $HOME/Library/Logs/ai-sentinel-error.log"
  (crontab -l 2>/dev/null || true; printf '%s\n' "$cron_line") | awk '!seen[$0]++' | crontab -
  echo 'LaunchAgent unavailable; installed user cron fallback.'
fi
echo 'AI Sentinel macOS inventory agent installed.'
