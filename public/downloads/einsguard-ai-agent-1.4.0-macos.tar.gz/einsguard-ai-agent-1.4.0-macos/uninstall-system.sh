#!/bin/sh
set -eu
[ "$(id -u)" -eq 0 ] || { echo 'Run with sudo.' >&2; exit 1; }
log=/Library/Logs/einsguard-ai-uninstall-$(date +%Y%m%d-%H%M%S).log
echo "Uninstall log: $log"
exec >>"$log" 2>&1
echo "EINSGUARD AI macOS Agent uninstall started: $(date)"
launchctl bootout system/com.einstech.einsguard-ai 2>/dev/null || true
rm -f /Library/LaunchDaemons/com.einstech.einsguard-ai.plist
rm -rf /Library/EINSGUARD
echo 'EINSGUARD AI macOS Agent removed. Logs were retained in /Library/Logs.'
