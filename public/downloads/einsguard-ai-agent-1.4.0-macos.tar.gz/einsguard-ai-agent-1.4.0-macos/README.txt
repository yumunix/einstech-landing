EINSGUARD AI macOS Agent 1.4.0

Requirements: macOS 13 or later, Python 3, administrator privileges, network access to the AI GUARD server.

Install:
  tar -xzf einsguard-ai-agent-1.4.0-macos.tar.gz
  cd einsguard-ai-agent-1.4.0-macos
  sudo ./install-system.sh SERVER_IP

After the registration request appears, approve it in AI GUARD > 장비·사용자.
The installer receives and stores the device-specific Agent key automatically.

Status:
  sudo ./status.sh

Uninstall:
  sudo ./uninstall-system.sh

Logs:
  /Library/Logs/einsguard-ai.log
  /Library/Logs/einsguard-ai-error.log
  /Library/Logs/einsguard-ai-uninstall-*.log

The installer waits up to 10 minutes for administrator approval.
