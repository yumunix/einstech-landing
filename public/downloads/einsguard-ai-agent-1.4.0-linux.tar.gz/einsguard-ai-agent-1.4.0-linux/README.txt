EINSGUARD AI Linux Agent 1.4.0

Requirements: systemd, Python 3, root privileges, network access to the AI GUARD server.

Install:
  tar -xzf einsguard-ai-agent-1.4.0-linux.tar.gz
  cd einsguard-ai-agent-1.4.0-linux
  sudo ./install.sh SERVER_IP

After the registration request appears, approve it in AI GUARD > 장비·사용자.
The installer receives and stores the Agent key automatically, then starts the service.

Status:
  sudo ./status.sh

Uninstall:
  sudo ./uninstall.sh

Logs:
  /var/log/einsguard-ai/agent.log
  /var/log/einsguard-ai/agent-error.log
  /var/log/einsguard-ai/uninstall-*.log

The installer waits up to 10 minutes for administrator approval.
The Agent reports the local interactive user list so added or removed users can be tracked without consuming extra device seats.
