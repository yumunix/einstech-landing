#!/bin/sh
set -u
echo 'EINSGUARD AI Linux Agent 1.4.0 status'
echo '-----------------------------------'
if systemctl is-active --quiet einsguard-ai.service; then echo 'Service: RUNNING'; else echo 'Service: STOPPED'; fi
systemctl status einsguard-ai.service --no-pager -l 2>/dev/null | sed -n '1,12p'
echo "Server: $(cat /etc/einsguard-ai/server.url 2>/dev/null || echo 'not configured')"
echo 'Current API authentication:'
EINSGUARD_STATUS_SERVER=$(cat /etc/einsguard-ai/server.url 2>/dev/null || true) \
EINSGUARD_STATUS_KEY_FILE=/etc/einsguard-ai/agent.key python3 - <<'PY'
import json, os, platform, urllib.error, urllib.parse, urllib.request
server=os.environ.get('EINSGUARD_STATUS_SERVER','').strip().rstrip('/')
key_file=os.environ.get('EINSGUARD_STATUS_KEY_FILE','')
if not server or not os.path.isfile(key_file):
    print('API: NOT CONFIGURED')
else:
    if not server.startswith(('http://','https://')):
        server=('http://'+server) if ':' in server else ('http://'+server+':3100')
    key=open(key_file,encoding='utf-8').read().strip()
    url=server+'/api/agent?action=policy-profile&hostname='+urllib.parse.quote(platform.node())
    request=urllib.request.Request(url,headers={'x-ai-sentinel-key':key})
    try:
        with urllib.request.urlopen(request,timeout=8) as response:
            json.load(response)
        print('API: OK · 서버 연결 및 Agent 키 인증 정상')
    except urllib.error.HTTPError as exc:
        print(f'API: ERROR · HTTP {exc.code}'+(' · Agent 재등록 승인이 필요합니다.' if exc.code in (401,403) else ''))
    except Exception as exc:
        print(f'API: ERROR · {exc}')
PY
echo 'Previous error records (may include resolved errors before the last restart):'
tail -n 20 /var/log/einsguard-ai/agent-error.log 2>/dev/null || true
