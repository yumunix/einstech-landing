#!/bin/sh
# EINSGUARD AI Linux Agent 1.4.0
# Copyright (C) 2026 EINSTECH Co., Ltd. All rights reserved.
# Unauthorized copying, modification, or distribution is prohibited.
set -eu
[ "$(id -u)" -eq 0 ] || { echo 'Run as root.' >&2; exit 1; }
EINSGUARD_API=${1:-${EINSGUARD_API:-}}
[ -n "$EINSGUARD_API" ] || { echo 'Usage: sudo ./install.sh SERVER_IP' >&2; exit 2; }
command -v systemctl >/dev/null || { echo 'systemd is required.' >&2; exit 3; }
src=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
agent_bin="$src/einsguard-agent"
enroll_bin="$src/einsguard-enroll"
[ -f "$agent_bin" ] || { echo 'einsguard-agent binary is missing from the package.' >&2; exit 3; }
[ -f "$enroll_bin" ] || { echo 'einsguard-enroll binary is missing from the package.' >&2; exit 3; }
case "$EINSGUARD_API" in
  http://*|https://*) EINSGUARD_API=${EINSGUARD_API%/} ;;
  *:*) EINSGUARD_API="http://$EINSGUARD_API" ;;
  *) EINSGUARD_API="http://$EINSGUARD_API:3100" ;;
esac
install -d -m 0755 /opt/einsguard-ai /etc/einsguard-ai /var/log/einsguard-ai
install -m 0755 "$agent_bin" /opt/einsguard-ai/einsguard-agent
install -m 0755 "$enroll_bin" /opt/einsguard-ai/enroll
if [ ! -s /etc/einsguard-ai/agent.key ]; then
  /opt/einsguard-ai/enroll "$EINSGUARD_API" /etc/einsguard-ai/agent.key
fi
printf '%s\n' "$EINSGUARD_API" > /etc/einsguard-ai/server.url; chmod 0644 /etc/einsguard-ai/server.url
cat > /etc/systemd/system/einsguard-ai.service <<EOF
[Unit]
Description=EINSGUARD AI Governance Agent
After=network-online.target
[Service]
Type=simple
ExecStart=/opt/einsguard-ai/einsguard-agent --api $EINSGUARD_API --key-file /etc/einsguard-ai/agent.key
Restart=always
RestartSec=5
NoNewPrivileges=true
StandardOutput=append:/var/log/einsguard-ai/agent.log
StandardError=append:/var/log/einsguard-ai/agent-error.log
[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable einsguard-ai.service
if [ -s /var/log/einsguard-ai/agent-error.log ]; then
  mv /var/log/einsguard-ai/agent-error.log "/var/log/einsguard-ai/agent-error-before-install-$(date +%Y%m%d-%H%M%S).log"
fi
systemctl restart einsguard-ai.service
sleep 2
systemctl is-active --quiet einsguard-ai.service || { systemctl status einsguard-ai.service --no-pager; exit 4; }
echo 'EINSGUARD AI Linux Agent 1.4.0 installed successfully.'
echo 'Status: sudo ./status.sh'
echo 'Logs: /var/log/einsguard-ai/'
