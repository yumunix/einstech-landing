#!/bin/sh
set -eu
[ "$(id -u)" -eq 0 ] || { echo 'Run as root.' >&2; exit 1; }

CONF_DIR=/etc/einsguard-ai
SERVER=$(cat "$CONF_DIR/server.url" 2>/dev/null || true)
KEY=$(cat "$CONF_DIR/agent.key" 2>/dev/null || true)
HOST=$(hostname 2>/dev/null || uname -n)
REASON=${EINSGUARD_REMOVAL_REASON:-"Linux agent uninstall requested on $HOST"}
POLL_LIMIT=${EINSGUARD_REMOVAL_POLL_LIMIT:-360}   # 360 x 10s = 60 minutes
BASE=""

normalize_url() {
  case "$1" in
    http://*|https://*) printf '%s' "${1%/}" ;;
    *:*) printf 'http://%s' "$1" ;;
    *) printf 'http://%s:3100' "$1" ;;
  esac
}

api() { # method path [body]
  _m=$1; _p=$2; _b=${3:-}
  if [ -n "$_b" ]; then
    curl -fsS -m 15 -X "$_m" "$BASE$_p" \
      -H "x-ai-sentinel-key: $KEY" -H 'Content-Type: application/json' -d "$_b"
  else
    curl -fsS -m 15 -X "$_m" "$BASE$_p" -H "x-ai-sentinel-key: $KEY"
  fi
}

require_admin_approval() {
  command -v curl >/dev/null 2>&1 || { echo 'curl is required to request removal approval.' >&2; exit 3; }
  BASE=$(normalize_url "$SERVER")

  if [ -n "${EINSGUARD_REMOVAL_TOKEN:-}" ]; then
    if curl -fsS -m 15 "$BASE/api/removal?verify=$EINSGUARD_REMOVAL_TOKEN" 2>/dev/null | grep -q '"valid":true'; then
      echo 'Removal token verified by the management server. Proceeding.'
      return 0
    fi
    echo 'Provided EINSGUARD_REMOVAL_TOKEN is not valid.' >&2
    exit 4
  fi

  echo "Requesting removal approval from $BASE ..."
  if ! api POST /api/removal "$(printf '{"hostname":"%s","os_version":"linux","reason":"%s"}' "$HOST" "$REASON")" >/dev/null 2>&1; then
    # A revoked/invalid key means the server already considers this device removed.
    if ! curl -fsS -m 10 "$BASE/login" >/dev/null 2>&1; then
      echo 'Cannot reach the management server. Removal is blocked until an administrator approves it.' >&2
      exit 5
    fi
    echo 'Server did not accept the removal request (key may already be revoked). Continuing.'
    return 0
  fi

  echo 'Removal request sent. Waiting for an administrator to approve it in the dashboard...'
  i=0
  while [ "$i" -lt "$POLL_LIMIT" ]; do
    status=$(api GET /api/removal 2>/dev/null | sed -n 's/.*"status":"\([a-z]*\)".*/\1/p')
    case "$status" in
      approved) echo 'Removal approved by administrator.'; return 0 ;;
      rejected) echo 'Administrator rejected the removal request.' >&2; exit 6 ;;
    esac
    i=$((i + 1)); sleep 10
  done
  echo 'Timed out waiting for removal approval. Re-run after an administrator approves it.' >&2
  exit 7
}

report_completion() {
  [ -n "$SERVER" ] && [ -n "$KEY" ] || return 0
  [ -n "$BASE" ] || BASE=$(normalize_url "$SERVER")
  curl -fsS -m 15 -X POST "$BASE/api/removal" \
    -H "x-ai-sentinel-key: $KEY" -H 'Content-Type: application/json' \
    -d '{"action":"complete"}' >/dev/null 2>&1 || true
}

if [ -n "$SERVER" ] && [ -n "$KEY" ]; then
  require_admin_approval
else
  echo 'No server/key configuration found; nothing to approve against. Continuing with local removal.'
fi

log=/var/log/einsguard-ai/uninstall-$(date +%Y%m%d-%H%M%S).log
mkdir -p /var/log/einsguard-ai
echo "Uninstall log: $log"
report_completion
exec >>"$log" 2>&1
echo "EINSGUARD AI Linux Agent uninstall started: $(date -Iseconds)"
systemctl disable --now einsguard-ai.service 2>/dev/null || true
rm -f /etc/systemd/system/einsguard-ai.service
rm -f /etc/opt/chrome/policies/managed/einsguard-ai.json /etc/chromium/policies/managed/einsguard-ai.json /etc/opt/edge/policies/managed/einsguard-ai.json
rm -rf /opt/einsguard-ai /etc/einsguard-ai
systemctl daemon-reload
echo 'EINSGUARD AI Linux Agent removed. Logs were retained in /var/log/einsguard-ai.'
