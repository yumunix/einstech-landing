#!/bin/sh
set -eu
[ "$(id -u)" -eq 0 ] || { echo 'Run as root.' >&2; exit 1; }
log=/var/log/einsguard-ai/uninstall-$(date +%Y%m%d-%H%M%S).log
mkdir -p /var/log/einsguard-ai
echo "Uninstall log: $log"
exec >>"$log" 2>&1
echo "EINSGUARD AI Linux Agent uninstall started: $(date -Iseconds)"
systemctl disable --now einsguard-ai.service 2>/dev/null || true
rm -f /etc/systemd/system/einsguard-ai.service
rm -f /etc/opt/chrome/policies/managed/einsguard-ai.json /etc/chromium/policies/managed/einsguard-ai.json /etc/opt/edge/policies/managed/einsguard-ai.json
rm -rf /opt/einsguard-ai /etc/einsguard-ai
systemctl daemon-reload
echo 'EINSGUARD AI Linux Agent removed. Logs were retained in /var/log/einsguard-ai.'
