import crypto from 'node:crypto';
import pool from '@/lib/db';

export async function verifyAgentKey(value: string | null) {
  const supplied = (value || '').trim();
  if (!supplied) {
    const {rows}=await pool.query('SELECT EXISTS(SELECT 1 FROM ai_agent_keys WHERE enabled=true) configured');
    return { configured:Boolean(rows[0]?.configured), valid:false, tenantId:null as number|null };
  }
  const hash=crypto.createHash('sha256').update(supplied).digest('hex');
  const {rows}=await pool.query(`UPDATE ai_agent_keys SET last_used_at=NOW() WHERE key_hash=$1 AND enabled=true
    RETURNING tenant_id`,[hash]);
  return {configured:true,valid:rows.length===1,tenantId:rows[0]?Number(rows[0].tenant_id):null};
}
