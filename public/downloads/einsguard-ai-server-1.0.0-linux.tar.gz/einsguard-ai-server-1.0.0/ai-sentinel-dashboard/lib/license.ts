import crypto from 'crypto';
import pool from '@/lib/db';

const PRODUCT_PUBLIC_KEY = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEATRyokS4PGs+k9Irgd6UQVzzHpvHFmFO3zqT89Yc3f9I=
-----END PUBLIC KEY-----`;

export type LicenseState = {
  tenant_id: number;
  installation_id: string;
  license_type: string;
  plan: string;
  status: string;
  starts_at: string;
  expires_at: string;
  agent_limit: number;
  agent_count: number;
  days_remaining: number;
  active: boolean;
  reason: string | null;
};

function publicKey() {
  if (process.env.LICENSE_PUBLIC_KEY_B64) return Buffer.from(process.env.LICENSE_PUBLIC_KEY_B64, 'base64').toString('utf8');
  return PRODUCT_PUBLIC_KEY;
}

export async function getLicenseState(tenantId: number): Promise<LicenseState> {
  await pool.query(`INSERT INTO ai_licenses(tenant_id) VALUES($1) ON CONFLICT(tenant_id) DO NOTHING`, [tenantId]);
  const { rows } = await pool.query(`SELECT l.*,COUNT(a.hostname)::int agent_count
    FROM ai_licenses l LEFT JOIN ai_agents a ON a.tenant_id=l.tenant_id
    WHERE l.tenant_id=$1 GROUP BY l.tenant_id`, [tenantId]);
  const row = rows[0];
  const now = Date.now();
  const expires = new Date(row.expires_at).getTime();
  const clockRollback = new Date(row.last_seen_at).getTime() > now + 5 * 60 * 1000;
  let reason: string | null = null;
  if (row.status !== 'active') reason = '라이선스가 비활성 상태입니다.';
  else if (clockRollback) reason = '시스템 시간 변경이 감지되었습니다.';
  else if (expires <= now) reason = '라이선스 사용기간이 만료되었습니다.';
  await pool.query(`UPDATE ai_licenses SET last_seen_at=GREATEST(last_seen_at,NOW()) WHERE tenant_id=$1`, [tenantId]);
  return {
    tenant_id: Number(row.tenant_id), installation_id: row.installation_id,
    license_type: row.license_type, plan: row.plan, status: row.status,
    starts_at: row.starts_at, expires_at: row.expires_at,
    agent_limit: Number(row.agent_limit), agent_count: Number(row.agent_count),
    days_remaining: Math.max(0, Math.ceil((expires - now) / 86400000)),
    active: !reason, reason,
  };
}

export async function requireActiveLicense(tenantId: number) {
  const license = await getLicenseState(tenantId);
  return license.active ? { license, response: null } : {
    license,
    response: Response.json({ error: license.reason, code: 'LICENSE_INACTIVE', license }, { status: 402 }),
  };
}

type SignedLicense = { tenant_code:string; installation_id:string; plan:string; expires_at:string; agent_limit:number; license_id:string };

export function verifyLicenseKey(key: string): SignedLicense {
  const [payloadPart, signaturePart] = key.trim().split('.');
  if (!payloadPart || !signaturePart) throw new Error('라이선스 키 형식이 올바르지 않습니다.');
  const keyPem = publicKey();
  if (!keyPem) throw new Error('라이선스 공개키가 설정되지 않았습니다.');
  const payload = Buffer.from(payloadPart, 'base64url');
  const signature = Buffer.from(signaturePart, 'base64url');
  if (!crypto.verify(null, payload, keyPem, signature)) throw new Error('라이선스 서명이 유효하지 않습니다.');
  const parsed = JSON.parse(payload.toString('utf8')) as SignedLicense;
  if (!parsed.tenant_code || !parsed.installation_id || !parsed.expires_at || !Number.isFinite(Number(parsed.agent_limit))) throw new Error('라이선스 정보가 불완전합니다.');
  return parsed;
}
