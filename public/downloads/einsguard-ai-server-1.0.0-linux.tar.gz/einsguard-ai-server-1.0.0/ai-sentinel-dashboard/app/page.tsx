'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, Legend } from 'recharts';
import { formatDistanceToNow, format } from 'date-fns';
import { ko } from 'date-fns/locale';

const TOOL_COLOR: Record<string, string> = { claude: '#16c79a', codex: '#6366f1' };
const SEV_COLOR: Record<string, string> = { HIGH: '#ef4444', MED: '#f59e0b', LOW: '#3b82f6' };
const SEV_LABEL:Record<string,string>={CRITICAL:'Critical',HIGH:'High',MED:'Med',LOW:'Low'};
const SEV_BADGE:Record<string,string>={CRITICAL:'border-fuchsia-300 bg-fuchsia-400 text-slate-950',HIGH:'border-red-300 bg-red-400 text-slate-950',MED:'border-amber-200 bg-amber-300 text-slate-950',LOW:'border-blue-200 bg-blue-300 text-slate-950'};

type Tab = 'overview' | 'analytics' | 'agents' | 'reports' | 'sessions' | 'alerts' | 'control' | 'governance' | 'catalog' | 'license';
type ControlTab = 'blocks' | 'policies' | 'approvals' | 'active';

export default function Dashboard() {
  const [tab, setTab] = useState<Tab>('overview');
  const [controlTab, setControlTab] = useState<ControlTab>('blocks');
  const [stats, setStats] = useState<any>(null);
  const [sessions, setSessions] = useState<any>(null);
  const [alerts, setAlerts] = useState<any>(null);
  const [controls, setControls] = useState<any>(null);
  const [analytics, setAnalytics] = useState<any>(null);
  const [governance, setGovernance] = useState<any>(null);
  const [agents, setAgents] = useState<any>(null);
  const [reports, setReports] = useState<any>(null);
  const [tenants, setTenants] = useState<any>(null);
  const [license, setLicense] = useState<any>(null);
  const [catalog,setCatalog]=useState<any>(null);
  const [selectedAlertIds,setSelectedAlertIds]=useState<number[]>([]);
  const [alertSeverityFilter,setAlertSeverityFilter]=useState<'ALL'|'CRITICAL'|'HIGH'|'MED'|'LOW'>('ALL');
  const [catalogForm,setCatalogForm]=useState({key:'',name:'',process:'',domain:'',notes:''});
  const [subscriptionForm,setSubscriptionForm]=useState({service_key:'chatgpt',service_name:'ChatGPT',plan_name:'Pro',seats:1,unit_price:0,currency:'USD'});
  const [licenseKey, setLicenseKey] = useState('');
  const [licenseMsg, setLicenseMsg] = useState('');
  const [tenantForm, setTenantForm] = useState({name:'',code:'',admin_username:'',admin_email:'',admin_password:''});
  const [newAgentKey, setNewAgentKey] = useState('');
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [lastUpdated, setLastUpdated] = useState(new Date());
  const [formMsg, setFormMsg] = useState('');
  const [showSettings, setShowSettings] = useState(false);
  const [showAppearance,setShowAppearance]=useState(false);
  const [appearance,setAppearance]=useState<'light'|'navy'|'dark'|'high-contrast'>('high-contrast');
  const [agentSearch,setAgentSearch]=useState('');
  const [agentStatus,setAgentStatus]=useState<'all'|'online'|'offline'>('all');
  const [agentPage,setAgentPage]=useState(1);
  const [agentPageSize,setAgentPageSize]=useState(25);
  const [settingsForm, setSettingsForm] = useState({ currentPassword: '', newUsername: '', newPassword: '', confirmPassword: '' });
  const [settingsMsg, setSettingsMsg] = useState('');
  const router = useRouter();

  const logout = async () => {
    await fetch('/api/auth', { method: 'DELETE' });
    router.push('/login');
  };

  const saveSettings = async () => {
    setSettingsMsg('');
    if (settingsForm.newPassword && settingsForm.newPassword !== settingsForm.confirmPassword) {
      setSettingsMsg('❌ 새 비밀번호가 일치하지 않습니다');
      return;
    }
    const r = await fetch('/api/auth', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        currentPassword: settingsForm.currentPassword,
        newUsername: settingsForm.newUsername || undefined,
        newPassword: settingsForm.newPassword || undefined,
      }),
    });
    const d = await r.json();
    if (d.ok) {
      setSettingsMsg('✅ 변경 완료');
      setSettingsForm({ currentPassword: '', newUsername: '', newPassword: '', confirmPassword: '' });
    } else {
      setSettingsMsg('❌ ' + d.error);
    }
  };

  const [blockForm, setBlockForm] = useState({ hostname: '', username: '', tool: 'claude', reason: '' });
  const [blockToolSearch, setBlockToolSearch] = useState('');
  const [customAiForm,setCustomAiForm]=useState({key:'',name:'',process:'',domain:''});
  const [policyForm, setPolicyForm] = useState({ hostname: '', username: '', allow_start: 9, allow_end: 18, max_per_hour: 10, template_key: '', tool: '*' });

  const fetchAll = async () => {
    const [s, se, al, an, ag, rep, gov, me, ten, lic, cat] = await Promise.all([
      fetch('/api/stats').then(r => r.json()),
      fetch('/api/sessions').then(r => r.json()),
      fetch('/api/alerts').then(r => r.json()),
      fetch('/api/analytics').then(r => r.json()),
      fetch('/api/agents').then(r => r.json()),
      fetch('/api/reports').then(r => r.json()),
      fetch('/api/governance').then(r => r.json()),
      fetch('/api/auth').then(r => r.json()),
      fetch('/api/tenants').then(r => r.json()),
      fetch('/api/license').then(r => r.json()),
      fetch('/api/catalog').then(r=>r.json()),
    ]);
    setStats(s); setSessions(se); setAlerts(al); setAnalytics(an); setAgents(ag); setReports(rep); setGovernance(gov); setCurrentUser(me); setTenants(ten); setLicense(lic.license);setCatalog(cat);
    setLastUpdated(new Date());
  };

  const fetchControls = async () => {
    const c = await fetch('/api/control').then(r => r.json());
    setControls(c);
  };

  useEffect(() => {
    const saved=window.localStorage.getItem('aiguard-appearance') as typeof appearance|null;if(saved&&['light','navy','dark','high-contrast'].includes(saved))setAppearance(saved);
    fetchAll();
    fetchControls();
    const t = setInterval(() => { fetchAll(); fetchControls(); }, 15000);
    return () => clearInterval(t);
  }, []);
  const changeAppearance=(value:typeof appearance)=>{setAppearance(value);window.localStorage.setItem('aiguard-appearance',value)};

  const resolveAlert = async (id: number) => {
    await fetch('/api/alerts', { method: 'PATCH', body: JSON.stringify({ id }), headers: { 'Content-Type': 'application/json' } });
    fetchAll();
  };
  const openAlerts=async()=>{setTab('alerts');if((alerts?.unread||0)>0){await fetch('/api/alerts',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'mark_read'})});setAlerts((prev:any)=>prev?{...prev,unread:0,alerts:(prev.alerts||[]).map((a:any)=>({...a,read_at:a.read_at||new Date().toISOString()}))}:prev);}};
  const deleteAlert=async(id:number)=>{if(!window.confirm('이 알림을 화면에서 삭제하시겠습니까? 삭제 이력은 감사 기록에 남습니다.'))return;await fetch('/api/alerts',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'delete',id,reason:'대시보드 사용자 삭제'})});fetchAll();};
  const toggleAlertSelection=(id:number)=>setSelectedAlertIds(ids=>ids.includes(id)?ids.filter(x=>x!==id):[...ids,id]);
  const visibleAlerts=(alerts?.alerts||[]).filter((a:any)=>alertSeverityFilter==='ALL'||a.severity===alertSeverityFilter);
  const toggleAllAlerts=()=>{const ids=visibleAlerts.map((a:any)=>Number(a.id));const allSelected=ids.length>0&&ids.every((id:number)=>selectedAlertIds.includes(id));setSelectedAlertIds(current=>allSelected?current.filter(id=>!ids.includes(id)):Array.from(new Set([...current,...ids])))};
  const deleteSelectedAlerts=async()=>{if(!selectedAlertIds.length)return;if(!window.confirm(`선택한 보안 알림 ${selectedAlertIds.length}건을 삭제하시겠습니까? 삭제 이력은 감사 기록에 남습니다.`))return;const r=await fetch('/api/alerts',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'delete_many',ids:selectedAlertIds})});const d=await r.json();if(d.ok){setSelectedAlertIds([]);setFormMsg(`✅ 보안 알림 ${d.deleted}건 삭제 완료`);fetchAll();}else setFormMsg('❌ '+d.error)};

  const addBlock = async () => {
    setFormMsg('');
    const r = await fetch('/api/control', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'add_block', ...blockForm }),
    });
    const d = await r.json();
    setFormMsg(d.ok ? '✅ 차단 등록 완료' : '❌ 실패: ' + d.error);
    fetchControls();
  };

  const removeBlock = async (id: number) => {
    await fetch('/api/control', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'remove_block', id }) });
    fetchControls();
  };

  const addCustomAi = async () => {
    setFormMsg('');
    const r=await fetch('/api/control',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'add_custom_ai',...customAiForm})});
    const d=await r.json();
    if(d.ok){setBlockForm(f=>({...f,tool:d.key}));setBlockToolSearch(customAiForm.name||d.key);setCustomAiForm({key:'',name:'',process:'',domain:''});setFormMsg('✅ 사용자 정의 AI 등록 완료 — 차단 등록을 누르세요.');fetchControls();}
    else setFormMsg('❌ 실패: '+d.error);
  };
  const addCatalogCandidate=async()=>{const r=await fetch('/api/catalog',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'add_candidate',...catalogForm})});const d=await r.json();if(d.ok){setFormMsg('✅ 신규 AI 후보가 검토함에 등록됐습니다.');setCatalogForm({key:'',name:'',process:'',domain:'',notes:''});fetchAll();}else setFormMsg('❌ '+d.error)};
  const setCatalogStatus=async(id:number,status:string)=>{await fetch('/api/catalog',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'set_status',id,status})});fetchAll();fetchControls();};
  const addSubscription=async()=>{const r=await fetch('/api/analytics',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'add_subscription',...subscriptionForm})});const d=await r.json();if(d.ok){setFormMsg('✅ 구독 비용 등록 완료');fetchAll();}else setFormMsg('❌ '+d.error)};
  const removeSubscription=async(id:number)=>{await fetch('/api/analytics',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'remove_subscription',id})});fetchAll();};

  const addPolicy = async () => {
    setFormMsg('');
    const r = await fetch('/api/control', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'add_policy', ...policyForm }),
    });
    const d = await r.json();
    setFormMsg(d.ok ? '✅ 정책 등록 완료' : '❌ 실패: ' + d.error);
    fetchControls();
  };

  const selectTemplate = (key: string) => {
    const template = governance?.templates?.find((item: any) => item.template_key === key);
    if (!template) return;
    setPolicyForm(f => ({ ...f, template_key: key, allow_start: template.allow_start, allow_end: template.allow_end, max_per_hour: template.max_per_hour, tool: template.tool }));
  };

  const updateRole = async (id: number, role: string) => {
    const r = await fetch('/api/governance', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'update_role', id, role }) });
    const d = await r.json();
    setFormMsg(d.ok ? '✅ 역할 변경 완료' : '❌ 실패: ' + d.error);
    fetchAll();
  };

  const resolveShadowEvent = async (id: number) => {
    await fetch('/api/agents', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({action:'resolve_event',id}) });
    fetchAll();
  };

  const toggleApprovedTool = async (agent: any, tool: string) => {
    const current: string[] = agent.approved_tools || [];
    const tools = current.includes(tool) ? current.filter(item => item !== tool) : [...current, tool];
    await fetch('/api/agents', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({action:'set_approved_tools',hostname:agent.hostname,tools}) });
    fetchAll();
  };

  const decideEnrollment = async (id:number, action:'approve'|'reject') => {
    await fetch('/api/enroll',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,action})});
    fetchAll();
  };

  const saveWeeklyReport = async () => {
    const r=await fetch('/api/reports',{method:'POST'}); const d=await r.json();
    setFormMsg(d.ok?'✅ 주간 보고서 초안 저장 완료':'❌ 실패: '+d.error); fetchAll();
  };

  const createTenant = async () => {
    setNewAgentKey(''); const r=await fetch('/api/tenants',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(tenantForm)});const d=await r.json();
    if(d.ok){setFormMsg('✅ 고객사 생성 완료');setNewAgentKey(d.agent_key);setTenantForm({name:'',code:'',admin_username:'',admin_email:'',admin_password:''});fetchAll();}else setFormMsg('❌ 실패: '+d.error);
  };

  const activateLicense = async () => {
    setLicenseMsg('');
    const r=await fetch('/api/license',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key:licenseKey})});
    const d=await r.json();
    if(d.ok){setLicense(d.license);setLicenseKey('');setLicenseMsg('✅ 라이선스 인증 완료');fetchAll();}
    else setLicenseMsg('❌ '+(d.error||'인증 실패'));
  };

  const removePolicy = async (id: number) => {
    await fetch('/api/control', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'remove_policy', id }) });
    fetchControls();
  };

  const killSession = async (sessionId: string) => {
    const r = await fetch('/api/control', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'kill_session', session_id: sessionId }),
    });
    const d = await r.json();
    setFormMsg(d.ok ? '🛑 강제종료 명령 전송됨' : '❌ 실패: ' + d.error);
    fetchControls();
  };

  const toggleSession = async (sessionId: string, paused: boolean) => {
    const r = await fetch('/api/control', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: paused ? 'resume_session' : 'pause_session', session_id: sessionId }),
    });
    const d = await r.json();
    setFormMsg(d.ok ? (paused ? '▶️ 세션 재개 명령 전송됨' : '⏸️ 세션 일시정지 명령 전송됨') : '❌ 실패: ' + d.error);
    fetchControls();
  };

  const reviewApproval = async (id: number, approved: boolean) => {
    await fetch('/api/control', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'review_approval', id, approved }),
    });
    fetchControls();
  };

  const unreadAlertCount = alerts?.unread ?? alerts?.alerts?.filter((a:any)=>!a.read_at).length ?? 0;
  const highRiskAlerts = alerts?.alerts?.filter((a: any) => !a.resolved && a.severity === 'HIGH') ?? [];
  const pendingApprovals = controls?.approvals?.filter((a: any) => a.status === 'pending').length ?? 0;
  const pendingEnrollments = agents?.enrollments?.filter((e: any) => e.status === 'pending').length ?? 0;
  const activeSessionCount = controls?.activeSessions?.length ?? 0;
  const blockedTargetCount = controls?.blocks?.length ?? 0;
  const aiCatalog=[...(controls?.catalog||[]),...(controls?.customCatalog||[])];
  const filteredAiCatalog=aiCatalog.filter((x:any)=>`${x.name} ${x.key}`.toLowerCase().includes(blockToolSearch.toLowerCase())).slice(0,80);
  const allAgentRows=agents?.agents||[];
  const filteredAgentRows=allAgentRows.filter((agent:any)=>{
    const online=Date.now()-new Date(agent.last_seen).getTime()<300000;
    const matchesStatus=agentStatus==='all'||(agentStatus==='online'?online:!online);
    const haystack=`${agent.hostname} ${agent.username||''} ${agent.os||''} ${(agent.installed_tools||[]).join(' ')}`.toLowerCase();
    return matchesStatus&&haystack.includes(agentSearch.trim().toLowerCase());
  });
  const agentPageCount=Math.max(1,Math.ceil(filteredAgentRows.length/agentPageSize));
  const safeAgentPage=Math.min(agentPage,agentPageCount);
  const pagedAgentRows=filteredAgentRows.slice((safeAgentPage-1)*agentPageSize,safeAgentPage*agentPageSize);
  const compactAgentView=allAgentRows.length>=25;

  useEffect(()=>{setAgentPage(1)},[agentSearch,agentStatus,agentPageSize]);

  const openControl = (next: ControlTab) => {
    setControlTab(next);
    setTab('control');
  };

  return (
    <div className="dashboard-shell min-h-screen text-white font-mono" data-appearance={appearance}>
      <div className="sticky top-0 z-40 border-b border-slate-700 bg-[#0a0f1e]/95 px-4 py-3 shadow-lg shadow-black/20 backdrop-blur md:px-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex min-w-0 flex-1 items-center gap-5">
          <button type="button" onClick={() => setTab('overview')} aria-label="AI GUARD 개요로 이동"
            className="group shrink-0 rounded-lg border-r border-slate-700 px-2 py-1 pr-5 text-left transition-colors hover:bg-slate-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400">
            <div className="text-emerald-400 text-[10px] tracking-widest">EINSTECH</div>
            <div className="text-lg font-bold tracking-tight group-hover:text-emerald-200">AI GUARD</div>
          </button>
          <div className="dashboard-nav flex min-w-0 flex-1 items-center gap-1 overflow-x-auto py-1">
            {(['overview', 'analytics', 'agents', 'reports', 'sessions', 'alerts', 'control', 'governance', 'catalog', 'license'] as Tab[]).map(t => (
              <button key={t} onClick={() => t==='alerts'?openAlerts():setTab(t)} aria-current={tab === t ? 'page' : undefined}
                className={`group relative flex min-h-11 shrink-0 items-center rounded-lg border px-4 py-2 text-[13px] font-bold transition-all ${tab === t ? 'border-emerald-400 bg-emerald-500/20 text-emerald-200 shadow-[inset_0_-3px_0_#34d399,0_0_18px_rgba(52,211,153,0.12)]' : 'border-transparent text-slate-300 hover:border-slate-600 hover:bg-slate-800 hover:text-white'}`}>
                {t === 'overview' ? '개요' : t === 'analytics' ? '비용·분석' : t === 'agents' ? 'AI 자산' : t === 'reports' ? '보고서' : t === 'sessions' ? '세션 활동' : t === 'alerts' ? '보안 알림' : t === 'control' ? '에이전트 제어' : t === 'governance' ? '거버넌스' : t==='catalog'?'AI 목록 관리':'라이선스'}
                {t === 'alerts' && unreadAlertCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[9px] rounded-full w-4 h-4 flex items-center justify-center">{unreadAlertCount}</span>
                )}
                {t === 'agents' && pendingEnrollments > 0 && (
                  <span className="absolute -top-1 -right-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-blue-500 px-1 text-[10px] text-white shadow-lg shadow-blue-500/30">{pendingEnrollments}</span>
                )}
                {t === 'control' && pendingApprovals > 0 && (
                  <span className="absolute -top-1 -right-1 bg-yellow-500 text-white text-[9px] rounded-full w-4 h-4 flex items-center justify-center">{pendingApprovals}</span>
                )}
              </button>
            ))}
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          <div className="flex min-h-10 items-center gap-3 whitespace-nowrap rounded-lg border border-slate-700 bg-slate-900 px-3">
            <div className="text-xs font-bold tabular-nums text-white">{format(lastUpdated, 'yyyy-MM-dd HH:mm:ss')}</div>
            <span className="text-xs font-bold text-emerald-400 animate-pulse">● LIVE</span>
          </div>
          <button onClick={() => setShowSettings(true)} title={`${currentUser?.tenant_name||''} · ${currentUser?.role||''}`}
            className="min-h-10 rounded-lg border border-slate-700 px-3 text-xs font-bold text-slate-300 hover:border-emerald-500/50 hover:bg-slate-800 hover:text-emerald-200">[{currentUser?.username||'확인 중'}] Profile</button>
          <button onClick={()=>setShowAppearance(true)} title="화면 색상 설정" aria-label="화면 색상 설정" className="flex min-h-10 min-w-10 items-center justify-center rounded-lg border border-slate-700 text-lg text-slate-200 hover:border-emerald-500/50 hover:bg-slate-800">⚙</button>
          <button onClick={logout} className="min-h-10 rounded-lg border border-transparent px-3 text-xs font-bold text-slate-400 hover:border-red-500/40 hover:bg-red-500/10 hover:text-red-300">로그아웃</button>
        </div>
        </div>
      </div>

      <div className="p-6">
        {pendingEnrollments > 0 && <button onClick={()=>setTab('agents')} className="mb-4 w-full animate-pulse rounded-lg border-2 border-blue-400 bg-blue-500/15 p-4 text-left text-sm font-bold text-blue-100 shadow-lg shadow-blue-500/10">🔔 Windows Agent 신규 등록 요청 {pendingEnrollments}건이 도착했습니다. <span className="float-right rounded bg-blue-400 px-3 py-1 text-xs text-slate-950">지금 확인 →</span></button>}
        {license && (!license.active || license.days_remaining <= 7) && <button onClick={()=>setTab('license')} className={`mb-4 w-full rounded-lg border p-3 text-left text-xs ${license.active?'border-yellow-500/40 bg-yellow-500/10 text-yellow-300':'border-red-500/40 bg-red-500/10 text-red-300'}`}>{license.active?`무료 체험 또는 구독 만료까지 ${license.days_remaining}일 남았습니다.`:`제품 기능이 잠겼습니다: ${license.reason}`} <span className="float-right">라이선스 관리 →</span></button>}
        {/* 개요 */}
        {tab === 'overview' && stats && (
          <div className="space-y-6">
            <div className="flex flex-col gap-1">
              <div className="text-xl font-semibold">보안 운영 현황</div>
              <div className="text-xs text-slate-500">위험을 확인하고 필요한 조치를 바로 실행하세요.</div>
            </div>
            <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
              {[
                { label: '고위험 알림', value: highRiskAlerts.length, color: highRiskAlerts.length ? 'text-red-400' : 'text-slate-400', action: openAlerts },
                { label: '승인 대기', value: pendingApprovals, color: pendingApprovals ? 'text-yellow-400' : 'text-slate-400', action: () => openControl('approvals') },
                { label: '활성 세션', value: activeSessionCount, color: 'text-emerald-400', action: () => openControl('active') },
                { label: '차단 대상', value: blockedTargetCount, color: 'text-orange-400', action: () => openControl('blocks') },
                { label: '오늘 실행', value: stats.summary?.today_usage ?? 0, color: 'text-blue-400' },
              ].map(({ label, value, color, action }) => (
                <button key={label} onClick={action} disabled={!action}
                  className={`bg-slate-900 border border-slate-800 rounded-lg p-4 text-left transition-colors ${action ? 'hover:border-slate-600 hover:bg-slate-800/70 cursor-pointer' : 'cursor-default'}`}>
                  <div className="text-slate-400 text-xs mb-1">{label}</div>
                  <div className={`text-3xl font-bold ${color}`}>{value}</div>
                  {action && <div className="text-[10px] text-slate-600 mt-2">클릭하여 확인 →</div>}
                </button>
              ))}
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <div className="text-sm font-semibold">즉시 확인이 필요한 위험</div>
                    <div className="text-[11px] text-slate-500 mt-1">미해결 고위험 이벤트와 탐지 근거</div>
                  </div>
                  <button onClick={openAlerts} className="text-xs text-emerald-400 hover:text-emerald-300">전체 알림 보기</button>
                </div>
                {highRiskAlerts.length === 0 ? (
                  <div className="rounded-lg border border-emerald-500/20 bg-emerald-500/5 px-4 py-5 text-sm text-emerald-300">현재 미해결 고위험 알림이 없습니다.</div>
                ) : (
                  <div className="space-y-2">
                    {highRiskAlerts.slice(0, 4).map((a: any) => (
                      <button key={a.id} onClick={openAlerts} className="w-full flex items-start gap-3 rounded-lg border border-red-500/25 bg-red-500/5 p-3 text-left hover:bg-red-500/10">
                        <span className="mt-1 h-2 w-2 rounded-full bg-red-500 flex-shrink-0" />
                        <span className="flex-1 min-w-0">
                          <span className="flex items-center gap-2 text-xs">
                            <span className="font-bold text-red-400">HIGH</span>
                            <span className="rounded bg-red-500/15 px-1.5 py-0.5 text-[10px] text-red-300">위험도 {a.risk_score ?? 80}점</span>
                            <span className="text-white">{a.alert_type}</span>
                            <span className="text-slate-500">{a.hostname} / {a.username}</span>
                          </span>
                          <span className="block mt-1 text-xs text-slate-400 truncate">탐지 근거: {a.risk_reason || a.detail || '상세 정보 없음'}</span>
                        </span>
                        <span className="text-[10px] text-slate-600">{formatDistanceToNow(new Date(a.created_at), { addSuffix: true, locale: ko })}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                <div className="text-sm font-semibold">빠른 조치</div>
                <div className="text-[11px] text-slate-500 mt-1 mb-4">운영 화면을 찾지 않고 바로 이동합니다.</div>
                <div className="space-y-2">
                  <button onClick={() => openControl('approvals')} className="w-full rounded-lg border border-yellow-500/25 bg-yellow-500/5 px-3 py-2.5 text-left text-xs text-yellow-300 hover:bg-yellow-500/10">승인 요청 검토 <span className="float-right">{pendingApprovals}건 →</span></button>
                  <button onClick={() => openControl('active')} className="w-full rounded-lg border border-red-500/25 bg-red-500/5 px-3 py-2.5 text-left text-xs text-red-300 hover:bg-red-500/10">활성 세션 제어 <span className="float-right">{activeSessionCount}건 →</span></button>
                  <button onClick={() => openControl('blocks')} className="w-full rounded-lg border border-slate-700 bg-slate-800/60 px-3 py-2.5 text-left text-xs text-slate-300 hover:bg-slate-800">사용자·서버 차단 <span className="float-right">→</span></button>
                  <button onClick={() => openControl('policies')} className="w-full rounded-lg border border-slate-700 bg-slate-800/60 px-3 py-2.5 text-left text-xs text-slate-300 hover:bg-slate-800">사용 정책 관리 <span className="float-right">→</span></button>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                <div className="text-xs text-slate-400 mb-3">시간대별 AI 사용량</div>
                <ResponsiveContainer width="100%" height={200}>
                  <LineChart data={stats.timeline ?? []}>
                    <XAxis dataKey="hour" tick={{ fill: '#94a3b8', fontSize: 10 }} />
                    <YAxis tick={{ fill: '#94a3b8', fontSize: 10 }} />
                    <Tooltip contentStyle={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 6 }} />
                    <Legend />
                    <Line type="monotone" dataKey="count" stroke="#16c79a" dot={false} name="실행 횟수" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                <div className="text-xs text-slate-400 mb-3">서버별 사용량</div>
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={stats.byServer ?? []}>
                    <XAxis dataKey="hostname" tick={{ fill: '#94a3b8', fontSize: 10 }} />
                    <YAxis tick={{ fill: '#94a3b8', fontSize: 10 }} />
                    <Tooltip contentStyle={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 6 }} />
                    <Bar dataKey="count" fill="#6366f1" name="횟수" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                <div className="text-xs text-slate-400 mb-3">도구별 사용량</div>
                <div className="space-y-2">
                  {(stats.byTool ?? []).map((t: any) => (
                    <div key={t.tool} className="flex items-center gap-2">
                      <span className="w-16 text-xs" style={{ color: TOOL_COLOR[t.tool] ?? '#94a3b8' }}>{t.tool}</span>
                      <div className="flex-1 bg-slate-800 rounded-full h-2">
                        <div className="h-2 rounded-full" style={{ width: `${Math.min(100, (t.count / (stats.summary?.total_usage || 1)) * 100)}%`, background: TOOL_COLOR[t.tool] ?? '#94a3b8' }} />
                      </div>
                      <span className="text-xs text-slate-400">{t.count}회</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                <div className="text-xs text-slate-400 mb-3">최근 실행</div>
                <div className="space-y-1">
                  {(stats.recent ?? []).slice(0, 8).map((r: any, i: number) => (
                    <div key={i} className="flex items-center gap-2 text-xs text-slate-400 py-1 border-b border-slate-800">
                      <span className="text-emerald-400">{format(new Date(r.logged_at), 'HH:mm:ss')}</span>
                      <span className="text-blue-400">{r.hostname}</span>
                      <span>{r.username}</span>
                      <span style={{ color: TOOL_COLOR[r.tool] ?? '#94a3b8' }}>{r.tool}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 비용·사용량 분석 */}
        {tab === 'analytics' && analytics && (
          <div className="space-y-6">
            <div>
              <div className="text-xl font-semibold">비용·사용량 분석</div>
              <div className="text-xs text-slate-500 mt-1">API 종량제 실사용 비용과 구독형 월 고정 비용을 분리해 표시합니다.</div>
            </div>
            <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
              {[
                ['총 실행', Number(analytics.summary?.executions || 0).toLocaleString() + '회', 'text-emerald-400'],
                ['AI가 읽은 양 (입력 토큰)', Number(analytics.summary?.input_tokens || 0)>0?Number(analytics.summary.input_tokens).toLocaleString():'수집 불가', 'text-blue-400'],
                ['AI가 생성한 양 (출력 토큰)', Number(analytics.summary?.output_tokens || 0)>0?Number(analytics.summary.output_tokens).toLocaleString():'수집 불가', 'text-purple-400'],
                ['API 종량제 비용', '$' + Number(analytics.summary?.cost_usd || 0).toFixed(2), 'text-yellow-400'],
                ['구독 월 비용', (analytics.subscriptionTotals||[]).length?(analytics.subscriptionTotals||[]).map((x:any)=>x.currency==='KRW'?`₩${Number(x.monthly_total).toLocaleString()}`:`$${Number(x.monthly_total).toFixed(2)}`).join(' + '):'미등록', 'text-orange-400'],
              ].map(([label, value, color]) => <div key={label} className="bg-slate-900 border border-slate-800 rounded-lg p-4"><div className="text-xs text-slate-400">{label}</div><div className={`text-2xl font-bold mt-1 ${color}`}>{value}</div></div>)}
            </div>
            {Number(analytics.summary?.input_tokens || 0) + Number(analytics.summary?.output_tokens || 0) === 0 && (
              <div className="rounded-lg border border-blue-500/25 bg-blue-500/5 p-4 text-xs text-blue-300">현재 구독형 앱·CLI는 정확한 토큰값을 제공하지 않습니다. 토큰 0이 아니라 ‘수집 불가’이며, 월 구독료는 아래에서 별도로 등록합니다. API 응답에서 실제 사용량이 들어오면 API 비용에 자동 반영됩니다.</div>
            )}
            <div className="grid gap-6 lg:grid-cols-2"><div className="rounded-lg border border-slate-800 bg-slate-900 p-4"><div className="mb-3 text-sm font-bold">구독형 월 비용 등록</div><div className="grid grid-cols-2 gap-2"><input value={subscriptionForm.service_name} onChange={e=>setSubscriptionForm(f=>({...f,service_name:e.target.value,service_key:e.target.value.toLowerCase().replace(/[^a-z0-9]+/g,'-')}))} placeholder="서비스 (ChatGPT)" className="rounded border border-slate-700 bg-slate-800 px-3 py-2 text-xs"/><input value={subscriptionForm.plan_name} onChange={e=>setSubscriptionForm(f=>({...f,plan_name:e.target.value}))} placeholder="요금제 (Pro/Max)" className="rounded border border-slate-700 bg-slate-800 px-3 py-2 text-xs"/><input type="number" min="1" value={subscriptionForm.seats} onChange={e=>setSubscriptionForm(f=>({...f,seats:Number(e.target.value)}))} placeholder="좌석" className="rounded border border-slate-700 bg-slate-800 px-3 py-2 text-xs"/><div className="flex"><select value={subscriptionForm.currency} onChange={e=>setSubscriptionForm(f=>({...f,currency:e.target.value}))} className="rounded-l border border-slate-700 bg-slate-800 px-2 text-xs"><option>USD</option><option>KRW</option></select><input type="number" min="0" step="0.01" value={subscriptionForm.unit_price} onChange={e=>setSubscriptionForm(f=>({...f,unit_price:Number(e.target.value)}))} placeholder="월 단가" className="min-w-0 flex-1 rounded-r border border-l-0 border-slate-700 bg-slate-800 px-3 py-2 text-xs"/></div></div><button disabled={!['admin','security'].includes(currentUser?.role)} onClick={addSubscription} className="mt-3 w-full rounded border border-orange-500/40 bg-orange-500/10 py-2 text-xs font-bold text-orange-300 disabled:opacity-40">구독 비용 등록</button></div><div className="rounded-lg border border-slate-800 bg-slate-900 p-4"><div className="mb-3 text-sm font-bold">현재 구독</div>{(analytics.subscriptions||[]).length===0?<div className="text-xs text-slate-500">등록된 구독 없음</div>:<div className="space-y-2">{analytics.subscriptions.map((s:any)=><div key={s.id} className="flex items-center gap-2 rounded border border-slate-800 p-2 text-xs"><span className="font-bold">{s.service_name} {s.plan_name}</span><span className="text-slate-500">{s.seats}석 × {s.currency==='KRW'?'₩'+Number(s.unit_price).toLocaleString():'$'+Number(s.unit_price).toFixed(2)}</span><span className="ml-auto font-bold text-orange-300">{s.currency==='KRW'?'₩'+Number(s.seats*s.unit_price).toLocaleString():'$'+Number(s.seats*s.unit_price).toFixed(2)}/월</span>{['admin','security'].includes(currentUser?.role)&&<button onClick={()=>removeSubscription(s.id)} className="text-red-300">삭제</button>}</div>)}</div>}</div></div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6"><div className="bg-slate-900 border border-slate-800 rounded-lg p-4"><div className="text-sm font-semibold mb-3">서비스·사용자별 실행</div><div className="space-y-2">{(analytics.byUser||[]).map((row:any)=><div key={row.username} className="grid grid-cols-3 text-xs border-b border-slate-800 pb-2"><span>{row.username}</span><span className="text-slate-400 text-right">{row.executions}회</span><span className="text-slate-500 text-right">{Number(row.tokens)>0?Number(row.tokens).toLocaleString()+' tokens':'토큰 미수집'}</span></div>)}</div></div><div className="bg-slate-900 border border-slate-800 rounded-lg p-4"><div className="text-sm font-semibold">API 실제 모델별 사용</div><div className="mb-3 mt-1 text-[11px] text-slate-500">API 응답에서 모델 ID와 토큰이 확인된 기록만 표시합니다.</div>{(analytics.byModel||[]).length===0?<div className="rounded border border-slate-700 bg-slate-800/60 p-4 text-xs text-slate-300">확인된 API 모델 사용 기록이 없습니다.<div className="mt-2 text-slate-500">모델 미확인 실행: {Number(analytics.unknownModelExecutions||0).toLocaleString()}회 · 구독형 앱·CLI 실행은 여기에 포함되지 않습니다.</div></div>:<div className="space-y-2">{analytics.byModel.map((row:any)=><div key={row.model} className="grid grid-cols-3 border-b border-slate-800 pb-2 text-xs"><span>{row.model}</span><span className="text-right text-slate-400">{row.executions}회 · {Number(row.tokens).toLocaleString()} tokens</span><span className="text-right text-yellow-400">${Number(row.cost_usd).toFixed(4)}</span></div>)}</div>}</div></div>
          </div>
        )}

        {/* AI 자산 및 Shadow AI */}
        {tab === 'agents' && agents && (
          <div className="space-y-6">
            <div><div className="text-xl font-semibold">AI 자산 및 Shadow AI</div><div className="text-xs text-slate-500 mt-1">Windows·macOS·Linux 에이전트와 미승인 AI 실행 현황</div></div>
            <div className="grid grid-cols-3 gap-4">
              {[['등록 에이전트',agents.summary?.agents||0,'text-blue-400'],['온라인',agents.summary?.online||0,'text-emerald-400'],['미해결 Shadow AI',(agents.events||[]).filter((e:any)=>!e.resolved).length,'text-red-400']].map(([label,value,color]:any)=><div key={label} className="bg-slate-900 border border-slate-800 rounded-lg p-4"><div className="text-xs text-slate-400">{label}</div><div className={`text-2xl font-bold mt-1 ${color}`}>{value}</div></div>)}
            </div>
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4"><div className="mb-1 text-sm font-semibold">Windows Agent 등록 요청 및 최근 이력</div><div className="mb-3 text-[11px] text-slate-500">대기 요청은 화면 상단에도 알림으로 표시되며, 승인 후에도 24시간 동안 이력이 남습니다.</div><div className="space-y-2">{(agents.enrollments||[]).length===0?<div className="text-xs text-slate-600">최근 등록 요청 없음</div>:(agents.enrollments||[]).map((e:any)=><div key={e.id} className={`flex flex-wrap items-center gap-3 rounded border p-3 text-xs ${e.status==='pending'?'border-blue-400 bg-blue-500/10':e.status==='claimed'?'border-emerald-500/30 bg-emerald-500/5':'border-slate-700 bg-slate-800/40'}`}><span className="font-semibold text-blue-300">{e.hostname}</span><span>{e.username}</span><span className="text-slate-500">{e.remote_ip} · {e.os_version}</span><span className={`rounded px-2 py-1 font-bold ${e.status==='pending'?'bg-blue-500/20 text-blue-200':e.status==='claimed'?'bg-emerald-500/15 text-emerald-300':e.status==='approved'?'bg-yellow-500/15 text-yellow-300':e.status==='rejected'?'bg-red-500/15 text-red-300':'bg-slate-700 text-slate-300'}`}>{e.status==='pending'?'승인 대기':e.status==='claimed'?'승인·키 수령 완료':e.status==='approved'?'승인됨·PC 수령 대기':e.status==='rejected'?'거부됨':e.status}</span><span className="ml-auto text-slate-500">{formatDistanceToNow(new Date(e.created_at),{addSuffix:true,locale:ko})}</span>{e.status==='pending'&&<><button onClick={()=>decideEnrollment(e.id,'approve')} className="rounded border border-emerald-500/40 bg-emerald-500/10 px-3 py-2 font-bold text-emerald-300">승인</button><button onClick={()=>decideEnrollment(e.id,'reject')} className="rounded border border-red-500/40 bg-red-500/10 px-3 py-2 font-bold text-red-300">거부</button></>}</div>)}</div></div>
            <div className="rounded-lg border border-slate-800 bg-slate-900 p-4">
              <div className="mb-3 flex flex-wrap items-center gap-2">
                <div><div className="text-sm font-semibold">Client 목록</div><div className="text-xs text-slate-500">전체 {allAgentRows.length}대 · 검색 결과 {filteredAgentRows.length}대 {compactAgentView?'· 대규모 표 보기 자동 적용':'· 카드 보기'}</div></div>
                <input value={agentSearch} onChange={e=>setAgentSearch(e.target.value)} placeholder="PC명·사용자·OS·AI 검색" className="ml-auto min-h-10 min-w-64 rounded border border-slate-700 bg-slate-800 px-3 text-xs"/>
                <select value={agentStatus} onChange={e=>setAgentStatus(e.target.value as typeof agentStatus)} className="min-h-10 rounded border border-slate-700 bg-slate-800 px-3 text-xs"><option value="all">전체 상태</option><option value="online">온라인</option><option value="offline">오프라인</option></select>
                <select value={agentPageSize} onChange={e=>setAgentPageSize(Number(e.target.value))} className="min-h-10 rounded border border-slate-700 bg-slate-800 px-3 text-xs"><option value="25">25개씩</option><option value="50">50개씩</option><option value="100">100개씩</option></select>
              </div>
              {pagedAgentRows.length===0?<div className="rounded border border-slate-700 p-6 text-center text-xs text-slate-500">조건에 맞는 Client가 없습니다.</div>:compactAgentView?<div className="overflow-x-auto"><table className="w-full min-w-[900px] text-left text-xs"><thead><tr className="border-b border-slate-700"><th className="px-2 py-3">상태</th><th className="px-2 py-3">Client / 사용자</th><th className="px-2 py-3">운영체제</th><th className="px-2 py-3">Agent</th><th className="px-2 py-3">감지 AI</th><th className="px-2 py-3 text-right">마지막 통신</th></tr></thead><tbody>{pagedAgentRows.map((agent:any)=>{const online=Date.now()-new Date(agent.last_seen).getTime()<300000;const detected=(agent.installed_tools||[]);return <tr key={agent.hostname} className="border-b border-slate-800 hover:bg-slate-800"><td className="px-2 py-3"><span className={`inline-flex items-center gap-2 font-bold ${online?'text-emerald-400':'text-slate-500'}`}><span className={`h-2 w-2 rounded-full ${online?'bg-emerald-400':'bg-slate-600'}`}/>{online?'온라인':'오프라인'}</span></td><td className="px-2 py-3"><div className="font-bold">{agent.hostname}</div><div className="text-slate-500">{agent.username||'-'}</div></td><td className="px-2 py-3">{agent.os} {agent.os_version}<div className="text-slate-500">{agent.arch}</div></td><td className="px-2 py-3">{agent.agent_version||'-'}</td><td className="px-2 py-3"><div className="flex max-w-md flex-wrap gap-1">{detected.length?detected.slice(0,6).map((tool:string)=>{const running=(agent.running_tools||[]).includes(tool);const approved=(agent.approved_tools||[]).includes(tool);return <button key={tool} disabled={currentUser?.role==='auditor'||currentUser?.role==='viewer'} onClick={()=>toggleApprovedTool(agent,tool)} className={`rounded border px-2 py-1 ${running&&!approved?'border-red-500 text-red-300':approved?'border-emerald-500/40 text-emerald-300':'border-yellow-500/40 text-yellow-300'}`}>{tool}{running?' ●':''}{approved?' ✓':''}</button>}):<span className="text-slate-500">없음</span>}{detected.length>6&&<span className="px-2 py-1 text-slate-500">+{detected.length-6}</span>}</div></td><td className="px-2 py-3 text-right text-slate-500">{formatDistanceToNow(new Date(agent.last_seen),{addSuffix:true,locale:ko})}</td></tr>})}</tbody></table></div>:<div className="space-y-3">{pagedAgentRows.map((agent:any)=>{const online=Date.now()-new Date(agent.last_seen).getTime()<300000;return <div key={agent.hostname} className="rounded-lg border border-slate-800 bg-slate-900 p-4"><div className="flex items-center gap-3"><span className={`h-2 w-2 rounded-full ${online?'bg-emerald-400':'bg-slate-600'}`}/><span className="font-semibold">{agent.hostname}</span><span className="text-xs text-slate-500">{agent.os} {agent.os_version} · {agent.arch} · Agent {agent.agent_version}</span><span className="ml-auto text-xs text-slate-500">{formatDistanceToNow(new Date(agent.last_seen),{addSuffix:true,locale:ko})}</span></div><div className="mt-3 flex flex-wrap gap-2">{(agents.knownTools||[]).map((tool:string)=>{const installed=(agent.installed_tools||[]).includes(tool);const running=(agent.running_tools||[]).includes(tool);const approved=(agent.approved_tools||[]).includes(tool);return <button key={tool} disabled={!installed||currentUser?.role==='auditor'||currentUser?.role==='viewer'} onClick={()=>toggleApprovedTool(agent,tool)} className={`rounded border px-2 py-1 text-[10px] ${running&&!approved?'border-red-500 bg-red-500/10 text-red-300':approved&&installed?'border-emerald-500/30 text-emerald-300':installed?'border-yellow-500/30 text-yellow-300':'border-slate-800 text-slate-700'}`}>{tool}{running?' ●':''}{approved?' ✓':''}</button>})}</div></div>})}</div>}
              <div className="mt-4 flex items-center justify-between text-xs"><span className="text-slate-500">{filteredAgentRows.length?`${(safeAgentPage-1)*agentPageSize+1}–${Math.min(safeAgentPage*agentPageSize,filteredAgentRows.length)} / ${filteredAgentRows.length}`:'0 / 0'}</span><div className="flex items-center gap-2"><button disabled={safeAgentPage<=1} onClick={()=>setAgentPage(p=>Math.max(1,p-1))} className="min-h-9 rounded border border-slate-700 px-3 disabled:opacity-30">이전</button><span className="min-w-20 text-center">{safeAgentPage} / {agentPageCount}</span><button disabled={safeAgentPage>=agentPageCount} onClick={()=>setAgentPage(p=>Math.min(agentPageCount,p+1))} className="min-h-9 rounded border border-slate-700 px-3 disabled:opacity-30">다음</button></div></div>
            </div>
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4"><div className="text-sm font-semibold mb-1">Shadow AI 이벤트</div><div className="mb-3 text-xs text-slate-500">이벤트를 선택하면 발생 의미·원인·권장 조치를 확인할 수 있습니다.</div><div className="space-y-2">{(agents.events||[]).length===0?<div className="text-xs text-slate-600">탐지된 이벤트 없음</div>:(agents.events||[]).map((e:any)=><details key={e.id} className={`group rounded border p-3 text-xs ${e.resolved?'border-slate-800 opacity-60':e.action_state==='blocked'?'border-orange-500/40 bg-orange-500/5':'border-red-500/30 bg-red-500/5'}`}><summary className="grid cursor-pointer list-none gap-2 lg:grid-cols-[110px_220px_210px_140px_1fr_150px] lg:items-center"><span className={`rounded px-2 py-1 text-center font-black ${e.action_state==='blocked'?'bg-orange-500/20 text-orange-300':e.action_state==='detected'?'bg-red-500/20 text-red-300':'bg-blue-500/20 text-blue-300'}`}>{e.action_state==='blocked'?'차단 완료':e.action_state==='detected'?'확인 필요':'정보'}</span><span className="font-bold text-red-400">{e.event_label||e.event_type}</span><span>{e.hostname} / {e.username}</span><span className="font-bold text-yellow-300">{e.tool}</span><span className="truncate text-slate-400">{e.detail||'상세 정보 없음'}</span><span className="text-right text-slate-500">{format(new Date(e.created_at),'yyyy-MM-dd HH:mm:ss')} ▾</span></summary><div className="mt-3 grid gap-3 border-t border-slate-700 pt-3 lg:grid-cols-3"><div className="rounded border border-slate-700 bg-slate-800 p-3"><div className="mb-1 font-black">발생 의미</div><div className="text-slate-300">{e.meaning}</div></div><div className="rounded border border-slate-700 bg-slate-800 p-3"><div className="mb-1 font-black">가능한 원인</div><div className="text-slate-300">{e.cause}</div></div><div className="rounded border border-blue-500/40 bg-blue-500/5 p-3"><div className="mb-1 font-black text-blue-300">권장 조치</div><div className="text-slate-300">{e.recommendation}</div></div></div><div className="mt-3 grid gap-2 rounded border-2 border-blue-500/50 p-4"><div><span className="font-black text-blue-300">발생 위치: </span><span>{e.occurrence}</span></div><div><span className="font-black text-blue-300">현재 조치: </span><span>{e.current_action}</span></div><div><span className="font-black text-blue-300">처리 방법: </span><span>{e.resolution}</span></div><div className="mt-2 flex flex-wrap gap-2"><button onClick={()=>{setAgentSearch(e.hostname||"" );setAgentStatus("all");setAgentPage(1);window.scrollTo({top:0,behavior:"smooth"})}} className="min-h-10 rounded border border-blue-500/50 px-4 font-bold text-blue-300">해당 Client 승인 설정 보기</button><button onClick={()=>openControl("blocks")} className="min-h-10 rounded border border-orange-500/50 px-4 font-bold text-orange-300">차단 관리 열기</button></div></div>{e.encoding_warning&&<div className="mt-2 rounded border border-yellow-500/40 p-2 text-yellow-300">표시 보정: {e.encoding_warning}</div>}<div className="mt-3 flex items-center justify-between"><span className="text-slate-500">원본 코드: {e.event_type}</span>{!e.resolved&&<button onClick={()=>resolveShadowEvent(e.id)} className="min-h-9 rounded border border-emerald-500/40 px-4 font-bold text-emerald-400">확인 후 해결 처리</button>}</div></details>)}</div></div>
          </div>
        )}

        {/* 주간 보고서 */}
        {tab === 'reports' && reports?.preview && (()=>{const r=reports.preview;return <div className="space-y-6">
          <div className="flex items-end justify-between"><div><div className="text-xl font-semibold">주간 운영·보안 보고서</div><div className="text-xs text-slate-500 mt-1">{r.periodStart} ~ {r.periodEnd} · 실시간 미리보기</div></div><button onClick={saveWeeklyReport} className="rounded border border-emerald-500/40 bg-emerald-500/10 px-4 py-2 text-xs text-emerald-300">초안 저장</button></div>
          <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">{[['실행',r.usage.executions,'text-blue-400'],['사용자',r.usage.users,'text-emerald-400'],['세션',r.sessions.total,'text-purple-400'],['Shadow AI',r.shadow.unresolved,'text-red-400'],['비용','$'+Number(r.usage.cost_usd).toFixed(2),'text-yellow-400']].map(([l,v,c]:any)=><div key={l} className="bg-slate-900 border border-slate-800 rounded-lg p-4"><div className="text-xs text-slate-400">{l}</div><div className={`text-2xl font-bold mt-1 ${c}`}>{v}</div></div>)}</div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6"><div className="bg-slate-900 border border-slate-800 rounded-lg p-4"><div className="text-sm font-semibold mb-3">보안 알림</div>{r.alerts.length===0?<div className="text-xs text-slate-500">이번 주 알림 없음</div>:r.alerts.map((a:any)=><div key={a.severity} className="flex justify-between border-b border-slate-800 py-2 text-xs"><span style={{color:SEV_COLOR[a.severity]}}>{a.severity}</span><span>{a.count}건 · 미해결 {a.unresolved}건</span></div>)}</div><div className="bg-slate-900 border border-slate-800 rounded-lg p-4"><div className="text-sm font-semibold mb-3">권장 조치</div>{r.recommendations.map((x:string,i:number)=><div key={i} className="border-b border-slate-800 py-2 text-xs text-slate-300">{i+1}. {x}</div>)}</div></div>
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-4"><div className="text-sm font-semibold mb-3">저장된 보고서</div>{(reports.reports||[]).length===0?<div className="text-xs text-slate-500">저장된 초안 없음</div>:(reports.reports||[]).map((x:any)=><div key={x.id} className="flex justify-between border-b border-slate-800 py-2 text-xs"><span>{x.title}</span><span className="text-slate-500">{x.delivery_status} · {format(new Date(x.created_at),'yyyy-MM-dd HH:mm')}</span></div>)}</div>
        </div>})()}

        {/* 세션 활동 */}
        {tab === 'sessions' && sessions && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                <div className="text-xs text-slate-400 mb-3">Top 사용자</div>
                {(sessions.topUsers ?? []).map((u: any, i: number) => (
                  <div key={i} className="flex justify-between text-xs py-1.5 border-b border-slate-800">
                    <span>{u.username}</span>
                    <span className="text-slate-400">{u.session_count}세션 / {Math.round((u.avg_duration ?? 0) / 60)}분 평균</span>
                  </div>
                ))}
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                <div className="text-xs text-slate-400 mb-3">Top 서버</div>
                {(sessions.topServers ?? []).map((s: any, i: number) => (
                  <div key={i} className="flex justify-between text-xs py-1.5 border-b border-slate-800">
                    <span className="text-blue-400">{s.hostname}</span>
                    <span className="text-slate-400">{s.session_count}세션 / {s.user_count}명</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
              <div className="text-xs text-slate-400 mb-3">세션 상세 로그</div>
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="text-slate-500 border-b border-slate-800">
                      <th className="text-left py-2 pr-4">시작</th>
                      <th className="text-left py-2 pr-4">서버</th>
                      <th className="text-left py-2 pr-4">사용자</th>
                      <th className="text-left py-2 pr-4">도구</th>
                      <th className="text-left py-2 pr-4">경로</th>
                      <th className="text-left py-2 pr-4">소요</th>
                      <th className="text-left py-2">변경</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(sessions.sessions ?? []).map((s: any, i: number) => (
                      <tr key={i} className="border-b border-slate-800/50 hover:bg-slate-800/30">
                        <td className="py-2 pr-4 text-emerald-400">{format(new Date(s.started_at), 'MM/dd HH:mm')}</td>
                        <td className="py-2 pr-4 text-blue-400">{s.hostname}</td>
                        <td className="py-2 pr-4">{s.username}</td>
                        <td className="py-2 pr-4" style={{ color: TOOL_COLOR[s.tool] ?? '#94a3b8' }}>{s.tool}</td>
                        <td className="py-2 pr-4 text-slate-400 max-w-[200px] truncate">{s.work_dir}</td>
                        <td className="py-2 pr-4 text-slate-400">{s.duration_sec ? `${Math.round(s.duration_sec / 60)}분` : '-'}</td>
                        <td className="py-2 text-slate-400">{s.files_changed || '-'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* 보안 알림 */}
        {tab === 'alerts' && alerts && (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-2 rounded-xl border border-slate-600 bg-slate-800 p-3 shadow-lg"><span className="mr-1 text-sm font-bold text-white">심각도 필터</span>{(['ALL','CRITICAL','HIGH','MED','LOW'] as const).map(sev=><button key={sev} onClick={()=>setAlertSeverityFilter(sev)} aria-pressed={alertSeverityFilter===sev} className={`min-h-10 rounded-lg border-2 px-4 text-sm font-extrabold tracking-wide ${sev==='ALL'?(alertSeverityFilter===sev?'border-white bg-white text-slate-950':'border-slate-500 bg-slate-700 text-white hover:border-white'):(alertSeverityFilter===sev?SEV_BADGE[sev]:'border-slate-500 bg-slate-900 text-slate-200 hover:border-slate-300')}`}>{sev==='ALL'?'전체':SEV_LABEL[sev]} <span className="ml-1">{sev==='ALL'?(alerts.alerts||[]).length:(alerts.alerts||[]).filter((a:any)=>a.severity===sev).length}</span></button>)}<span className="ml-auto text-sm font-bold text-white">표시 {visibleAlerts.length}건</span></div>
            <div className="grid grid-cols-3 gap-4">
              {['HIGH', 'MED', 'LOW'].map(sev => (
                <div key={sev} className="rounded-xl border border-slate-600 bg-slate-800 p-4 shadow-md">
                  <div className={`mb-2 inline-flex rounded-md border px-3 py-1 text-sm font-black ${SEV_BADGE[sev]}`}>{SEV_LABEL[sev]}</div>
                  <div className="text-3xl font-black text-white">{alerts.summary?.[sev.toLowerCase()] ?? 0}</div>
                </div>
              ))}
            </div>
            {['admin','security'].includes(currentUser?.role)&&<div className="flex flex-wrap items-center gap-2 rounded-lg border border-slate-800 bg-slate-900 p-3"><label className="flex min-h-9 cursor-pointer items-center gap-2 rounded px-2 text-xs text-slate-300 hover:bg-slate-800"><input type="checkbox" checked={visibleAlerts.length>0&&visibleAlerts.every((a:any)=>selectedAlertIds.includes(Number(a.id)))} onChange={toggleAllAlerts} className="h-4 w-4 accent-emerald-500"/>현재 필터 전체 선택</label><span className="text-xs text-slate-500">{selectedAlertIds.length}건 선택</span><button disabled={!selectedAlertIds.length} onClick={deleteSelectedAlerts} className="ml-auto min-h-9 rounded border border-red-500/40 bg-red-500/10 px-4 text-xs font-bold text-red-300 disabled:cursor-not-allowed disabled:opacity-40">선택 삭제</button></div>}
            <div className="space-y-3 rounded-xl border border-slate-600 bg-slate-800 p-4 shadow-lg">
              {visibleAlerts.map((a: any) => (
                <div key={a.id} className={`flex items-start gap-3 rounded-lg border p-4 ${a.resolved ? 'border-slate-600 bg-slate-900/60 opacity-60' : 'border-slate-500 bg-slate-900'}`}>
                  {['admin','security'].includes(currentUser?.role)&&<input type="checkbox" aria-label={`알림 ${a.id} 선택`} checked={selectedAlertIds.includes(Number(a.id))} onChange={()=>toggleAlertSelection(Number(a.id))} className="mt-0.5 h-4 w-4 shrink-0 accent-emerald-500"/>}
                  <div className="w-2 h-2 rounded-full mt-1 flex-shrink-0" style={{ background: SEV_COLOR[a.severity] }} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`rounded-md border px-2.5 py-1 text-xs font-black ${SEV_BADGE[a.severity]||'border-slate-300 bg-slate-200 text-slate-950'}`}>{SEV_LABEL[a.severity]||a.severity}</span>
                      <span className="rounded bg-slate-700 px-2 py-1 text-xs font-bold text-white">위험도 {a.risk_score ?? 0}점</span>
                      <span className="text-sm font-bold text-white">{a.alert_type}</span>
                      <span className="text-xs text-slate-300">{a.hostname} / {a.username}</span>
                      <span className="ml-auto text-xs text-slate-300">{formatDistanceToNow(new Date(a.created_at), { addSuffix: true, locale: ko })}</span>
                    </div>
                    <div className="text-sm leading-6 text-slate-100">{a.detail}</div>
                    {a.risk_reason && <div className="mt-1 text-xs text-slate-300">점수 근거: {a.risk_reason}</div>}
                    {a.auto_action === 'pause_requested' && <div className="mt-1 text-[10px] text-yellow-400">자동 조치: 세션 일시정지 및 관리자 승인 요청</div>}
                  </div>
                  {!a.resolved && (
                    <button onClick={() => resolveAlert(a.id)} className="text-xs text-emerald-400 hover:text-emerald-300">해결</button>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 에이전트 제어 */}
        {tab === 'control' && (
          <div className="space-y-4">
            {formMsg && <div className="bg-slate-800 border border-slate-700 rounded px-4 py-2 text-sm">{formMsg}</div>}

            <div className="dashboard-nav flex flex-wrap gap-2 rounded-xl border border-slate-800 bg-slate-900/60 p-2">
              {([
                { key: 'blocks', label: '🚫 차단 관리' },
                { key: 'policies', label: '📋 사용 정책' },
                { key: 'approvals', label: `✅ 승인 큐${pendingApprovals > 0 ? ` (${pendingApprovals})` : ''}` },
                { key: 'active', label: '🔴 활성 세션' },
              ] as { key: ControlTab; label: string }[]).map(({ key, label }) => (
                <button key={key} onClick={() => setControlTab(key)} aria-pressed={controlTab === key}
                  className={`min-h-11 rounded-lg border px-4 py-2 text-xs font-bold transition-all ${controlTab === key ? 'border-emerald-400 bg-emerald-500/20 text-emerald-200 shadow-[inset_0_-3px_0_#34d399]' : 'border-transparent text-slate-300 hover:border-slate-600 hover:bg-slate-800 hover:text-white'}`}>
                  {label}
                </button>
              ))}
            </div>

            {/* 차단 관리 */}
            {controlTab === 'blocks' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                  <div className="text-xs text-slate-400 mb-3">새 차단 등록</div>
                  <div className="space-y-2">
                    <input placeholder="서버명 (비우면 전체 *)" value={blockForm.hostname}
                      onChange={e => setBlockForm(f => ({ ...f, hostname: e.target.value }))}
                      className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500" />
                    <input placeholder="사용자명 (비우면 전체 *)" value={blockForm.username}
                      onChange={e => setBlockForm(f => ({ ...f, username: e.target.value }))}
                      className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500" />
                    <div className="rounded-lg border border-slate-700 bg-slate-800 p-2">
                      <input placeholder="AI 이름 검색 (예: Copilot, ChatGPT, Gemini)" value={blockToolSearch}
                        onChange={e=>setBlockToolSearch(e.target.value)} className="w-full rounded border border-slate-600 bg-slate-900 px-3 py-2 text-xs text-white placeholder-slate-500 focus:border-emerald-500 focus:outline-none" />
                      <div className="mt-2 max-h-48 space-y-1 overflow-y-auto">
                        <button onClick={()=>{setBlockForm(f=>({...f,tool:'*'}));setBlockToolSearch('전체 AI')}} className={`w-full rounded px-3 py-2 text-left text-xs ${blockForm.tool==='*'?'bg-red-500/20 text-red-200':'hover:bg-slate-700'}`}>전체 AI 도구 차단</button>
                        {filteredAiCatalog.map((tool:any)=><button key={tool.key} onClick={()=>{setBlockForm(f=>({...f,tool:tool.key}));setBlockToolSearch(tool.name)}} className={`w-full rounded px-3 py-2 text-left text-xs ${blockForm.tool===tool.key?'bg-emerald-500/20 text-emerald-200':'text-slate-300 hover:bg-slate-700'}`}><span className="font-bold">{tool.name}</span><span className="ml-2 text-slate-500">{tool.key}</span></button>)}
                        {filteredAiCatalog.length===0&&<div className="px-2 py-3 text-xs text-yellow-300">검색 결과가 없습니다. 아래에서 사용자 정의 AI를 등록하세요.</div>}
                      </div>
                      <div className="mt-2 text-[11px] text-emerald-300">선택됨: {blockForm.tool}</div>
                    </div>
                    <details className="rounded-lg border border-slate-700 bg-slate-800 p-3">
                      <summary className="text-xs font-bold text-blue-300">목록에 없는 AI 직접 등록</summary>
                      <div className="mt-3 grid grid-cols-2 gap-2">
                        <input placeholder="식별자 (예: new-ai)" value={customAiForm.key} onChange={e=>setCustomAiForm(f=>({...f,key:e.target.value}))} className="rounded border border-slate-600 bg-slate-900 px-2 py-2 text-xs" />
                        <input placeholder="표시 이름" value={customAiForm.name} onChange={e=>setCustomAiForm(f=>({...f,name:e.target.value}))} className="rounded border border-slate-600 bg-slate-900 px-2 py-2 text-xs" />
                        <input placeholder="프로세스명 (선택)" value={customAiForm.process} onChange={e=>setCustomAiForm(f=>({...f,process:e.target.value}))} className="rounded border border-slate-600 bg-slate-900 px-2 py-2 text-xs" />
                        <input placeholder="도메인 (선택)" value={customAiForm.domain} onChange={e=>setCustomAiForm(f=>({...f,domain:e.target.value}))} className="rounded border border-slate-600 bg-slate-900 px-2 py-2 text-xs" />
                      </div>
                      <button onClick={addCustomAi} className="mt-2 w-full rounded border border-blue-500/40 bg-blue-500/15 px-3 py-2 text-xs font-bold text-blue-300">AI 식별 규칙 추가</button>
                    </details>
                    <input placeholder="차단 사유" value={blockForm.reason}
                      onChange={e => setBlockForm(f => ({ ...f, reason: e.target.value }))}
                      className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500" />
                    <button onClick={addBlock}
                      className="w-full bg-red-500/20 hover:bg-red-500/30 border border-red-500/40 text-red-400 rounded px-3 py-2 text-xs transition-colors">
                      차단 등록
                    </button>
                  </div>
                </div>
                <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                  <div className="text-xs text-slate-400 mb-3">현재 차단 목록</div>
                  {(controls?.blocks ?? []).length === 0 ? (
                    <div className="text-xs text-slate-600">등록된 차단 없음</div>
                  ) : (
                    <div className="space-y-2">
                      {controls.blocks.map((b: any) => (
                        <div key={b.id} className="flex items-center gap-2 text-xs p-2 bg-slate-800 rounded">
                          <div className="flex-1">
                            <span className="text-red-400">{b.hostname || '*'}</span>
                            <span className="text-slate-500 mx-1">/</span>
                            <span className="text-white">{b.username || '*'}</span>
                            <span className="text-slate-500 mx-1">/</span>
                            <span style={{ color: TOOL_COLOR[b.tool] ?? '#94a3b8' }}>{b.tool}</span>
                            {b.reason && <div className="text-slate-500 mt-0.5">{b.reason}</div>}
                          </div>
                          <button onClick={() => removeBlock(b.id)} className="text-slate-500 hover:text-red-400">✕</button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* 정책 설정 */}
            {controlTab === 'policies' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                  <div className="text-xs text-slate-400 mb-3">새 정책 등록</div>
                  <div className="space-y-2">
                    <select value={policyForm.template_key} onChange={e => selectTemplate(e.target.value)} className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white">
                      <option value="">정책 템플릿 선택</option>
                      {(governance?.templates || []).map((t: any) => <option key={t.template_key} value={t.template_key}>{t.name} — {t.description}</option>)}
                    </select>
                    <input placeholder="서버명 (비우면 전체 *)" value={policyForm.hostname}
                      onChange={e => setPolicyForm(f => ({ ...f, hostname: e.target.value }))}
                      className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500" />
                    <input placeholder="사용자명 (비우면 전체 *)" value={policyForm.username}
                      onChange={e => setPolicyForm(f => ({ ...f, username: e.target.value }))}
                      className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500" />
                    <select value={policyForm.tool} onChange={e => setPolicyForm(f => ({ ...f, tool: e.target.value }))} className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white"><option value="*">전체 AI 도구</option>{aiCatalog.map((tool:any)=><option key={tool.key} value={tool.key}>{tool.name} ({tool.key})</option>)}</select>
                    <div className="flex gap-2">
                      <div className="flex-1">
                        <div className="text-xs text-slate-500 mb-1">허용 시작 (시)</div>
                        <input type="number" min={0} max={23} value={policyForm.allow_start}
                          onChange={e => setPolicyForm(f => ({ ...f, allow_start: parseInt(e.target.value) }))}
                          className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500" />
                      </div>
                      <div className="flex-1">
                        <div className="text-xs text-slate-500 mb-1">허용 종료 (시)</div>
                        <input type="number" min={0} max={23} value={policyForm.allow_end}
                          onChange={e => setPolicyForm(f => ({ ...f, allow_end: parseInt(e.target.value) }))}
                          className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500" />
                      </div>
                      <div className="flex-1">
                        <div className="text-xs text-slate-500 mb-1">시간당 최대</div>
                        <input type="number" min={0} value={policyForm.max_per_hour}
                          onChange={e => setPolicyForm(f => ({ ...f, max_per_hour: parseInt(e.target.value) }))}
                          className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500" />
                      </div>
                    </div>
                    <div className="text-xs text-slate-500">* 시간당 최대 = 0 이면 승인 필수 모드</div>
                    <button onClick={addPolicy}
                      className="w-full bg-blue-500/20 hover:bg-blue-500/30 border border-blue-500/40 text-blue-400 rounded px-3 py-2 text-xs transition-colors">
                      정책 등록
                    </button>
                  </div>
                </div>
                <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                  <div className="text-xs text-slate-400 mb-3">현재 정책 목록</div>
                  {(controls?.policies ?? []).length === 0 ? (
                    <div className="text-xs text-slate-600">등록된 정책 없음</div>
                  ) : (
                    <div className="space-y-2">
                      {controls.policies.map((p: any) => (
                        <div key={p.id} className="flex items-start gap-2 text-xs p-2 bg-slate-800 rounded">
                          <div className="flex-1">
                            <span className="text-blue-400">{p.hostname || '*'}</span>
                            <span className="text-slate-500 mx-1">/</span>
                            <span className="text-white">{p.username || '*'}</span>
                            <div className="text-slate-500 mt-0.5">
                              허용: {p.allow_start}시~{p.allow_end}시 | 시간당 최대 {p.max_per_hour === 0 ? '승인필수' : `${p.max_per_hour}회`}
                            </div>
                          </div>
                          <button onClick={() => removePolicy(p.id)} className="text-slate-500 hover:text-red-400">✕</button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* 승인 큐 */}
            {controlTab === 'approvals' && (
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                <div className="text-xs text-slate-400 mb-3">승인 대기 목록</div>
                {(controls?.approvals ?? []).length === 0 ? (
                  <div className="text-xs text-slate-600">대기 중인 승인 요청 없음</div>
                ) : (
                  <div className="space-y-3">
                    {controls.approvals.map((a: any) => (
                      <div key={a.id} className={`p-3 rounded border ${a.status === 'pending' ? 'border-yellow-500/40 bg-yellow-500/5' : a.status === 'approved' ? 'border-emerald-500/30 opacity-50' : 'border-red-500/30 opacity-50'}`}>
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1 space-y-1 text-xs">
                            <div className="flex gap-3">
                              <span className="text-yellow-400">{a.status === 'pending' ? '⏳ 대기' : a.status === 'approved' ? '✅ 승인됨' : '❌ 거부됨'}</span>
                              {a.token?.startsWith('risk-pause:') && <span className="rounded bg-red-500/15 px-1.5 py-0.5 text-[10px] text-red-300">위험 세션 자동정지</span>}
                              <span className="text-blue-400">{a.hostname}</span>
                              <span>{a.username}</span>
                              <span style={{ color: TOOL_COLOR[a.tool] ?? '#94a3b8' }}>{a.tool}</span>
                            </div>
                            <div className="text-slate-400">{a.work_dir}</div>
                            {a.args && <div className="text-slate-500">args: {a.args}</div>}
                            <div className="text-slate-600">{formatDistanceToNow(new Date(a.created_at), { addSuffix: true, locale: ko })}</div>
                          </div>
                          {a.status === 'pending' && (
                            <div className="flex gap-2 flex-shrink-0">
                              <button onClick={() => reviewApproval(a.id, true)}
                                className="bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-400 rounded px-3 py-1 text-xs">승인</button>
                              <button onClick={() => reviewApproval(a.id, false)}
                                className="bg-red-500/20 hover:bg-red-500/30 border border-red-500/40 text-red-400 rounded px-3 py-1 text-xs">거부</button>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* 활성 세션 */}
            {controlTab === 'active' && (
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                <div className="text-xs text-slate-400 mb-3">활성 세션 (강제종료 가능)</div>
                {(controls?.activeSessions ?? []).length === 0 ? (
                  <div className="text-xs text-slate-600">현재 활성 세션 없음</div>
                ) : (
                  <div className="space-y-2">
                    {controls.activeSessions.map((s: any) => (
                      <div key={s.session_id} className="flex items-center gap-3 p-3 bg-slate-800 rounded border border-slate-700">
                        <div className={`w-2 h-2 rounded-full flex-shrink-0 ${s.state === 'paused' ? 'bg-yellow-400' : 'bg-green-400 animate-pulse'}`} />
                        <div className="flex-1 text-xs space-y-0.5">
                          <div className="flex gap-3">
                            <span className="text-blue-400">{s.hostname}</span>
                            <span>{s.username}</span>
                            <span style={{ color: TOOL_COLOR[s.tool] ?? '#94a3b8' }}>{s.tool}</span>
                            <span className="text-slate-500">PID: {s.pid}</span>
                            <span className={s.state === 'paused' ? 'text-yellow-400' : 'text-emerald-400'}>{s.state === 'paused' ? '일시정지' : '실행 중'}</span>
                          </div>
                          <div className="text-slate-500">{s.work_dir || '-'}</div>
                          <div className="text-slate-600">{formatDistanceToNow(new Date(s.started_at), { addSuffix: true, locale: ko })} 시작</div>
                        </div>
                        <button onClick={() => toggleSession(s.session_id, s.state === 'paused')}
                          className="bg-yellow-500/20 hover:bg-yellow-500/30 border border-yellow-500/40 text-yellow-300 rounded px-3 py-1.5 text-xs flex-shrink-0">
                          {s.state === 'paused' ? '▶ 재개' : '⏸ 일시정지'}
                        </button>
                        <button
                          onClick={() => { if (confirm(`${s.hostname}/${s.username} 세션을 강제 종료하시겠습니까?`)) killSession(s.session_id); }}
                          className="bg-red-500/20 hover:bg-red-500/30 border border-red-500/40 text-red-400 rounded px-3 py-1.5 text-xs flex-shrink-0">
                          🛑 강제종료
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* 거버넌스 */}
      {tab === 'governance' && governance && (
        <div className="space-y-6 p-6">
          <div><div className="text-xl font-semibold">거버넌스 설정</div><div className="text-xs text-slate-500 mt-1">정책 템플릿, 역할 및 데이터 보호 상태</div></div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
              <div className="text-sm font-semibold mb-3">정책 템플릿</div>
              <div className="space-y-2">{(governance.templates || []).map((t: any) => <button key={t.template_key} onClick={() => { selectTemplate(t.template_key); openControl('policies'); }} className="w-full rounded-lg border border-slate-700 p-3 text-left hover:bg-slate-800"><span className="text-xs text-white">{t.name}</span><span className="float-right text-[10px] text-slate-500">{t.risk_level}</span><span className="block text-[10px] text-slate-500 mt-1">{t.description}</span></button>)}</div>
            </div>
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
              <div className="text-sm font-semibold mb-3">데이터 보호</div>
              {(governance.settings || []).map((s: any) => <div key={s.setting_key} className="border-b border-slate-800 py-3 text-xs"><span className="text-slate-300">{s.setting_key === 'retention' ? '로그 보존정책' : '민감정보 보호'}</span><pre className="text-[10px] text-emerald-400 mt-1 whitespace-pre-wrap">{JSON.stringify(s.setting_value)}</pre></div>)}
              <div className="mt-3 text-[10px] text-slate-500">보존기간 자동삭제는 기본 비활성화되어 있으며 별도 승인 후 활성화합니다.</div>
            </div>
          </div>
          {currentUser?.platform_admin && <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4"><div className="text-sm font-semibold mb-3">고객사 관리</div><div className="space-y-2">{(tenants?.tenants||[]).map((t:any)=><div key={t.id} className="flex justify-between border-b border-slate-800 py-2 text-xs"><span>{t.name}<span className="ml-2 text-slate-500">{t.code}</span></span><span className="text-slate-500">관리자 {t.admins} · 에이전트 {t.agents}</span></div>)}</div></div>
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4"><div className="text-sm font-semibold mb-3">새 고객사 생성</div><div className="grid grid-cols-2 gap-2">{[['고객사명','name','text'],['고객사 코드','code','text'],['관리자 아이디','admin_username','text'],['관리자 이메일','admin_email','email'],['초기 비밀번호','admin_password','password']].map(([label,key,type])=><input key={key} type={type} placeholder={label} value={(tenantForm as any)[key]} onChange={e=>setTenantForm(f=>({...f,[key]:e.target.value}))} className="bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs"/>)}<button onClick={createTenant} className="col-span-2 rounded border border-emerald-500/40 bg-emerald-500/10 py-2 text-xs text-emerald-300">고객사 생성</button></div>{newAgentKey&&<div className="mt-3 rounded border border-yellow-500/30 bg-yellow-500/5 p-3 text-xs"><div className="text-yellow-300">에이전트 키는 지금 한 번만 표시됩니다.</div><code className="mt-2 block break-all text-slate-300">{newAgentKey}</code></div>}</div>
          </div>}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
            <div className="text-sm font-semibold mb-3">관리자 역할</div>
            {(governance.users || []).map((u: any) => <div key={u.id} className="flex items-center gap-3 border-b border-slate-800 py-2 text-xs"><span className="flex-1">{u.username}<span className="ml-2 text-slate-500">{u.email}</span></span><select value={u.role} disabled={currentUser?.role !== 'admin'} onChange={e => updateRole(u.id, e.target.value)} className="bg-slate-800 border border-slate-700 rounded px-2 py-1"><option value="admin">관리자</option><option value="security">보안담당자</option><option value="auditor">감사자</option><option value="viewer">열람자</option></select></div>)}
          </div>
        </div>
      )}

      {tab==='catalog'&&catalog&&(
        <div className="space-y-6 p-6">
          <div><div className="text-xl font-semibold">AI 중앙 카탈로그 관리</div><div className="mt-1 text-xs text-slate-500">신규 AI를 검토하고 승인된 탐지 규칙을 모든 Agent에 재설치 없이 배포합니다.</div></div>
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">{[['기본 카탈로그',catalog.builtIn?.length||0,'text-blue-400'],['검토 중',(catalog.entries||[]).filter((x:any)=>x.status==='review').length,'text-yellow-400'],['활성 사용자 규칙',(catalog.entries||[]).filter((x:any)=>x.status==='active').length,'text-emerald-400'],['종료·오탐',(catalog.entries||[]).filter((x:any)=>['retired','false_positive'].includes(x.status)).length,'text-slate-400']].map(([l,v,c]:any)=><div key={l} className="rounded-lg border border-slate-800 bg-slate-900 p-4"><div className="text-xs text-slate-400">{l}</div><div className={`mt-1 text-2xl font-bold ${c}`}>{v}</div></div>)}</div>
          <div className="grid gap-5 lg:grid-cols-2">
            <div className="rounded-lg border border-slate-800 bg-slate-900 p-4"><div className="mb-3 text-sm font-bold">신규 AI 후보 등록</div><div className="grid grid-cols-2 gap-2"><input placeholder="식별자" value={catalogForm.key} onChange={e=>setCatalogForm(f=>({...f,key:e.target.value}))} className="rounded border border-slate-700 bg-slate-800 px-3 py-2 text-xs"/><input placeholder="표시 이름" value={catalogForm.name} onChange={e=>setCatalogForm(f=>({...f,name:e.target.value}))} className="rounded border border-slate-700 bg-slate-800 px-3 py-2 text-xs"/><input placeholder="프로세스명" value={catalogForm.process} onChange={e=>setCatalogForm(f=>({...f,process:e.target.value}))} className="rounded border border-slate-700 bg-slate-800 px-3 py-2 text-xs"/><input placeholder="도메인" value={catalogForm.domain} onChange={e=>setCatalogForm(f=>({...f,domain:e.target.value}))} className="rounded border border-slate-700 bg-slate-800 px-3 py-2 text-xs"/><input placeholder="검토 메모" value={catalogForm.notes} onChange={e=>setCatalogForm(f=>({...f,notes:e.target.value}))} className="col-span-2 rounded border border-slate-700 bg-slate-800 px-3 py-2 text-xs"/></div><button onClick={addCatalogCandidate} className="mt-3 w-full rounded border border-blue-500/40 bg-blue-500/15 py-2 text-xs font-bold text-blue-300">검토함에 추가</button></div>
            <div className="rounded-lg border border-slate-800 bg-slate-900 p-4"><div className="mb-2 text-sm font-bold">운영 주기</div><div className="space-y-2 text-xs text-slate-300"><div>검토 주기: <span className="text-emerald-300">{catalog.schedule?.reviewCycle==='monthly'?'매월':'분기'}</span></div><div>신규 후보 자동 수집: {catalog.schedule?.candidateAutoCollect?'사용':'중지'}</div><div>승인 규칙 Agent 자동 배포: {catalog.schedule?.autoDeployApproved?'사용':'중지'}</div><div className="rounded border border-blue-500/20 bg-blue-500/5 p-3 text-blue-200">서비스가 사라져도 삭제하지 않고 ‘서비스 종료’로 전환해 과거 감사 기록을 보존합니다.</div></div></div>
          </div>
          <div className="rounded-lg border border-slate-800 bg-slate-900 p-4"><div className="mb-3 text-sm font-bold">검토·사용자 정의 목록</div>{(catalog.entries||[]).length===0?<div className="text-xs text-slate-500">등록된 후보가 없습니다.</div>:<div className="space-y-2">{catalog.entries.map((x:any)=><div key={x.id} className="flex flex-wrap items-center gap-2 rounded border border-slate-800 bg-slate-950/40 p-3 text-xs"><span className="font-bold text-white">{x.display_name}</span><span className="text-slate-500">{x.tool_key}</span><span className={`rounded px-2 py-1 ${x.status==='active'?'bg-emerald-500/15 text-emerald-300':x.status==='review'?'bg-yellow-500/15 text-yellow-300':'bg-slate-700 text-slate-300'}`}>{x.status==='active'?'활성':x.status==='review'?'검토 중':x.status==='retired'?'서비스 종료':'오탐'}</span><span className="flex-1 text-slate-500">{(x.processes||[]).filter(Boolean).join(', ')} {(x.domains||[]).filter(Boolean).join(', ')}</span>{x.status!=='active'&&<button onClick={()=>setCatalogStatus(x.id,'active')} className="rounded border border-emerald-500/40 px-2 py-1 text-emerald-300">승인·배포</button>}{x.status!=='retired'&&<button onClick={()=>setCatalogStatus(x.id,'retired')} className="rounded border border-slate-600 px-2 py-1 text-slate-300">서비스 종료</button>}{x.status!=='false_positive'&&<button onClick={()=>setCatalogStatus(x.id,'false_positive')} className="rounded border border-red-500/30 px-2 py-1 text-red-300">오탐</button>}</div>)}</div>}</div>
          <div className="rounded-lg border border-slate-800 bg-slate-900 p-4"><div className="mb-3 text-sm font-bold">최근 변경 이력</div><div className="space-y-1">{(catalog.history||[]).slice(0,20).map((h:any,i:number)=><div key={i} className="flex justify-between border-b border-slate-800 py-2 text-xs"><span><span className="text-blue-300">{h.tool_key}</span> · {h.action}</span><span className="text-slate-500">{h.changed_by} · {format(new Date(h.changed_at),'yyyy-MM-dd HH:mm')}</span></div>)}</div></div>
        </div>
      )}

      {tab === 'license' && license && (
        <div className="space-y-6 p-6">
          <div><div className="text-xl font-semibold">라이선스 관리</div><div className="mt-1 text-xs text-slate-500">15일 무료 체험과 월 구독 상태를 관리합니다.</div></div>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="rounded-lg border border-slate-600 bg-slate-800 p-4"><div className="text-sm font-bold text-slate-200">상태</div><div className={`mt-2 text-2xl font-black ${license.active?'text-emerald-400':'text-red-400'}`}>{license.active?'사용 가능':'기능 잠김'}</div><div className="mt-1 text-xs text-slate-300">{license.license_type==='trial'?'15일 무료 체험':license.plan}</div></div>
            <div className="rounded-lg border border-slate-600 bg-slate-800 p-4"><div className="text-sm font-bold text-slate-200">남은 기간</div><div className="mt-2 text-2xl font-black text-white">{license.days_remaining}일</div><div className="mt-1 text-xs text-slate-300">만료 {new Date(license.expires_at).toLocaleString('ko-KR')}</div></div>
            <div className="rounded-lg border border-slate-600 bg-slate-800 p-4"><div className="text-sm font-bold text-slate-200">관리 대상</div><div className="mt-2 text-2xl font-black text-white">{license.agent_count} / {license.agent_limit}대</div><div className="mt-1 text-xs text-slate-300">OS와 관계없이 장비 ID 기준</div></div>
          </div>
          <div className="rounded-lg border border-slate-800 bg-slate-900 p-4">
            <div className="text-sm font-semibold">구독 키 인증</div><div className="mt-1 text-[10px] text-slate-500">설치 ID: {license.installation_id}</div>
            <textarea value={licenseKey} onChange={e=>setLicenseKey(e.target.value)} placeholder="EINSTECH에서 발급받은 라이선스 키를 입력하세요" className="mt-4 h-24 w-full rounded border border-slate-700 bg-slate-800 p-3 text-xs" />
            {licenseMsg&&<div className="mt-2 text-xs">{licenseMsg}</div>}
            <button disabled={currentUser?.role!=='admin'||!licenseKey.trim()} onClick={activateLicense} className="mt-3 rounded border border-emerald-500/40 bg-emerald-500/10 px-4 py-2 text-xs text-emerald-300 disabled:opacity-40">라이선스 인증</button>
          </div>
        </div>
      )}

      {/* 사용자 프로필 모달 */}
      {showAppearance&&<div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70" onClick={()=>setShowAppearance(false)}><div className="w-full max-w-md rounded-xl border border-slate-500 bg-slate-900 p-6 shadow-2xl" onClick={e=>e.stopPropagation()}><div className="mb-5 flex items-start justify-between"><div><div className="text-lg font-bold text-white">화면 색상 설정</div><div className="mt-1 text-xs text-slate-300">서로 확실히 다른 화면을 선택합니다. 이 브라우저에 저장됩니다.</div></div><button onClick={()=>setShowAppearance(false)} className="text-xl text-slate-200">✕</button></div><div className="grid grid-cols-2 gap-3">{([{key:'light',name:'라이트',desc:'부드러운 회색 · 진한 글자',preview:'bg-slate-100 text-slate-950 border-slate-500'},{key:'navy',name:'네이비',desc:'파란 배경 · 밝은 글자',preview:'bg-blue-950 text-blue-50 border-blue-500'},{key:'dark',name:'다크',desc:'무채색 검정 · 흰 글자',preview:'bg-zinc-950 text-white border-zinc-500'},{key:'high-contrast',name:'고대비',desc:'차분한 자주 · 웜 아이보리',preview:'bg-purple-950 text-orange-50 border-amber-600'}] as const).map(x=><button key={x.key} onClick={()=>changeAppearance(x.key)} className={`min-h-28 rounded-xl border-4 p-4 text-left ${x.preview} ${appearance===x.key?'ring-4 ring-yellow-400 ring-offset-2 ring-offset-slate-900':''}`}><div className="text-base font-black">{x.name}</div><div className="mt-2 text-xs font-bold opacity-90">{x.desc}</div><div className="mt-3 flex gap-1"><span className="h-3 w-8 rounded bg-emerald-600"/><span className="h-3 w-5 rounded bg-yellow-400"/><span className="h-3 w-4 rounded bg-red-600"/></div></button>)}</div><button onClick={()=>setShowAppearance(false)} className="mt-5 w-full rounded-lg bg-emerald-600 px-4 py-3 text-sm font-bold text-white">적용 완료</button></div></div>}
      {showSettings && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50" onClick={() => setShowSettings(false)}>
          <div className="bg-slate-900 border border-slate-700 rounded-lg p-6 w-full max-w-sm" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-center mb-4">
              <div><div className="text-sm font-bold">[{currentUser?.username||'확인 중'}] Profile</div><div className="mt-1 text-[11px] text-slate-500">{currentUser?.tenant_name||''} · {currentUser?.role||''} · 로그인 아이디와 비밀번호를 변경합니다.</div></div>
              <button onClick={() => setShowSettings(false)} className="text-slate-500 hover:text-white">✕</button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-xs text-slate-400 block mb-1">현재 비밀번호 *</label>
                <input type="password" value={settingsForm.currentPassword}
                  onChange={e => setSettingsForm(f => ({ ...f, currentPassword: e.target.value }))}
                  className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500" />
              </div>
              <div>
                <label className="text-xs text-slate-400 block mb-1">새 아이디 (변경 시)</label>
                <input type="text" value={settingsForm.newUsername}
                  onChange={e => setSettingsForm(f => ({ ...f, newUsername: e.target.value }))}
                  className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500" />
              </div>
              <div>
                <label className="text-xs text-slate-400 block mb-1">새 비밀번호 (변경 시)</label>
                <input type="password" value={settingsForm.newPassword}
                  onChange={e => setSettingsForm(f => ({ ...f, newPassword: e.target.value }))}
                  className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500" />
              </div>
              <div>
                <label className="text-xs text-slate-400 block mb-1">새 비밀번호 확인</label>
                <input type="password" value={settingsForm.confirmPassword}
                  onChange={e => setSettingsForm(f => ({ ...f, confirmPassword: e.target.value }))}
                  className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500" />
              </div>
              {settingsMsg && <div className="text-xs">{settingsMsg}</div>}
              <button onClick={saveSettings}
                className="w-full bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-400 rounded py-2 text-xs transition-colors">
                프로필 변경 저장
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
