import crypto from 'crypto';
import { NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/db';
import { requireRole } from '@/lib/auth';
import { getLicenseState, verifyLicenseKey } from '@/lib/license';

export async function GET(req:NextRequest) {
  const auth=await requireRole(req,['admin','security','auditor','viewer']);
  if(auth.response)return auth.response;
  return NextResponse.json({license:await getLicenseState(auth.user!.tenantId)});
}

export async function POST(req:NextRequest) {
  const auth=await requireRole(req,['admin']);
  if(auth.response)return auth.response;
  try {
    const {key}=await req.json();
    const signed=verifyLicenseKey(String(key||''));
    const current=await getLicenseState(auth.user!.tenantId);
    if(signed.tenant_code!==auth.user!.tenantCode) return NextResponse.json({error:'다른 고객사의 라이선스입니다.'},{status:400});
    if(signed.installation_id!==current.installation_id) return NextResponse.json({error:'이 관리 서버용 라이선스가 아닙니다.'},{status:400});
    if(new Date(signed.expires_at).getTime()<=Date.now()) return NextResponse.json({error:'이미 만료된 라이선스입니다.'},{status:400});
    await pool.query(`UPDATE ai_licenses SET license_type='subscription',plan=$1,status='active',expires_at=$2,
      agent_limit=$3,license_hash=$4,last_verified_at=NOW(),updated_at=NOW() WHERE tenant_id=$5`,
      [signed.plan,signed.expires_at,Number(signed.agent_limit),crypto.createHash('sha256').update(key).digest('hex'),auth.user!.tenantId]);
    return NextResponse.json({ok:true,license:await getLicenseState(auth.user!.tenantId)});
  } catch(error) {
    return NextResponse.json({error:error instanceof Error?error.message:'라이선스 인증 실패'},{status:400});
  }
}
