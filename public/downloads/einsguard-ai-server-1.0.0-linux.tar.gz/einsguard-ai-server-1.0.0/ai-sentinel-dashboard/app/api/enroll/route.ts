import {NextRequest,NextResponse} from 'next/server';
import crypto from 'node:crypto';
import pool from '@/lib/db';
import {requireRole} from '@/lib/auth';

const hash=(value:string)=>crypto.createHash('sha256').update(value).digest('hex');
const clientIp=(req:NextRequest)=>(req.headers.get('x-forwarded-for')||'').split(',')[0].trim()||null;

export async function GET(req:NextRequest){
  const token=req.nextUrl.searchParams.get('token');
  if(token){
    if(!/^[a-f0-9]{64}$/.test(token))return NextResponse.json({error:'invalid token'},{status:400});
    const client=await pool.connect();
    try{await client.query('BEGIN');
      const {rows}=await client.query(`SELECT id,status,issued_key FROM ai_agent_enrollments WHERE request_hash=$1 AND created_at>NOW()-INTERVAL '30 minutes' FOR UPDATE`,[hash(token)]);
      if(!rows.length){await client.query('ROLLBACK');return NextResponse.json({status:'expired'},{status:404});}
      const row=rows[0];
      if(row.status==='approved'&&row.issued_key){
        await client.query(`UPDATE ai_agent_enrollments SET status='claimed',claimed_at=NOW(),issued_key=NULL WHERE id=$1`,[row.id]);
        await client.query('COMMIT');return NextResponse.json({status:'approved',agent_key:row.issued_key});
      }
      await client.query('COMMIT');return NextResponse.json({status:row.status});
    }catch(e){await client.query('ROLLBACK');throw e;}finally{client.release();}
  }
  const auth=await requireRole(req,['admin','security']);if(auth.response)return auth.response;
  const {rows}=await pool.query(`SELECT id,hostname,username,os_version,remote_ip,status,created_at,decided_at,claimed_at
    FROM ai_agent_enrollments WHERE tenant_id=$1 AND created_at>NOW()-INTERVAL '24 hours' ORDER BY created_at DESC LIMIT 100`,[auth.user!.tenantId]);
  return NextResponse.json({enrollments:rows});
}

export async function POST(req:NextRequest){
  const body=await req.json();
  if(body.action==='approve'||body.action==='reject'){
    const auth=await requireRole(req,['admin','security']);if(auth.response)return auth.response;
    if(body.action==='reject'){
      await pool.query(`UPDATE ai_agent_enrollments SET status='rejected',decided_at=NOW(),decided_by=$1 WHERE id=$2 AND tenant_id=$3 AND status='pending'`,[auth.user!.username,body.id,auth.user!.tenantId]);
      return NextResponse.json({ok:true});
    }
    const rawKey=crypto.randomBytes(32).toString('hex');
    const client=await pool.connect();
    try{await client.query('BEGIN');
      const result=await client.query(`UPDATE ai_agent_enrollments SET status='approved',issued_key=$1,decided_at=NOW(),decided_by=$2 WHERE id=$3 AND tenant_id=$4 AND status='pending' RETURNING hostname`,[rawKey,auth.user!.username,body.id,auth.user!.tenantId]);
      if(!result.rowCount){await client.query('ROLLBACK');return NextResponse.json({error:'등록 요청이 없거나 이미 처리됐습니다'},{status:409});}
      await client.query(`INSERT INTO ai_agent_keys(tenant_id,key_name,key_hash) VALUES($1,$2,$3)`,[auth.user!.tenantId,`Windows ${result.rows[0].hostname}`,hash(rawKey)]);
      await client.query('COMMIT');return NextResponse.json({ok:true});
    }catch(e){await client.query('ROLLBACK');throw e;}finally{client.release();}
  }
  const hostname=String(body.hostname||'').trim().slice(0,255);
  if(!hostname)return NextResponse.json({error:'hostname required'},{status:400});
  const tenants=await pool.query(`SELECT id FROM ai_tenants WHERE enabled=true ORDER BY id LIMIT 2`);
  if(tenants.rows.length!==1)return NextResponse.json({error:'서버에서 기본 고객사를 하나로 설정해야 합니다'},{status:409});
  const recent=await pool.query(`SELECT id FROM ai_agent_enrollments WHERE hostname=$1 AND remote_ip IS NOT DISTINCT FROM $2::inet AND status='pending' AND created_at>NOW()-INTERVAL '2 minutes'`,[hostname,clientIp(req)]);
  if(recent.rows.length)return NextResponse.json({error:'이미 승인 대기 중입니다. 잠시 후 다시 시도하세요.'},{status:429});
  const token=crypto.randomBytes(32).toString('hex');
  await pool.query(`INSERT INTO ai_agent_enrollments(tenant_id,request_hash,hostname,username,os_version,remote_ip) VALUES($1,$2,$3,$4,$5,$6::inet)`,[tenants.rows[0].id,hash(token),hostname,String(body.username||'').slice(0,150),String(body.os_version||'').slice(0,150),clientIp(req)]);
  return NextResponse.json({ok:true,token,status:'pending'});
}
