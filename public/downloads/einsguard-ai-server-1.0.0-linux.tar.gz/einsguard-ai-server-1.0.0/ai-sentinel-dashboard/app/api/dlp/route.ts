import {NextRequest,NextResponse} from 'next/server';
import pool from '@/lib/db';
import {requireRole} from '@/lib/auth';
import {verifyAgentKey} from '@/lib/agent-auth';

const allowedSeverity=new Set(['LOW','MED','HIGH','CRITICAL']);

export async function POST(req:NextRequest){
  const auth=await verifyAgentKey(req.headers.get('x-ai-sentinel-key'));
  if(!auth.configured||!auth.valid||!auth.tenantId)return NextResponse.json({error:'Unauthorized agent'},{status:401});
  const body=await req.json();
  const severity=allowedSeverity.has(String(body.severity))?String(body.severity):'HIGH';
  const hash=String(body.evidence_hash||'');
  if(!/^[a-f0-9]{64}$/i.test(hash))return NextResponse.json({error:'Invalid evidence hash'},{status:400});
  const settings=await pool.query(`SELECT setting_value FROM ai_settings WHERE tenant_id=$1 AND setting_key='dlp_policy'`,[auth.tenantId]);
  const policy=settings.rows[0]?.setting_value||{};
  const evidenceDays=Math.max(7,Math.min(3650,Number(policy.evidenceRetentionDays)||90));
  await pool.query(`UPDATE ai_dlp_events SET raw_content=NULL WHERE tenant_id=$1 AND raw_expires_at<NOW() AND raw_content IS NOT NULL`,[auth.tenantId]);
  await pool.query(`DELETE FROM ai_dlp_events WHERE tenant_id=$1 AND created_at<NOW()-($2||' days')::interval`,[auth.tenantId,evidenceDays]);
  const rawAllowed=policy.storeRawChat===true&&['chat','clipboard'].includes(String(body.channel));
  const raw=rawAllowed?String(body.raw_content||'').slice(0,50000):null;
  const rawDays=Math.max(1,Math.min(30,Number(policy.rawRetentionDays)||7));
  const inserted=await pool.query(`INSERT INTO ai_dlp_events
    (tenant_id,hostname,username,tool,channel,violation_type,severity,evidence_hash,masked_evidence,match_count,action_taken,raw_content,raw_expires_at)
    SELECT $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,CASE WHEN $12::text IS NULL THEN NULL ELSE NOW()+($13||' days')::interval END
    WHERE NOT EXISTS(SELECT 1 FROM ai_dlp_events WHERE tenant_id=$1 AND hostname=$2 AND evidence_hash=$8 AND created_at>NOW()-INTERVAL '1 hour') RETURNING id`,
    [auth.tenantId,String(body.hostname||'').slice(0,255),String(body.username||'').slice(0,150),String(body.tool||'unknown').slice(0,100),String(body.channel||'unknown').slice(0,30),String(body.violation_type||'SENSITIVE_DATA').slice(0,80),severity,hash,String(body.masked_evidence||'').slice(0,500),Math.max(1,Number(body.match_count)||1),String(body.action_taken||'alert').slice(0,50),raw,rawDays]);
  if(inserted.rowCount&&['HIGH','CRITICAL'].includes(severity)){
    await pool.query(`INSERT INTO ai_alerts(hostname,username,tool,alert_type,severity,detail,risk_score,risk_reason,auto_action,tenant_id)
      VALUES($1,$2,$3,'DLP_VIOLATION',$4,$5,$6,$7,$8,$9)`,[body.hostname,body.username,body.tool,severity,`${body.violation_type}: ${String(body.masked_evidence||'').slice(0,300)}`,severity==='CRITICAL'?100:85,'AI 입력 경로에서 민감정보 패턴 탐지',body.action_taken||'alert',auth.tenantId]);
  }
  return NextResponse.json({ok:true,deduplicated:inserted.rowCount===0,raw_stored:Boolean(raw)});
}

export async function GET(req:NextRequest){
  const auth=await requireRole(req,['admin','security','auditor']);if(auth.response)return auth.response;
  const id=req.nextUrl.searchParams.get('id');
  if(id){
    if(!['admin','security'].includes(auth.user!.role))return NextResponse.json({error:'원문 감사 권한이 없습니다'},{status:403});
    const reason=String(req.nextUrl.searchParams.get('reason')||'').trim();
    if(reason.length<5)return NextResponse.json({error:'원문 열람 사유를 입력해야 합니다'},{status:400});
    const {rows}=await pool.query(`SELECT id,raw_content,raw_expires_at FROM ai_dlp_events WHERE tenant_id=$1 AND id=$2`,[auth.user!.tenantId,id]);
    await pool.query(`INSERT INTO ai_audit_access_log(tenant_id,username,action,object_type,object_id,reason,remote_ip) VALUES($1,$2,'READ_RAW_CONTENT','ai_dlp_events',$3,$4,$5::inet)`,[auth.user!.tenantId,auth.user!.username,id,reason,(req.headers.get('x-forwarded-for')||'').split(',')[0]||null]);
    if(!rows.length)return NextResponse.json({error:'사건을 찾을 수 없습니다'},{status:404});
    return NextResponse.json({id:rows[0].id,raw_content:rows[0].raw_content,raw_expires_at:rows[0].raw_expires_at});
  }
  const {rows}=await pool.query(`SELECT id,created_at,hostname,username,tool,channel,violation_type,severity,evidence_hash,masked_evidence,match_count,action_taken,raw_content IS NOT NULL raw_available
    FROM ai_dlp_events WHERE tenant_id=$1 ORDER BY created_at DESC LIMIT 200`,[auth.user!.tenantId]);
  await pool.query(`INSERT INTO ai_audit_access_log(tenant_id,username,action,object_type,reason,remote_ip) VALUES($1,$2,'LIST_DLP_EVENTS','ai_dlp_events','DLP 사건 목록 열람',$3::inet)`,[auth.user!.tenantId,auth.user!.username,(req.headers.get('x-forwarded-for')||'').split(',')[0]||null]);
  return NextResponse.json({events:rows});
}
