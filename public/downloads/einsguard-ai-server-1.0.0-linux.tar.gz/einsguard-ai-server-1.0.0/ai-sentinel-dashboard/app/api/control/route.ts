import { NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/db';
import { requireRole } from '@/lib/auth';
import { requireActiveLicense } from '@/lib/license';
import {AI_CATALOG} from '@/lib/ai-catalog';

// GET: 차단/정책/승인/활성세션 목록 조회
export async function GET(req:NextRequest) {
  const auth=await requireRole(req,['admin','security','auditor','viewer']);if(auth.response)return auth.response;const tenantId=auth.user!.tenantId;
  const [blocks, policies, approvals, activeSessions, customCatalog, managedCatalog] = await Promise.all([
    pool.query(`SELECT * FROM ai_blocks WHERE enabled = TRUE AND tenant_id=$1 ORDER BY created_at DESC`,[tenantId]),
    pool.query(`SELECT * FROM ai_policies WHERE enabled = TRUE AND tenant_id=$1 ORDER BY id DESC`,[tenantId]),
    pool.query(`SELECT * FROM ai_approvals WHERE tenant_id=$1 ORDER BY created_at DESC LIMIT 50`,[tenantId]),
    pool.query(`
      SELECT c.session_id, c.hostname, c.username, c.tool, c.pid,
             s.work_dir, s.started_at,
             CASE WHEN EXISTS (
               SELECT 1 FROM ai_commands p
               WHERE p.session_id = c.session_id AND p.tenant_id=c.tenant_id AND p.command = 'pause' AND p.status = 'executed'
                 AND NOT EXISTS (
                   SELECT 1 FROM ai_commands r
                   WHERE r.session_id = c.session_id AND r.tenant_id=c.tenant_id AND r.command IN ('resume', 'kill')
                     AND r.created_at > p.created_at
                 )
             ) THEN 'paused' ELSE 'running' END AS state
      FROM ai_commands c
      LEFT JOIN ai_sessions s ON s.session_id = c.session_id AND s.tenant_id=c.tenant_id
      WHERE c.command = 'registered' AND c.status = 'active' AND c.tenant_id=$1
        AND s.ended_at IS NULL
      ORDER BY c.created_at DESC
    `,[tenantId]),
    pool.query(`SELECT setting_value FROM ai_settings WHERE tenant_id=$1 AND setting_key='custom_ai_catalog'`,[tenantId]),
    pool.query(`SELECT tool_key key,display_name name FROM ai_catalog_entries WHERE tenant_id=$1 AND status IN('active','review')`,[tenantId]),
  ]);

  return NextResponse.json({
    blocks: blocks.rows,
    policies: policies.rows,
    approvals: approvals.rows,
    activeSessions: activeSessions.rows,
    catalog: [...AI_CATALOG.map(x=>({key:x.key,name:x.name})),...managedCatalog.rows],
    customCatalog: customCatalog.rows[0]?.setting_value||[],
  });
}

// POST: 제어 액션 실행
export async function POST(req: NextRequest) {
  const auth = await requireRole(req, ['admin', 'security']);
  if (auth.response) return auth.response;
  const licenseCheck=await requireActiveLicense(auth.user!.tenantId);if(licenseCheck.response)return licenseCheck.response;
  const body = await req.json();
  const { action } = body;
  const tenantId=auth.user!.tenantId;

  try {
    if(action==='add_custom_ai'){
      const key=String(body.key||'').trim().toLowerCase().replace(/[^a-z0-9._-]/g,'-').slice(0,80);
      const name=String(body.name||key).trim().slice(0,120);
      const process=String(body.process||'').trim().toLowerCase().slice(0,150);
      const domain=String(body.domain||'').trim().toLowerCase().replace(/^https?:\/\//,'').split('/')[0].slice(0,253);
      if(!key||(!process&&!domain))return NextResponse.json({ok:false,error:'식별자와 프로세스명 또는 도메인이 필요합니다'},{status:400});
      await pool.query(`INSERT INTO ai_settings(setting_key,setting_value,updated_by,tenant_id) VALUES('custom_ai_catalog',jsonb_build_array(jsonb_build_object('key',$1,'name',$2,'processes',jsonb_build_array($3),'commands',jsonb_build_array($3),'domains',jsonb_build_array($4))),$5,$6)
        ON CONFLICT(tenant_id,setting_key) DO UPDATE SET setting_value=(SELECT jsonb_agg(DISTINCT x) FROM jsonb_array_elements(ai_settings.setting_value||EXCLUDED.setting_value)x),updated_at=NOW(),updated_by=EXCLUDED.updated_by`,[key,name,process,domain,auth.user!.username,tenantId]);
      return NextResponse.json({ok:true,key});
    }
    if (action === 'add_block') {
      const { hostname, username, tool, reason } = body;
      await pool.query(
        `INSERT INTO ai_blocks (hostname, username, tool, reason, enabled, tenant_id)
         VALUES ($1, $2, $3, $4, TRUE,$5)`,
        [hostname || '*', username || '*', tool || '*', reason || '',tenantId]
      );
      return NextResponse.json({ ok: true });
    }

    if (action === 'remove_block') {
      await pool.query(`UPDATE ai_blocks SET enabled = FALSE WHERE id = $1 AND tenant_id=$2`, [body.id,tenantId]);
      return NextResponse.json({ ok: true });
    }

    if (action === 'add_policy') {
      const { hostname, username, allow_start, allow_end, max_per_hour, template_key, tool } = body;
      await pool.query(
        `INSERT INTO ai_policies (hostname, username, allow_start, allow_end, max_per_hour, enabled, template_key, tool,tenant_id)
         VALUES ($1, $2, $3, $4, $5, TRUE, $6, $7,$8)
         ON CONFLICT DO NOTHING`,
        [hostname || '*', username || '*', allow_start ?? 0, allow_end ?? 23, max_per_hour ?? 10, template_key || null, tool || '*',tenantId]
      );
      return NextResponse.json({ ok: true });
    }

    if (action === 'remove_policy') {
      await pool.query(`UPDATE ai_policies SET enabled = FALSE WHERE id = $1 AND tenant_id=$2`, [body.id,tenantId]);
      return NextResponse.json({ ok: true });
    }

    if (action === 'kill_session') {
      const { session_id } = body;
      // session_id에 해당하는 활성 command 레코드 조회해서 hostname/username/tool 가져오기
      const { rows } = await pool.query(
        `SELECT hostname, username, tool, pid FROM ai_commands
         WHERE session_id = $1 AND tenant_id=$2 AND command = 'registered' AND status = 'active' LIMIT 1`,
        [session_id,tenantId]
      );
      if (rows.length === 0) return NextResponse.json({ ok: false, error: '세션을 찾을 수 없습니다' });

      const { hostname, username, tool, pid } = rows[0];
      await pool.query(
        `INSERT INTO ai_commands (session_id, hostname, username, tool, pid, command, status,tenant_id)
         VALUES ($1, $2, $3, $4, $5, 'kill', 'pending',$6)`,
        [session_id, hostname, username, tool, pid,tenantId]
      );
      return NextResponse.json({ ok: true });
    }

    if (action === 'pause_session' || action === 'resume_session') {
      const command = action === 'pause_session' ? 'pause' : 'resume';
      const { rows } = await pool.query(
        `SELECT hostname, username, tool, pid FROM ai_commands
         WHERE session_id = $1 AND tenant_id=$2 AND command = 'registered' AND status = 'active' LIMIT 1`,
        [body.session_id,tenantId]
      );
      if (rows.length === 0) return NextResponse.json({ ok: false, error: '활성 세션을 찾을 수 없습니다' });
      const { hostname, username, tool, pid } = rows[0];
      await pool.query(
        `INSERT INTO ai_commands (session_id, hostname, username, tool, pid, command, status,tenant_id)
         VALUES ($1, $2, $3, $4, $5, $6, 'pending',$7)`,
        [body.session_id, hostname, username, tool, pid, command,tenantId]
      );
      return NextResponse.json({ ok: true });
    }

    if (action === 'review_approval') {
      const { id, approved } = body;
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        const { rows } = await client.query(
          `UPDATE ai_approvals SET status = $1, reviewed_by = 'admin', reviewed_at = NOW()
           WHERE id = $2 AND tenant_id=$3 AND status = 'pending'
           RETURNING session_id, hostname, username, tool, token`,
          [approved ? 'approved' : 'rejected', id,tenantId]
        );
        if (rows.length === 0) {
          await client.query('ROLLBACK');
          return NextResponse.json({ ok: false, error: '이미 처리되었거나 존재하지 않는 승인 요청입니다' }, { status: 409 });
        }
        const approval = rows[0];
        if (approval.token?.startsWith('risk-pause:')) {
          const command = approved ? 'resume' : 'kill';
          const { rows: registered } = await client.query(
            `SELECT pid FROM ai_commands WHERE session_id=$1 AND tenant_id=$2 AND command='registered' ORDER BY created_at DESC LIMIT 1`,
            [approval.session_id,tenantId]
          );
          await client.query(
            `INSERT INTO ai_commands (session_id, hostname, username, tool, pid, command, status,tenant_id)
             VALUES ($1,$2,$3,$4,$5,$6,'pending',$7)`,
            [approval.session_id, approval.hostname, approval.username, approval.tool, registered[0]?.pid ?? null, command,tenantId]
          );
        }
        await client.query('COMMIT');
      } catch (error) {
        await client.query('ROLLBACK');
        throw error;
      } finally {
        client.release();
      }
      return NextResponse.json({ ok: true });
    }

    return NextResponse.json({ error: 'unknown action' }, { status: 400 });
  } catch (err: any) {
    return NextResponse.json({ ok: false, error: err.message }, { status: 500 });
  }
}
