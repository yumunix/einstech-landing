import { NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/db';
import { requireRole } from '@/lib/auth';
import { verifyAgentKey } from '@/lib/agent-auth';
import { requireActiveLicense } from '@/lib/license';
import {AI_CATALOG} from '@/lib/ai-catalog';

const KNOWN_TOOLS = AI_CATALOG.map(x=>x.key);
const SHADOW_EVENT_LABELS:Record<string,string>={
  UNAPPROVED_AI_RUNNING:'승인되지 않은 AI 실행 감지',
  UNAPPROVED_AI_BLOCKED:'승인되지 않은 AI 앱·CLI 실행 차단',
  UNAPPROVED_WEB_AI_BLOCKED:'승인되지 않은 웹 AI 접속 차단',
  AI_WINDOW_DETECTED:'AI 앱 창 실행 감지',
  WINDOWS_SECURITY_EVENT:'Windows 보안 이벤트',
};
const SHADOW_EVENT_GUIDES:Record<string,{meaning:string;cause:string;recommendation:string;action_state:'detected'|'blocked'|'information'}>={
  UNAPPROVED_AI_RUNNING:{meaning:'승인 목록에 없는 AI가 현재 실행되었습니다.',cause:'사용자가 미승인 앱·CLI를 실행했거나 승인 정책에 해당 AI가 등록되지 않았습니다.',recommendation:'업무상 필요한 AI인지 사용자에게 확인한 뒤 승인 목록에 추가하거나, 불필요하면 프로세스를 종료하고 차단 정책을 적용하십시오.',action_state:'detected'},
  UNAPPROVED_AI_BLOCKED:{meaning:'승인되지 않은 AI 앱 또는 CLI 실행을 Agent가 차단했습니다.',cause:'실행한 AI가 허용 목록에 없거나 해당 사용자·PC에 차단 정책이 적용되어 있습니다.',recommendation:'오탐 여부와 업무 필요성을 확인하십시오. 정상 업무라면 승인 목록에 추가하고, 비인가 사용이면 현재 차단 상태를 유지하십시오.',action_state:'blocked'},
  UNAPPROVED_WEB_AI_BLOCKED:{meaning:'브라우저에서 승인되지 않은 AI 서비스 접속을 Agent가 차단했습니다.',cause:'접속 도메인이 AI 카탈로그에 탐지되었지만 사용자 또는 PC의 허용 목록에는 없습니다.',recommendation:'접속 목적과 서비스의 데이터 처리 정책을 확인하십시오. 업무 승인 시 웹 AI를 허용 목록에 추가하고, 미승인 서비스라면 차단을 유지하십시오.',action_state:'blocked'},
  AI_WINDOW_DETECTED:{meaning:'AI 앱 또는 AI 웹 화면의 창 제목이 감지되었습니다.',cause:'AI 앱 실행, 브라우저 탭, 또는 WebView 기반 AI 화면이 열렸습니다.',recommendation:'프로세스·창 제목·네트워크 기록을 함께 확인하십시오. 허용된 사용이면 승인 처리하고, 미승인 사용이면 세션을 종료하거나 차단 정책을 적용하십시오.',action_state:'detected'},
  WINDOWS_SECURITY_EVENT:{meaning:'Windows Agent가 보안 관련 상태를 보고했습니다.',cause:'Agent 정책, 실행 상태 또는 Windows 감시 과정에서 확인이 필요한 이벤트가 발생했습니다.',recommendation:'상세 내용과 해당 PC의 Agent 진단 로그를 확인한 뒤 정책 오류인지 실제 위반인지 판별하십시오.',action_state:'information'},
};

function normalizeShadowEvent(event:any){
  const label=SHADOW_EVENT_LABELS[event.event_type]||String(event.event_type||'알 수 없는 이벤트');
  const guide=SHADOW_EVENT_GUIDES[event.event_type]||{meaning:'분류되지 않은 AI 보안 이벤트입니다.',cause:'Agent가 보낸 이벤트 코드가 현재 서버 카탈로그에 등록되지 않았습니다.',recommendation:'이벤트 코드와 상세 로그를 확인하고 AI 이벤트 카탈로그에 새 유형을 등록하십시오.',action_state:'information'};
  const corrupt=typeof event.detail==='string'&&/\?{2,}/.test(event.detail);
  const isCli=event.event_type==='UNAPPROVED_AI_BLOCKED'||event.event_type==='UNAPPROVED_AI_RUNNING';
  const occurrence=`${event.hostname||'알 수 없는 Client'} PC에서 ${event.username||'알 수 없는 사용자'} 계정이 ${event.tool||'알 수 없는 AI'}${isCli?' 앱 또는 CLI를 실행':' 서비스를 사용'}할 때 Windows Agent가 발생시켰습니다.`;
  const currentAction=guide.action_state==='blocked'?`Agent가 ${event.tool||'해당 AI'} 실행 또는 접속을 이미 차단했습니다. 현재 추가 차단 작업은 필요하지 않습니다.`:'Agent가 사용 사실을 탐지했으며 자동 차단 여부는 적용된 정책에 따라 다릅니다.';
  const resolution=guide.action_state==='blocked'
    ? `업무상 필요한 사용이면 [AI 자산] → Client 목록에서 ${event.hostname||'해당 PC'}를 검색하고 ${event.tool||'해당 AI'}를 승인하십시오. 비업무 사용이면 [에이전트 제어] → [차단 관리]에서 차단 정책을 유지한 뒤 사용자에게 사유를 안내하고 이 사건을 해결 처리하십시오.`
    : `먼저 [AI 자산] → Client 목록에서 ${event.hostname||'해당 PC'}와 실행 중인 AI를 확인하십시오. 업무 승인 대상이면 ${event.tool||'해당 AI'}를 승인하고, 미승인 대상이면 [에이전트 제어] → [차단 관리]에서 차단 정책을 추가하십시오.`;
  return {...event,event_label:label,...guide,occurrence,current_action:currentAction,resolution,detail:corrupt?`${label}: ${event.tool||'알 수 없는 AI'}`:event.detail,encoding_warning:corrupt?'Agent에서 전송한 한글 상세 문구가 손상되어 이벤트 코드 기준으로 복원했습니다.':null};
}

export async function GET(req:NextRequest) {
  const auth=await requireRole(req,['admin','security','auditor','viewer']); if(auth.response)return auth.response;
  const tenantId=auth.user!.tenantId;
  const [agents, events, summary, enrollments] = await Promise.all([
    pool.query(`SELECT hostname,os,os_version,arch,agent_version,username,installed_tools,running_tools,
      approved_tools,last_ip,first_seen,last_seen FROM ai_agents WHERE tenant_id=$1 ORDER BY last_seen DESC`,[tenantId]),
    pool.query(`SELECT * FROM ai_shadow_events WHERE tenant_id=$1 ORDER BY created_at DESC LIMIT 100`,[tenantId]),
    pool.query(`SELECT COUNT(*)::int agents,
      COUNT(*) FILTER (WHERE last_seen > NOW()-INTERVAL '5 minutes')::int online,
      COUNT(*) FILTER (WHERE last_seen <= NOW()-INTERVAL '5 minutes')::int offline
      FROM ai_agents WHERE tenant_id=$1`,[tenantId]),
    pool.query(`SELECT id,hostname,username,os_version,remote_ip,status,created_at,decided_at,claimed_at
      FROM ai_agent_enrollments WHERE tenant_id=$1 AND created_at>NOW()-INTERVAL '24 hours'
      ORDER BY created_at DESC LIMIT 100`,[tenantId]),
  ]);
  return NextResponse.json({ agents: agents.rows, events: events.rows.map(normalizeShadowEvent), enrollments:enrollments.rows, summary: summary.rows[0], knownTools: KNOWN_TOOLS });
}

export async function POST(req: NextRequest) {
  const action = req.nextUrl.searchParams.get('action') || '';
  if (action === 'inventory-report') {
    const agentAuth = await verifyAgentKey(req.headers.get('x-ai-sentinel-key'));
    if (!agentAuth.configured) return NextResponse.json({ error: 'Agent authentication is not configured' }, { status: 503 });
    if (!agentAuth.valid) {
      return NextResponse.json({ error: 'Unauthorized agent' }, { status: 401 });
    }
    const tenantId=agentAuth.tenantId!;
    const licenseCheck=await requireActiveLicense(tenantId); if(licenseCheck.response)return licenseCheck.response;
    const body = await req.json();
    const installed = Array.isArray(body.installed_tools) ? body.installed_tools.filter((x: unknown) => typeof x === 'string') : [];
    const running = Array.isArray(body.running_tools) ? body.running_tools.filter((x: unknown) => typeof x === 'string') : [];
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const existing = await client.query('SELECT approved_tools,running_tools FROM ai_agents WHERE tenant_id=$1 AND hostname=$2', [tenantId,body.hostname]);
      if (!existing.rows.length) {
        const count=await client.query('SELECT COUNT(*)::int count FROM ai_agents WHERE tenant_id=$1',[tenantId]);
        if(Number(count.rows[0].count)>=licenseCheck.license.agent_limit) {
          await client.query('ROLLBACK');
          return NextResponse.json({error:'요금제의 관리 대상 수를 초과했습니다.',code:'AGENT_LIMIT_REACHED',license:licenseCheck.license},{status:402});
        }
      }
      const approved = existing.rows[0]?.approved_tools || ['claude','codex'];
      const previouslyRunning:string[]=Array.isArray(existing.rows[0]?.running_tools)?existing.rows[0].running_tools:[];
      await client.query(`INSERT INTO ai_agents(hostname,os,os_version,arch,agent_version,username,installed_tools,running_tools,last_ip,tenant_id)
        VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
        ON CONFLICT(tenant_id,hostname) DO UPDATE SET os=EXCLUDED.os,os_version=EXCLUDED.os_version,arch=EXCLUDED.arch,
        agent_version=EXCLUDED.agent_version,username=EXCLUDED.username,installed_tools=EXCLUDED.installed_tools,
        running_tools=EXCLUDED.running_tools,last_ip=EXCLUDED.last_ip,last_seen=NOW()`,
        [body.hostname,body.os||'unknown',body.os_version||'',body.arch||'',body.agent_version||'unknown',body.username||'',JSON.stringify(installed),JSON.stringify(running),req.headers.get('x-forwarded-for')?.split(',')[0]||null,tenantId]);
      for (const tool of running.filter((tool:string)=>!previouslyRunning.includes(tool))) {
        await client.query(`INSERT INTO ai_usage(logged_at,hostname,username,tool,args,tenant_id)
          VALUES(NOW(),$1,$2,$3,$4,$5)`,[body.hostname,body.username||'',tool,'앱/브라우저/CLI 실행 감지',tenantId]);
      }
      for (const tool of running.filter((tool: string) => !approved.includes(tool))) {
        await client.query(`INSERT INTO ai_shadow_events(hostname,username,tool,event_type,detail,tenant_id)
          SELECT $1::varchar,$2::varchar,$3::varchar,'UNAPPROVED_AI_RUNNING',$4::text,$5 WHERE NOT EXISTS(
            SELECT 1 FROM ai_shadow_events WHERE hostname=$1::varchar AND tool=$3::varchar AND tenant_id=$5 AND resolved=false AND created_at>NOW()-INTERVAL '1 hour')`,
          [body.hostname,body.username||'',tool,`승인되지 않은 AI 도구 실행 감지: ${tool}`,tenantId]);
      }
      await client.query('COMMIT');
      return NextResponse.json({ ok:true, approved_tools:approved });
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally { client.release(); }
  }
  const auth = await requireRole(req,['admin','security']);
  if (auth.response) return auth.response;
  const licenseCheck=await requireActiveLicense(auth.user!.tenantId); if(licenseCheck.response)return licenseCheck.response;
  const body = await req.json();
  if (body.action === 'set_approved_tools') {
    const tools = Array.isArray(body.tools) ? body.tools.filter((x: unknown) => typeof x === 'string') : [];
    await pool.query('UPDATE ai_agents SET approved_tools=$1 WHERE hostname=$2 AND tenant_id=$3',[JSON.stringify(tools),body.hostname,auth.user!.tenantId]);
    return NextResponse.json({ok:true});
  }
  if (body.action === 'resolve_event') {
    await pool.query('UPDATE ai_shadow_events SET resolved=true,resolved_at=NOW(),resolved_by=$1 WHERE id=$2 AND tenant_id=$3',[auth.user?.username,body.id,auth.user!.tenantId]);
    return NextResponse.json({ok:true});
  }
  return NextResponse.json({error:'unknown action'},{status:400});
}
