# AI Sentinel 설치 시작

지원 서버는 Linux x86_64/arm64이며 Docker Compose 또는 Podman Compose가 필요합니다.

```bash
tar -xzf ai-sentinel-0.2.0-trial-linux.tar.gz
cd ai-sentinel-0.2.0-trial-linux
./ai-sentinel-dashboard/release/preflight.sh
./ai-sentinel-dashboard/release/install.sh
```

설치 프로그램은 DB 비밀번호, 세션 비밀값, 에이전트 키를 자동 생성하고 `.env`를
권한 600으로 저장합니다. 관리자 비밀번호는 12자 이상이어야 합니다.

운영 명령:

```bash
./ai-sentinel-dashboard/release/status.sh
./ai-sentinel-dashboard/release/backup.sh
./ai-sentinel-dashboard/release/update.sh
```

삭제 명령은 기본적으로 데이터 볼륨을 보존합니다. `--purge DELETE-ALL-DATA`는
백업 없이는 복구할 수 없으므로 운영 승인 후에만 사용하십시오.

상세 내용은 `ai-sentinel-dashboard/deploy/README.md`와
`ai-sentinel-dashboard/release/RELEASE_NOTES.md`를 확인하십시오.
