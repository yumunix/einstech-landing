#!/bin/sh
set -eu
[ "${1:-}" = --confirm ] && [ -n "${2:-}" ] || { printf '사용법: %s --confirm 백업디렉터리\n' "$0" >&2; exit 2; }
backup=$2
[ -f "$backup/database.dump" ] || { printf 'database.dump가 없습니다.\n' >&2; exit 1; }
(cd "$backup" && sha256sum -c SHA256SUMS)
. "$(dirname -- "$0")/common.sh"
compose stop dashboard parser
compose exec -T postgres sh -c 'PGPASSWORD="$POSTGRES_PASSWORD" pg_restore -U "$POSTGRES_USER" -d "$POSTGRES_DB" --clean --if-exists' < "$backup/database.dump"
compose start dashboard parser
printf '복원 완료. 대시보드를 확인하십시오.\n'
