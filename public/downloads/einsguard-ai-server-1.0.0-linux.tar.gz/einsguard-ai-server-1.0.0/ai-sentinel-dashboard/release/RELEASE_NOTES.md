# AI Sentinel 0.2.0-trial

- Linux Docker/Podman 온프레미스 관리 서버
- Linux 및 macOS AI 도구 인벤토리·세션·정책·위험 제어
- 고객사별 데이터와 에이전트 키 격리
- 15일 무료 체험, 관리 대상 5대
- Ed25519 서명 월 구독 키와 설치 ID 결합
- 만료 시 핵심 기능 잠금 및 기존 데이터 조회 유지
- PostgreSQL, 대시보드, 파서, TCP/UDP syslog 수집기 포함

Windows 에이전트는 이번 공개 후보 버전에서 제외되며 후속 검증 후 추가합니다.
