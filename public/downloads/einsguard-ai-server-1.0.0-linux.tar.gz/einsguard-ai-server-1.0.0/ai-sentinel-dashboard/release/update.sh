#!/bin/sh
set -eu
. "$(dirname -- "$0")/common.sh"
"$(dirname -- "$0")/backup.sh"
compose build --pull
compose up -d
compose ps
printf '업데이트 완료.\n'
