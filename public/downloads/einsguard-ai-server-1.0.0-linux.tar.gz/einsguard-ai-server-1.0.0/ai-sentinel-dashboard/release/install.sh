#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
./ai-sentinel-dashboard/release/preflight.sh
DEPLOY="$ROOT/ai-sentinel-dashboard/deploy"

if [ ! -f "$DEPLOY/.env" ]; then
  admin_password=${AI_SENTINEL_ADMIN_PASSWORD:-}
  if [ -z "$admin_password" ]; then
    printf '초기 관리자 비밀번호: ' >&2
    stty -echo; IFS= read -r admin_password; stty echo; printf '\n' >&2
  fi
  [ "${#admin_password}" -ge 12 ] || { printf '관리자 비밀번호는 12자 이상이어야 합니다.\n' >&2; exit 1; }
  printf '%s' "$admin_password" | grep -Eq '^[A-Za-z0-9._!@#%+=-]+$' || { printf '비밀번호에는 영문, 숫자 및 ._!@#%%+=-만 사용할 수 있습니다.\n' >&2; exit 1; }
  db_password=$(openssl rand -hex 24)
  session_secret=$(openssl rand -hex 32)
  agent_key=$(openssl rand -hex 32)
  sed -e "s|CHANGE_TO_A_LONG_RANDOM_PASSWORD|$db_password|" \
      -e "s|CHANGE_TO_AT_LEAST_32_RANDOM_CHARACTERS|$session_secret|" \
      -e "s|CHANGE_TO_A_STRONG_ADMIN_PASSWORD|$admin_password|" \
      -e "s|CHANGE_TO_A_64_HEX_CHARACTER_KEY|$agent_key|" \
      -e "s|INIT_TENANT_NAME=EINSTECH|INIT_TENANT_NAME=${AI_SENTINEL_TENANT_NAME:-EINSTECH}|" \
      -e "s|INIT_TENANT_CODE=einstech|INIT_TENANT_CODE=${AI_SENTINEL_TENANT_CODE:-einstech}|" \
      "$DEPLOY/.env.example" > "$DEPLOY/.env"
  chmod 600 "$DEPLOY/.env"
fi
. "$ROOT/ai-sentinel-dashboard/release/common.sh"
compose up -d --build
compose ps
dashboard_port=$(sed -n 's/^DASHBOARD_PORT=//p' "$DEPLOY/.env")
printf '\n설치 완료: http://서버주소:%s\n' "${dashboard_port:-3100}"
printf '에이전트 키는 %s/.env의 INIT_AGENT_KEY에 저장되어 있습니다.\n' "$DEPLOY"
