# AI Sentinel 온프레미스 설치

## 기본 라이선스

- 최초 설치 시 15일 무료 체험이 자동 시작됩니다.
- 체험판은 운영체제와 관계없이 관리 대상 5대까지 등록할 수 있습니다.
- 관리 화면의 `라이선스` 메뉴에서 설치 ID, 남은 기간, 등록 장비 수를 확인합니다.
- 구독 키는 해당 설치 ID에 결합되어 다른 관리 서버에서 재사용할 수 없습니다.
- 만료 시 수집·분석·제어·설정 변경·보고서 생성은 잠기고 기존 데이터 조회와
  라이선스 갱신은 계속 사용할 수 있습니다.

## 설치

필수 조건은 Linux 서버, 4GB 이상 메모리, 10GB 이상 여유 공간과 Docker Compose
또는 Podman Compose입니다. 패키지 최상위 디렉터리에서 먼저 다음을 실행하십시오.

```bash
./ai-sentinel-dashboard/release/preflight.sh
./ai-sentinel-dashboard/release/install.sh
```

### 수동 설치

1. `.env.example`을 `.env`로 복사하고 `CHANGE_` 값을 모두 강한 난수로 변경합니다.
2. `docker compose --env-file .env up -d --build`를 실행합니다.
3. `http://서버주소:3100`에서 초기 관리자 계정으로 로그인합니다.
4. 발급한 `INIT_AGENT_KEY`를 에이전트의 `~/.config/ai-sentinel/agent.key`에 권한 600으로 저장합니다.
5. 고객사 서버의 rsyslog가 AI Sentinel 서버의 `${SYSLOG_PORT}` TCP 포트로 전달하도록 설정합니다.

데이터는 `postgres-data`, 수집 로그는 `ai-logs` 볼륨에 보존됩니다. 이메일 설정을
비워두면 외부 메일은 발송되지 않습니다. 운영 전에는 리버스 프록시에서 HTTPS를
적용하고 PostgreSQL 볼륨 백업 정책을 구성해야 합니다.
